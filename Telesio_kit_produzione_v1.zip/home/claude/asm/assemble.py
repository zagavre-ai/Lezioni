import re,subprocess,sys,os
FF='ffmpeg'
SRC='/mnt/user-data/uploads/anteprima_per_Claude.mp4'
AUD='/mnt/user-data/attachments/6f0ad356-eb6e-5e82-bb5b-b32ac31c8256/0743a8c5-audio_per_Claude.m4a'
GAIN=open('/home/claude/lez1/work/gain.txt').read().strip()
SL='/home/claude/gen/png/%s'
O='/home/claude/assets/out/';O2='/home/claude/assets/out2/'
W='/home/claude/asm/w';os.makedirs(W,exist_ok=True)
DUR=3631.6
def sec(t):
    p=t.split(':');return float(p[0])*3600+float(p[1])*60+float(p[2])
rows=[]
for l in open('/home/claude/lez1/tempi.txt'):
    l=l.split('#')[0].strip()
    if not l or l.startswith('WEBCAM'):continue
    a=l.split();rows.append((sec(a[0]),a[2]))
IS={'IS00':(20,O+'IS00_roadmap.mp4',10),'IS01':(221,O+'IS01_o-a.mp4',10),'IS02':(355,O+'IS02_femenino.mp4',12),'IS03':(971,O+'IS03_plural.mp4',12),'IS04':(1624,O+'IS04_interrogativos.mp4',15),
'IS05':(2314,O+'IS05_pronombres.mp4',10),'IS06':(2330,O+'IS06_vosotros-ustedes.mp4',12),'IS07':(2960,O+'IS07_ser-tener.mp4',12),'IS08':(3239,O+'IS08_taglia-desinenza.mp4',12),'IS09':(3270,O+'IS09_tre-gruppi.mp4',12),'IS10':(3439,O+'IS10_reflexivos.mp4',10)}
VF='fps=30,scale=960:540:flags=lanczos,setsar=1,format=yuv420p'
ENC=['-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-r','30','-g','60','-threads','2']
AE=['-c:a','aac','-b:a','128k','-ar','48000','-ac','2']
def run(cmd):subprocess.run(cmd,check=True)
# IS con dissolvenza verso il bianco incorporata (480 px di larghezza non servono: scala 164x195)
def prep_is():
    for k,(t,f,d) in IS.items():
        out=f'{W}/{k}.mp4'
        if os.path.exists(out):continue
        run([FF,'-y','-loglevel','error','-i',f,'-vf',f'scale=164:196:flags=lanczos,fps=30,fade=t=in:st=0:d=0.5:color=white,fade=t=out:st={d-0.5}:d=0.5:color=white,format=yuv420p']+ENC+['-an',out])
def pieces(a,b):
    cuts=[a,b]
    for i,(t,img) in enumerate(rows):
        if a<t<b:cuts.append(t)
    for k,(t,f,d) in IS.items():
        for x in (t,t+d):
            if a<x<b:cuts.append(x)
    cuts=sorted(set(round(c,3) for c in cuts));out=[]
    for s0,e0 in zip(cuts,cuts[1:]):
        if e0-s0<0.034:continue
        mid=(s0+e0)/2;img=[im for t,im in rows if t<=mid][-1]
        ov=None
        for k,(t,f,d) in IS.items():
            if t<=mid<t+d:ov=(k,s0-t)
        out.append((s0,e0,img,ov))
    return out
def block(name,a,b):
    parts=[]
    for i,(s0,e0,img,ov) in enumerate(pieces(a,b)):
        n=int(round((e0-a)*30))-int(round((s0-a)*30))
        if n<1:continue
        o=f'{W}/{name}_{i:03d}.mp4'
        cam="[1:v]fps=30,crop=514:386:253:97,scale=166:124:flags=lanczos,hqdn3d=1.5:1.5:3:3[c]"
        fc=f"[0:v]scale=960:540,setsar=1[bg];{cam};[bg][c]overlay=755:74[v1]"
        cmd=[FF,'-y','-loglevel','error','-nostdin','-loop','1','-framerate','30','-i',SL%img,'-ss','%.3f'%s0,'-i',SRC]
        if ov:
            cmd+=['-ss','%.3f'%max(0,ov[1]),'-i',f'{W}/{ov[0]}.mp4'];fc+=";[v1][2:v]overlay=755:280,format=yuv420p[v]"
        else:fc+=";[v1]format=yuv420p[v]"
        run(cmd+['-filter_complex',fc,'-map','[v]','-frames:v',str(n),'-an']+ENC+[o]);parts.append(o)
    open(f'{W}/{name}_v.txt','w').write(''.join("file '%s'\n"%p for p in parts))
    run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',f'{W}/{name}_v.txt','-c','copy',f'{W}/{name}_v.mp4'])
    af=f"highpass=f=80,volume={GAIN}dB,alimiter=limit=0.89,aresample=48000,aformat=channel_layouts=stereo"
    run([FF,'-y','-loglevel','error','-nostdin','-ss','%.3f'%a,'-t','%.3f'%(b-a),'-i',AUD,'-af',af,'-c:a','aac','-b:a','128k','-ar','48000',f'{W}/{name}_a.m4a'])
    run([FF,'-y','-loglevel','error','-i',f'{W}/{name}_v.mp4','-i',f'{W}/{name}_a.m4a','-c','copy','-t','%.3f'%(b-a),f'{W}/{name}.mp4']);print(name,flush=True)
def clip(name,src,dur=None,still=False,fade=True,loop=None):
    out=f'{W}/{name}.mp4'
    if still:
        d=dur;pre=[FF,'-y','-loglevel','error','-nostdin','-loop','1','-framerate','30','-t',str(d),'-i',src,'-f','lavfi','-t',str(d),'-i','anullsrc=r=48000:cl=stereo']
        vf=VF+(f',fade=t=in:st=0:d=0.4:color=white,fade=t=out:st={d-0.4}:d=0.4:color=white' if fade else '')
        run(pre+['-vf',vf,'-map','0:v','-map','1:a','-shortest']+ENC+AE+[out]);return out
    pr=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',src],capture_output=True,text=True);d=float(pr.stdout)
    hasaud='audio' in subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type','-of','csv=p=0',src],capture_output=True,text=True).stdout
    vf=VF+(f',fade=t=in:st=0:d=0.4:color=white,fade=t=out:st={d-0.4}:d=0.4:color=white' if fade else '')
    if hasaud:
        run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-vf',vf,'-af',f'aresample=48000,aformat=channel_layouts=stereo,afade=t=in:st=0:d=0.3,afade=t=out:st={d-0.3}:d=0.3']+ENC+AE+[out])
    else:
        run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-f','lavfi','-t',str(d),'-i','anullsrc=r=48000:cl=stereo','-vf',vf,'-map','0:v','-map','1:a','-shortest']+ENC+AE+[out])
    return out
if __name__=='__main__':
    step=sys.argv[1]
    if step=='prep':
        prep_is()
        for n in range(1,8):clip(f'QZ{n}',f'/home/claude/asm/card{n}.png',dur=4,still=True)
        for k,f in {'AN01':O2+'Genere_Plurali_v3.mp4','AN05':O2+'AN05_SER-TENER_v3.mp4','AN06':O2+'AN06_Presente-regular_v3.mp4','FOND':O2+'Fondamenti_v3.mp4','PO02':O+'PO02_plurale.mp4','PO03':O+'PO03_interrogativos.mp4','PO04':O+'PO04_pronombres.mp4','PO05':O+'PO05_ser-tener.mp4','PO06':O+'PO06_presente-regular.mp4','PO07':O+'PO07_reflexivos.mp4'}.items():clip(k,f);print(k,flush=True)
        for k,f in {'S0':'/home/claude/lez1/sigla_iniziale.mp4','S9':'/home/claude/lez1/sigla_finale.mp4'}.items():clip(k,f,fade=False);print(k,flush=True)
    if step=='blocks':
        B={'B0':(0,600),'B1':(953.9,1219.6),'B2':(1552.8,1962.1),'B3':(2296.7,2626.1),'B4a':(2841.6,2919.0),'B4b':(2919.0,3031.0),'B5':(3196.2,3312.1),'B6':(3418.1,3497.0),'B7':(3569.1,DUR)}
        for k in sys.argv[2:]:block(k,*B[k])
    if step=='final':
        # S0 -> xfade 1.8 s -> B0
        run([FF,'-y','-loglevel','error','-i',f'{W}/S0.mp4','-i',f'{W}/B0.mp4','-filter_complex','[0:v][1:v]xfade=transition=fade:duration=1.8:offset=13.2[v];[0:a][1:a]acrossfade=d=1.8[a]','-map','[v]','-map','[a]']+ENC+AE+[f'{W}/S0B0.mp4'])
        seq=['S0B0','AN01','QZ1','B1','PO02','QZ2','B2','PO03','QZ3','B3','PO04','QZ4','B4a','AN05','B4b','PO05','QZ5','AN06','B5','PO06','QZ6','B6','PO07','QZ7','FOND','B7','S9']
        open(f'{W}/all.txt','w').write(''.join("file '%s/%s.mp4'\n"%(W,n) for n in seq))
        run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',f'{W}/all.txt','-c','copy','-movflags','+faststart','/home/claude/asm/Spagnolo_Lez1_ANTEPRIMA_INSIEME_540p.mp4']);print('final ok')
