import sys;sys.path.insert(0,'/home/claude/assets')
from lib_long import *
from playwright.sync_api import sync_playwright
Qs=[('1','Femminile','Actividad 1A','6 punti · trasformazione guidata'),('2','Plurale','Actividad 2A e 2B','10 punti · trascrizione guidata e vero/falso'),
('3','Interrogativos','Actividad 3A e 3B','11 punti · completamento e abbinamento'),('4','Pronombres','Actividad 4A','5 punti · scelta multipla'),
('5','SER y TENER','Actividad 5A e 5B','12 punti · scelta e ordina le parole'),('6','Verbi regolari','Actividad 6A e 6B','15 punti · completamento e testo a buchi'),
('7','Verbi riflessivi','Actividad 7A e 7B','10 punti · completamento e scelta multipla')]
css=BASE if False else ''
from engine import BASE
H='<!doctype html><meta charset=utf-8><style>%s%s</style><body><div id=root style="width:1920px;height:1080px;position:relative;background:#fff">%s</div>'
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={'width':1920,'height':1080})
    for n,t,a,pt in Qs:
        body='<div class="hd"><img src="data:image/png;base64,%s"></div><div class="ft">SPAGNOLO</div>'%LG
        body+='<div style="position:absolute;left:140px;top:290px"><span class="lb" style="font-size:24px">Pausa del video</span><div class="hero" style="font-size:130px;margin-top:26px">Quiz · %s</div><div style="font-weight:700;font-size:48px;margin-top:26px">%s</div><div style="font-weight:500;font-size:36px;margin-top:10px;opacity:.8">%s</div></div>'%(t,a,pt)
        body+='<div class="note" style="position:absolute;left:140px;top:760px;font-size:32px;padding:20px 34px">Rispondi, premi <b>Check</b> e poi <b>Continua il video</b>.</div>'
        open('c.html','w').write(H%(BASE+CSS,'',body).replace('%s','')) if False else open('c.html','w').write('<!doctype html><meta charset=utf-8><style>%s%s</style><body><div id=root style="width:1920px;height:1080px;position:relative;background:#fff">%s</div>'%(BASE,CSS,body))
        pg.goto('file:///home/claude/asm/c.html');pg.evaluate("document.fonts.ready");pg.screenshot(path='card%s.png'%n)
    b.close()
print('ok')
