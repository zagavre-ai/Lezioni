from kit import *
X='<style>.dq{border:.5pt solid #DDE3EE;border-radius:1.6mm;padding:2.4mm 3mm;margin-bottom:2.6mm}.dq h4{font:800 9.4pt Figtree;margin-bottom:1.4mm}.dq h4 b{color:#2060AF;margin-right:1.6mm}.dq .o{line-height:1.9}.nt{border-bottom:.5pt solid #C9D0DC;margin-top:1mm}</style>'
b=X+'<h1>Decisioni dell\'amministrazione</h1><div class="bar"></div><p style="margin-bottom:4mm">Modulo compilabile: spuntare la scelta e, se serve, scrivere una nota. Riferimento: sezione 17 delle linee guida.</p>'
Q=[('Avviso dei diritti riservati sulla sigla finale',[('ok','Testo approvato'),('mod','Testo da modificare (vedi nota)')]),
('Esercizi e scorrimento della lezione',[('a','A · Nessun vincolo'),('b','B · Vincolo leggero'),('c','C · Vincolo con soglia: ')]),
('Esercizi già svolti quando lo studente rivede la lezione',[('no','Non si ripropongono (si possono rifare a scelta)'),('si','Si ripresentano a ogni nuova visione')]),
('Sottotitoli come file separato, spenti all\'avvio',[('si','Sì, da realizzare'),('no','No')]),
('Priorità di rifacimento delle lezioni esistenti',[])]
for i,(t,opts) in enumerate(Q,1):
    b+=f'<div class="dq"><h4><b>{i}</b>{H.escape(t)}</h4><div class="o">'
    for k,l in opts:
        b+=C(f'd{i}_{k}',l)
        if k=='c':b+=f'<span style="display:inline-block;width:18mm;vertical-align:middle">{F("d2_soglia","f","height:4.8mm")}</span>%'
    b+='</div>'+(f'<div class="nt">{F(f"d{i}_nota","f","height:6mm")}</div>' if opts else f'<div style="border:.5pt solid #DDE3EE;border-radius:1mm">{F(f"d{i}_nota","f","height:16mm")}</div>')+'</div>'
b+=f'<div class="lab">Altre osservazioni o richieste di modifica (per iscritto)</div><div style="border:.5pt solid #DDE3EE;border-radius:1.2mm">{F("osservazioni","f","height:30mm")}</div>'
b+=f'<table style="margin-top:5mm"><tr><th>Data</th><th>Nome e firma</th></tr><tr><td>{F("data")}</td><td>{F("firma")}</td></tr></table>'
print(build('0_Decisioni_amministrazione',[page('Decisioni dell\'amministrazione',b,1)],'Decisioni'))
