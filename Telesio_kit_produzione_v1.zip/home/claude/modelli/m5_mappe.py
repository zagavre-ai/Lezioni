from kit import *
X='<style>.map{position:relative;width:267mm;height:124mm;margin-top:2mm}.map svg.cn{position:absolute;inset:0;width:267mm;height:124mm}.bx{position:absolute;display:flex;align-items:center;justify-content:center;text-align:center;border-radius:2.4mm;font-weight:800;padding:1mm}.L0{background:#0B1530;color:#fff;font:800 13pt "Bricolage Grotesque"}.L1{background:#2060AF;color:#fff;font-size:10pt}.L2{background:#fff;border:1pt solid #2060AF;color:#0B1530;font-size:9pt}.L3{background:#fff;border:.8pt solid #C9D0DC;color:#4A5570;font-weight:500;font-size:8.6pt}.bx .f{position:absolute;inset:1.4mm;width:auto;height:auto}.leg{display:flex;gap:6mm;margin-top:3mm;font-size:7.4pt;color:#4A5570}.leg span i{display:inline-block;width:6mm;height:3.4mm;border-radius:1mm;vertical-align:-0.6mm;margin-right:1.4mm}</style>'
COL={'L0':'#FFFFFF','L1':'#FFFFFF','L2':'#0B1530','L3':'#0B1530'}
def mm(v):return f'{v}mm'
def mapa(boxes,links,pref,fields=True):
    s='<div class="map"><svg class="cn" viewBox="0 0 267 124">'
    B={b[0]:b for b in boxes}
    for a,c,kind in links:
        _,_,x1,y1,w1,h1,_=B[a];_,_,x2,y2,w2,h2,_=B[c]
        if kind=='v':
            sx,sy=x1+w1/2,y1+h1;ex,ey=x2+w2/2,y2;my=(sy+ey)/2
            s+=f'<path d="M{sx} {sy} V{my} H{ex} V{ey}" fill="none" stroke="#2060AF" stroke-width=".45"/>'
        else:
            sx,sy=x1+w1,y1+h1/2;ex,ey=x2,y2+h2/2;mx=(sx+ex)/2
            s+=f'<path d="M{sx} {sy} H{mx} V{ey} H{ex}" fill="none" stroke="#2060AF" stroke-width=".45"/>'
    s+='</svg>'
    for k,lv,x,y,w,h,txt in boxes:
        inner=F(f'{pref}_{k}','f','',COL[lv],'0') if fields else H.escape(txt).replace('\n','<br>')
        s+=f'<div class="bx {lv}" style="left:{mm(x)};top:{mm(y)};width:{mm(w)};height:{mm(h)}">{inner}</div>'
    return s+'</div>'
LEG='<div class="leg"><span><i style="background:#0B1530"></i>Livello 0 · concetto principale</span><span><i style="background:#2060AF"></i>Livello 1 · ramo</span><span><i style="border:1pt solid #2060AF"></i>Livello 2 · parola chiave</span><span><i style="border:.8pt solid #C9D0DC"></i>Livello 3 · dettaglio o esempio</span></div>'
def tree(pref,fields=True,T=None):
    bx=[('r','L0',83.5,0,100,13,T and T[0] or '')];ln=[]
    for i in range(3):
        x=6+i*88;bx.append((f'b{i}','L1',x,25,79,11,T and T[1][i] or ''));ln.append(('r',f'b{i}','v'))
        for j in range(2):
            xx=x+j*41;bx.append((f'k{i}{j}','L2',xx,46,38,20,T and T[2][i*2+j] or ''));ln.append((f'b{i}',f'k{i}{j}','v'))
            bx.append((f'd{i}{j}','L3',xx,78,38,32,T and T[3][i*2+j] or ''));ln.append((f'k{i}{j}',f'd{i}{j}','v'))
    return mapa(bx,ln,pref,fields)
def right(pref):
    bx=[('r','L0',0,45,55,32,'')];ln=[]
    for i in range(4):
        y=2+i*31;bx.append((f'b{i}','L1',78,y+6,62,11.5,''));ln.append(('r',f'b{i}','h'))
        for j in range(2):
            bx.append((f'k{i}{j}','L2',162,y+j*14,105,11.5,''));ln.append((f'b{i}',f'k{i}{j}','h'))
    return mapa(bx,ln,pref)
LA='Mappa concettuale'
p1='<h1>Mappe concettuali BES/DSA</h1><div class="bar"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8mm">'
p1+='<div><div class="lab" style="margin-top:0">Come si compila</div><ul style="padding-left:4mm;line-height:1.6"><li>Apri il PDF e clicca dentro un riquadro: si scrive direttamente.</li><li>Il testo si adatta da solo alla dimensione del riquadro.</li><li>Pagina 2: mappa ad albero (dall\'alto verso il basso). Pagina 3: mappa a destra (da sinistra verso destra).</li><li>Si salva e si stampa come un normale PDF, in A4 orizzontale.</li></ul></div>'
p1+='<div><div class="lab" style="margin-top:0">Regole per le mappe BES/DSA</div><ul style="padding-left:4mm;line-height:1.6"><li>Un solo concetto per riquadro, con parole chiave.</li><li>Non più di 5–6 rami per livello: se servono di più, due mappe.</li><li>Niente frasi lunghe e niente corsivo.</li><li>Lo stesso colore indica sempre lo stesso livello.</li></ul></div></div>'
p1+='<div class="lab">I quattro livelli</div>'+LEG
p1+='<div class="box" style="margin-top:8mm"><b class="t">Esempio</b>La pagina 4 mostra una mappa compilata: Inglese, il verbo «to be» al presente.</div>'
p2='<h2>Materia – argomento della mappa</h2><div class="bar" style="margin-bottom:2mm"></div>'+tree('albero')+LEG
p3='<h2>Materia – argomento della mappa</h2><div class="bar" style="margin-bottom:2mm"></div>'+right('destra')+LEG
T=('Il verbo TO BE (presente)',['Forma affermativa','Forma negativa','Forma interrogativa'],['I am · you are\nhe/she/it is','we are · you are\nthey are','I am not\n(I\'m not)','isn\'t · aren\'t','Am I …?\nAre you …?','Is he …?\nAre they …?'],['I am Italian.','They are students.','I\'m not tired.','She isn\'t at home.','Are you ready?','Is it cold?'])
p4='<h2>Inglese – il verbo to be al presente <small>esempio</small></h2><div class="bar" style="margin-bottom:2mm"></div>'+tree('es',False,T)+LEG
print(build('5_Mappe_BES',[page(LA,X+p1,1),page(LA,X+p2,2),page(LA,X+p3,3),page(LA,X+p4,4)],'Mappe BES',W=297,Hh=210))
