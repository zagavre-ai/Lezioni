from kit import *
import datetime as D
GG=['LUN','MAR','MER','GIO','VEN','SAB','DOM'];MM=['','Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre']
days=[];d=D.date(2026,10,1)
while d<=D.date(2027,6,30):days.append(d);d+=D.timedelta(1)
CSSX='<style>.cal td{padding:0 1.6mm;height:8.4mm}.cal td.g{text-align:center;background:#E9EFF7;width:13mm;line-height:1.05}.cal td.g small{display:block;font:800 6pt Figtree;letter-spacing:.1em;color:#2060AF}.cal td.g b{font:800 12pt "Bricolage Grotesque"}.cal .we td.g{background:#DDE3EE}.cal td.v{width:24mm;white-space:nowrap}.mh td{background:#fff;border:0;padding:3mm 0 1.2mm;height:auto;font:800 7pt Figtree;letter-spacing:.16em;color:#2060AF;text-transform:uppercase}</style>'
def table(ds):
    h='<table class="cal dk"><tr><th style="width:13mm">Giorno</th><th>Materia</th><th>Lezione assegnata</th><th style="width:24mm">Visionata</th><th style="width:36mm">Note</th></tr>'
    cur=None
    for d in ds:
        if d.month!=cur:
            cur=d.month;h+=f'<tr class="mh"><td colspan="5">{MM[d.month]} {d.year}</td></tr>'
        k=d.isoformat();we=' class="we"' if d.weekday()>=5 else ''
        for j in (1,2):
            h+=f'<tr{we}>'
            if j==1:h+=f'<td class="g" rowspan="2"><small>{GG[d.weekday()]}</small><b>{d.day}</b></td>'
            h+=f'<td>{F(f"{k}_{j}_materia")}</td><td>{F(f"{k}_{j}_lezione")}</td><td class="v">{C(f"{k}_{j}_si","Sì")}{C(f"{k}_{j}_no","No")}</td>'
            if j==1:h+=f'<td rowspan="2">{F(f"{k}_note","f","height:15mm")}</td>'
            h+='</tr>'
    return h+'</table>'
pages=[];n=1
b=CSSX+'<h1>Calendario delle attività didattiche</h1><div class="bar"></div><table><tr><th>Studente</th><th>Corso / classe</th><th style="width:30mm">Anno scolastico</th><th style="width:44mm">Periodo</th></tr><tr><td>'+F('studente')+'</td><td>'+F('classe')+'</td><td>2026/2027</td><td>01/10/2026 – 30/06/2027</td></tr></table><div style="height:2mm"></div>'
first=8;b+=table(days[:first]);pages.append(page('Calendario attività studente',b,n));n+=1
i=first
while i<len(days):
    ch=days[i:i+12];t=f'{MM[ch[0].month]} {ch[0].year} · giorni {ch[0].day}–{ch[-1].day}' if ch[0].month==ch[-1].month else f'{ch[0].day} {MM[ch[0].month].lower()} – {ch[-1].day} {MM[ch[-1].month].lower()} {ch[-1].year}'
    pages.append(page('Calendario attività studente',CSSX+f'<h2>{t}</h2><div class="bar"></div>'+table(ch),n));n+=1;i+=12
print(build('4_Calendario_studente',pages,'Calendario attività studente'))
