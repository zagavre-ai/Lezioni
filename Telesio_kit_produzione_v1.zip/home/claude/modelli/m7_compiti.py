from kit import *
X='<style>.it{display:flex;gap:3mm;padding:2.4mm 0;border-bottom:.5pt solid #DDE3EE;align-items:center;font-size:9.4pt}.it b.nn{color:#2060AF;width:5mm}.it .tx{flex:1}.ln{display:inline-block;width:28mm;border-bottom:.8pt solid #0B1530;vertical-align:-1mm;margin:0 1mm}.ln .f{height:5mm}.ex{font:800 12pt "Bricolage Grotesque";margin:6mm 0 1mm}.cons{color:#4A5570;margin-bottom:2.5mm}.words{background:#E9EFF7;border-radius:1.6mm;padding:2.6mm 4mm;margin-bottom:2mm;font-weight:800}.words span.t{font:800 6.8pt Figtree;letter-spacing:.14em;color:#2060AF;margin-right:4mm}.words i{font-style:normal;margin-right:5mm}.sol td{font-size:9pt}</style>'
L='Inglese · Compiti'
def blank(n):return f'<span class="ln">{F(n)}</span>'
p1=X+'<h1>Compiti</h1><div class="bar"></div><div class="lab" style="margin-top:0">Pronomi personali, to be, question words</div>'
p1+='<div class="ex">Esercizio 1</div><div class="cons">Indica se le affermazioni sono vere (V) o false (F).</div>'
for i,t in enumerate(['Il pronome personale «I» si scrive sempre con la lettera minuscola.','In inglese il pronome personale soggetto va sempre espresso, anche quando in italiano è sottinteso.','L\'espressione «be hungry» significa «avere sonno».','«Here\'s my book» è un modo corretto per tradurre «Ecco il mio libro».','Alle domande chiuse (Yes/No questions) in inglese si può rispondere semplicemente con «Yes» o «No», senza altro.'],1):
    p1+=f'<div class="it"><b class="nn">{i}.</b><span class="tx">{H.escape(t)}</span>{C(f"vf_{i}_V","V")}{C(f"vf_{i}_F","F")}</div>'
p1+='<div class="ex">Esercizio 2</div><div class="cons">Completa le frasi scegliendo la parola corretta. Ogni parola va usata una sola volta.</div><div class="words"><span class="t">Parole da usare</span><i>am</i><i>are</i><i>Why</i><i>hungry</i><i>Here\'s</i><i>late</i></div>'
E2=['I {} a student at this school.','You and your brother {} very tall.','{} are you crying? Did something happen?','{} my bag! I was looking for it everywhere.','I\'m so {}, I haven\'t eaten anything since this morning.','Hurry up, we are {} for the bus!']
for i,t in enumerate(E2,1):p1+=f'<div class="it"><b class="nn">{i}.</b><span class="tx">{H.escape(t).replace("{}",blank(f"es2_{i}"))}</span></div>'
p2=X+'<div class="ex" style="margin-top:0">Esercizio 3</div><div class="cons">Completa le frasi.</div>'
E3=['{} live in Rome with my family.','My parents {} both doctors.','Can you give this book to {}?','{} you coming to the party tonight?','{} is your birthday?','This present is for {}.']
for i,t in enumerate(E3,1):p2+=f'<div class="it"><b class="nn">{i}.</b><span class="tx">{H.escape(t).replace("{}",blank(f"es3_{i}"))}</span></div>'
p2+='<h1 style="margin-top:14mm">Soluzioni</h1><div class="bar"></div>'
for t,row in [('Esercizio 1',['F','V','F','V','F']),('Esercizio 2',['am','are','Why','Here\'s','hungry','late']),('Esercizio 3',['I','are','her','Are','When','them'])]:
    p2+=f'<div class="lab">{t}</div><table class="sol"><tr>'+''.join(f'<td><b style="color:#2060AF">{i}.</b> {H.escape(v)}</td>' for i,v in enumerate(row,1))+'</tr></table>'
print(build('7_Compiti_di_materia_Inglese',[page(L,p1,1),page(L,p2,2)],'Compiti di materia'))
