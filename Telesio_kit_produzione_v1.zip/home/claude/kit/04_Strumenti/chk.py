import pdfplumber, glob, re, json, collections
out={}
for f in sorted(glob.glob('zip/*.pdf'), key=lambda x:int(re.search(r'Lez(\d+)',x).group(1))):
    n=int(re.search(r'Lez(\d+)',f).group(1)); r=dict(pages=0,issues=[],minsize={},text=[])
    with pdfplumber.open(f) as pdf:
        r['pages']=len(pdf.pages)
        for i,p in enumerate(pdf.pages,1):
            W,H=p.width,p.height
            ch=[c for c in p.chars if c['text'].strip()]
            words=p.extract_words(use_text_flow=False, keep_blank_chars=False, extra_attrs=['size'])
            txt=p.extract_text() or ''
            r['text'].append(txt)
            # fuori pagina / margini
            out_m=[c for c in ch if c['x0']<20 or c['x1']>W-20 or c['top']<15 or c['bottom']>H-12]
            if out_m: r['issues'].append(f'p{i}: {len(out_m)} caratteri fuori dai margini ("{"".join(c["text"] for c in out_m[:20])}")')
            # dimensione minima del testo del corpo (escludo intestazione/piè)
            body=[c for c in ch if 70<c['top']<H-60]
            if body:
                ms=min(round(c['size'],1) for c in body); r['minsize'][i]=ms
            # sovrapposizioni tra parole
            ov=0; ex=[]
            for a_i in range(len(words)):
                a=words[a_i]
                for b in words[a_i+1:a_i+40]:
                    ix=min(a['x1'],b['x1'])-max(a['x0'],b['x0']); iy=min(a['bottom'],b['bottom'])-max(a['top'],b['top'])
                    if ix>2 and iy>2 and ix*iy>0.3*min((a['x1']-a['x0'])*(a['bottom']-a['top']),(b['x1']-b['x0'])*(b['bottom']-b['top'])):
                        ov+=1; ex.append(a['text']+'/'+b['text'])
            if ov: r['issues'].append(f'p{i}: {ov} parole sovrapposte ({", ".join(ex[:3])})')
            # pagina quasi vuota
            bt=[c for c in ch if 90<c['top']<H-70]
            ys=[c['bottom'] for c in bt]
            fill=(max(ys)-90)/(H-160) if ys else 0
            imgs=len(p.images)+len([x for x in p.rects if (x['x1']-x['x0'])>100 and (x['bottom']-x['top'])>100])
            if i<r['pages'] and fill<0.45 and imgs==0: r['issues'].append(f'p{i}: pagina riempita solo al {int(fill*100)}%')
            if re.search(r'Grazie per l', txt): r['issues'].append(f'p{i}: c\'è ancora "Grazie per l\'attenzione"')
            if not re.search(r'Pagina\s*\d+', txt) and i>1: r['issues'].append(f'p{i}: manca "Pagina X"')
    out[n]=r
json.dump(out,open('chk.json','w'),ensure_ascii=False)
for n,r in out.items():
    small=[f'p{k}:{v}' for k,v in r['minsize'].items() if v<9]
    print(f"Lez{n}: {r['pages']} pag. | min pt per pagina: {min(r['minsize'].values()) if r['minsize'] else '-'} {'| piccoli: '+' '.join(small) if small else ''}")
    for x in r['issues']: print('    ',x)
