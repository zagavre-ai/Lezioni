import glob,re,sys
from pptx import Presentation
from PIL import ImageFont
FD='/usr/share/fonts/truetype/liberation/'
F={}
def font(b,i,sz):
    k=(b,i,sz)
    if k not in F:
        nm='LiberationSans-'+('BoldItalic' if b and i else 'Bold' if b else 'Italic' if i else 'Regular')+'.ttf'
        F[k]=ImageFont.truetype(FD+nm, int(sz*20))
    return F[k]
def wordw(text,b,i,sz): return font(b,i,sz).getlength(text)/20  # pt
def check(path):
    p=Presentation(path); out=[]
    for si,s in enumerate(p.slides,1):
        for sh in s.shapes:
            if not sh.has_table: continue
            tb=sh.table; cw=[c.width for c in tb.columns]
            for ri,row in enumerate(tb.rows):
                for ci,cell in enumerate(row.cells):
                    if cell.is_spanned: continue
                    span=cell.span_width if cell.is_merge_origin else 1
                    w=sum(cw[ci:ci+span])/12700 - (cell.margin_left+cell.margin_right)/12700
                    for para in cell.text_frame.paragraphs:
                        for r in para.runs:
                            sz=(r.font.size.pt if r.font.size else 10)
                            b=bool(r.font.bold); it=bool(r.font.italic)
                            for wd in re.split(r'\s+',r.text):
                                if not wd: continue
                                ww=wordw(wd,b,it,sz)
                                if ww>w-2.0: out.append((si,ri,ci,wd,round(ww,1),round(w,1)))
    return out
if __name__=='__main__':
    for f in sys.argv[1:]:
        o=check(f)
        if o: print(re.search(r'Lez\d+',f).group(0), o[:12])
