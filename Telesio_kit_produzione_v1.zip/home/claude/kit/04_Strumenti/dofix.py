import copy, re, sys
sys.path.insert(0,'.')
from pptx import Presentation
from pptx.util import Emu
import tablechk
D='fix/'
def shapes_by_id(s): return {sh.shape_id:sh for sh in s.shapes}
def content(s, by_tree=True):
    sh=[x for x in s.shapes if x.name not in ('Title 1',) and not x.name.startswith('Slide Number')]
    return sh if by_tree else sorted(sh,key=lambda x:x.top)
def restack(s, start=2627630):
    """rimette in colonna le forme di contenuto, nell'ordine del documento, con spazi regolari"""
    sh=content(s); y=start; prev=None
    for x in sh:
        if prev is not None:
            g=x.top-(prev[0]+prev[1]) if prev[2] else None
            if x.name.startswith('Titolo sezione') and not x.name.endswith('barra'): g=406400
            elif x.name.endswith('barra'): g=107950
            elif g is None or g<-40000 or g>260000: g=127000
            y+=g
        orig=(x.top,x.height,True)
        x.top=Emu(y); y+=x.height
        prev=(orig[0],orig[1],True)
def remove(s, ids):
    m=shapes_by_id(s)
    for i in ids: el=m[i]._element; el.getparent().remove(el)
def move(src, dst, ids, at_start=False):
    m=shapes_by_id(src); els=[m[i]._element for i in ids]
    tree=dst.shapes._spTree
    cont=content(dst)
    for el in els:
        el.getparent().remove(el)
    if at_start and cont:
        anchor=cont[0]._element
        for el in els: anchor.addprevious(el)
    else:
        for el in els: tree.append(el)
    return els
log=[]
# 17: duplicato «want»
p=Presentation(D+'Inglese_Lez17_dispensa.pptx'); s=p.slides[3]; remove(s,[8,9]); p.save(D+'Inglese_Lez17_dispensa.pptx'); log.append('17 ok')
# 18: duplicato «regular verbs» + esempi riuniti alla loro sezione
p=Presentation(D+'Inglese_Lez18_dispensa.pptx'); s7=p.slides[6]; s8=p.slides[7]
remove(s7,[5,6]); restack(s7)
m8=shapes_by_id(s8); ex=m8[3]
last=max(content(s7), key=lambda x:x.top+x.height); y=last.top+last.height+51000
el=ex._element; el.getparent().remove(el); s7.shapes._spTree.append(el); ex.top=Emu(y)
restack(s8); p.save(D+'Inglese_Lez18_dispensa.pptx'); log.append('18 ok')
# 8: riga coperta dalla tabella -> tabella più in basso
p=Presentation(D+'Inglese_Lez8_dispensa.pptx'); s=p.slides[2]; t=shapes_by_id(s)[4]; t.top=Emu(t.top+420000); p.save(D+'Inglese_Lez8_dispensa.pptx'); log.append('8 ok')
# 9: esempi su tutta la larghezza della tabella
p=Presentation(D+'Inglese_Lez9_dispensa.pptx'); s=p.slides[1]
tsh=[x for x in s.shapes if x.has_table][0]; tb=tsh.table; c=tb.cell(5,0)
for para in c.text_frame.paragraphs:
    for r in para.runs: r.text=r.text.replace('?- Yes','? – Yes')
c.merge(tb.cell(5,2)); tb.rows[5].height=Emu(560000)
old_h=tsh.height; tsh.height=Emu(sum(r.height for r in tb.rows))
restack(s); p.save(D+'Inglese_Lez9_dispensa.pptx'); log.append('9 ok')
# 22: colonne ribilanciate perché nessuna parola venga spezzata
p=Presentation(D+'Inglese_Lez22_dispensa.pptx')
for s in p.slides:
    for sh in s.shapes:
        if not sh.has_table or len(sh.table.columns)!=6: continue
        tb=sh.table; cols=tb.columns; total=sum(c.width for c in cols); need=[0]*6
        for row in tb.rows:
            for ci,cell in enumerate(row.cells):
                for para in cell.text_frame.paragraphs:
                    for r in para.runs:
                        sz=r.font.size.pt if r.font.size else 10
                        for wd in r.text.split():
                            need[ci]=max(need[ci], tablechk.wordw(wd,bool(r.font.bold),bool(r.font.italic),sz))
        need=[int((n+14.4+5)*12700) for n in need]
        spare=total-sum(need); assert spare>0, spare
        for c,n in zip(cols,need): c.width=Emu(n+spare//6)
        cols[5].width=Emu(total-sum(c.width for c in list(cols)[:5]))
p.save(D+'Inglese_Lez22_dispensa.pptx'); log.append('22 ok')
# 1: titolo e piè di pagina uniformi
import zipfile, shutil, os
p=Presentation(D+'Inglese_Lez1_dispensa.pptx')
def strip(tf):
    for para in tf.paragraphs:
        for r in para.runs:
            if 'PRIMO BIENNIO' in r.text: r.text=r.text.replace(' – PRIMO BIENNIO','').replace('– PRIMO BIENNIO','').rstrip()
for s in p.slides:
    for sh in s.shapes:
        if sh.has_text_frame: strip(sh.text_frame)
for lay in p.slide_layouts:
    for sh in lay.shapes:
        if sh.has_text_frame: strip(sh.text_frame)
for sh in p.slide_master.shapes:
    if sh.has_text_frame: strip(sh.text_frame)
p.save(D+'Inglese_Lez1_dispensa.pptx'); log.append('1 ok')
# 30, 39: elenco argomenti più compatto in copertina
from lxml import etree
A='{http://schemas.openxmlformats.org/drawingml/2006/main}'
for n in (30,39):
    p=Presentation(D+f'Inglese_Lez{n}_dispensa.pptx'); sh=[x for x in p.slides[0].shapes if x.name=='Argomenti'][0]
    for pr in sh._element.iter(A+'pPr'):
        for e in pr.iter(A+'spcPct'): e.set('val','122000')
        for e in pr.iter(A+'spcPts'):
            if e.getparent().tag==A+'spcAft': e.set('val','200')
    p.save(D+f'Inglese_Lez{n}_dispensa.pptx')
log.append('30/39 ok')
# 42: il titolo della sezione 4 va insieme alla sua tabella
p=Presentation(D+'Inglese_Lez42_dispensa.pptx'); s7,s8,s9=p.slides[6],p.slides[7],p.slides[8]
m8=shapes_by_id(s8)
move(s8,s9,[6,7,8],at_start=True)        # «The following verbs…» + tabella + «Some verbs…» passano alla pagina dopo
move(s7,s8,[6,7,8,9],at_start=True)     # titolo sezione 4 + barra + sottotitolo + testo in testa alla pagina 8
for sh in s8.shapes:
    if sh.name=='Title 1': sh.text_frame.text=''
restack(s7); restack(s8); restack(s9)
p.save(D+'Inglese_Lez42_dispensa.pptx'); log.append('42 ok')
print(log)
for n,s in ((42,8),(42,9),(18,7),(18,8),(9,2)):
    pr=Presentation(D+f'Inglese_Lez{n}_dispensa.pptx'); sl=pr.slides[s-1]
    print(n,s,[(x.name[:18],x.top,x.top+x.height) for x in content(sl)])
