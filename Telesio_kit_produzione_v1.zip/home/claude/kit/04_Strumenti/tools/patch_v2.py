import sys
p=sys.argv[1]; s=open(p).read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:80]
    s=s.replace(old,new)

rep("""#  Si aggiungono solo la sigla iniziale e la sigla finale.
# =====================================================================""",
"""#  Si aggiungono solo la sigla iniziale e la sigla finale.
#  Versione 2: correzione automatica di colore e luci sull'immagine della prof
#  e riquadro nascosto quando la webcam mostra lo schermo nero con le iniziali.
# =====================================================================""")

# skip / aggiornamento
rep("""  [ -f "$OUT" ] && { echo "✓ $NOME: già corretto, salto."; continue; }""",
"""  if [ -f "$OUT" ]; then
    if [ "$AGGIORNA" = "1" ] && ! "$FP" -v error -show_entries format_tags=comment -of csv=p=0 "$OUT" 2>/dev/null | grep -q "$FIRMA-v2"; then
      echo ""; echo "↻ $NOME: lo rifaccio con la versione nuova (il video vecchio resta finché il nuovo non è pronto)"
    else
      echo "✓ $NOME: già corretto, salto."; continue
    fi
  fi""")

# intervalli in chiaro per l'analisi
rep("""      A=""; Cv=""; P=""; Fn=""
""","""      A=""; Cv=""; P=""; Fn=""; Ar=""; Pr=""; Fr=""
""")
rep("""        if (tipo[i]=="animazione") A=A sprintf("+between(t,%.3f,%.3f)", s, e)
""","""        if (tipo[i]=="animazione") { A=A sprintf("+between(t,%.3f,%.3f)", s, e); Ar=Ar sprintf(" %.3f-%.3f", s, e) }
""")
rep("""        if (pieno[i]==1)           P=P sprintf("+between(t,%.3f,%.3f)", s, e)
        if (fine[i]==1)            Fn=Fn sprintf("+between(t,%.3f,%.3f)", s, e)
""","""        if (pieno[i]==1)           { P=P sprintf("+between(t,%.3f,%.3f)", s, e); Pr=Pr sprintf(" %.3f-%.3f", s, e) }
        if (fine[i]==1)            { Fn=Fn sprintf("+between(t,%.3f,%.3f)", s, e); Fr=Fr sprintf(" %.3f-%.3f", s, e) }
""")
rep("""      print "WX=" wx; print "WY=" wy; print "WW=" ww; print "WH=" wh
""","""      print "WX=" wx; print "WY=" wy; print "WW=" ww; print "WH=" wh
      print "RA=\\"" Ar "\\""; print "RP=\\"" Pr "\\""; print "RF=\\"" Fr "\\""
""")

# analisi: colore + tratti senza volto
rep("""  [ -n "$VXE" ] && CAMCROP="crop=w=${VCW}:h=${VCH}:x='${VXE}':y='${VYE}'"
""","""  [ -n "$VXE" ] && CAMCROP="crop=w=${VCW}:h=${VCH}:x='${VXE}':y='${VYE}'"

  # --- analisi dell'immagine della prof: colore medio e tratti senza volto ---
  # due fotogrammi al secondo, ridotti a 16x12: a sinistra il riquadro webcam,
  # a destra il centro dello schermo (usato quando la prof e' a tutto schermo)
  echo "  Analizzo l'immagine della prof (colori, luci, schermate nere)..."
  "$FF" -nostdin -hide_banner -loglevel error -i "$VID" -an -filter_complex \\
    "[0:v]fps=2,scale=1920:1080,setsar=1,split=2[a][b];[a]crop=${CW}:${WH}:${CX}:${WY},scale=16:12:flags=area[s];[b]crop=1440:1080:240:0,scale=16:12:flags=area[c];[s][c]hstack=inputs=2,format=rgb24" \\
    -f rawvideo - 2>/dev/null | od -An -v -tu1 | awk -v ra="$RA" -v rp="$RP" -v rf="$RF" '
    function inr(t, lst,   n,k,a,b){ n=split(lst,a," "); for(k=1;k<=n;k++){ split(a[k],b,"-"); if (t>=b[1] && t<b[2]) return 1 } return 0 }
    { for (i=1;i<=NF;i++) { v=$i; ch=pos%3
        if (ch==0) r=v; else if (ch==1) g=v; else {
          px=int(pos/3); col=px%32; y=(299*r+587*g+114*v)/1000
          if (col<16) { sl+=y; if (y<40) sd++; sr+=r; sg+=g; sb+=v } else { cl+=y; if (y<40) cd++; cr+=r; cg+=g; cb+=v }
        }
        pos++
        if (pos==1152) { fine_frame(); pos=0; sl=sd=sr=sg=sb=cl=cd=cr=cg=cb=0 } } }
    function fine_frame(   t,usa,m,d){
      t=fr/2; fr++
      if (inr(t,rp) || inr(t,rf)) { usa="c"; m=cl/192; d=cd/192 }
      else if (inr(t,ra)) { usa=""; m=255; d=0 }
      else { usa="s"; m=sl/192; d=sd/192 }
      nero=(usa!="" && m<45 && d>0.70)
      if (nero) { if (!in_n) { ns=t; in_n=1 } ne=t; secn+=0.5 }
      else {
        if (in_n) { chiudi() }
        if (usa=="s") { TR+=sr; TG+=sg; TB+=sb; NP+=192 }
        if (usa=="c") { TR+=cr; TG+=cg; TB+=cb; NP+=192 }
      }
    }
    function chiudi(){ a=ns-0.5; if (a<0) a=0; b=ne+1.0; NE=NE sprintf("+between(t,%.2f,%.2f)", a, b); in_n=0 }
    function clamp(x,lo,hi){ return x<lo?lo:(x>hi?hi:x) }
    END {
      if (in_n) chiudi()
      if (NE=="") NE="+0"
      print "NERO=\\"" substr(NE,2) "\\""; printf "SECNERO=%d\\n", secn
      if (NP>0) {
        R=TR/NP; G=TG/NP; B=TB/NP; M=(R+G+B)/3
        gr=clamp(1+0.5*(M/R-1),0.85,1.20); gg=clamp(1+0.5*(M/G-1),0.85,1.20); gb=clamp(1+0.5*(M/B-1),0.85,1.20)
        Y=0.299*R*gr+0.587*G*gg+0.114*B*gb; if (Y<5) Y=5; if (Y>250) Y=250
        gam=clamp(log(Y/255)/log(118/255),0.90,1.35)
      } else { gr=gg=gb=1; gam=1 }
      printf "CRR=%.3f\\nCGG=%.3f\\nCBB=%.3f\\nCGAM=%.3f\\n", gr, gg, gb, gam
    }' > "$L/.analisi.txt"
  NERO="0"; SECNERO=0; CRR=1; CGG=1; CBB=1; CGAM=1
  # shellcheck disable=SC1090
  . "$L/.analisi.txt" 2>/dev/null
  [ "$SECNERO" -gt 0 ] 2>/dev/null && echo "  Schermata nera/senza volto nel riquadro: circa $SECNERO secondi, verranno nascosti"
  echo "  Correzione colore: rosso x$CRR, verde x$CGG, blu x$CBB, luminosità (gamma) $CGAM"
  # correzione applicata SOLO all'immagine della prof (le slide restano intatte)
  COLORE="hqdn3d=1.5:1.5:3:3,colorchannelmixer=rr=${CRR}:gg=${CGG}:bb=${CBB},eq=gamma=${CGAM}:contrast=1.04:saturation=1.03"
  NITIDO="cas=0.35"
""")

rep("""[src1]${CAMCROP},scale=332:249:flags=lanczos[cam1];\\
[src2]${CAMCROP},scale=332:249:flags=lanczos[cam2];\\
[src3]crop=1888:975:16:0,scale=1588:820:flags=lanczos[an];\\
[src4]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam3];\\
[src5]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam4];\\""",
"""[src1]${CAMCROP},${COLORE},scale=332:249:flags=lanczos,${NITIDO}[cam1];\\
[src2]${CAMCROP},${COLORE},scale=332:249:flags=lanczos,${NITIDO}[cam2];\\
[src3]crop=1888:975:16:0,${COLORE},scale=1588:820:flags=lanczos,${NITIDO}[an];\\
[src4]crop=1440:1080:240:0,${COLORE},scale=332:249:flags=lanczos,${NITIDO}[cam3];\\
[src5]crop=1440:1080:240:0,${COLORE},scale=332:249:flags=lanczos,${NITIDO}[cam4];\\""")
rep("""enable='eq(${ANIM}+${COPE},0)*eq(${FINE},0)'[b1]""","""enable='eq(${ANIM}+${COPE},0)*eq(${FINE},0)*eq(${NERO},0)'[b1]""")
rep("""enable='gt(${COPE},0)*eq(${PIENO},0)'[b2]""","""enable='gt(${COPE},0)*eq(${PIENO},0)*eq(${NERO},0)'[b2]""")
rep("""enable='gt(${PIENO},0)'[b3]""","""enable='gt(${PIENO},0)*eq(${NERO},0)'[b3]""")
rep("""enable='gt(${FINE},0)'[b4]""","""enable='gt(${FINE},0)*eq(${NERO},0)'[b4]""")
rep("""-metadata comment="$FIRMA-audiopulito\"""","""-metadata comment="$FIRMA-v2-audiopulito\"""")
rep("""  rm -f "$CONC" "$L/.piano.txt\"""","""  rm -f "$CONC" "$L/.piano.txt" "$L/.analisi.txt\"""")
open(p,'w').write(s)
