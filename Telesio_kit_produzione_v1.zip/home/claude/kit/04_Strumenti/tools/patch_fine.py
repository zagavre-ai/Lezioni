import sys
p=sys.argv[1]; s=open(p).read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:70]
    s=s.replace(old,new)
rep("""      A=""; Cv=""; P=""
""","""      A=""; Cv=""; P=""; Fn=""
""")
rep("""      for (i=1;i<=n;i++) {
        s=t[i];""","""      # FINE UNIFORME: se la lezione finisce con la docente a tutto schermo
      # (ultima riga animazione), al suo posto resta l'ultima slide
      # ("Grazie per l'attenzione") con la docente nel riquadro in alto a destra.
      if (n>=2 && tipo[n]=="animazione") {
        for (j=n-1;j>=1;j--) if (tipo[j]=="slide" || tipo[j]=="copertina") { tipo[n]="slide"; img[n]=img[j]; fine[n]=1; break }
      }
      for (i=1;i<=n;i++) {
        s=t[i];""")
rep("""        if (pieno[i]==1)           P=P sprintf("+between(t,%.3f,%.3f)", s, e)
""","""        if (pieno[i]==1)           P=P sprintf("+between(t,%.3f,%.3f)", s, e)
        if (fine[i]==1)            Fn=Fn sprintf("+between(t,%.3f,%.3f)", s, e)
""")
rep("""      if (P=="") P="+0"; print "PIENO=\\"" substr(P,2) "\\\"\"""","""      if (P=="") P="+0"; print "PIENO=\\"" substr(P,2) "\\\"\"
      if (Fn=="") Fn="+0"; print "FINE=\\"" substr(Fn,2) "\\\"\"""")
rep("""split=4[src1][src2][src3][src4];\\""","""split=5[src1][src2][src3][src4][src5];\\""")
rep("""[src4]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam3];\\""","""[src4]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam3];\\
[src5]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam4];\\""")
rep("""[bg][cam1]overlay=1511:149:enable='eq(${ANIM}+${COPE},0)'[b1];\\""","""[bg][cam1]overlay=1511:149:enable='eq(${ANIM}+${COPE},0)*eq(${FINE},0)'[b1];\\""")
rep("""[b2][cam3]overlay=1511:104:enable='gt(${PIENO},0)'[b3];\\""","""[b2][cam3]overlay=1511:104:enable='gt(${PIENO},0)'[b3];\\
[b3][cam4]overlay=1511:149:enable='gt(${FINE},0)'[b4];\\""")
rep("""[b3][an]overlay=166:143""","""[b4][an]overlay=166:143""")
open(p,'w').write(s)
