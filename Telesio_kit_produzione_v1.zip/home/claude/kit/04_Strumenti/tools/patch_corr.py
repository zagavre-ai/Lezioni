import sys
p=sys.argv[1]; s=open(p).read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:60]
    s=s.replace(old,new)
rep("""      A=""; Cv=""
      for (i=1;i<=n;i++) {""","""      A=""; Cv=""; P=""
      # INIZIO UNIFORME: se la lezione comincia con la docente a tutto schermo
      # (animazione alle 0:00:00), al suo posto si mostra la copertina con la
      # docente nel riquadro in alto a destra, come nelle prime lezioni.
      if (n>=2 && tipo[1]=="animazione" && t[1]==0) {
        for (j=2;j<=n;j++) if (tipo[j]=="copertina") { tipo[1]="copertina"; img[1]=img[j]; pieno[1]=1; break }
      }
      for (i=1;i<=n;i++) {""")
rep("""        if (tipo[i]=="copertina")  Cv=Cv sprintf("+between(t,%.3f,%.3f)", s, e)
""","""        if (tipo[i]=="copertina")  Cv=Cv sprintf("+between(t,%.3f,%.3f)", s, e)
        if (pieno[i]==1)           P=P sprintf("+between(t,%.3f,%.3f)", s, e)
""")
rep("""      print "COPE=\\"" substr(Cv,2) "\\\"\"""","""      print "COPE=\\"" substr(Cv,2) "\\\"\"
      if (P=="") P="+0"; print "PIENO=\\"" substr(P,2) "\\\"\"""")
rep("""setsar=1,split=3[src1][src2][src3];\\""","""setsar=1,split=4[src1][src2][src3][src4];\\""")
rep("""[src3]crop=1888:975:16:0,scale=1588:820:flags=lanczos[an];\\""","""[src3]crop=1888:975:16:0,scale=1588:820:flags=lanczos[an];\\
[src4]crop=1440:1080:240:0,scale=332:249:flags=lanczos[cam3];\\""")
rep("""[b1][cam2]overlay=1511:104:enable='gt(${COPE},0)'[b2];\\""","""[b1][cam2]overlay=1511:104:enable='gt(${COPE},0)*eq(${PIENO},0)'[b2];\\
[b2][cam3]overlay=1511:104:enable='gt(${PIENO},0)'[b3];\\""")
rep("""[b2][an]overlay=166:143""","""[b3][an]overlay=166:143""")
open(p,'w').write(s)
