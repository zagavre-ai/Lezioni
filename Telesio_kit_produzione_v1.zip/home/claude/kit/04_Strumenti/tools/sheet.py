import sys,numpy as np
from PIL import Image,ImageDraw
n=sys.argv[1]; ts=[int(x) for x in sys.argv[2:]]
a=np.load(f'/tmp/claude-0/-home-claude/8c6bed57-912f-536e-ba3b-2ab57087e318/scratchpad/l{n}/frames_480.npy',mmap_mode='r')
cols=4; W,H=480,270; rows=(len(ts)+cols-1)//cols
im=Image.new('RGB',(cols*W,rows*H))
for i,t in enumerate(ts):
    t=min(t,a.shape[0]-1); f=Image.fromarray(np.array(a[t])); d=ImageDraw.Draw(f); d.text((6,6),f'{t//3600}:{t%3600//60:02d}:{t%60:02d}',fill=(255,0,0))
    im.paste(f,((i%cols)*W,(i//cols)*H))
im.save(f'/tmp/claude-0/-home-claude/8c6bed57-912f-536e-ba3b-2ab57087e318/scratchpad/sheet_{n}.png')
