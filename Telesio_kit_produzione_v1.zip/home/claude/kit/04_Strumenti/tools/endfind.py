import sys,numpy as np
S='/tmp/claude-0/-home-claude/8c6bed57-912f-536e-ba3b-2ab57087e318/scratchpad'
for n in sys.argv[1:]:
    a=np.load(f'{S}/l{n}/frames_480.npy',mmap_mode='r'); T=a.shape[0]
    m=np.array([np.asarray(a[t][90:230,432:476]).mean() for t in range(T)])
    full=m>25   # docente a tutto schermo: la zona nera a destra non e' piu' nera
    # sequenze di full-screen lunghe >=20s
    runs=[];s=None
    for t in range(T):
        if full[t] and s is None: s=t
        if (not full[t] or t==T-1) and s is not None:
            e=t if not full[t] else T
            if e-s>=20: runs.append((s,e))
            s=None
    g=[]
    for s_,e_ in runs:
        if g and s_-g[-1][1]<=120: g[-1][1]=e_
        else: g.append([s_,e_])
    import json; json.dump({'fe':g[0][1] if g[0][0]<5 else 0,'end':g[-1][0]},open(f'{S}/l{n}/run.json','w'))
    print(n,T,[(f'{s//3600}:{s%3600//60:02d}:{s%60:02d}',e-s) for s,e in runs])
