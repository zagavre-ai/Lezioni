"""Sigla iniziale con titolo e riga materia/docente a scelta, ricalcata sulla sigla di Lez20."""
import sys, os, subprocess
import numpy as np
from PIL import Image, ImageFont, ImageDraw
S=os.environ['S']; SRC=f'{S}/lez20/sigla_iniziale.mp4'; FR=f'{S}/lez20/sg'
FB='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
FRG='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
frames=[np.array(Image.open(f'{FR}/f{i:03d}.png').convert('RGB')).astype(np.float32) for i in range(1,211)]
final=frames[150]
def band_anim(Y0,Y1,X0,X1):
    ys=np.arange(Y0,Y1)
    prof=lambda f:(255-f.mean(axis=2)[Y0:Y1,X0:X1]).clip(0,None).sum(axis=1)
    pf=prof(final); inkf=pf.sum(); cyf=(ys*pf).sum()/inkf
    al=[];dy=[]
    for f in frames:
        p=prof(f); ink=p.sum(); al.append(ink/inkf); dy.append(((ys*p).sum()/ink-cyf) if ink>0.05*inkf else 0.0)
    al=np.clip(np.array(al),0,1); dy=np.array(dy); k=np.ones(3)/3
    a=np.convolve(np.pad(al,1,mode='edge'),k,'valid'); d=np.convolve(np.pad(dy,1,mode='edge'),k,'valid')
    d[a<0.05]=0; a[a<0.002]=0
    g=final.mean(axis=2)[Y0:Y1,X0:X1]; col=np.median(final[Y0:Y1,X0:X1][g<120],axis=0)
    return a,np.round(d).astype(int),col
BANDS=[dict(Y0=622,Y1=742,X0=560,X1=1360,font=ImageFont.truetype(FB,64),ybase=642,ex=(150,1770)),
       dict(Y0=743,Y1=792,X0=600,X1=1320,font=ImageFont.truetype(FRG,32),ybase=738,ex=(150,1770))]
for b in BANDS: b['a'],b['d'],b['col']=band_anim(b['Y0'],b['Y1'],b['X0'],b['X1'])
def cov(b,text,shift):
    bb=b['font'].getbbox(text); x=960-(bb[0]+bb[2])/2
    im=Image.new('L',(1920,b['Y1']-b['Y0']),0); ImageDraw.Draw(im).text((x,b['ybase']-b['Y0']+shift),text,font=b['font'],fill=255)
    return np.array(im).astype(np.float32)/255
def build(titolo,sotto,out):
    texts=[titolo,sotto]; cache={}
    for b,t in zip(BANDS,texts):
        w=b['font'].getlength(t); assert w<b['ex'][1]-b['ex'][0], (t,w)
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','30','-i','-','-i',SRC,
         '-map','0:v','-map','1:a','-c:v','libx264','-preset','medium','-crf','15','-pix_fmt','yuv420p','-c:a','copy','-t','7','-movflags','+faststart',out]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for i,f in enumerate(frames):
        h=f.copy()
        for k,(b,t) in enumerate(zip(BANDS,texts)):
            a=b['a'][i]; s=int(b['d'][i])
            if a>0:
                h[b['Y0']:b['Y1'],b['ex'][0]:b['ex'][1]]=255
                key=(k,s)
                if key not in cache: cache[key]=cov(b,t,s)[...,None]
                c=cache[key]*a
                h[b['Y0']:b['Y1']]=h[b['Y0']:b['Y1']]*(1-c)+b['col']*c
        p.stdin.write(np.clip(h,0,255).astype(np.uint8).tobytes())
    p.stdin.close(); p.wait()
if __name__=='__main__':
    build(sys.argv[1],sys.argv[2],sys.argv[3])
