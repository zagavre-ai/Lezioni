import sys, os, copy, subprocess, shutil
from pptx import Presentation
n=sys.argv[1]; base=f'{os.environ["S"]}/l{n}'
pptx=f'{base}/Inglese_Lez{n}.pptx'
# 1) PDF per le slide (se manca)
pdf=f'{base}/Inglese_Lez{n}.pdf'
if not os.path.exists(pdf):
    subprocess.run(['soffice',f'-env:UserInstallation=file:///tmp/lo{n}','--headless','--convert-to','pdf','--outdir',base,pptx],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=280)
out=f'{base}/slide'; os.makedirs(out,exist_ok=True)
subprocess.run(['pdftoppm','-png','-scale-to-x','1920','-scale-to-y','1080',pdf,f'{out}/p'],check=True)
for f in sorted(os.listdir(out)):
    if f.startswith('p-'):
        k=int(f[2:-4]); os.replace(f'{out}/{f}',f'{out}/{k:02d}.png')
# 2) cornice: una slide di testo svuotata
prs=Presentation(pptx)
idx=2 if len(prs.slides)>2 else 1
s=prs.slides[idx]
for sh in list(s.shapes): sh._element.getparent().remove(sh._element)
ids=prs.slides._sldIdLst
for i,sid in reversed(list(enumerate(list(ids)))):
    if i!=idx: ids.remove(sid)
prs.save(f'{base}/cornice.pptx')
subprocess.run(['soffice',f'-env:UserInstallation=file:///tmp/lo{n}','--headless','--convert-to','pdf','--outdir',base,f'{base}/cornice.pptx'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=200)
subprocess.run(['pdftoppm','-png','-singlefile','-scale-to-x','1920','-scale-to-y','1080',f'{base}/cornice.pdf',f'{out}/cornice'],check=True)
print(n,'slide:',len([f for f in os.listdir(out) if f[0].isdigit()]))
# 3) cornice pulita: base di Lez20 + numero lezione di questa lezione
from PIL import Image
ref=Image.open(f'{os.environ["S"]}/lez20/slide/cornice.png').convert('RGB'); new=Image.open(f'{out}/cornice.png').convert('RGB')
ref.paste(new.crop((0,995,420,1045)),(0,995)); ref.save(f'{out}/cornice.png')
