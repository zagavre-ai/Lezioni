import sys, os, json, numpy as np
sys.path.insert(0, os.environ['S']+'/tools')
import frames
def fmt(t): return f'{t//3600}:{(t%3600)//60:02d}:{t%60:02d}'
def analyze(n):
    a=frames.load(n); T=len(a)
    blackR=np.zeros(T); whiteS=np.zeros(T); cnt=np.zeros(T)
    prev=None
    for i in range(0,T,200):
        ch=np.asarray(a[i:i+200]).astype(np.int16).mean(axis=3)
        B=str(n) in os.environ.get('LAYB','').split(',')
        blackR[i:i+200]=1.0 if B else (ch[:,90:230,432:476]<25).mean(axis=(1,2))
        S=ch[:,20:236,4:365] if B else ch[:,20:236,4:414]
        whiteS[i:i+200]=(S>235).mean(axis=(1,2))
        full=S if prev is None else np.concatenate([prev[None],S])
        d=(np.abs(full[1:]-full[:-1])>50).sum(axis=(1,2))
        if prev is None: cnt[i+1:i+200]=d
        else: cnt[i:i+200]=d
        prev=S[-1]
    isB=(blackR>0.9)&(whiteS>0.3)
    k=np.convolve(isB.astype(float),np.ones(5)/5,'same')>0.5
    return dict(T=T,isB=k,cnt=cnt,whiteS=whiteS,blackR=blackR)
def segments(mask):
    out=[];s=None
    for t,v in enumerate(mask):
        if v and s is None: s=t
        if not v and s is not None: out.append((s,t-1)); s=None
    if s is not None: out.append((s,len(mask)-1))
    return out
def events(d,thr=250,gap=2):
    k=d['isB']; cnt=d['cnt']; ev=[]
    for (s,e) in segments(k):
        t=s+1; 
        ev.append((s,'inizioB'))
        while t<=e:
            if cnt[t]>thr:
                st=t; last=t
                while t<=e and (cnt[t]>thr or t-last<=gap):
                    if cnt[t]>thr: last=t
                    t+=1
                ev.append((st,'cambio',last+1))
            else: t+=1
    return ev
if __name__=='__main__':
    for n in sys.argv[1:]:
        d=analyze(int(n)); segs=segments(d['isB']); ev=events(d)
        print(f'--- Lez{n}: durata {fmt(d["T"])}  segmenti slide: '+', '.join(f'{fmt(s)}-{fmt(e)}' for s,e in segs))
        print('   eventi cambio:',len([e for e in ev if e[1]=="cambio"]))
