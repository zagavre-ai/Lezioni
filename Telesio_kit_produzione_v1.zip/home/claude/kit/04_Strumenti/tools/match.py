import sys, os, json, re, subprocess, math
sys.path.insert(0, os.environ['S']+'/tools')
import detect
from multiprocessing import Pool
from PIL import Image
from pptx import Presentation
S=os.environ['S']
def slide_texts(n):
    prs=Presentation(f'{S}/l{n}/Inglese_Lez{n}.pptx'); out=[]
    for s in prs.slides:
        parts=[]
        for sh in s.shapes:
            if not sh.has_text_frame: 
                if sh.has_table:
                    for r in sh.table.rows:
                        for c in r.cells: parts.append(c.text_frame.text)
                continue
            t=sh.text_frame.text.strip()
            if not t or re.fullmatch(r'Pagina \d+',t) or re.match(r'^\d\d · ',t): continue
            parts.append(t)
        out.append(' '.join(parts))
    return out
def toks(t):
    return [w for w in re.sub(r'[^a-z0-9àèéìòù]+',' ',t.lower()).split() if len(w)>=3]
def ocr_frame(args):
    n,t=args
    f=f'{S}/l{n}/ev/{t:05d}.png'
    if not os.path.exists(f):
        os.makedirs(f'{S}/l{n}/ev',exist_ok=True)
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',f'{S}/l{n}/anteprima.mp4','-frames:v','1',f],check=True)
    tf=f+'.txt'
    if os.path.exists(tf): return t,open(tf).read()
    im=Image.open(f).convert('L').crop((0,34,836,474)); im=im.resize((im.width*3,im.height*3),Image.LANCZOS); im.save(f+'.c.png')
    txt=subprocess.run(['tesseract',f+'.c.png','-','--psm','6','-l','eng'],capture_output=True,text=True).stdout
    open(tf,'w').write(txt); return t,txt
def cos(a,b):
    A={};B={}
    for w in a: A[w]=A.get(w,0)+1
    for w in b: B[w]=B.get(w,0)+1
    num=sum(min(A[w],B[w]) for w in A if w in B)
    return num/math.sqrt(max(1,len(a))*max(1,len(b)))
def run(n):
    d=detect.analyze(n); ev=detect.events(d)
    pts=[]
    for e in ev:
        if e[1]=='inizioB': pts.append((e[0],'inizioB',min(e[0]+2,d['T']-1)))
        else: pts.append((e[0],'cambio',min(e[2]+1,d['T']-1)))
    with Pool(2) as p: res=dict(p.map(ocr_frame,[(n,x[2]) for x in pts]))
    st=slide_texts(n); stk=[toks(x) for x in st]
    rows=[]
    for (t0,kind,ts) in pts:
        o=toks(res[ts]); sc=[cos(o,s) for s in stk]
        order=sorted(range(len(sc)),key=lambda i:-sc[i])
        rows.append(dict(t=t0,kind=kind,ts=ts,best=order[0]+1,sc=round(sc[order[0]],2),second=order[1]+1,sc2=round(sc[order[1]],2),ocr=' '.join(res[ts].split())[:70],full=' '.join(res[ts].split())))
    json.dump(rows,open(f'{S}/l{n}/events.json','w'),indent=0,ensure_ascii=False)
    return rows,st
if __name__=='__main__':
    for n in sys.argv[1:]:
        rows,st=run(int(n)); print(f'=== Lez{n}: {len(st)} slide')
        for r in rows: print(f"{detect.fmt(r['t'])} {r['kind'][:3]} -> {r['best']:>2} ({r['sc']}) | alt {r['second']:>2} ({r['sc2']}) | {r['ocr']}")
