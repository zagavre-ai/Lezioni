import sys,os,re
import numpy as np
from PIL import Image
S=os.environ['S']; sys.path.insert(0,S+'/tools')
import match,align,subprocess
def sec(s): h,m,x=map(int,s.split(':')); return h*3600+m*60+x
for n in map(int,sys.argv[1:]):
    a=np.load(f'{S}/l{n}/frames_480.npy',mmap_mode='r'); st=match.slide_texts(n); stk=[match.toks(x) for x in st]
    bad=[]
    for line in open(f'{S}/l{n}/tempi.txt'):
        m=re.match(r'(\d+:\d\d:\d\d) (slide|copertina) (\d+)\.png',line)
        if not m: continue
        t=sec(m.group(1)); k=int(m.group(3))-1
        res=[]
        for dt in (3,):
            f=f'/tmp/chk_{n}_{t+dt}.png'
            im=Image.fromarray(np.array(a[min(t+dt,len(a)-1)])).convert('L').resize((1440,810)); im.save(f)
            txt=subprocess.run(['tesseract',f,'-','--psm','6','-l','eng'],capture_output=True,text=True).stdout
            o=match.toks(txt); sc=[align.prec_score(o,s) for s in stk]
            best=max(range(len(stk)),key=lambda j:sc[j])
            if best!=k and sc[k]<0.5: bad.append((m.group(1),k+1,round(sc[k],2),best+1,round(sc[best],2)))
    print(n,bad)
