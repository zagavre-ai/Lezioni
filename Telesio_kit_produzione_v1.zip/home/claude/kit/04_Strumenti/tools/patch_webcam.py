import sys
p=sys.argv[1]; s=open(p).read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:70]
    s=s.replace(old,new)
rep("""    $1=="WEBCAM" { wx=$2; wy=$3; ww=$4; wh=$5; next }
""","""    $1=="WEBCAM" { wx=$2; wy=$3; ww=$4; wh=$5; next }
    # cambio di dimensione del riquadro webcam a meta' lezione: "H:MM:SS webcam x y w h"
    $2=="webcam" { nw++; vt[nw]=sec($1); vx[nw]=$3; vy[nw]=$4; vw[nw]=$5; vh[nw]=$6; next }
""")
rep("""      print "WX=" wx; print "WY=" wy; print "WW=" ww; print "WH=" wh
""","""      print "WX=" wx; print "WY=" wy; print "WW=" ww; print "WH=" wh
      if (nw>0) {
        # periodi: 0 = riga WEBCAM, poi i cambi. Ritaglio 4:3 della stessa misura per tutti,
        # centrato sul riquadro del momento (bordo di 4 pixel tolto come sempre)
        px[0]=wx+4; py[0]=wy+4; pw[0]=ww-8; ph[0]=wh-8
        for (k=1;k<=nw;k++){ px[k]=vx[k]+4; py[k]=vy[k]+4; pw[k]=vw[k]-8; ph[k]=vh[k]-8 }
        mh=ph[0]; mw=pw[0]
        for (k=1;k<=nw;k++){ if (ph[k]<mh) mh=ph[k]; if (pw[k]<mw) mw=pw[k] }
        c=int(mh*4/3/2)*2; if (c>mw) c=mw; mh=int(mh/2)*2
        XE=""; YE=""
        for (k=nw;k>=0;k--){
          cx=int(px[k]+(pw[k]-c)/2); cy=int(py[k]+(ph[k]-mh)/2); if (cy<0) cy=0
          if (k==nw) { XE=cx; YE=cy }
          else { XE="if(lt(t," vt[k+1] ")," cx "," XE ")"; YE="if(lt(t," vt[k+1] ")," cy "," YE ")" }
        }
        print "VCW=" c; print "VCH=" mh; print "VXE=\\"" XE "\\""; print "VYE=\\"" YE "\\""
      }
""")
rep("""  CX=$(awk -v x="$WX" -v w="$WW" -v c="$CW" 'BEGIN{print int(x+(w-c)/2)}')
""","""  CX=$(awk -v x="$WX" -v w="$WW" -v c="$CW" 'BEGIN{print int(x+(w-c)/2)}')
  CAMCROP="crop=${CW}:${WH}:${CX}:${WY}"
  # riquadro webcam che cambia misura durante la lezione
  [ -n "$VXE" ] && CAMCROP="crop=w=${VCW}:h=${VCH}:x='${VXE}':y='${VYE}'"
""")
rep("""[src1]crop=${CW}:${WH}:${CX}:${WY},scale=332:249""","""[src1]${CAMCROP},scale=332:249""")
rep("""[src2]crop=${CW}:${WH}:${CX}:${WY},scale=332:249""","""[src2]${CAMCROP},scale=332:249""")
open(p,'w').write(s)
