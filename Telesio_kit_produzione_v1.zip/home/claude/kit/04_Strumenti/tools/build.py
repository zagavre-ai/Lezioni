import sys,os,json,re
import numpy as np
S=os.environ['S']; sys.path.insert(0,S+'/tools')
import align,match
def fmt(t): return f'{t//3600}:{t%3600//60:02d}:{t%60:02d}'
RUNS={21:(227,'0:48:42'),22:(99,'0:52:29'),23:(193,'1:01:25'),24:(422,'0:57:07'),25:(147,'0:56:06'),27:(366,'1:05:11'),28:(237,'0:54:22'),29:(139,'0:53:32'),30:(109,'0:57:00')}
def sec(s): h,m,x=map(int,s.split(':')); return h*3600+m*60+x
TITLES={21:'Comparative & superlative',22:'-ing/-ed, preposizioni + -ing, used to',23:'',24:'',25:'',27:'',28:'',29:'',30:''}
out={}
for n in map(int,sys.argv[1:]):
    rows,seq,sc,K=align.align(n); st=match.slide_texts(n)
    first={}
    for r,s,c in zip(rows,seq,sc):
        if s not in first: first[s]=r['t']
    R=RUNS.get(n)
    if R: fe=R[0]; endt=sec(R[1])
    else:
        rj=json.load(open(f'{S}/l{n}/run.json')); fe=rj['fe']; endt=rj['end']
    t={}
    cover=fe+3
    t[0]=cover
    for k,v in first.items():
        if k>0 and v>cover and v<endt: t[k]=v
    t[K-1]=min(t.get(K-1,endt-14),endt-8) if K-1 in t and t[K-1]<endt else endt-14
    est=set()
    for k in range(1,K-1):
        if k in t and t[k]>=t[K-1]: del t[k]
    for k in range(K):
        if k in t: continue
        a=max(j for j in t if j<k); b=min(j for j in t if j>k)
        miss=[j for j in range(a+1,b) if j not in t]
        i=miss.index(k)+1
        tk=int(t[a]+(t[b]-t[a])*i/(len(miss)+1))
        ntok=len(match.toks(st[k]))
        if ntok<=8 and k==min(miss) and k+1==b: tk=t[b]-5
        t[k]=tk; est.add(k)
    # ordine crescente
    prev=-1
    for k in range(K):
        if t[k]<=prev: t[k]=prev+1; est.add(k)
        prev=t[k]
    L=[f'# Inglese_Lez{n} - Inglese · Lezione {n}','# registrazione Teams: la webcam e\' il riquadro piccolo a destra','WEBCAM 1676 96 240 136',
       '# inizio: la docente a tutto schermo (resta intera, dentro la cornice)','0:00:00 animazione']
    for k in range(K):
        if k in est: L.append('# ATTENZIONE: tempo stimato (da verificare)')
        L.append(f'{fmt(t[k])} {"copertina" if k==0 else "slide"} {k+1:02d}.png')
    L+=['# saluti finali: la docente a tutto schermo (resta intera, dentro la cornice)',f'{fmt(endt)} animazione']
    open(f'{S}/l{n}/tempi.txt','w').write('\n'.join(L)+'\n')
    out[n]=[k+1 for k in sorted(est)]
    print(n,'stimate:',out[n])
json.dump(out,open(S+'/estimates.json','w'))
