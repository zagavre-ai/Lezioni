import sys, os, json, re, math
sys.path.insert(0, os.environ['S']+'/tools')
import detect, match
S=os.environ['S']
def prec_score(o,sl):
    if not o: return 0.0
    B=set(sl); m=sum(1 for w in set(o) if w in B)
    return (m/len(set(o)))*min(1.0,m/max(2,min(6,len(set(sl)))))
def align(n):
    rows=match.run(n)[0] if not os.path.exists(f'{S}/l{n}/events.json') or 'full' not in json.load(open(f'{S}/l{n}/events.json'))[0] else json.load(open(f'{S}/l{n}/events.json'))
    st=match.slide_texts(n); stk=[match.toks(x) for x in st]; K=len(stk)
    sc=[[prec_score(match.toks(r['full']),stk[k]) for k in range(K)] for r in rows]
    # DP non decrescente
    m=len(rows); NEG=-1e9
    best=[[NEG]*K for _ in range(m)]; prv=[[0]*K for _ in range(m)]
    for k in range(K): best[0][k]=sc[0][k]-0.02*k
    for i in range(1,m):
        run=NEG;arg=0
        for k in range(K):
            if best[i-1][k]>run: run=best[i-1][k];arg=k
            best[i][k]=run+sc[i][k]-0.01*0; prv[i][k]=arg
    k=max(range(K),key=lambda j:best[m-1][j]); seq=[0]*m
    for i in range(m-1,-1,-1):
        seq[i]=k; k=prv[i][k]
    return rows,seq,sc,K
if __name__=='__main__':
    for n in sys.argv[1:]:
        n=int(n); rows,seq,sc,K=align(n)
        print(f'=== Lez{n} ({K} slide)')
        first={}
        for r,s,c in zip(rows,seq,sc):
            if s not in first: first[s]=(r['t'],c[s])
            flag='  <-- basso' if c[s]<0.45 else ''
            print(f"{detect.fmt(r['t'])} -> {s+1:>2} ({c[s]:.2f}){flag} | {r['ocr'][:50]}")
        print('PRIMA COMPARSA:', ', '.join(f'{k+1}:{detect.fmt(v[0])}' for k,v in sorted(first.items())))
        print('SLIDE SENZA EVENTO:', [k+1 for k in range(K) if k not in first])
