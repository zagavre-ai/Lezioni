import os, subprocess, numpy as np
S=os.environ['S']
def load(n, w=480, h=270):
    cache=f'{S}/l{n}/frames_{w}.npy'
    if os.path.exists(cache): return np.load(cache,mmap_mode='r')
    p=subprocess.run(['ffmpeg','-v','error','-i',f'{S}/l{n}/anteprima.mp4','-vf',f'fps=1,scale={w}:{h}','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE,check=True)
    a=np.frombuffer(p.stdout,np.uint8).reshape(-1,h,w,3)
    np.save(cache,a); return a
