import sys, os, subprocess
import numpy as np
from PIL import Image, ImageFont, ImageDraw
S=os.environ['S']; SRC=f'{S}/lez20/sigla_iniziale.mp4'; FR=f'{S}/lez20/sg'
F='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
font=ImageFont.truetype(F,64)
Y0,Y1=622,742; X0,X1=560,1360
frames=[np.array(Image.open(f'{FR}/f{i:03d}.png').convert('RGB')).astype(np.float32) for i in range(1,211)]
final=frames[150]
gf=final.mean(axis=2)[Y0:Y1]
color=np.median(final[Y0:Y1][gf<60],axis=0)
ys=np.arange(Y0,Y1)
def ink_profile(f):
    return (255-f.mean(axis=2)[Y0:Y1,X0:X1]).clip(0,None).sum(axis=1)
pf=ink_profile(final); inkf=pf.sum(); cyf=(ys*pf).sum()/inkf
alpha=[];dy=[]
for f in frames:
    p=ink_profile(f); ink=p.sum()
    alpha.append(ink/inkf)
    dy.append(((ys*p).sum()/ink-cyf) if ink>0.05*inkf else 0.0)
alpha=np.clip(np.array(alpha),0,1); dy=np.array(dy)
k=np.ones(3)/3
alpha_s=np.convolve(np.pad(alpha,1,mode='edge'),k,'valid'); dy_s=np.convolve(np.pad(dy,1,mode='edge'),k,'valid')
dy_s[alpha_s<0.05]=0; alpha_s[alpha_s<0.03]=0
DY=np.round(dy_s).astype(int)
def coverage(text,shift):
    bb=font.getbbox(text); x=960-(bb[0]+bb[2])/2
    im=Image.new('L',(1920,Y1-Y0),0); ImageDraw.Draw(im).text((x,640+2-Y0+shift),text,font=font,fill=255)
    return np.array(im).astype(np.float32)/255
def build(num,out):
    text=f'INGLESE · LEZIONE {num}'
    cache={}
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','30','-i','-','-i',SRC,
         '-map','0:v','-map','1:a','-c:v','libx264','-preset','medium','-crf','15','-pix_fmt','yuv420p','-c:a','copy','-t','7','-movflags','+faststart',out]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
    for f,a,s in zip(frames,alpha_s,DY):
        h=f.copy()
        if a>0:
            h[Y0:Y1,300:1620]=255
            if s not in cache: cache[s]=coverage(text,int(s))[...,None]
            c=cache[s]*a
            h[Y0:Y1]=h[Y0:Y1]*(1-c)+color*c
        p.stdin.write(np.clip(h,0,255).astype(np.uint8).tobytes())
    p.stdin.close(); p.wait()
if __name__=='__main__':
    print('colore',color,'dy range',DY.min(),DY.max(),'primo>0',int(np.argmax(alpha_s>0)))
    for n in sys.argv[1:]:
        out=f'{S}/l{n}/sigla_iniziale.mp4'; build(n,out); print('ok',n)
