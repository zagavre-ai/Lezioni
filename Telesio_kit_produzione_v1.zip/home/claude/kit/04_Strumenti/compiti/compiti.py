"""Compiti PDF (Word) -> PDF A4 nella grafica delle dispense Telesio.
Uso: python3 -I compiti.py input.pdf output.pdf "Materia – Docente" "TITOLO PIE' DI PAGINA" [json_debug]
"""
import base64, html, io, json, re, subprocess, sys
from PIL import Image

LOGO = '/tmp/claude-0/-home-claude/8c6bed57-912f-536e-ba3b-2ab57087e318/scratchpad/comp/media/image-1003-1.png'
BLU, ACC, TXT, GRIG, BORD = '#0A1D37', '#003366', '#1A1A1A', '#F8F9FA', '#CBD5E1'

ITEM = re.compile(r'^\s*(?:[•●▪◦\-–]\s*)?(?:(\d{1,2})[.)]\s+)?(.*)$')
BULLET = re.compile(r'^\s*[•●▪◦]\s*')
NUM = re.compile(r'^\s*(?:[•●▪◦]\s*)?(\d{1,2})[.)]\s+')
VF = re.compile(r'\s+V\s+F\s*$')


def leggi(pdf):
    t = subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True).stdout
    return [l.rstrip() for l in t.replace('\f', '\n').split('\n')]


def is_bank(l):
    parti = [p.strip() for p in re.split(r'\s+[–—-]\s+|\s*/\s*|\s*;\s*', l.strip()) if p.strip()]
    return len(parti) >= 3 and all(len(p.split()) <= 3 for p in parti) and not NUM.match(l) and not BULLET.match(l)


def analizza(righe):
    titolo, es, sol, cur, mode = None, [], {}, None, 'es'
    solcur = None
    for raw in righe:
        l = raw.strip()
        if not l:
            if cur is not None:
                cur['_gap'] = True
            continue
        if titolo is None and not l.lower().startswith('esercizio'):
            titolo = l
            continue
        if re.match(r'^soluzion[ei]\b', l, re.I):
            mode = 'sol'
            continue
        m = re.match(r'^esercizio\s+(\d+)\s*(.*)$', l, re.I)
        if m and mode == 'es':
            cur = {'n': int(m.group(1)), 'extra': m.group(2).strip(' :.'), 'istr': [], 'bank': None, 'items': [], '_gap': False}
            es.append(cur)
            continue
        if m and mode == 'sol':
            solcur = int(m.group(1))
            sol[solcur] = ''
            continue
        if mode == 'sol':
            if solcur is not None:
                sol[solcur] += ' ' + l
            continue
        if cur is None:
            continue
        if is_bank(l) and not cur['items']:
            cur['bank'] = [p.strip() for p in re.split(r'\s+[–—-]\s+|\s*/\s*|\s*;\s*', l) if p.strip()]
            continue
        nm = NUM.match(raw)
        bl = BULLET.match(raw)
        if l in ('•', '●', '▪'):
            cur['_newitem'] = True
            continue
        if nm or bl or cur.pop('_newitem', False):
            testo = l
            num = None
            if nm:
                num = int(nm.group(1)); testo = raw[nm.end():].strip()
            elif bl:
                testo = raw[bl.end():].strip()
            cur['items'].append({'num': num, 't': testo})
            cur['_gap'] = False
            continue
        if cur['items'] and not cur.get('_gap'):
            cur['items'][-1]['t'] += ' ' + l
        elif not cur['items']:
            cur['istr'].append(l)
        else:
            cur['items'][-1]['t'] += ' ' + l
        cur['_gap'] = False
    # pulizia
    for e in es:
        e['istr'] = ' '.join(e['istr'])
        vf = 'vero' in e['istr'].lower() or '(v)' in e['istr'].lower()
        e['tipo'] = 'vf' if vf else ('completa' if any('___' in i['t'] for i in e['items']) else 'lista')
        for i in e['items']:
            t = re.sub(r'\s+', ' ', i['t']).strip()
            t = VF.sub('', t)
            t = re.sub(r'\s+V$', '', t) if vf else t
            t = re.sub(r'\s+([.,;:!?])', r'\1', t)
            i['t'] = t
        # numeri originali -> nuovi
        e['mappa'] = {}
        for k, i in enumerate(e['items'], 1):
            if i['num'] is not None:
                e['mappa'][i['num']] = k
        for k in ('_gap', '_newitem'):
            e.pop(k, None)
    soluzioni = {}
    for n, testo in sol.items():
        coppie = re.findall(r'(\d{1,2})[.)]\s*(.+?)(?=\s+\d{1,2}[.)]\s|$)', testo.strip())
        e = next((x for x in es if x['n'] == n), None)
        mp = e['mappa'] if e else {}
        soluzioni[n] = [(mp.get(int(a), int(a)), b.strip()) for a, b in coppie]
    return titolo, es, soluzioni


def blank(t):
    t = html.escape(t)
    return re.sub(r'_{3,}', '<span class="bl"></span>', t)


def costruisci(titolo, es, sol, docente, piede, sottotitolo):
    lg = Image.open(LOGO).convert('RGBA')
    lg = lg.crop(lg.getbbox()); lg.thumbnail((700, 700))
    b = io.BytesIO(); lg.save(b, 'PNG')
    logo = 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()
    corpo = []
    for e in es:
        corpo.append('<section class="es">')
        corpo.append(f'<h2>Esercizio {e["n"]}</h2>')
        if e['istr']:
            corpo.append(f'<p class="istr">{html.escape(e["istr"])}</p>')
        if e['bank']:
            corpo.append('<div class="bank"><span class="lab">PAROLE DA USARE</span>' +
                         ''.join(f'<span class="w">{html.escape(w)}</span>' for w in e['bank']) + '</div>')
        corpo.append('<table class="it">')
        for k, i in enumerate(e['items'], 1):
            if e['tipo'] == 'vf':
                corpo.append(f'<tr><td class="n">{k}.</td><td>{blank(i["t"])}</td>'
                             f'<td class="vf"><span>V</span><span>F</span></td></tr>')
            else:
                corpo.append(f'<tr><td class="n">{k}.</td><td>{blank(i["t"])}</td></tr>')
        corpo.append('</table></section>')
    soltab = []
    for e in es:
        r = sol.get(e['n'], [])
        if not r:
            continue
        celle = ''.join(f'<td><b>{n}.</b> {html.escape(a)}</td>' for n, a in r)
        soltab.append(f'<h2>Esercizio {e["n"]}</h2><table class="sol"><tr>{celle}</tr></table>')
    css = f"""
@page {{ size: A4; margin: 116pt 57pt 100pt 57pt; }}
@page :first {{ margin-top: 102pt; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; font-family: Arial, 'Liberation Sans', sans-serif; color:{TXT}; font-size:11pt; line-height:1.45;
  -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
.tit {{ min-height:74pt; display:flex; flex-direction:column; justify-content:flex-end; }}
h1 {{ font-size:28pt; line-height:1.15; color:{BLU}; margin:0; font-weight:bold; }}
.bar {{ width:69pt; height:2.5pt; background:{BLU}; margin:8pt 0 0; }}
.sub {{ margin:14pt 0 4pt; color:{ACC}; font-size:12pt; font-weight:bold; }}
h2 {{ font-size:12pt; color:{ACC}; margin:20pt 0 4pt; font-weight:bold; break-after:avoid; }}
.es {{ break-inside:avoid; }}
.istr {{ margin:0 0 8pt; }}
.bank {{ background:{GRIG}; border:0.75pt solid {BORD}; padding:7pt 10pt; margin:0 0 8pt; display:flex; flex-wrap:wrap; gap:4pt 18pt; align-items:center; }}
.bank .lab {{ font-size:8pt; letter-spacing:1.6pt; font-weight:bold; color:{ACC}; margin-right:4pt; }}
.bank .w {{ font-weight:bold; color:{BLU}; }}
table {{ border-collapse:collapse; width:100%; }}
table.it td {{ border-bottom:0.75pt solid {BORD}; padding:6pt 6pt 6pt 0; vertical-align:top; }}
table.it tr:first-child td {{ border-top:0.75pt solid {BORD}; }}
td.n {{ width:22pt; color:{ACC}; font-weight:bold; }}
td.vf {{ width:62pt; white-space:nowrap; text-align:right; }}
td.vf span {{ display:inline-block; width:19pt; height:19pt; line-height:17pt; text-align:center; border:0.75pt solid #CBD5E2;
  border-radius:50%; margin-left:6pt; font-weight:bold; color:{BLU}; font-size:9.5pt; }}
.bl {{ display:inline-block; width:62pt; border-bottom:0.9pt solid #1A1A1B; margin:0 2pt; transform:translateY(-2pt); }}
.solpage {{ break-before:page; }}
table.sol td {{ border:0.75pt solid {BORD}; padding:5pt 8pt; font-size:10.5pt; }}
table.sol td b {{ color:{ACC}; }}
"""
    sub = f'<div class="sub">{html.escape(sottotitolo)}</div>' if sottotitolo else ''
    doc = f"""<!doctype html><html lang="it"><head><meta charset="utf-8"><style>{css}</style></head><body>
<div class="tit"><h1>Compiti</h1></div><div class="bar"></div>{sub}
{''.join(corpo)}
<div class="solpage"><div class="tit"><h1>Soluzioni</h1></div><div class="bar"></div>{''.join(soltab)}</div>
</body></html>"""
    head = f"""<div style="width:100%;margin:0 57pt;position:relative;height:116pt;font-family:Arial,'Liberation Sans';-webkit-print-color-adjust:exact;">
<img src="{logo}" style="position:absolute;left:0;top:57pt;height:22.5pt;">
<div style="position:absolute;right:0;top:63pt;font-size:8pt;color:{ACC};">{html.escape(docente)}</div>
<div style="position:absolute;left:0;right:0;top:85pt;border-top:0.75pt solid {BORD};"></div></div>"""
    foot = f"""<div style="width:100%;margin:0 57pt;position:relative;height:100pt;font-family:Arial,'Liberation Sans';-webkit-print-color-adjust:exact;">
<div style="position:absolute;left:0;right:0;top:20pt;border-top:0.75pt solid {BORD};"></div>
<div style="position:absolute;left:0;top:28pt;font-size:7pt;color:{ACC};">{html.escape(piede)}</div>
<div style="position:absolute;right:0;top:27pt;font-size:8pt;font-weight:bold;color:{BLU};">Pagina&nbsp;<span class="pageNumber"></span></div></div>"""
    return doc, head, foot


def stampa(doc, head, foot, out):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        br = p.chromium.launch(); pg = br.new_page()
        pg.set_content(doc, wait_until='load')
        pg.pdf(path=out, format='A4', print_background=True, display_header_footer=True,
               header_template=head, footer_template=foot, prefer_css_page_size=True)
        br.close()


if __name__ == '__main__':
    inp, out, docente, piede = sys.argv[1:5]
    sottot = sys.argv[5] if len(sys.argv) > 5 else ''
    titolo, es, sol = analizza(leggi(inp))
    json.dump({'titolo': titolo, 'es': es, 'sol': sol}, open(out + '.json', 'w'), ensure_ascii=False, indent=1)
    stampa(*costruisci(titolo, es, sol, docente, piede, sottot), out)
    print('ok', out)
