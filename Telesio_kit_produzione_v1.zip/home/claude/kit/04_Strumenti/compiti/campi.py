"""Rende compilabile il PDF dei compiti: campi di testo sulle righe ___ e
scelta V/F (si cerchia la lettera con un clic). Uso: campi.py in.pdf out.pdf"""
import sys
import pdfplumber
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (ArrayObject, BooleanObject, DecodedStreamObject, DictionaryObject,
                           FloatObject, NameObject, NumberObject, TextStringObject)

BL = (0.102, 0.102, 0.106)   # #1A1A1B righe da completare
CI = (0.7961, 0.8353, 0.8863)  # #CBD5E2 cerchi V/F


def vicino(c, rif):
    try:
        return c is not None and len(c) == 3 and all(abs(a - b) < 0.004 for a, b in zip(c, rif))
    except TypeError:
        return False


def trova(pdf):
    out = []
    with pdfplumber.open(pdf) as d:
        for pg in d.pages:
            H = float(pg.height)
            bl = [r for r in pg.rects if vicino(r.get('non_stroking_color'), BL) and r['width'] > 20]
            ci = [c for c in pg.curves if vicino(c.get('stroking_color'), CI) or vicino(c.get('non_stroking_color'), CI)]
            # cerchi: deduplica per bbox
            seen, cer = set(), []
            for c in ci:
                k = (round(c['x0']), round(c['top']))
                if k not in seen and 12 < c['x1'] - c['x0'] < 30:
                    seen.add(k); cer.append(c)
            cer.sort(key=lambda c: (round(c['top']), c['x0']))
            coppie, i = [], 0
            while i + 1 < len(cer):
                a, b = cer[i], cer[i + 1]
                if abs(a['top'] - b['top']) < 3:
                    coppie.append((a, b)); i += 2
                else:
                    i += 1
            out.append((H, sorted(bl, key=lambda r: (round(r['top']), r['x0'])), coppie))
    return out


def stream(w, contenuto, bbox):
    s = DecodedStreamObject()
    s.set_data(contenuto.encode())
    s.update({NameObject('/Type'): NameObject('/XObject'), NameObject('/Subtype'): NameObject('/Form'),
              NameObject('/BBox'): ArrayObject([FloatObject(v) for v in bbox])})
    return w._add_object(s)


def main(inp, out):
    info = trova(inp)
    w = PdfWriter(clone_from=PdfReader(inp))
    font = w._add_object(DictionaryObject({NameObject('/Type'): NameObject('/Font'), NameObject('/Subtype'): NameObject('/Type1'),
                                           NameObject('/BaseFont'): NameObject('/Helvetica'),
                                           NameObject('/Encoding'): NameObject('/WinAnsiEncoding')}))
    campi = ArrayObject()
    nt = nr = 0
    for p, (H, bl, coppie) in enumerate(info):
        page = w.pages[p]
        annots = page.get('/Annots')
        annots = annots.get_object() if annots is not None else ArrayObject()
        for r in bl:
            nt += 1
            x0, x1 = r['x0'] - 1, r['x1'] + 1
            y0 = H - r['bottom'] + 0.5
            rect = [x0, y0, x1, y0 + 14]
            f = DictionaryObject({
                NameObject('/Type'): NameObject('/Annot'), NameObject('/Subtype'): NameObject('/Widget'),
                NameObject('/FT'): NameObject('/Tx'), NameObject('/T'): TextStringObject(f'riga_{nt}'),
                NameObject('/Rect'): ArrayObject([FloatObject(v) for v in rect]),
                NameObject('/F'): NumberObject(4), NameObject('/Ff'): NumberObject(0),
                NameObject('/DA'): TextStringObject('/Helv 10 Tf 0.039 0.114 0.216 rg'),
                NameObject('/Q'): NumberObject(1), NameObject('/P'): page.indirect_reference,
            })
            ref = w._add_object(f); annots.append(ref); campi.append(ref)
        for a, b in coppie:
            nr += 1
            padre = DictionaryObject({NameObject('/FT'): NameObject('/Btn'), NameObject('/Ff'): NumberObject(49152),
                                      NameObject('/T'): TextStringObject(f'vf_{nr}'), NameObject('/V'): NameObject('/Off'),
                                      NameObject('/Kids'): ArrayObject()})
            pref = w._add_object(padre)
            for c, val in ((a, 'V'), (b, 'F')):
                x0, x1 = c['x0'], c['x1']
                y0, y1 = H - c['bottom'], H - c['top']
                wd, ht = x1 - x0, y1 - y0
                cx, cy, rr = wd / 2, ht / 2, min(wd, ht) / 2 + 0.2
                k = 0.5523 * rr
                cerchio = (f'0.039 0.114 0.216 RG 1.6 w {cx + rr:.2f} {cy:.2f} m '
                           f'{cx + rr:.2f} {cy + k:.2f} {cx + k:.2f} {cy + rr:.2f} {cx:.2f} {cy + rr:.2f} c '
                           f'{cx - k:.2f} {cy + rr:.2f} {cx - rr:.2f} {cy + k:.2f} {cx - rr:.2f} {cy:.2f} c '
                           f'{cx - rr:.2f} {cy - k:.2f} {cx - k:.2f} {cy - rr:.2f} {cx:.2f} {cy - rr:.2f} c '
                           f'{cx + k:.2f} {cy - rr:.2f} {cx + rr:.2f} {cy - k:.2f} {cx + rr:.2f} {cy:.2f} c S')
                on = stream(w, cerchio, [0, 0, wd, ht])
                off = stream(w, '', [0, 0, wd, ht])
                kid = DictionaryObject({
                    NameObject('/Type'): NameObject('/Annot'), NameObject('/Subtype'): NameObject('/Widget'),
                    NameObject('/Parent'): pref, NameObject('/F'): NumberObject(4),
                    NameObject('/Rect'): ArrayObject([FloatObject(v) for v in (x0, y0, x1, y1)]),
                    NameObject('/AS'): NameObject('/Off'), NameObject('/P'): page.indirect_reference,
                    NameObject('/MK'): DictionaryObject(),
                    NameObject('/AP'): DictionaryObject({NameObject('/N'): DictionaryObject({
                        NameObject('/' + val): on, NameObject('/Off'): off})}),
                })
                kref = w._add_object(kid)
                padre['/Kids'].append(kref); annots.append(kref)
            campi.append(pref)
        page[NameObject('/Annots')] = annots
    w._root_object[NameObject('/AcroForm')] = DictionaryObject({
        NameObject('/Fields'): campi, NameObject('/NeedAppearances'): BooleanObject(True),
        NameObject('/DA'): TextStringObject('/Helv 10 Tf 0 g'),
        NameObject('/DR'): DictionaryObject({NameObject('/Font'): DictionaryObject({NameObject('/Helv'): font})}),
    })
    w.write(out)
    print(f'campi di testo: {nt}  scelte V/F: {nr}')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
