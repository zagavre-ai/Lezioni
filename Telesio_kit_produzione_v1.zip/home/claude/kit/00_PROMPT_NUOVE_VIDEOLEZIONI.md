# PROMPT – NUOVE VIDEOLEZIONI, SLIDE 16:9, DISPENSE A4 E COMPITI
Centro Studi Telesio · aggiornato al 29/10/2026

Incolla questo testo come primo messaggio di una chat nuova e allega `Kit_nuove_videolezioni.zip`.

======================================================================
Ciao Claude. Sono Sara Zagarese del Centro Studi Telesio (Milano).

In un'altra chat lavoro sulle videolezioni "vecchia maniera". In questa ci occupiamo
delle **NUOVE videolezioni**, cioè quelle registrate dai docenti con le nostre
indicazioni (per esempio Spagnolo), e dei materiali che le accompagnano:
- slide 16:9;
- dispensa A4;
- compiti.

Lo ZIP allegato contiene modelli, misure, kit, script ed esempi. Prima di fare
qualsiasi cosa leggi questo messaggio e i file in `05_Documenti`. Poi riassumimi in
5 righe come procederai.

Rispondimi sempre in italiano, in modo semplice e pratico: non sono una
programmatrice. Lavoro su un Mac con macOS Monterey 12.7.6.

## 1. REGOLE FISSE
1. **Il video del docente non si taglia MAI.** Il video finale dura quanto
   l'originale più 7 s di sigla iniziale e 7 s di sigla finale (+14 s).
2. **I contenuti dei docenti non si cambiano.** Niente riassunti, aggiunte o
   riformulazioni. Correggi solo i refusi evidenti e segnalameli in un elenco.
3. **Niente numero di lezione** (decisione della direzione del 29/10/2026). In nessun
   materiale deve comparire "LEZIONE N" o "Lez. N": copertina, sigla, piè di pagina,
   dispense, titolo del file PDF. Al suo posto va solo la MATERIA, per esempio
   "SPAGNOLO". I nomi di file e cartelle invece restano col numero
   (`Spagnolo_Lez1`), perché servono al kit.
4. **Logo:** quello adesivo (sticker) si usa così com'è.
5. **Sul mio Mac non si installa niente.** Si usano solo i file `.command` del kit, con
   ffmpeg nella cartella `bin`. Tutto il resto lo fai tu nel cloud.
6. **I kit restano separati:**
   - kit "vecchia maniera" (Mac + Windows di mio fratello);
   - kit NUOVE registrazioni, da costruire;
   - kit Corpini, solo per la Prof.ssa Caputi (Moda).

   Non mischiarli e non modificare i kit esistenti senza dirmelo.
7. **Prima di consegnare controlla sempre.**
   - Converti in immagini e guarda pagina per pagina.
   - Ascolta o misura l'audio.
   - Prova i comandi su una lezione di prova.

   Deve venire tutto perfetto: "non voglio più tornarci e non voglio avere richiami".
8. **Ogni volta che consegni un kit:**
   - spiegami passo passo cosa sostituire, dove cliccare e in che ordine lanciare i
     comandi;
   - dimmi quanto tempo ci vuole.

## 2. COSA C'È NELLO ZIP

### 01_Modelli
- **Videolezioni 16:9:** `2_Videolezione_16-9_modello.pptx` e il suo PDF. È il modello
  ufficiale dal 22/10/2026; quello vecchio non va più usato.
- **Esempio di videodispensa:** `Esempio_videodispensa_16-9_Letteratura_Lez1.pptx`,
  una lezione già fatta sul modello.
- **Dispensa A4:** `Modello_dispensa_A4_esempio_Inglese_Lez1.pptx` e il suo PDF. È una
  dispensa vera, già senza numero, con i layout "Copertina", "Pagina di testo" e
  "Pagina solo titolo". Usala come modello.
- **`loghi_font`:**
  - `logo_sticker_copertina.png` (1080×1080, trasparente);
  - `logo_orizzontale_blu.png` (intestazioni);
  - `logo_sigla.png`;
  - font Liberation Sans, metricamente uguali ad Arial.

### 02_Video
- **Sigle:**
  - `sigla_modello_Lez20.mp4`: 7 s, 30 fps, 210 fotogrammi, con musica;
  - `sigla_INGLESE.mp4` e `sigla_LETTERATURA.mp4`: già senza numero;
  - `sigla_finale.mp4`: uguale per tutti.
- **Audio:** `musica_sigla.wav` e `sh.rnnn` (modello antirumore RNNoise).
- **Esempio:** `cornice_esempio.png`.

### 03_Kit
- **`Kit_Mac`:** i comandi del kit "vecchia maniera", aggiornati con:
  - `6_Togli_numero_lezione`;
  - la cartella `Titoli`;
  - il segno `RIFARE_VIDEO.txt` nel comando 2.

  Serve come base tecnica per il kit nuovo.
- **`Telesio_Videolezioni_Windows11_aggiornato.zip`:** il kit di mio fratello (Python
  + `.bat`).

### 04_Strumenti
- **`tools/`**, gli script Python:
  - `render.py` e `render_noref.py`: dal PowerPoint alle PNG 1920×1080;
  - `sigla.py` e `sigla2.py`: sigla iniziale;
  - `frames.py`, `detect.py`, `endfind.py`, `match.py`, `align.py`, `build.py`,
    `check.py`, `sheet.py`: rilevamento dei cambi slide;
  - `patch_*.py`.
- **`compiti/`:** `compiti.py` e `campi.py`, dal PDF dei compiti al PDF compilabile.
- **Controlli delle dispense:** `dofix.py`, `tablechk.py`, `chk.py`.

### 05_Documenti
- `linee_guida_maschera_video.md`: tutte le misure del modello 16:9.
- `note_registrazioni_OBS_marcatori.md`: prove OBS di Inglese e Spagnolo e regole F9.
- `kit_nuove_registrazioni.md`: decisione sul kit nuovo.
- `regola_titoli_e_compiti.md`: niente numero di lezione, compiti, Moda.
- `prompt_telesio.md`: prompt per le slide 16:9 e per le dispense A4.
- `prompt_pacchetto_lezione.md`: il pacchetto lezione (`tempi.txt`, slide, sigla).
- `flusso_di_lavoro_letteratura.md`.

### 06_Esempi
- **Compiti:** quelli della docente (originale) e la nostra versione compilabile.
- **Moda, Lez13:** la nostra dispensa e quella della professoressa.
- **Prove video:** prima e dopo, per Spagnolo e per Inglese OBS.

## 3. LE NUOVE REGISTRAZIONI (OBS)

### Come registrano i docenti
- OBS, 1920×1080, 30 fps.
- Solo la webcam a tutto schermo, viso centrato. Nel video non ci sono slide.
- **F9** a ogni cambio di slide o argomento, compresa la slide finale "Grazie per
  l'attenzione". I segni diventano capitoli del file:
  `ffprobe -show_chapters video.mp4`.
- Si va solo avanti con le slide, non si usa F9 per altro, e dopo l'ultimo F9 si
  restano 3–4 s.
- Controllo: numero di F9 = numero di slide − 1. Se non torna, avvisami.

### Prova di Spagnolo (prof.ssa Romina Gisel Luna, 26/10) – APPROVATA
- Codifica: obs_x264, circa 10 Mbit/s.
- Audio: −18,5 LUFS.
- Pause: a silenzio totale (gate di OBS). A 0:49 c'è una ripartenza brusca della voce.
- Immagine: luce forte a destra, con il muro bruciato per circa il 24%. Le abbiamo
  detto di fare attenzione alla luce sulla destra.
- Montaggio di prova: correzione minima del colore (rr 0.99, gg 1.00, bb 1.01,
  gamma 0.90).

### Prova di Inglese (prof.ssa Fontanesi) – APPROVATA
- Audio basso (−26,5 LUFS), ma il kit lo porta a −16.
- La direzione trova l'immagine poco definita: webcam circa 720p e bitrate basso.
- Consigli già pronti per i docenti:
  - webcam a 1920×1080;
  - OBS "Qualità indistinguibile", oppure 15.000–20.000 kbps;
  - aspettare 3–4 s prima di parlare;
  - luce davanti.

### Materiali in arrivo dai docenti
1. **Caso A – le dispense sono già dentro le slide del docente.** Si parte dal suo
   PowerPoint: lo rifai sul modello Telesio 16:9, poi ne ricavi la dispensa A4.
2. **Caso B – il docente manda un file di testo.** Si parte dal testo: prima la dispensa
   A4, poi le slide 16:9, una per paragrafo o concetto, nell'ordine del testo.

### Come agganciare le slide al video
- **Con F9 coerenti:** `tempi.txt` si ricava dai capitoli. Copertina a 0:00:00, poi
  una slide a ogni F9.
- **Senza F9, o con F9 incoerenti:** trascrivi l'audio (nel cloud) e abbina ogni
  slide al momento in cui il docente ne pronuncia il testo.
- Se una slide del docente diventa due slide nostre, stima il secondo cambio e scrivi
  sopra la riga:

  `# ATTENZIONE: tempo stimato (da verificare) - quando arriva a «...»`

### File delle docenti di Spagnolo su OneDrive
Si scaricano i singoli file, non la cartella intera: con la cartella OneDrive crea
uno ZIP che il Mac non apre. Se c'è già uno ZIP, si apre dal Terminale:

`ditto -x -k file.zip cartella`

## 4. MONTAGGIO VIDEO – COME FUNZIONA IL KIT (v2)

### Formato di tempi.txt
- `WEBCAM x y w h`: zona del docente nel video originale. Per OBS a tutto schermo:
  `WEBCAM 0 0 1920 1080`.
- Una riga per ogni cambio: `H:MM:SS copertina|slide|animazione NN.png`.
  - `copertina` si usa solo per `01.png`.
  - `animazione` = docente a tutto schermo.
- `H:MM:SS webcam x y w h`: la zona della webcam cambia a metà lezione.
- Le righe che iniziano con `#` sono commenti.

### Da fare per il kit nuovo
- **Ritaglio stretto sul viso.** Le riprese a tutto schermo sono larghe e nel riquadro
  il viso sembra piccolo. Va fatto con la riga WEBCAM, o in automatico, e provato su
  un video vero prima di applicarlo a tutti.
- **Comando che scrive `tempi.txt` dai segni F9**, con il controllo
  "numero di segni = slide − 1".

### Composizione del video
- **Sfondo:** la slide PNG 1920×1080.
- **Riquadro del docente:** 332×249 a x 1511, y 149; sulla copertina a x 1511, y 104.
  - La cornice del modello è a x 1516, y 153, misura 324×243 e ha un bordo #CBD5E1 di
    2 px.
  - Il video del docente è ritagliato al centro in 4:3.
- **Tratti `animazione`:** il video ridotto dentro la cornice, a x 166, y 143, misura
  1588×820.
- **Inizio e fine uniformi:**
  - un'animazione a 0:00 diventa la copertina con il docente nel riquadro;
  - l'ultima animazione diventa l'ultima slide con il docente nel riquadro;
  - il video finisce sulla slide, non a tutto schermo.
- **Schermata nera con le iniziali** (es. Meet/Teams): il riquadro viene nascosto.
  - Fotogrammi a 2 fps ridotti a 16×12.
  - È nera se la media è < 45 e più del 70% dei pixel è < 40.

### Correzione colore automatica (solo sull'immagine del docente)
- **Guadagno di ogni canale:** clamp(1 + 0.5·(M/c − 1), 0.85, 1.20). È un
  bilanciamento del bianco al 50% verso il neutro: M = media dei tre canali, c = media
  del canale.
- **Gamma:** clamp(log(Y/255) / log(112/255), 0.90, 1.25). Porta la luminosità media
  verso 112.
- **Altri filtri:** contrasto 1.04, saturazione 1.03, `hqdn3d=1.5:1.5:3:3`
  (antigrana), `cas=0.35` (nitidezza).
- **Ordine:** la correzione si applica DOPO la riduzione al riquadro, per la velocità.
  Sul Mac va a circa 2,6x.

### Audio
- **Catena attuale:** `aresample=48000`, `highpass=f=80`, `arnndn=m=bin/sh.rnnn`
  (RNNoise), `loudnorm` a −16 LUFS (TP −1.5), `alimiter`.
- **In corso nell'altra chat:** la direzione sente ancora un fruscio in cuffia. Sto
  provando una pulizia più forte:
  - `afftdn` con profilo del rumore;
  - taglio delle frequenze più alte;
  - silenzio nelle pause.

  Quando la scelgo te la passo. Fino ad allora non cambiare l'audio del kit.

### Uscita
- Codifica: H.264, 1920×1080, 30 fps, AAC 192k, `faststart`.
- Firma nel commento: `CentroStudiTelesio-videocorretto-v2-audiopulito`. Il comando
  `3_Verifica` la controlla.

### Sigla iniziale
È la sigla modello con le scritte cambiate. Musica, durata e animazione restano
identiche.
- **Titolo:** solo la MATERIA, per esempio "SPAGNOLO". LiberationSans-Bold 64 px,
  colore ≈ RGB(11,28,53), fascia y 622–742.
- **Sottotitolo:** "Materia – Docente" come sulla copertina, per esempio
  "Spagnolo – Prof.ssa Romina Gisel Luna". Regular 32 px, colore ≈ RGB(14,50,95),
  fascia y 743–792.
- **Script:** `tools/sigla2.py`, che vuole i fotogrammi in `$S/lez20/sg/f001…f210.png`:
  ```
  mkdir -p lez20/sg
  ffmpeg -i sigla_modello_Lez20.mp4 lez20/sg/f%03d.png
  cp sigla_modello_Lez20.mp4 lez20/sigla_iniziale.mp4
  S=<cartella> python3 tools/sigla2.py "SPAGNOLO" "Spagnolo – Prof.ssa …" out.mp4
  ```
- Con la soglia alpha a 0.002 non restano "fantasmi" del titolo vecchio nella
  dissolvenza. Controlla i fotogrammi 1, 4 e 6,8 s.

## 5. SLIDE 16:9 (VIDEODISPENSA) – MODELLO
Tutte le misure sono in `linee_guida_maschera_video.md`. Le essenziali, su 1920×1080:

### Palette e font
- **Palette** (solo queste tinte):
  - #0A1D37: titoli, bande, barra;
  - #003366: accenti, materia/docente, sottotitoli;
  - #1A1A1A: testo;
  - #F8F9FA: box e intestazioni delle tabelle;
  - #CBD5E1: linee, bordi, cornice della webcam;
  - bianco.
- **Font:** solo Arial (Liberation Sans).
  - Titolo slide: 28 pt Bold.
  - Titolo copertina: 32 pt Bold MAIUSCOLO.
  - Riga sopra il titolo: 12 pt Bold #003366.
  - Corpo: 16 pt, interlinea 1,4.
  - Tabelle: 15 pt.
  - Etichette spaziate: 10–12 pt.
- Niente ombre, gradienti o angoli arrotondati.

### Gabbia
- Margini: 80 px.
- Colonna dei contenuti: da x 80 a x 1473. Niente a destra di x 1473, è la zona della
  webcam.
- Contenuti fino a y 953.

### Pagine interne
- Logo: x 80, y 52, h 52.
- Materia – Docente: a destra, fino a x 1840, base y 104.
- Linea: y 124.
- Riga di sezione: y 153.
- Titolo: y 196–328.
- Barra: x 80, y 343, 108×5.
- Corpo: da y 386.
- Linea del piè di pagina: y 982.
- Piè di pagina a sinistra (y 996): **solo la MATERIA in maiuscolo**.
- Piè di pagina a destra: "Pagina X".

### Copertina
- Bande: #0A1D37 da y 0 a 60, poi #003366 da y 60 a 67; in basso #0A1D37 da y 1060
  a 1080.
- Sticker: x 63, y 86, 367×367.
- Colonna sinistra:
  - VIDEOLEZIONE: y 482;
  - **titolo: solo MATERIA, oppure il tema se il docente lo dà, mai il numero**:
    y 521;
  - barra: y 740;
  - MATERIA E DOCENTE: y 804/844.
- Colonna destra: ARGOMENTI DELLA LEZIONE a x 1094, y 482, elenco numerato.
- Riquadro webcam in copertina: y 108.

### Layout disponibili
Copertina, Sezione, Testo, Testo e box "Nota bene", Tabella, Immagine, Chiusura
"Grazie per l'attenzione".

### Esportazione
1. PPTX → PDF con LibreOffice.
2. PDF → PNG 1920×1080 (`pdftoppm -scale-to-x 1920 -scale-to-y 1080`).
3. Nomi: `01.png`, `02.png`…
4. Aggiungi `cornice.png`: l'ultima slide svuotata tra y 124 e y 982.

Se una pagina del docente è troppo piena, dividila in più slide invece di rimpicciolire
il testo.

## 6. DISPENSA A4 – MODELLO
Pagina A4: 595×842 pt, margini 57 pt.

### Pagine interne (layout "Pagina solo titolo" / "Pagina di testo")
- **Intestazione:**
  - logo orizzontale a x 57, y 57, altezza 23;
  - "Materia – Docente" a destra (box x 291–539, y 57), circa 8–9 pt, #003366;
  - linea a y 85, #CBD5E1.
- **Titolo:**
  - box y 102–176, ancorato in basso;
  - 28 pt Bold #0A1D37, interlinea 115%;
  - barra 69×2 a y 184.
- **Corpo:** da y 207.
  - Sottotitoli: 12 pt Bold #003366.
  - Testo: 11 pt #1A1A1A (mai sotto 10,5).
  - Tabelle: 10 pt (mai sotto 9), intestazione Bold su #F8F9FA, prima colonna
    #003366, filetti orizzontali #CBD5E1, niente linee verticali.
- **Piè di pagina:**
  - linea a y 762;
  - a sinistra, a y 769, solo la MATERIA in maiuscolo, 7–8 pt, #003366;
  - a destra "Pagina N", Bold #0A1D37.

### Copertina (layout "Copertina")
- Banda 0–45 #0A1D37, più 4 pt #003366.
- Sticker: x 45, y 68, 269×269.
- "DISPENSA DIDATTICA": y 363, 10 pt Bold spaziato #003366.
- **Titolo:** y 386, 32 pt Bold MAIUSCOLO, **solo MATERIA (o tema), mai il numero**.
- Barra: y 482.
- Linea: y 516.
- MATERIA E DOCENTE: y 533 (9 pt Bold) e y 550 (14 pt).
- ARGOMENTI DELLA LEZIONE: y 612, elenco 12 pt a y 632.
- CENTRO STUDI TELESIO: y 768.
- Banda in basso: 828–842.

### Regole della dispensa
- Impaginazione continua, non una slide per pagina.
- Le sezioni diventano titoli numerati ("1. …").
- Togli la webcam e la slide "Grazie per l'attenzione".
- Le tabelle devono essere tabelle vere e modificabili.
- Titolo del documento nei metadati: "Materia – Dispensa".
- Consegna PPTX + PDF.
- Prima di consegnare controlla ogni pagina in immagine: niente sovrapposizioni, testo
  fuori margine o pagine quasi vuote.

### Moda (Prof.ssa Caputi)
Dove si parla di un tessuto (es. denim), affianca l'immagine del cartamodello, come
nella dispensa della prof (`06_Esempi`).

## 7. COMPITI
I docenti mandano un PDF Word con gli esercizi e le soluzioni. Va rifatto nella
grafica A4 delle dispense, in **PDF compilabile**.

### Script
```
python3 -I compiti.py COMPITI.pdf base.pdf "Materia – Docente" "MATERIA" "Tema (facoltativo)"
python3 -I campi.py base.pdf Materia_LezN_compiti.pdf
```
- In `compiti.py` cambia il percorso `LOGO` con quello di `logo_orizzontale_blu.png`.
- Servono Playwright/Chromium, pdfplumber e pypdf.

### Risultato
- Titolo "Compiti" con barra.
- "Esercizio N" e la consegna.
- Le righe `___` diventano campi in cui si scrive.
- V e F diventano cerchietti cliccabili, che si cerchiano con un clic.
- Le parole da usare stanno in un riquadro grigio.
- Le soluzioni vanno su una pagina a parte.

Se il docente salta un numero, rinumera anche le soluzioni e segnalamelo. Per tipi di
esercizio nuovi, estendi `analizza()` e mostrami una prova.

## 8. COME PROCEDIAMO
1. **Spagnolo, lezione di prova:**
   - io ti mando il materiale della docente (PowerPoint o testo) e, se serve, il video
     o l'anteprima;
   - tu fai le slide 16:9 e la dispensa A4 e mi mostri le anteprime;
   - io approvo;
   - tu fai le slide PNG, la sigla e `tempi.txt` (dai segni F9).
2. **Kit NUOVE registrazioni:** una cartella separata sul Mac, con comandi numerati come
   l'altro kit. Prima lo provi su una lezione vera.
3. **Le altre lezioni:** a gruppi di 3–4, con le stesse regole della prova.
======================================================================
