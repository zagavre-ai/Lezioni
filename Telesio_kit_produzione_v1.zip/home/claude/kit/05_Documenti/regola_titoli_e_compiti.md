# Regole nuove (29/10/2026)

## Titoli senza numero di lezione (richiesta della direzione)
- In nessun materiale deve comparire "LEZIONE N" / "Lez. N": copertina 16:9, sigla, piè di pagina delle slide, copertina e piè di pagina delle dispense A4, titolo del documento (metadati).
- Al posto di "MATERIA · LEZIONE N" si scrive solo la MATERIA (es. "INGLESE", "SPAGNOLO").
- I nomi di file e cartelle (Spagnolo_Lez1…) restano col numero: servono al kit per l'ordine.
- Già applicato: dispense A4 Inglese 1–42; comando 6_Togli_numero_lezione nei kit (Mac e Windows) per i video già fatti; 1_Prepara_lezioni (Windows) lo applica da solo.

## Compiti dei docenti
- I docenti mandano un PDF (da Word) "Compiti" con esercizi + soluzioni. Vanno impaginati nella grafica delle dispense A4, in PDF COMPILABILE:
  intestazione logo + "Materia – Docente", piè di pagina "MATERIA" + "Pagina N", titolo "Compiti" 28 pt con barra, sottotitolo (tema) 12 pt bold #003366, "Esercizio N" 12 pt bold #003366, consegna 11 pt, righe numerate separate da filetti #CBD5E1, riquadro grigio "PAROLE DA USARE", V e F in cerchietti cliccabili, righe ___ come campi di testo, "Soluzioni" su pagina a parte.
- Strumenti: compiti.py (pdftotext -layout → analisi → HTML → PDF con Chromium/Playwright) + campi.py (pdfplumber trova le righe colore #1A1A1B e i cerchi #CBD5E2; pypdf aggiunge campi di testo e scelte V/F con aspetto "cerchio").
- Prova approvata/da approvare: Inglese Lez1. Poi conversione in blocco.
- Numerazione saltata nel PDF del docente: rinumerare e segnalare.

## Moda (Prof.ssa Caputi) – da affrontare
- Dove si parla di un tessuto (es. denim) va affiancata l'immagine del cartamodello, come nella dispensa della prof. Il resto si allinea ai nostri modelli. Video originali 852×480: problema di qualità.
