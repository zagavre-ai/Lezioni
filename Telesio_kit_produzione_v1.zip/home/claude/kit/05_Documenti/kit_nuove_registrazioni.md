# Kit separato per le NUOVE registrazioni (decisione del 29/10/2026)

## Decisione
- Due kit distinti, che non si toccano:
  1. **Kit attuale (vecchia maniera)**: resta com'è (Mac + Windows del fratello) per tutte le lezioni vecchie, con dispense e slide del docente registrate nel video (anteprima → pacchetto con tempi.txt → 2_Correggi_video). Nessuna modifica per non rischiare di rovinare il lavoro in corso.
  2. **Kit nuovo (Telesio_Nuove_Registrazioni)**: solo per le lezioni registrate con le nostre indicazioni (OBS, docente a tutto schermo, F9 ai cambi argomento, dispense a parte). Si parte da zero.
- Il kit Corpini (Prof.ssa Caputi) resta a sua volta isolato.

## Kit nuovo – contenuto previsto
- Cartella propria con propri `bin/` (ffmpeg, sh.rnnn), `Sigle/`, `Lezioni/`.
- Due tipi di partenza dei contenuti:
  - A) dispense già dentro le slide della docente → si parte dal suo PowerPoint;
  - B) dispensa come file di testo → si parte dal testo (A4 prima, slide dopo).
- Da Claude per ogni lezione: dispensa A4 (PDF+PPTX), videodispensa 16:9 Telesio, slide PNG, sigla_iniziale.mp4.
- Comandi nuovi: lettura marcatori F9 → tempi.txt automatico (controllo segni = slide − 1); montaggio con WEBCAM a tutto schermo e ritaglio più stretto sul viso; verifica e archivi.
- Senza F9 (o F9 non coerenti): trascrizione dell'audio e abbinamento slide ↔ parlato, fatto da Claude nel cloud (niente installazioni sul Mac).

## Prossimo passo
Una lezione di prova per tipo (A e B): materiali + video (o anteprima) + indicazione se è stato usato F9.
