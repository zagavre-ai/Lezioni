# Linee guida – Maschera videolezioni Centro Studi Telesio

Riferimento ufficiale: `2_Videolezione_16-9_modello.pptx` (16:9, 30 slide; dal 22/10/2026 sostituisce `Videolezione_Telesio_modello.pptx`, che non va più usato). Ogni maschera per le videolezioni deve essere identica a questo modello. Questa scheda riporta le misure per l'esportazione video a 1920 × 1080 px (1 pollice = 144 px; 1 pt = 2 px).

## Palette (uniche tinte ammesse)

| Uso | Colore |
|---|---|
| Titoli, logo, bande, barra d'accento, numero pagina | Blu Telesio #0A1D37 |
| Riga sopra il titolo, materia/docente, sottotitoli, dettagli | Blu Accento #003366 |
| Testo del corpo | Grigio Antracite #1A1A1A |
| Sfondo box di approfondimento, intestazione tabelle | Grigio Chiarissimo #F8F9FA |
| Linee, bordi tabelle e box, cornice webcam | Grigio Bordo #CBD5E1 |
| Sfondo slide | Bianco #FFFFFF |

## Tipografia

- Font unico: Arial (Regular / Bold). Niente Montserrat, Inter o altri font.
- Titolo slide: 28 pt Bold (56 px), interlinea 1,15, colore #0A1D37, allineato a sinistra, su massimo 2 righe.
- Titolo copertina: 32 pt Bold (64 px), MAIUSCOLO.
- Riga sopra il titolo (es. "01 · Nome della sezione"): 12 pt Bold (24 px), #003366.
- Corpo: 16 pt (32 px), interlinea 1,4, #1A1A1A. Apertura sezione: 20 pt (40 px).
- Tabelle: 15 pt (30 px); intestazione Bold #0A1D37 su #F8F9FA; prima colonna #003366.
- Etichette maiuscole spaziate (VIDEOLEZIONE, MATERIA E DOCENTE, ARGOMENTI DELLA LEZIONE): 10–12 pt Bold, #003366.

## Gabbia (pixel su 1920 × 1080)

- Margini laterali: 80 px.
- Colonna contenuti: da x 80 a x 1473 (larghezza 1393 px). Niente contenuti a destra di x 1473, è lo spazio della webcam.
- Riquadro webcam: x 1516, y 153, 324 × 243 px (4:3), cornice #CBD5E1 da 2 px, fondo bianco. In copertina: x 1516, y 108.

## Pagine interne

| Elemento | Posizione |
|---|---|
| Logo (orizzontale, blu) | x 80, y 52, altezza 52 px |
| Materia – Docente (11 pt, #003366) | allineato a destra a x 1840, base a y 104 |
| Linea intestazione (#CBD5E1, 1 px) | y 124, da x 80 a 1840 |
| Riga sopra il titolo | y 153 |
| Titolo (ancorato in basso) | box y 196–328 |
| Barra d'accento #0A1D37 | x 80, y 343, 108 × 5 px |
| Inizio corpo | y 386 |
| Limite inferiore contenuti | y 953 |
| Linea piè di pagina (#CBD5E1) | y 982, da x 80 a 1840 |
| Piè sinistro: titolo lezione (10 pt, #003366, MAIUSCOLO) | y 996 |
| Piè destro: "Pagina X" (11 pt Bold, #0A1D37) | allineato a destra a x 1840, y 996 |

## Copertina

- Banda superiore #0A1D37 da y 0 a 60, poi filetto #003366 da y 60 a 67.
- Logo adesivo nuovo (PNG su sfondo trasparente, quello del modello `2_Videolezione_16-9_modello.pptx`): x 63, y 86, 367 × 367 px.
- Colonna sinistra (x 80, larghezza 922): VIDEOLEZIONE a y 482, titolo a y 521 (fino a 2 righe), barra d'accento a y 740 (108 × 6 px), linea a y 783, MATERIA E DOCENTE a y 804, nome materia/docente a y 844 (16 pt, #003366).
- Colonna destra (x 1094): ARGOMENTI DELLA LEZIONE a y 482, linea a y 540, elenco numerato a y 562 (16 pt).
- CENTRO STUDI TELESIO (9 pt Bold) a y 972.
- Banda inferiore #0A1D37 da y 1060 a 1080.
- In copertina non ci sono intestazione né "Pagina X".

## Tipi di slide (layout del modello)

- Copertina: titolo, materia e docente, argomenti numerati.
- Sezione: "0N · Nome sezione", titolo "N. Titolo della sezione", sottoargomenti N.1, N.2…
- Testo: paragrafi brevi o elenco puntato.
- Testo e box: testo a sinistra (56% della colonna) e box "Nota bene" a destra (#F8F9FA, bordo #CBD5E1, titolo Bold #003366).
- Solo titolo + tabella: tabella con commento a destra, oppure a tutta colonna.
- Immagine: immagine nella colonna contenuti.
- Chiusura: "Fine della lezione" e "Grazie per l'attenzione".

## Regole

- Nessun elemento nella zona webcam o fuori dalla gabbia.
- Niente ombre, gradienti, angoli arrotondati o colori fuori palette.
- Numerazione: solo "Pagina X".
- Titolo e riga di sezione occupano sempre la stessa posizione in tutte le slide.

## Montaggio in CapCut

1. Esporta le slide come immagini PNG a 1920 × 1080 (PowerPoint: File → Esporta → PNG, tutte le diapositive).
2. Metti le slide sulla traccia principale (sotto), una per ogni sezione del video.
3. Metti il video del docente su una traccia di sovrapposizione (sopra), ridimensionato e ritagliato in 4:3 dentro il riquadro webcam: posizione x 1516, y 153, dimensione 324 × 243 px (x 1516, y 108 sulla copertina).
4. In questo modo non serve nessuna trasparenza: il volto del docente appare nella cornice e il resto della slide resta visibile.

## Correzione automatica dei video (OBS → maschera)

- Sigla iniziale (7 s, generata per ogni lezione con titolo e materia) + lezione ricomposta + sigla finale (7 s, uguale per tutti). Musica originale, sobria.
- Tratti con webcam: slide nuova a tutto schermo + webcam ritagliata dal video originale (scena OBS: riquadro x 94, y 739, 480 × 270; ritaglio centrale 4:3) inserita nel riquadro interno 320 × 240 a x 1517, y 154 (copertina: y 110).
- Tratti senza webcam (animazioni): video originale ridotto dentro la cornice istituzionale (intestazione + piè di pagina), senza il timbro giallo.
- Audio della lezione normalizzato a -16 LUFS.
