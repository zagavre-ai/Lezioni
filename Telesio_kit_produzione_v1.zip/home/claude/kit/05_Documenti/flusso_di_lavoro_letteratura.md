# Flusso di lavoro: dispense Letteratura Italiana (A4 + video)

## Stato (27/10/2026) – DISPENSE COMPLETE
- Consegnato il set definitivo Lez 1–26 (uno ZIP per lezione: dispensa A4 PDF + PPTX, videodispensa 16:9). Sostituisce tutti gli invii precedenti.
- Tutte le pagine del libro (lezioni 1, 2, 3, 5, 6, 8, 9, 11, 13, 14, 16, 17, 18) sono in alta risoluzione, comprese Lez 5 T4 (pp. 128–130) e Lez 13 T6 (p. 484).
- Pulizia su tutte: tolte intestazioni del libro, numeri di pagina e icona segnalibro dalle fettine.
- Lezioni 4, 7, 10, 12, 15, 19–26: senza pagine del libro, invariate.
- Inglese: manca ancora la Lez 41.

## Numero di slide delle videodispense (serve per i marcatori F9: F9 = slide − 1)
1:26 · 2:24 · 3:22 · 4:11 · 5:134 · 6:20 · 7:14 · 8:45 · 9:45 · 10:11 · 11:31 · 12:15 · 13:86 · 14:54 · 15:15 · 16:20 · 17:33 · 18:27 · 19:16 · 20:10 · 21:10 · 22:9 · 23:9 · 24:10 · 25:13 · 26:12

## Come sono state fatte (per eventuali rifacimenti)
- Input: uno ZIP per lezione con il PDF del docente e gli screenshot ingranditi (~2350 px) in `screen/LezNN_pPPP.png`. Gli screenshot vanno dentro lo ZIP: come immagini allegate vengono ridotti.
- Abbinamento automatico di ogni fettina "Pagina libro" allo screenshot ad alta risoluzione; ritaglio allargato a tutta la larghezza del testo; fascia alta (intestazione/segnalibro) e bassa (numero di pagina) escluse.
- A4: fettine contigue ricomposte senza giunzioni, spazio tra fettine non contigue, tagli su righe bianche.
- Revisione: tutte le pagine A4 in anteprima + ingrandimento dei punti dubbi; videodispense a campione.
