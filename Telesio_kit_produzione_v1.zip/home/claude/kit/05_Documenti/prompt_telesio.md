# Prompt di lavoro – Centro Studi Telesio

Nota: il modello videolezioni di riferimento è `2_Videolezione_16-9_modello.pptx` (dal 22/10/2026). Il vecchio `Videolezione_Telesio_modello.pptx` non va più usato.

---

## A. Prompt per creare le slide delle videolezioni (chat "maschera")

### Primo messaggio della chat (una volta sola)

Allega: `2_Videolezione_16-9_modello.pptx`.

Questo è il modello ufficiale delle videolezioni del Centro Studi Telesio. Per tutte le lezioni che ti manderò segui esattamente il modello allegato e il documento claude/linee_guida_maschera_video.md del Progetto: stessi layout, misure, colori, font Arial, riquadro webcam, intestazione e piè di pagina. Non cambiare mai la grafica.

### Messaggio per ogni gruppo di lezioni (3–5 PDF alla volta)

Allega i PDF delle slide originali dei docenti.

Crea le slide di queste lezioni sul modello Telesio. Regole:

1. Un file PowerPoint per ogni PDF, chiamato come la cartella della lezione (es. Inglese_Lez1.pptx). Il nome della lezione è: [scrivi qui i nomi, uno per PDF].
2. Usa esattamente i testi del docente: non inventare, non riassumere, non aggiungere contenuti. Correggi solo errori di battitura evidenti e segnalameli.
3. Mantieni lo stesso ordine del PDF: deve seguire l'ordine in cui il docente spiega nel video.
4. Se una pagina del PDF ha troppo testo, dividila in più slide consecutive invece di rimpicciolire il testo.
5. Copertina con titolo, materia, docente e argomenti; una slide di apertura per ogni sezione; chiusura "Grazie per l'attenzione".
6. Tabelle come tabelle del modello, concetti chiave nel box "Nota bene", immagini del PDF nel layout Immagine.
7. Alla fine dammi i file .pptx da scaricare e un elenco: lezione → numero di slide.

### Poi

Scarica i .pptx e portali nella chat "Correzione video" insieme alle anteprime (anteprima_per_Claude.mp4) delle stesse lezioni.

---

## B. Dispense A4 dalle slide delle videolezioni

### Primo messaggio da incollare nella nuova chat

Ciao Claude. Lavoro al Centro Studi Telesio (Milano) e devo trasformare le slide delle videolezioni (PowerPoint 16:9, già nella grafica Telesio) in dispense A4 da dare agli alunni, impaginate nel nostro modello A4. Ti allego:

- 1_Dispensa_A4_modello.pptx: il modello A4 ufficiale. Usa i suoi layout ("Copertina", "Pagina di testo", "Pagina solo titolo") e la sua grafica senza cambiarla.
- 1_Dispensa_A4.pdf: l'anteprima del modello, per vedere com'è fatto.
- logo_copertina.png (adesivo su sfondo trasparente) e logo_orizzontale.png.
- Uno ZIP con i PowerPoint 16:9 delle lezioni già lavorate (es. Inglese_Lez1.pptx…).

Cosa devi fare, per ogni PowerPoint 16:9:

1. Crea una dispensa A4 per lezione, nominata come la lezione con "_dispensa" (es. Inglese_Lez1_dispensa.pptx), e anche il PDF dello stesso file.
2. Copertina (layout Copertina): titolo della lezione, "Materia – Docente" e gli argomenti, presi dalla copertina 16:9. Logo adesivo come nel modello, pulito, senza aloni né riquadri attorno.
3. Contenuti: riporta tutti i testi, le tabelle e le immagini delle slide, nello stesso ordine. Le slide di sezione ("1. …", "2. …") diventano titoli di paragrafo numerati; i titoli delle slide diventano sottotitoli.
4. Non è una slide per pagina: impagina in modo continuo e compatto, riempiendo le pagine A4 ma senza testi troppo piccoli. Corpo del testo mai sotto 10,5 pt e tabelle mai sotto 9 pt, con margini e gabbia del modello.
5. Togli tutto ciò che serve solo al video: il riquadro della webcam, la slide finale "Grazie per l'attenzione" e le scritte di intestazione o piè di pagina della videolezione.
6. Le tabelle vanno ricostruite come vere tabelle modificabili (non immagini), con lo stile del modello. Le immagini vanno tenute, ben leggibili.
7. Non cambiare i contenuti dei docenti: niente riassunti, aggiunte o riformulazioni. Correggi solo refusi evidenti e segnalameli in un elenco alla fine.
8. Numeri di pagina come nel modello ("Pagina X"), lingua del documento italiano. Font Arial, palette #0A1D37, #003366, #1A1A1A, #F8F9FA, #CBD5E1.

Prima di consegnarmi i file, convertili in immagini e controllali pagina per pagina:

- nessun testo che esce dai margini o si sovrappone;
- nessuna pagina quasi vuota;
- tutte le slide 16:9 presenti.

Poi mandami i PPTX e i PDF in uno ZIP, con una riga per lezione: numero di pagine ed eventuali refusi corretti.

Come procediamo: comincia con una sola lezione come prova. Quando la approvo, procedi con le altre a gruppi di 3–4 lezioni per volta.

### Messaggio per ogni gruppo successivo

Perfetto, procedi con le lezioni [Inglese_Lez2, Inglese_Lez3, Inglese_Lez4] usando esattamente le stesse regole della lezione di prova.
