PROMPT PER CLAUDE - PACCHETTO DI UNA VIDEOLEZIONE (Centro Studi Telesio)
Da incollare all'inizio di una chat nuova. Poi, per ogni lezione, allegare i file indicati.

======================================================================
Ciao Claude. Lavoro al Centro Studi Telesio e monto le videolezioni con un kit
gia' pronto sul mio PC Windows (cartella Telesio_Videolezioni_Windows). Il kit
prende il video originale del docente e lo rimonta con le slide nuove; a te chiedo
di preparare il "pacchetto" di ogni lezione, cioe' lo ZIP che io estraggo nella
cartella della lezione accanto al video originale.

PER OGNI LEZIONE TI ALLEGO
1. anteprima_per_Claude.mp4: il video originale ridotto (960x540, 1 fotogramma al
   secondo, senza audio). I tempi dell'anteprima coincidono con quelli del video vero.
2. il PowerPoint delle slide nuove 16:9 (es. Letteratura_Lez1_videodispensa.pptx).
3. sigla_iniziale.mp4 di una lezione gia' fatta (serve come modello per la sigla:
   7 secondi, con musica). Te la mando la prima volta; tienila per tutte le lezioni.
4. il nome della cartella della lezione (es. Letteratura_Lez1).

COSA DEVI CONSEGNARMI: NomeLezione.zip (es. Letteratura_Lez1.zip) che contiene,
direttamente alla radice (niente cartella in piu'):
  slide/01.png, 02.png, ...   ogni slide del PowerPoint, PNG 1920x1080, numerate a 2 cifre
  slide/cornice.png           una slide "vuota" (vedi sotto)
  tempi.txt                   il piano di montaggio (vedi sotto)
  sigla_iniziale.mp4          la sigla di questa lezione (vedi sotto)

1) SLIDE
- Esporta il PowerPoint in PDF con LibreOffice (soffice --headless --convert-to pdf)
  e poi in PNG 1920x1080 (pdftoppm -scale-to-x 1920 -scale-to-y 1080), rinominando
  in 01.png, 02.png...
- cornice.png: prendi l'ultima slide e cancella in bianco tutto quello che sta tra la
  linea grigia dell'intestazione (circa y 124) e quella del pie' di pagina (circa y 982),
  e anche "Pagina N" in basso a destra. Devono restare solo logo, materia/docente
  in alto e il titolo della lezione in basso a sinistra.
- Controlla visivamente alcune slide prima di andare avanti.

2) TEMPI.TXT (la parte piu' importante)
Formato, una riga per ogni cambio, orari in ordine crescente (H:MM:SS):
  # righe che iniziano con # sono commenti
  WEBCAM x y larghezza altezza
  0:00:00 copertina 01.png
  0:01:15 slide 02.png
  0:05:52 slide 03.png
  ...
- Tipi: "copertina" (solo per 01.png), "slide", "animazione" (= docente a tutto
  schermo: il kit lo mostra comunque come copertina/slide finale con il docente nel
  riquadro, quindi usalo solo se il video inizia o finisce con il docente a tutto schermo).
- WEBCAM = posizione del riquadro del docente NEL VIDEO ORIGINALE, in pixel su
  1920x1080 (cioe' le misure dell'anteprima moltiplicate per 2). Misurala sui
  fotogrammi: bordo sinistro, alto, larghezza e altezza del riquadro con il volto.
  Esempi gia' usati: Teams "slide a sinistra + webcam piccola in alto a destra":
  WEBCAM 1676 96 240 136; registrazioni con slide a tutto schermo e webcam in basso
  a destra (Letteratura): WEBCAM 1444 602 434 246; registrazione OBS con solo la
  webcam: WEBCAM 0 0 1920 1080.
- Se il riquadro cambia misura durante la lezione, aggiungi righe come
  "0:38:31 webcam 1592 0 328 192" (orario + nuova posizione).
- Come trovare i cambi di slide: estrai un fotogramma al secondo dall'anteprima,
  calcola quanto cambia l'immagine (escludendo la zona della webcam), prendi i
  momenti in cui cambia molto e guarda/leggi (OCR) ogni schermata per capire a quale
  slide nuova corrisponde. Fai fogli di miniature per controllare a occhio.
- Le slide nuove spesso dividono in due una slide del docente: in quel caso stima il
  momento del passaggio in proporzione alla lunghezza del testo e scrivi sopra la riga
  "# ATTENZIONE: tempo stimato (da verificare) - quando il docente arriva a «...»".
- Se il docente torna su una slide gia' vista, ripeti quella slide nell'orario giusto.
- Se il docente salta o mostra slide in un ordine diverso, segui quello che si vede nel
  video (anche se alcune slide nuove non compaiono mai): il video del docente NON va
  mai tagliato.
- Se registrazione OBS con marcatori F9: i capitoli del file (ffprobe -show_chapters)
  sono i cambi slide; in quel caso basta il PowerPoint e il video vero, non l'anteprima.
- L'ultima slide ("Grazie per l'attenzione") va messa quando il docente saluta; se nel
  video non c'e' un saluto, negli ultimi 4-5 secondi, con il commento ATTENZIONE.
- L'ultimo orario deve essere prima della fine del video.

3) SIGLA_INIZIALE.MP4
Parti dalla sigla modello che ti ho dato e cambia SOLO le due scritte, mantenendo
musica, durata (7 s) e animazione identiche:
- titolo: SOLO "MATERIA", senza numero di lezione (es. "LETTERATURA ITALIANA",
  "INGLESE"): regola della direzione dal 29/10/2026. Arial/Liberation Sans Bold 64 px, centrato, colore come
  l'originale (circa RGB 11,28,53), fascia y 622-742;
- sotto: "Materia – Docente" come scritto sulla copertina del PowerPoint (es.
  "Letteratura Italiana V – Prof. Giorgio Mazzotti"), Regular 32 px, colore circa
  RGB 14,50,95, fascia y 743-792.
Metodo: estrai tutti i 210 fotogrammi della sigla modello; per ogni fotogramma misura
quanto e' "visibile" ciascuna scritta (quantita' di inchiostro nella fascia rispetto
al fotogramma 150, dove e' piena) e lo spostamento verticale; poi cancella la fascia
in bianco e ridisegna la scritta nuova con la stessa trasparenza e lo stesso
spostamento. Nella dissolvenza finale non devono restare tracce della scritta vecchia:
controlla i fotogrammi verso la fine. Rimonta con l'audio originale (-c:a copy, -t 7).

4) CONTROLLI PRIMA DI CONSEGNARE
- Tutte le slide citate in tempi.txt esistono in slide/; orari crescenti.
- Guarda la sigla (un fotogramma a meta' e uno alla fine).
- Se puoi, simula il montaggio su un pezzo dell'anteprima ingrandita a 1920x1080 e
  controlla che nel riquadro si veda bene il volto del docente.
- Dimmi in una riga: numero di slide, quali tempi sono stimati e perche', e
  qualsiasi cosa strana (slide mai mostrate, docente che torna indietro, ecc.).

REGOLE
- Niente "Lezione N" / "Lez. N" in nessun materiale (sigla, copertina, pie' di pagina
  delle slide, dispense): al suo posto solo la materia. Se il PowerPoint ha ancora il
  numero nel pie' di pagina o in copertina, segnalamelo.
- Non modificare mai il contenuto delle slide e non tagliare mai il video del docente.
- Nomi esatti: cartella e ZIP come la lezione (es. Letteratura_Lez1), slide 01.png...
- Rispondimi in italiano, in modo semplice: io poi estraggo lo ZIP e lancio
  0_Controlla_cartelle e 2_Correggi_video.
======================================================================
