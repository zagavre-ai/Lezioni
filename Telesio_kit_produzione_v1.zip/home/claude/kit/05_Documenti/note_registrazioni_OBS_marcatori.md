# Nuove registrazioni OBS con marcatori F9 (triennio) – note e cose da fare

Aggiornato: 26/10/2026

## Video di prova della prof.ssa Fontanesi – Inglese (26/10/2026) – APPROVATO
- File: 2026-10-26_09-08-14.mp4, 1920×1080, 30 fps, H.264 (OBS 32.2.2, encoder AMD), 1 min 05 s, circa 7,5 Mbit/s.
- Inquadratura: solo webcam a tutto schermo, viso centrato (nessuna slide registrata).
- Marcatori F9 salvati come capitoli nel file (a 0:45, 0:51, 0:57), nelle pause del parlato: funzionano.
- Audio pulito, pause silenziose; volume basso (-26,5 LUFS) ma il kit lo porta a -16 LUFS.
- Prova di montaggio con 2_Correggi_video aggiornato: tempi.txt ricavato dai marcatori, riga `WEBCAM 0 0 1920 1080`. Risultato corretto.

## Video di prova della docente di Spagnolo (26/10/2026) – APPROVATO
- File: Video_prova_26_ott.mp4, 1920×1080, 30 fps, H.264 obs_x264, circa 10 Mbit/s, 1 min 19 s. Qualità di codifica migliore della prova d'inglese.
- Marcatori F9: 3 (0:36, 0:55, 1:17), tutti nelle pause. L'ultimo 2 s prima della fine.
- Audio: -18,5 LUFS (buono); pause a silenzio totale (filtro di OBS attivo). A 0:49 la voce riparte di colpo e satura per un istante (26 campioni a 0 dBFS): probabile gate di rumore troppo brusco.
- Immagine: viso ben esposto, colori quasi neutri; muro sovraesposto, a destra ~24% dello sfondo bruciato (luce/finestra a destra). Dettaglio da webcam ~720p. Inquadratura larga.
- Prova di montaggio con il kit v2: correzione minima (rr 0.99, gg 1.00, bb 1.01, gamma 0.90), nessuna schermata nera, slide ai marcatori. Risultato corretto.
- Suggerimenti facoltativi: evitare luce forte di lato o abbassare l'esposizione; avvicinarsi alla webcam; 3–4 s di silenzio dopo l'ultimo F9; ammorbidire il gate di rumore se usato.

## Qualità dell'immagine (osservazione della direzione, 26/10)
- La direzione trova il video d'inglese poco definito. Analisi: dettaglio da webcam ~720p portata a 1080p, compressione visibile (quadrettini sul viso) per bitrate basso, primi secondi sgranati per l'esposizione automatica. Dominante arancione e immagine un po' scura.
- La risoluzione non si può aumentare davvero in montaggio: va migliorata in registrazione.
- Da proporre alla docente d'inglese (nuova prova di 1 minuto): webcam a 1920×1080 nelle proprietà della sorgente OBS; qualità di registrazione «Qualità indistinguibile» o 15.000–20.000 kbps; aspettare 3–4 secondi dopo l'avvio prima di parlare; luce davanti (finestra di fronte, non alle spalle).
- Nel video montato la docente è nel riquadro 324×243: lì la sgranatura quasi non si vede.

## Kit aggiornato (26/10/2026)
- 2_Correggi_video v2: correzione automatica di colore e luci calcolata per ogni lezione e applicata solo all'immagine della docente (bilanciamento del bianco al 50% verso il neutro, gamma verso luminosità 112, contrasto 1,04, hqdn3d leggero, cas 0,35); riquadro nascosto nei tratti con schermo nero/iniziali/logo (media < 45 e > 70% di pixel scuri sulla zona mostrata nel riquadro); inizio su copertina e fine su slide finale; firma «-v2».
- 4_Migliora_video_finiti: rifà con la v2 i video già corretti con la versione vecchia (sostituisce il vecchio solo a lavoro finito).
- 5_Crea_archivi_video: zip per materia in Archivi_video, max 4 GB ciascuno (MAX_GB in testa al file).
- 3_Verifica_video_corretti: controllo di completezza, durata, audio, schermate nere.

## Regole da dare alla docente
- Premere F9 una sola volta a ogni cambio di slide, anche per la slide finale «Grazie per l'attenzione».
- Andare solo avanti con le slide.
- Non usare F9 per altri scopi.
- Dopo l'ultimo F9 restare 3–4 secondi prima di fermare la registrazione.

## DA FARE quando arrivano i video
1. Inquadratura più stretta nel riquadro webcam: le riprese sono larghe e il viso nel riquadro appare piccolo. Far ritagliare al kit una zona più stretta attorno al viso (si può fare con la riga WEBCAM, senza chiedere nulla alla docente). Provare su un video vero prima di applicarlo a tutte.
2. Comando che legge i marcatori F9 dal video e scrive da solo tempi.txt (copertina a 0:00:00, poi una slide nuova a ogni marcatore). Controllo: numero di marcatori = numero di slide − 1, altrimenti avvisare.
3. Con questo metodo non serve più l'anteprima per Claude né la revisione dei tempi: per ogni lezione basta il PowerPoint.
4. Eventuale mail alle docenti con le impostazioni OBS per la qualità (vedi sopra), se la direzione la chiede.
