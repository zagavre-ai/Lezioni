from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":1920,"height":1080})
    for n in ("s16","anim"):
        pg.goto(f"file:///home/claude/l1/prev/{n}.html"); pg.wait_for_timeout(600)
        pg.screenshot(path=f"{n}.png")
    pg2=b.new_page(viewport={"width":1123,"height":794})
    pg2.goto("file:///home/claude/l1/prev/a4.html"); pg2.wait_for_timeout(600)
    pg2.pdf(path="a4.pdf",width="297mm",height="210mm",print_background=True,prefer_css_page_size=True)
    print(pg2.evaluate("document.fonts.check('800 20px BG')"),pg.evaluate("document.fonts.check('700 20px FG')"))
    b.close()
