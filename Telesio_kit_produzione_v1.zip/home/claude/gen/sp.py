import gen,sys
from playwright.sync_api import sync_playwright
def sp(top,name,role):
    return '<div class="sheet s16" style="background:transparent"><div class="sp" style="top:%scqw"><div class="n">%s</div><div class="r">%s</div></div></div>'%(top,name,role)
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080})
    for fn,top in (('sottopancia',22.0),('sottopancia_cover',19.6)):
        h='<!doctype html><meta charset=utf-8><style>%s html,body{background:transparent!important}.sheet{background:transparent!important}</style>%s'%(gen.CSS,sp(top,'Romina Gisel Luna','Prof.ssa · Spagnolo'))
        open('t2.html','w').write(h);pg.goto('file:///home/claude/gen/t2.html');pg.evaluate("document.fonts.ready")
        pg.query_selector('.sheet').screenshot(path=fn+'.png',omit_background=True)
    b.close()
from PIL import Image
for fn,sl in (('sottopancia','png/03.png'),('sottopancia_cover','png/01.png')):
    a=Image.open(sl).convert('RGBA');a.alpha_composite(Image.open(fn+'.png'));a.convert('RGB').save('prev_'+fn+'.png')
