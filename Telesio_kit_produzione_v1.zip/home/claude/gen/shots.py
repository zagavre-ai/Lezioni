import sys
from playwright.sync_api import sync_playwright
scale=float(sys.argv[1]) if len(sys.argv)>1 else 1
out=sys.argv[2] if len(sys.argv)>2 else 'png'
import os;os.makedirs(out,exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080},device_scale_factor=scale)
    pg.goto('file:///home/claude/gen/video.html');pg.evaluate("document.fonts.ready")
    n=pg.evaluate("document.querySelectorAll('.sheet').length")
    for i in range(n):
        el=pg.query_selector_all('.sheet')[i];el.screenshot(path=f'{out}/{i+1:02d}.png')
    b.close();print(n)
