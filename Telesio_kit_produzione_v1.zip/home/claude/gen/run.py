import sys,re,json,copy,os,shutil
sys.path.insert(0,'/home/claude/gen');sys.path.insert(0,'/home/claude/sp')
import gen,build as B
from playwright.sync_api import sync_playwright
items=B.applica_correzioni(B.parse_docx('/home/claude/sp/Spagnolo_Lez1.docx'))
info,secs=B.plan(items,'Spagnolo')
pages=B.build_pages(secs,avail=10**7)   # i testi li spezzo io dopo la misura; le tabelle restano intere
# unisco "testo breve + tabella" della stessa sezione/titolo
merged=[];i=0
while i<len(pages):
    p=pages[i]
    if p['type']=='text' and i+1<len(pages) and pages[i+1]['type']=='table' and pages[i+1]['title']==p['title'] and pages[i+1]['row']==p['row'] and len(p['blocks'])<=3 and not pages[i+1].get('pre'):
        q=copy.deepcopy(pages[i+1]);q['card']=p['blocks'];q['cand_split']=p['blocks'];merged.append(q);i+=2
    else:merged.append(p);i+=1
pages=merged
slides=[{'kind':'cover'}]
rows=info['intro']
slides.append({'kind':'page','pg':{'type':'text','row':info['theme'],'title':rows[0][0],'blocks':[],'custom':True},'arg':0})
for p in pages:
    m=re.match(r'(\d+)',p['row']);slides.append({'kind':'page','pg':p,'arg':int(m.group(1))})
def hero_bilingue(blocks):
    # due paragrafi ITALIANO / ESPAÑOL -> due colonne affiancate (testo invariato)
    cols=''
    for kind,runs in blocks:
        t=gen.plain1(runs)
        m=re.match(r'(ITALIANO|ESPAÑOL)\s*[·•]\s*(.*)',t,re.S)
        if not m:return None
        cols+='<div class="c"><b>[%s]</b><p>%s</p></div>'%(m.group(1),gen.esc(m.group(2)))
    return '<div class="cols2">%s</div>'%cols
MAPA=[('1','Formación del femenino','el chico → la chica'),('2','Formación del plural','libro → libros'),('3','Interrogativos','¿qué? ¿quién? ¿dónde?'),('4','Pronombres sujeto','yo · tú · él / ella'),('5','Verbos SER y TENER','yo soy · yo tengo'),('6','Presente: verbos regulares','hablo · como · vivo'),('7','Verbos reflexivos','me llamo · me levanto')]
def intro_html():
    g=''.join('<p class="bu" data-g="%d">%s</p>'%(i,gen.esc(x)) for i,x in enumerate(['presentarte','pedir información','hablar de ti de forma sencilla']))
    o='<div class="fc" id="goals"><span class="lb">[OBJETIVOS]</span><div class="tx">%s</div></div>'%g
    o+='<div class="tbl" id="mapa" style="grid-template-columns:.5fr 3fr 3fr"><div class="h">N.º</div><div class="h">Tema</div><div class="h le">Ejemplo</div>'
    for i,(n,t,e) in enumerate(MAPA):
        lr=' lr' if i==len(MAPA)-1 else ''
        o+='<div class="k r%d%s" data-r="%d">%s</div><div class="r%d%s" data-r="%d">%s</div><div class="le r%d%s" data-r="%d">%s</div>'%(i,lr,i,n,i,lr,i,gen.esc(t),i,lr,i,gen.esc(e))
    return o+'</div>'
def body_of(pg):
    o=''
    if pg.get('custom'):return intro_html()
    if pg['type']=='text' and pg['title'].strip().endswith('Formación del femenino'):
        h=hero_bilingue(pg['blocks'])
        if h:
            return h+'<div class="hero"><span class="lb">[EJEMPLO]</span><div class="ex">el ch<mark>ico</mark><i>→</i>la ch<mark>ica</mark></div><div class="rl">-o → -a<br>alto → alta</div></div>'
    if pg.get('card'):o+=gen.card_html(pg['card'],'[FOCUS]')
    return o+gen.page_body(pg)
def make(s,mode,k,num):
    if s['kind']=='cover':return gen.slide_html(mode,'','', '',num,1,True,cover=gen.cover_html(info))
    pg=s['pg']
    if mode=='a' and pg.get('custom'):k=1.12
    return gen.slide_html(mode,pg['row'] if re.match(r'\d',pg['row']) else pg['row'],gen.strip_num(pg['title']),body_of(pg),num,k)
LIM=948.5
def doc(htmls,mode):
    pc='@page{size:1920px 1080px;margin:0}' if mode=='v' else '@page{size:297mm 210mm;margin:0}'
    return '<!doctype html><meta charset=utf-8><style>%s%s</style>%s'%(gen.CSS,pc,''.join(htmls))
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080})
    def bottom(s,k,num):
        open('t.html','w').write(doc([make(s,'v',k,num)],'v'));pg.goto('file:///home/claude/gen/t.html');pg.evaluate("document.fonts.ready")
        return pg.evaluate("(()=>{const e=document.querySelector('.bd');return e?e.getBoundingClientRect().bottom:0})()")
    out=[];log=[]
    idx=0
    queue=list(slides)
    while queue:
        s=queue.pop(0)
        if s['kind']=='cover':out.append((s,1));continue
        k=1.7 if s['pg'].get('custom') else 1.0
        while k>0.5 and bottom(s,k,3)>LIM:k=round(k-0.03,3)
        pgd=s['pg']
        if k<0.78 and pgd['type']=='text' and len(pgd['blocks'])>1:
            h=len(pgd['blocks'])//2
            a=copy.deepcopy(s);a['pg']['blocks']=pgd['blocks'][:h]
            c=copy.deepcopy(s);c['pg']['blocks']=pgd['blocks'][h:]
            queue=[a,c]+queue;continue
        if k<0.78 and pgd.get('card') and pgd['type']=='table':
            # la card separata dalla tabella
            a={'kind':'page','pg':{'type':'text','row':pgd['row'],'title':pgd['title'],'blocks':pgd['card']},'arg':s['arg']}
            c=copy.deepcopy(s);c['pg'].pop('card');queue=[a,c]+queue;continue
        if k<0.7:log.append('ATTENZIONE: %s | %s k=%.2f'%(pgd['row'],pgd['title'],k))
        out.append((s,k))
    b.close()
json.dump({'n':len(out),'log':log,'slides':[{'n':i+1,'kind':s['kind'],'arg':s.get('arg',0) if s['kind']!='cover' else -1,'row':(s['pg']['row'] if s['kind']!='cover' else ''),'title':(s['pg']['title'] if s['kind']!='cover' else info['theme']),'type':(s['pg']['type'] if s['kind']!='cover' else 'cover'),'card':bool(s['kind']!='cover' and s['pg'].get('card')),'k':k} for i,(s,k) in enumerate(out)],'info':{'theme':info['theme'],'argomenti':info['argomenti']}},open('manifest.json','w'),ensure_ascii=False,indent=1)
V=[make(s,'v',k,i+1) for i,(s,k) in enumerate(out)]
A=[make(s,'a',k,i+1) for i,(s,k) in enumerate(out)]
open('video.html','w').write(doc(V,'v'));open('a4.html','w').write(doc(A,'a'))
print(len(out),'slide');print('\n'.join(log))
