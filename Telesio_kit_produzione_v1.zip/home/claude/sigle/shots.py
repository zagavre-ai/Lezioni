import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":1920,"height":1080})
    errs=[];pg.on("pageerror",lambda e:errs.append(str(e)))
    pg.goto("file:///home/claude/sigle/render.html");pg.wait_for_timeout(300)
    for m in ("spagnolo","inglese","letteratura"):
        pg.evaluate("([m,t])=>{TELESIO_SIGLA.build(m,t,LOGOS)}",[m,"intro"]);pg.evaluate("document.fonts.ready");pg.wait_for_timeout(200)
        pg.evaluate("TELESIO_SIGLA.build('%s','intro',LOGOS)"%m);pg.wait_for_timeout(150)
        pg.evaluate("TELESIO_SIGLA.setT(2.6)");pg.screenshot(path=f"i_{m}.png")
        pg.evaluate("TELESIO_SIGLA.build('%s','outro',LOGOS)"%m);pg.wait_for_timeout(150)
        pg.evaluate("TELESIO_SIGLA.setT(3.2)");pg.screenshot(path=f"o_{m}.png")
        pg.evaluate("TELESIO_SIGLA.setT(4.8)");pg.screenshot(path=f"c_{m}.png")
    print(errs)
    b.close()
