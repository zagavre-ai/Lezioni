import sys,subprocess,os,shutil
from playwright.sync_api import sync_playwright
FPS=30
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"])
    pg=b.new_page(viewport={"width":1920,"height":1080})
    pg.goto("file:///home/claude/sigle/render.html");pg.wait_for_timeout(400)
    for m in ("spagnolo","inglese","letteratura"):
        for typ,dur,aud in (("intro",4,"out/audio_intro_4s.wav"),("outro",5,"out/audio_outro_5s.wav")):
            pg.evaluate("TELESIO_SIGLA.build('%s','%s',LOGOS)"%(m,typ));pg.wait_for_timeout(250)
            d=f"frames/{m}_{typ}";shutil.rmtree(d,ignore_errors=True);os.makedirs(d)
            for i in range(dur*FPS):
                pg.evaluate("TELESIO_SIGLA.setT(%f)"%(i/FPS))
                pg.screenshot(path=f"{d}/{i:04d}.png")
            name=f"out/sigla_{'iniziale' if typ=='intro' else 'finale'}_{m}.mp4"
            subprocess.run(["ffmpeg","-y","-loglevel","error","-framerate",str(FPS),"-i",f"{d}/%04d.png","-i",aud,
              "-c:v","libx264","-preset","medium","-crf","16","-pix_fmt","yuv420p","-r",str(FPS),"-c:a","aac","-b:a","192k","-ar","48000","-shortest","-movflags","+faststart",name],check=True)
            shutil.rmtree(d)
            print(name,flush=True)
    b.close()
