# Sigle Centro Studi Telesio – Specifiche di montaggio (BOZZA PER APPROVAZIONE)

## Formato comune
- 1920×1080, 30 fps, H.264 (CRF 16, yuv420p), AAC 192 kbps 48 kHz stereo, +faststart
- Intro (`sigla_iniziale_<materia>.mp4`) = 4,0 s ; Outro (`sigla_finale_<materia>.mp4`) = 5,0 s
- Sfondo carta a quadretti bianca #FFFFFF; inchiostro Blu notte #0B1530 (tratto 6 px); evidenziatore #FFE600 costante; Blu Telesio #2060AF per sottotitolo
- Font: Bricolage Grotesque 800 (titoli), Figtree 700 (testi), DM Mono 500 (etichette [..])
- Sound logo comune 2,0 s (`sound_logo_2s.wav`): beat pulito (kick+hat+clap) + pluck Do-Mi-Sol-Do, sempre all'apertura (t=0). Nessuna voce.

## Intro 4 s (timeline)
| t (s) | Evento |
|---|---|
| 0.00 | Sound logo + comparsa griglia/logo Telesio |
| 0.30–0.80 | Badge [..] con linguetta colore materia |
| 0.60–1.50 | Titolo materia (2 righe per Letteratura) a scatto, evidenziatore giallo sotto il titolo |
| 1.40–1.90 | Barretta accento + sottotitolo "Materia – Docente" |
| 0.90–2.20 | Illustrazione (¿ / balloon EN / pennino) |
| 3.35–3.90 | Pannello d'uscita + whoosh; ultimo frame pulito per stacco su lezione |

## Outro 5 s
| t (s) | Evento |
|---|---|
| 0.00–0.50 | Wipe d'apertura + whoosh |
| 0.45–1.20 | Badge + titolo "Riepilogo" evidenziato |
| 1.00–3.00 | Checklist argomenti (spunta uno alla volta) + illustrazione piccola |
| 3.00 | Sting di chiusura; pannello inchiostro con logo bianco |
| 3.6–5.0 | Striscia gialla + "MATERIA · [BADGE]" |

## Varianti
- SPAGNOLO: giallo + rosso caldo (#E8412C solo su linguetta/puntino), ¿ stilizzata, badge [UNITÀ SPAGNOLO]
- INGLESE: blu elettrico (#2B4BFF), balloon "EN" con ombra offset, badge [ENGLISH SYSTEM]
- LETTERATURA ITALIANA: blu notte, pennino + svolazzo tracciato (nessun font corsivo, regola no-corsivo), badge [ANALISI TESTUALE]

## Dati per lezione (da modificare in `sorgenti/core.js`, oggetto CFG)
name, sub (Materia – Docente), badge, acc (colore), items (checklist outro: esempi per Inglese/Letteratura da confermare).

## Rigenerare i video
`python3 audio.py` poi `python3 rv.py` (Playwright + ffmpeg; i font sono incorporati in render.html). Il motore è deterministico (`setT(t)`), nessuna animazione CSS.

## Integrazione nel master
Concatenare: sigla_iniziale → lezione 60 min → sigla_finale; stesso audio loudnorm −16 LUFS delle lezioni. Nel kit va aggiunto un comando per anteporre/accodare le sigle.

## STOP
Come da Direzione: nessun montaggio/chiusura della Lezione 1 finché le sigle non sono approvate.
