(function(){
var INK='#0B1530',BLUE='#2060AF',HL='#FFE600';
var CFG={
 spagnolo:{name:['SPAGNOLO'],sub:'Spagnolo – Prof.ssa Romina Gisel Luna',badge:'[UNITÀ SPAGNOLO]',acc:'#E2472F',
   items:['Formación del femenino','Formación del plural','Interrogativos','Pronombre sujeto','Verbo ser y tener','Presente: verbos regulares','Verbos reflexivos']},
 inglese:{name:['INGLESE'],sub:'Inglese – Prof.ssa Maria Vittoria Fontanesi',badge:'[ENGLISH SYSTEM]',acc:'#2B4DFF',
   items:['Be used to + -ing','Get used to + -ing','Used to + infinito']},
 letteratura:{name:['LETTERATURA','ITALIANA'],sub:'Letteratura Italiana V – Prof. Giorgio Mazzotti',badge:'[ANALISI TESTUALE]',acc:'#13285A',
   items:['Il pessimismo storico','Il pessimismo cosmico','Le Operette morali']}
};
var ART={
 spagnolo:'<ellipse class="blob" cx="270" cy="360" rx="200" ry="250" fill="#FFE600" transform="rotate(-8 270 360)"/><g transform="rotate(180 270 360)"><path class="stroke" pathLength="1" d="M150 250 C150 110 390 110 390 250 C390 360 270 370 270 480" fill="none" stroke="#0B1530" stroke-width="46" stroke-linecap="round"/><circle class="dot" cx="270" cy="590" r="42" fill="#E2472F" stroke="#0B1530" stroke-width="12"/></g><g class="sparks" stroke="#0B1530" stroke-width="10" stroke-linecap="round"><path d="M455 120 l30 -34"/><path d="M490 175 l44 -10"/><path d="M60 600 l-34 24"/></g>',
 inglese:'<path class="shadow" d="M102 172 H482 Q522 172 522 212 V452 Q522 492 482 492 H282 L192 582 L202 492 H142 Q102 492 102 452 V212 Q102 172 142 172 Z" fill="#2B4DFF"/><path class="bub" d="M80 150 H460 Q500 150 500 190 V430 Q500 470 460 470 H260 L170 560 L180 470 H120 Q80 470 80 430 V190 Q80 150 120 150 Z" fill="#fff" stroke="#0B1530" stroke-width="14" stroke-linejoin="round"/><text class="entx" x="290" y="352" text-anchor="middle" font-family="DM Mono,monospace" font-weight="500" font-size="170" letter-spacing="8" fill="#0B1530">EN</text><g class="sparks" stroke="#0B1530" stroke-width="10" stroke-linecap="round"><path d="M110 640 h120"/><path d="M110 676 h70"/></g>',
 letteratura:'<path class="nib" d="M270 70 C325 190 385 290 385 400 C385 480 335 530 270 575 C205 530 155 480 155 400 C155 290 215 190 270 70 Z" fill="#13285A"/><path class="slit" pathLength="1" d="M270 330 V560" stroke="#fff" stroke-width="9" fill="none" stroke-linecap="round"/><circle class="hole" cx="270" cy="330" r="24" fill="#fff"/><path class="flo" pathLength="1" d="M40 660 C150 570 230 720 320 650 S470 590 510 670" fill="none" stroke="#13285A" stroke-width="14" stroke-linecap="round"/><path class="flo2" pathLength="1" d="M90 700 C180 650 250 740 330 700" fill="none" stroke="#FFE600" stroke-width="16" stroke-linecap="round"/>'
};
function clamp(x){return x<0?0:x>1?1:x}
function seg(t,a,b){return clamp((t-a)/(b-a))}
function eo(p){return 1-Math.pow(1-p,3)}
function eb(p){var c=1.70158,c3=c+1;return 1+c3*Math.pow(p-1,3)+c*Math.pow(p-1,2)}
function eio(p){return p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2}
var S={},stage=null,LOGO=null,LOGOW=null;
function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e}
function fit(lines,maxW,maxFs){
  var probe=el('div','line');probe.style.cssText='position:absolute;visibility:hidden;font-size:100px';stage.appendChild(probe);
  var w=0;lines.forEach(function(l){probe.textContent=l;w=Math.max(w,probe.offsetWidth)});stage.removeChild(probe);
  return Math.min(maxFs,Math.floor(100*maxW/w));
}
function build(m,type,logos){
  LOGO=logos.blue;LOGOW=logos.white;var c=CFG[m];S={m:m,type:type,c:c};
  var host=document.querySelector('.stage');if(host)host.remove();
  stage=el('div','stage');document.getElementById('mount').appendChild(stage);
  stage.appendChild(el('div','grid'));
  S.grid=stage.firstChild;
  var accent=c.acc;
  if(type==='intro'){
    S.logo=el('img','logo');S.logo.src='data:image/png;base64,'+LOGO;stage.appendChild(S.logo);
    S.badge=el('div','badge','<i style="background:'+accent+'"></i>'+c.badge);stage.appendChild(S.badge);
    var fs=fit(c.name,1000,c.name.length>1?160:240);
    S.fs=fs;S.tb=el('div','tbox');S.lines=[];
    c.name.forEach(function(n){var l=el('div','line','<span class="hl"></span><span class="tx">'+n+'</span>');l.style.fontSize=fs+'px';S.tb.appendChild(l);S.lines.push(l)});
    stage.appendChild(S.tb);
    var th=fs*c.name.length;S.bar=el('div','bar');S.bar.style.top=(392+th+22)+'px';S.bar.style.background=accent;stage.appendChild(S.bar);
    S.sub=el('div','sub',c.sub);S.sub.style.top=(392+th+70)+'px';stage.appendChild(S.sub);
    S.art=el('div','art','<svg viewBox="0 0 540 720" width="540" height="720">'+ART[m]+'</svg>');stage.appendChild(S.art);
  }else{
    S.badge=el('div','badge olabel','<i style="background:'+accent+'"></i>'+c.badge);stage.appendChild(S.badge);
    S.ot=el('div','otitle');var l=el('div','line','<span class="hl"></span><span class="tx">Riepilogo</span>');l.style.fontSize='150px';S.ot.appendChild(l);S.otl=l;stage.appendChild(S.ot);
    S.list=el('ul','list');S.items=[];
    c.items.forEach(function(t){var li=el('li','','<span class="ck"><svg viewBox="0 0 34 34"><path class="cp" pathLength="1" d="M5 18 l8 8 l16 -18" fill="none" stroke="'+INK+'" stroke-width="6" stroke-linecap="square"/></svg></span><span>'+t+'</span>');S.list.appendChild(li);S.items.push(li)});
    stage.appendChild(S.list);
    S.art=el('div','oart','<svg viewBox="0 0 540 720" width="540" height="720">'+ART[m]+'</svg>');stage.appendChild(S.art);
    S.open=el('div','panel');stage.appendChild(S.open);
    S.card=el('div','panel');S.card.style.background=INK;
    S.cardlogo=el('img','ologo');S.cardlogo.src='data:image/png;base64,'+LOGOW;S.card.appendChild(S.cardlogo);
    S.strip=el('div','ostrip');S.card.appendChild(S.strip);
    S.omat=el('div','omat',c.name.join(' ')+'  ·  '+c.badge);S.card.appendChild(S.omat);
    stage.appendChild(S.card);
  }
  S.panel=el('div','panel');stage.appendChild(S.panel);
}
function artState(svg,m,p){
  // p: 0..1 reveal progress for the art
  var q=function(a,b){return seg(p,a,b)};
  var g=function(s){return svg.querySelector(s)};
  if(m==='spagnolo'){
    var b=g('.blob');b.setAttribute('transform','rotate(-8 270 360) translate(270 360) scale('+eb(q(0,.45))+') translate(-270 -360)');b.style.opacity=q(0,.2);
    var s=g('.stroke');s.setAttribute('stroke-dasharray','1');s.setAttribute('stroke-dashoffset',1-eio(q(.2,.8)));
    var d=g('.dot');d.setAttribute('transform','translate(270 590) scale('+eb(q(.75,1))+') translate(-270 -590)');d.style.opacity=q(.75,.85);
    g('.sparks').style.opacity=q(.8,1);
  }else if(m==='inglese'){
    var sh=g('.shadow');sh.style.opacity=q(.2,.5);sh.setAttribute('transform','translate('+(-22*(1-q(.2,.7)))+' '+(-22*(1-q(.2,.7)))+')');
    var bu=g('.bub');bu.setAttribute('transform','translate(170 560) scale('+eb(q(0,.5))+') translate(-170 -560)');bu.style.opacity=q(0,.15);
    var en=g('.entx');en.style.opacity=q(.45,.7);en.setAttribute('transform','translate(0 '+(24*(1-eo(q(.45,.75))))+')');
    g('.sparks').style.opacity=q(.75,1);
  }else{
    var n=g('.nib');n.setAttribute('transform','translate(270 575) scale('+eb(q(0,.45))+') translate(-270 -575)');n.style.opacity=q(0,.12);
    var sl=g('.slit');sl.setAttribute('stroke-dasharray','1');sl.setAttribute('stroke-dashoffset',1-eio(q(.4,.65)));
    g('.hole').style.opacity=q(.35,.5);
    var f2=g('.flo2');f2.setAttribute('stroke-dasharray','1');f2.setAttribute('stroke-dashoffset',1-eio(q(.55,.85)));
    var f=g('.flo');f.setAttribute('stroke-dasharray','1');f.setAttribute('stroke-dashoffset',1-eio(q(.5,1)));
  }
}
function lineState(l,fs,pr,ph){
  var tx=l.querySelector('.tx'),hl=l.querySelector('.hl');
  tx.style.clipPath='inset(0 '+((1-eo(pr))*100)+'% 0 0)';tx.style.transform='translateX('+(-30*(1-eo(pr)))+'px)';
  hl.style.width=(tx.offsetWidth+16)*eio(ph)+'px';
}
function setT(t){
  if(!S.type)return;
  var c=S.c;
  if(S.type==='intro'){
    S.grid.style.opacity=eo(seg(t,0,.5));S.grid.style.backgroundPosition=(t*10)+'px '+(t*10)+'px';
    S.logo.style.opacity=eo(seg(t,.1,.45));S.logo.style.transform='translateY('+(-24*(1-eo(seg(t,.1,.5))))+'px)';
    var pb=seg(t,.35,.7);S.badge.style.opacity=pb>0?1:0;S.badge.style.transform='scale('+(pb>0?eb(pb):.01)+')';
    S.lines.forEach(function(l,i){lineState(l,S.fs,seg(t,.55+.18*i,1.0+.18*i),seg(t,.95+.18*i,1.4+.18*i))});
    var pbar=eio(seg(t,1.45,1.75));S.bar.style.width=(108*pbar)+'px';
    var ps=eo(seg(t,1.5,1.95));S.sub.style.opacity=ps;S.sub.style.transform='translateY('+(22*(1-ps))+'px)';
    artState(S.art.querySelector('svg'),S.m,seg(t,.7,1.7));
    var w=eio(seg(t,3.62,3.95));S.panel.style.transform='translateX('+(-100+100*w)+'%)';
    S.panel.style.display=w>0?'block':'none';
  }else{
    S.grid.style.opacity=1;S.grid.style.backgroundPosition=(t*10)+'px '+(t*10)+'px';
    var pb2=seg(t,.3,.6);S.badge.style.opacity=pb2>0?1:0;S.badge.style.transform='scale('+(pb2>0?eb(pb2):.01)+')';
    lineState(S.otl,150,seg(t,.45,.95),seg(t,.8,1.25));
    S.items.forEach(function(li,i){var p=eo(seg(t,.95+.2*i,1.3+.2*i));li.style.opacity=p;li.style.transform='translateX('+(-40*(1-p))+'px)';
      var cp=li.querySelector('.cp');cp.setAttribute('stroke-dasharray','1');cp.setAttribute('stroke-dashoffset',1-eio(seg(t,1.15+.2*i,1.45+.2*i)))});
    artState(S.art.querySelector('svg'),S.m,seg(t,.6,1.6));
    // opening panel (continuity from lesson end): covers then slides away
    var open=eio(seg(t,0,.3));S.open.style.transform='translateX('+(100*open)+'%)';S.open.style.display=open<1?'block':'none';
    // closing: ink panel sweeps in at 3.65, then card content
    var w2=eio(seg(t,3.65,3.98));
    S.panel.style.transform='translateX('+(-100+100*w2)+'%)';S.panel.style.display=(w2>0&&t<4.0)?'block':'none';
    S.card.style.display=t>=3.98?'block':'none';
    var pl=eb(seg(t,4.05,4.45));S.cardlogo.style.opacity=seg(t,4.05,4.2);S.cardlogo.style.transform='translate(-50%,-50%) scale('+Math.max(pl,.01)+')';
    var lw=S.cardlogo.offsetWidth||700;
    S.strip.style.left=(960-lw/2)+'px';S.strip.style.width=(lw*eio(seg(t,4.35,4.75)))+'px';S.strip.style.top=(540+105+16)+'px';
    S.omat.style.top=(540+105+90)+'px';S.omat.style.opacity=eo(seg(t,4.55,4.9));
  }
}
window.TELESIO_SIGLA={CFG:CFG,build:build,setT:setT};
})();
