import numpy as np, wave
SR=48000
def env(n,a,d,s=0.0):
    t=np.arange(n)/SR; e=np.minimum(t/a,1)*np.exp(-t/d); return e
def tone(f,n,a=.004,d=.25,h=((1,1),(2,.35),(3,.12))):
    t=np.arange(n)/SR; y=sum(A*np.sin(2*np.pi*f*k*t) for k,A in h); return y*env(n,a,d)
def kick(n):
    t=np.arange(n)/SR; f=140*np.exp(-t*28)+48; ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-t*9)
def hat(n,seed=1):
    r=np.random.RandomState(seed).randn(n); r=np.diff(r,prepend=0); return r*np.exp(-np.arange(n)/SR*60)
def clap(n):
    r=np.random.RandomState(3).randn(n); return r*np.exp(-np.arange(n)/SR*28)
def put(buf,x,t,g=1):
    i=int(t*SR); buf[i:i+len(x)]+=x[:len(buf)-i]*g
def logo():
    b=np.zeros(int(2.0*SR))
    # beat: 100 bpm-ish clean modern: kick, hat, clap + pluck motif C5 E5 G5 C6
    put(b,kick(int(.35*SR)),0,.9)
    put(b,hat(int(.08*SR)),0.30,.10); put(b,hat(int(.08*SR),2),0.60,.10)
    put(b,clap(int(.2*SR)),0.60,.16)
    for k,(f,t) in enumerate([(523.25,0.0),(659.25,0.30),(783.99,0.60),(1046.5,0.90)]):
        put(b,tone(f,int(1.1*SR),d=.22),t,.30)
    put(b,tone(1046.5*1.5,int(.9*SR),d=.3,h=((1,1),)),0.90,.08)
    fade=np.ones_like(b); n=int(.25*SR); fade[-n:]=np.linspace(1,0,n); b*=fade
    return b/np.max(np.abs(b))*0.8
def whoosh(dur=.6,up=True):
    n=int(dur*SR); r=np.random.RandomState(5).randn(n)
    t=np.linspace(0,1,n); e=np.sin(np.pi*t)**2
    # crude lowpass sweep
    y=np.zeros(n); a=0
    for i in range(n):
        c=0.02+0.35*(t[i] if up else 1-t[i]); a+=c*(r[i]-a); y[i]=a
    return y*e/np.max(np.abs(y*e))*0.5
def sting():
    b=np.zeros(int(1.2*SR))
    for f,t in [(783.99,0),(659.25,.12),(523.25,.24)]:
        put(b,tone(f,int(.9*SR),d=.2),t,.35)
    put(b,kick(int(.3*SR)),.24,.5)
    return b/np.max(np.abs(b))*0.7
def save(name,x):
    x=np.clip(x,-1,1); s=(np.stack([x,x],1)*32767).astype('<i2')
    w=wave.open(name,'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(s.tobytes()); w.close()
L=logo(); save('out/sound_logo_2s.wav',L)
I=np.zeros(int(4*SR)); put(I,L,0,1); put(I,whoosh(.55,True),3.35,.7); I[int(3.9*SR):]*=0
fade=np.ones_like(I); n=int(.1*SR); fade[-n:]=np.linspace(1,0,n); save('out/audio_intro_4s.wav',I*fade)
O=np.zeros(int(5*SR)); put(O,whoosh(.5,False),0,.6); put(O,sting(),3.0,1); put(O,L[:int(1.0*SR)]*np.linspace(1,0,int(1.0*SR)),0.45,.35)
fade=np.ones_like(O); n=int(.3*SR); fade[-n:]=np.linspace(1,0,n); save('out/audio_outro_5s.wav',O*fade)
print('ok')
