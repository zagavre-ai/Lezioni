import sys,os,shutil,subprocess,json
sys.path.insert(0,'/home/claude/gen')
from engine import BASE,gen,strip_lb
from playwright.sync_api import sync_playwright
class V:
    def __init__(s):s.items=[];s.html=[]
    def add(s,html,style,t0,fade=.5,t1=None,fo=.4):
        i=len(s.items);s.items.append((t0,fade,t1,fo))
        s.html.append('<div class="it" id="it%d" style="position:absolute;%s">%s</div>'%(i,style,html))
    def render(s,name,W,H,dur,css,outdir,audio=None,scale=1,crf=14):
        html='<!doctype html><meta charset=utf-8><style>%s%s</style><body><div id=root style="width:%dpx;height:%dpx;position:relative;overflow:hidden;background:#fff">%s</div>'%(BASE,css,W,H,''.join(s.html))
        html=strip_lb(html)
        os.makedirs(outdir+'/'+name,exist_ok=True);fr=outdir+'/'+name+'/f';shutil.rmtree(fr,ignore_errors=True);os.makedirs(fr)
        open(outdir+'/'+name+'/p.html','w').write(html)
        N=int(round(dur*30));seen={}
        with sync_playwright() as p:
            b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":W,"height":H},device_scale_factor=scale)
            pg.goto('file://'+os.path.abspath(outdir+'/'+name+'/p.html'));pg.evaluate("document.fonts.ready")
            pg.evaluate("window.T0=%s"%json.dumps(s.items))
            pg.evaluate("""window.setT=function(t){var k=[];function r(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)}
            window.T0.forEach(function(a,i){var o=r((t-a[0])/a[1]);if(a[2]!==null)o=o*(1-r((t-a[2])/a[3]));o=Math.round(o*100)/100;var e=document.getElementById('it'+i);e.style.opacity=o;e.style.transform='translateY('+((1-o)*8)+'px)';k.push(o)});return k.join(',')}""")
            for n in range(N):
                k=pg.evaluate("setT(%f)"%(n/30.0));fn='%s/%05d.png'%(fr,n+1)
                if k in seen:os.link(seen[k],fn)
                else:pg.screenshot(path=fn);seen[k]=fn
            b.close()
        out=outdir+'/'+name+'.mp4';cmd=['ffmpeg','-y','-loglevel','error','-framerate','30','-i',fr+'/%05d.png']
        if audio:cmd+=['-i',audio,'-map','0:v','-map','1:a','-c:a','aac','-b:a','160k','-t','%.3f'%dur]
        cmd+=['-c:v','libx264','-preset','veryfast','-crf',str(crf),'-pix_fmt','yuv420p','-r','30','-movflags','+faststart',out]
        subprocess.run(cmd,check=True)
        shutil.copy('%s/%05d.png'%(fr,N),outdir+'/'+name+'_finale.png');shutil.rmtree(fr);print(name,len(seen),'stati')
