from lib_long import *
OUT='/home/claude/assets/out2'
I='stroke="#0B1530" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"'
def svg(b,s=150):return '<svg width="%d" height="%d" viewBox="0 0 100 100" fill="none" %s>%s</svg>'%(s,s,I,b)
PERSON=svg('<circle cx="50" cy="32" r="16" fill="#FFE600"/><path d="M18 88 Q18 56 50 56 Q82 56 82 88Z" fill="#2060AF"/>')
PIN=svg('<path d="M50 90 C20 55 20 12 50 12 C80 12 80 55 50 90Z" fill="#2060AF"/><circle cx="50" cy="38" r="11" fill="#FFE600"/>')
STAR=svg('<path d="M50 8 L61 38 L93 40 L68 60 L77 92 L50 74 L23 92 L32 60 L7 40 L39 38Z" fill="#FFE600"/>')
BOOK=svg('<path d="M10 20 H46 Q50 20 50 26 V84 Q50 78 44 78 H10Z" fill="#2060AF"/><path d="M90 20 H54 Q50 20 50 26 V84 Q50 78 56 78 H90Z" fill="#FFE600"/>')
CAKE=svg('<rect x="15" y="50" width="70" height="36" fill="#2060AF"/><rect x="15" y="50" width="70" height="12" fill="#FFE600"/><line x1="35" y1="22" x2="35" y2="44"/><line x1="50" y1="22" x2="50" y2="44"/><line x1="65" y1="22" x2="65" y2="44"/>')
def cap(v,t0,t1,txt):
    v.add('<div style="background:#EEF0F4;border-left:8px solid #2060AF;padding:14px 30px;font-weight:700;font-size:36px;line-height:1.3;width:1760px">%s</div>'%txt,'left:80px;top:862px;z-index:10',t0,.5,t1)
def icard(v,x,y,t0,t1,icon,lab,sub,w=520):
    v.add('<div class="card" style="width:%dpx;text-align:left">%s<h3 style="font-size:50px;margin:10px 0 6px">%s</h3><p style="font-size:30px">%s</p></div>'%(w,icon,lab,sub),'left:%dpx;top:%dpx;z-index:10'%(x,y),t0,.6,t1)
def chip(v,t0,t1,txt):
    v.add('<div style="background:var(--ink);color:#fff;font-family:BG;font-weight:800;font-size:110px;padding:14px 50px;box-shadow:0 14px 30px rgba(11,21,48,.25);border-radius:16px;display:inline-block">%s</div>'%txt,'left:80px;top:170px;z-index:10',t0,.5,t1)
def table(v,t0,rows,hdr,cols,x,y,fs=30,w=860):
    v.add(T(hdr,cols,'h','font-size:20px;white-space:nowrap'),'left:%dpx;top:%dpx;width:%dpx;z-index:20'%(x,y,w),t0,.5)
    for i,r in enumerate(rows):v.add(T(r,cols,'last' if i==len(rows)-1 else '','font-size:%dpx;--p:7px'%fs),'left:%dpx;top:%dpx;width:%dpx;z-index:20'%(x,y+54+i*(fs*1.25+16),w),t0+.2+i*.15,.4)
# ---------- AN06
v=V();header(v)
v.add('<span class="lb">[PASO 1]</span>','left:80px;top:150px;z-index:10',.3,.5,14)
v.add('<div class="hero" style="font-size:230px">habl<span style="background:var(--hl);padding:0 .06em">ar</span></div>','left:200px;top:300px;z-index:10',1.5,.8,14)
v.add('<div style="position:absolute;left:0;top:0"></div>','left:0;top:0;z-index:10',0,.01,14)
v.add('<div style="width:520px;height:14px;background:var(--ink);transform:rotate(-8deg)"></div>','left:670px;top:430px;z-index:12',7,.6,14)
v.add('<div class="note" style="font-size:40px"><span class="lb">[TOGLI]</span><br>-ar · -er · -ir</div>','left:200px;top:680px;width:700px;z-index:10',9,.7,14)
cap(v,.8,14,'Per coniugare un verbo regolare al presente, togliamo <b>-ar</b>, <b>-er</b> o <b>-ir</b> e aggiungiamo la desinenza corretta.')
v.add('<span class="lb">[PASO 2]</span>','left:80px;top:150px;z-index:10',14.2,.5,24)
for x,txt,t,w_ in [(200,'habl-',14.8,420),(660,'+',16.4,0),(760,'-o',17,0),(1000,'=',19,0),(1160,'hablo',20,0)]:
    if txt in('+','='):v.add('<div class="hero" style="font-size:150px;color:var(--blue)">%s</div>'%txt,'left:%dpx;top:330px;z-index:10'%x,t,.5,24)
    else:v.add('<div class="card" style="padding:14px 34px"><span class="hero" style="font-size:130px">%s</span></div>'%(('<mark>%s</mark>'%txt) if txt=='-o' else (('<span style="color:var(--blue)">%s</span>'%txt) if txt!='habl-' else txt)),'left:%dpx;top:320px;z-index:10'%x,t,.6,24)
cap(v,14.8,24,'Poi aggiungiamo la terminazione della persona.')
v.add('<span class="lb">[PASO 3]</span>','left:80px;top:150px;z-index:10',24.2,.5,34)
forms=[('yo','habl<mark>o</mark>'),('tú','habl<mark>as</mark>'),('él / ella / usted','habl<mark>a</mark>'),('nosotros/as','habl<mark>amos</mark>'),('vosotros/as','habl<mark>áis</mark>'),('ellos / ellas / ustedes','habl<mark>an</mark>')]
for i,(p,f) in enumerate(forms):
    v.add(T([p,f],'38% 62%','last' if i==5 else '','font-size:38px;--p:9px'),'left:300px;top:%dpx;width:1000px;z-index:10'%(250+i*76),24.8+[0,1.07,2.07,3.0,3.92,4.83][i],.5,34.6)
cap(v,24.8,34.6,'<b>hablo, hablas, habla, hablamos, habláis, hablan.</b>')
v.add('<span class="lb">[-ER / -IR]</span>','left:80px;top:150px;z-index:10',34.2,.5,47.6)
v.add(T(['Persona','COMER (-ER)','VIVIR (-IR)'],'30% 35% 35%','h','font-size:24px'),'left:200px;top:260px;width:1300px;z-index:10',34.6,.5,47.6)
rows=[('yo','com<mark>o</mark>','viv<mark>o</mark>'),('tú','com<mark>es</mark>','viv<mark>es</mark>'),('nosotros/as','com<mark>emos</mark>','viv<mark>imos</mark>'),('vosotros/as','com<mark>éis</mark>','viv<mark>ís</mark>')]
for i,r in enumerate(rows):v.add(T(list(r),'30% 35% 35%','last' if i==3 else '','font-size:40px;--p:12px'),'left:200px;top:%dpx;width:1300px;z-index:10'%(325+i*84),35.4+i*1.6,.5,47.6)
v.add('<div class="note" style="font-size:30px"><span class="lb">[DIFERENCIAS]</span><br>Uguali: yo, tú, él, ellos. Diverse: nosotros (-emos / -imos) e vosotros (-éis / -ís).</div>','left:200px;top:700px;width:1300px;z-index:10',40.5,.6,47.6)
cap(v,34.8,40.3,'I verbi in <b>-er</b> e <b>-ir</b> hanno desinenze simili, ma non identiche.')
cap(v,40.5,47.6,'Uguali: <b>yo, tú, él, ellos</b>. Diverse: <b>nosotros</b> e <b>vosotros</b>.')
v.add('<span class="lb">[EJEMPLOS]</span>','left:80px;top:150px;z-index:10',47.8,.5)
for i,s in enumerate(['<mark>Hablo</mark> italiano.','<mark>Como</mark> en casa.','<mark>Vivo</mark> en una ciudad.','<mark>Estudiamos</mark> español.']):
    v.add('<div class="card" style="width:800px;padding:14px 30px"><span class="hero" style="font-size:52px">%s</span></div>'%s,'left:80px;top:%dpx;z-index:10'%(230+i*130),48.0+[0,1.31,2.53,4.05][i],.5)
table(v,54.2,[['yo','hablo','como','vivo'],['tú','hablas','comes','vives'],['él/ella','habla','come','vive'],['nosotros','hablamos','comemos','vivimos'],['vosotros','habláis','coméis','vivís'],['ellos','hablan','comen','viven']],['','-AR: HABLAR','-ER: COMER','-IR: VIVIR'],'18% 28% 27% 27%',950,230,26,890)
cap(v,48.0,57.5,'<b>Hablo</b> italiano. <b>Como</b> en casa. <b>Vivo</b> en una ciudad. <b>Estudiamos</b> español.')
v.render('AN06_Presente-regular_v4',1920,1080,58,CSS,OUT)
