from lib_long import *
W,H=720,1280;OUT='/home/claude/assets/out2'
PCSS="""
.hd2{position:absolute;left:40px;top:40px;right:40px;height:64px;border-bottom:1.5px solid #C9D0DC}.hd2 img{height:44px}
.tr{font-size:34px}.tr>div{padding:var(--p,12px) 18px}
.chip{background:var(--ink);color:#fff;font-family:'BG';font-weight:800;font-size:66px;padding:10px 34px;box-shadow:9px 9px 0 var(--blue);display:inline-block}
.nt{border:1px solid #D5DCE8;border-radius:16px;box-shadow:8px 8px 0 var(--ink);background:rgba(32,96,175,.07);padding:18px 24px;font-weight:700;font-size:32px;line-height:1.35}
"""
def pill(name,label,title,header_,rows,cols,note,D=24,fs=34,pad=26,r0=2.5,dt=2.6,t_note=None,y=330):
    v=V()
    v.add('<div class="hd2"><img src="data:image/png;base64,%s"></div>'%LG,'left:0;top:0;width:720px;z-index:5',0,.01)
    v.add('<span class="lb" style="font-size:22px">[PILLOLA]</span>','left:40px;top:140px;z-index:10',.2,.5)
    v.add('<span class="chip">%s</span>'%title,'left:40px;top:190px;z-index:10',.4,.6)
    v.add(T(header_,cols,'h','font-size:%dpx;--p:%dpx'%(22,12)),'left:40px;top:%dpx;width:640px;z-index:10'%y,1.2,.5)
    rh=fs*1.25+pad+2
    for i,r in enumerate(rows):
        v.add(T(r,cols,'last' if i==len(rows)-1 else '','font-size:%dpx;--p:%dpx'%(fs,pad//2)),'left:40px;top:%dpx;width:640px;z-index:10'%(y+58+i*rh),r0+i*dt,.5)
    v.add('<div class="nt"><span class="lb" style="font-size:20px">[%s]</span><br>%s</div>'%(label,note),'left:40px;top:%dpx;width:630px;z-index:10'%(y+58+len(rows)*rh+40),t_note or (r0+len(rows)*dt+.6),.6)
    v.add('<div style="font-family:FG;font-weight:800;letter-spacing:.14em;font-size:20px;color:var(--blue);font-weight:500">SPAGNOLO</div>','left:40px;top:1220px;z-index:10',0,.01)
    v.render(name,W,H,D,CSS+PCSS,OUT)
pill('Pillola_01_femenino','REGLA','Femenino',['Regla','Ejemplo'],[['-o → -a','chic<mark>o</mark> → chic<mark>a</mark>'],['-or → -ora','profesor → profesor<mark>a</mark>'],['+ -a','doctor → doctor<mark>a</mark>'],['-e: igual','estudiante = igual'],['irregular','actor → actriz']],'38% 62%','El adjetivo concuerda: el chico simpático → la chica simpática.',D=26,fs=30,pad=24,dt=3.0)
pill('Pillola_02_plural','REGLA','Plural',['Regla','Ejemplo'],[['vocal + -s','chica → chica<mark>s</mark>'],['cons. + -es','doctor → doctor<mark>es</mark>'],['-z → -ces','luz → lu<mark>ces</mark>'],['-s átona: igual','el lunes → los lunes']],'42% 58%','Cambian también el artículo y el adjetivo: las chicas simpáticas.',D=24,fs=32,pad=28,dt=3.2)
pill('Pillola_03_interrogativos','USO','Preguntas',['Forma','Uso'],[['¿Quién?','persona'],['¿Qué?','cosa'],['¿Cuál?','elección'],['¿Dónde?','lugar'],['¿De dónde?','origen'],['¿Cómo?','manera / nombre'],['¿Cuándo?','momento'],['¿Cuántos?','cantidad'],['¿Por qué?','motivo']],'42% 58%','«¿De dónde eres?» origen · «¿Dónde vives?» residencia.',D=26,fs=30,pad=18,dt=1.9,r0=2.2)
pill('Pillola_04_pronombres','OMISIÓN','Pronombres',['Persona','Pronombre'],[['1.ª sing.','yo'],['2.ª sing.','tú'],['3.ª sing.','él / ella / usted'],['1.ª pl.','nosotros / as'],['2.ª pl.','vosotros / as'],['3.ª pl.','ellos / ellas / ustedes']],'34% 66%','Se puede omitir: «Vivo en Roma». Vosotros: España · ustedes: América Latina.',D=24,fs=32,pad=24,dt=2.3)
pill('Pillola_06_presente-regular','HABLAR · COMER · VIVIR','Presente',['','-AR','-ER','-IR'],[['yo','habl<mark>o</mark>','com<mark>o</mark>','viv<mark>o</mark>'],['tú','habl<mark>as</mark>','com<mark>es</mark>','viv<mark>es</mark>'],['él','habl<mark>a</mark>','com<mark>e</mark>','viv<mark>e</mark>'],['nos.','habl<mark>amos</mark>','com<mark>emos</mark>','viv<mark>imos</mark>'],['vos.','habl<mark>áis</mark>','com<mark>éis</mark>','viv<mark>ís</mark>'],['ellos','habl<mark>an</mark>','com<mark>en</mark>','viv<mark>en</mark>']],'16% 28% 28% 28%','Quita -ar / -er / -ir y añade la terminación de la persona.',D=24,fs=26,pad=22,dt=2.2)
pill('Pillola_07_reflexivos','ESTRUCTURA','Reflexivos',['','LLAMARSE','LEVANTARSE'],[['yo','me llamo','me levanto'],['tú','te llamas','te levantas'],['él','se llama','se levanta'],['nos.','nos llamamos','nos levantamos'],['vos.','os llamáis','os levantáis'],['ellos','se llaman','se levantan']],'16% 38% 46%','[pronombre] + [verbo]: me, te, se, nos, os, se.',D=24,fs=26,pad=22,dt=2.2)
