from lib_long import *
import sys
def build(name,W,H,fs,OUT='/home/claude/assets/out2'):
    v=V();D=24.1
    s=fs
    css="""
    .hd2{position:absolute;left:%dpx;top:%dpx;right:%dpx;border-bottom:1.5px solid #C9D0DC;height:%dpx}.hd2 img{height:%dpx}
    .chip{background:var(--ink);color:#fff;font-family:'BG';font-weight:800;font-size:%dpx;padding:%dpx %dpx;box-shadow:%dpx %dpx 0 var(--blue);display:inline-block}
    .br{border-left:4px solid var(--blue);padding-left:%dpx;margin-left:%dpx}
    .br b{font-family:'BG';font-weight:800;font-size:%dpx;display:block}
    .ex{font-weight:700;font-size:%dpx;margin-top:%dpx}
    .cmp{display:grid;grid-template-columns:1fr 1fr;gap:%dpx;font-weight:800;font-size:%dpx}
    .cmp div{padding:%dpx %dpx;border-bottom:2px solid var(--ink)}
    .cmp .h{background:var(--ink);color:#fff;font-family:'BG';font-size:%dpx}
    """%(int(.06*W),int(.04*H),int(.06*W),int(.05*H),int(.035*H),int(.075*W),int(.012*H),int(.04*W),int(.007*W),int(.007*W),int(.03*W),int(.03*W),int(.055*W),int(.04*W),int(.01*H),int(.01*W),int(.04*W),int(.006*H),int(.02*W),int(.05*W))
    css+='.chip{font-size:%dpx!important}.br b{font-size:%dpx!important}.ex{font-size:%dpx!important}'%(int(.11*W),int(.08*W),int(.058*W))
    L=int(.06*W)
    v.add('<div class="hd2"><img src="data:image/png;base64,%s"></div>'%LG,'left:0;top:0;width:%dpx;z-index:5'%W,0,.01)
    def grp(t0,t1,chip,items,y):
        v.add('<span class="chip">%s</span>'%chip,'left:%dpx;top:%dpx;z-index:10'%(L,y),t0,.5,t1)
        for (html,tt,yy) in items:
            v.add(html,'left:%dpx;top:%dpx;width:%dpx;z-index:10'%(L,yy,W-2*L),tt,.5,t1)
    Y0=int(.17*H);
    ys=lambda k:int(Y0+(.13+.24*k)*H*(1 if H>1000 else .8))
    # SER
    grp(0,12.4,'SER',[('<div class="br"><b>Identificazione</b><div class="ex" style="opacity:1;visibility:hidden">·</div></div>',1.9,ys(0)),
                      ('<div class="br"><b>Provenienza</b></div>',2.6,ys(1)),
                      ('<div class="br"><b>Caratteristica</b></div>',3.3,ys(2))],Y0)
    for i,(tx,tt) in enumerate([('Soy estudiante.',5.0),('Soy de Italia.',7.4),('Somos simpáticos.',10.0)]):
        v.add('<div class="ex"><mark>%s</mark></div>'%tx,'left:%dpx;top:%dpx;z-index:11'%(L+int(.05*W),ys(i)+int(.075*H)),tt,.5,12.4)
    # TENER
    grp(12.4,19.6,'TENER',[('<div class="br"><b>Possesso / proprietà</b></div>',13.8,ys(0)),('<div class="br"><b>Età / anni</b></div>',15.2,ys(1))],Y0)
    for tx,tt,k in [('Tengo un libro.',16.5,0),('Tengo quince años.',18.0,1)]:
        v.add('<div class="ex"><mark>%s</mark></div>'%tx,'left:%dpx;top:%dpx;z-index:11'%(L+int(.05*W),ys(k)+int(.075*H)),tt,.5,19.6)
    # confronto
    t0=19.6;t1=D+1
    v.add('<div class="cmp"><div class="h">SER</div><div class="h">TENER</div></div>','left:%dpx;top:%dpx;width:%dpx;z-index:10'%(L,Y0,W-2*L),t0,.5,t1)
    pron=['yo soy|yo tengo','tú eres|tú tienes','él/ella/usted es|él/ella/usted tiene','nosotros somos|nosotros tenemos','vosotros sois|vosotros tenéis','ellos/ustedes son|ellos/ustedes tienen']
    rowh=int(.052*H)
    rows='<div class="cmp">'+''.join('<div>%s</div><div>%s</div>'%tuple(p.split('|')) for p in pron)+'</div>'
    v.add(rows,'left:%dpx;top:%dpx;width:%dpx;z-index:10;font-size:%dpx'%(L,Y0+int(.075*H),W-2*L,int(.034*H)),21.9,.8,t1)
    v.add('<div class="note" style="font-size:%dpx;padding:%dpx %dpx;box-shadow:%dpx %dpx 0 var(--ink)"><span class="mk" style="background:#B3261E;width:%dpx;height:%dpx;font-size:%dpx">✗</span> <i style="font-style:normal">*Soy quince años</i><br><span class="mk" style="background:#1B6B3A;width:%dpx;height:%dpx;font-size:%dpx;margin-top:%dpx">✓</span> <mark>Tengo</mark> quince años</div>'%(int(.04*H),int(.014*H),int(.03*W),int(.006*W),int(.006*W),int(.04*H),int(.04*H),int(.026*H),int(.04*H),int(.04*H),int(.026*H),int(.008*H)),'left:%dpx;top:%dpx;width:%dpx;z-index:10'%(L,Y0+int(.075*H)+int(.50*H),W-2*L),19.9,.6,t1)
    v.render(name,W,H,D,css,OUT,audio='/home/claude/assets/src/sertener.mp4')
if __name__=='__main__':
    build('SerTener_verticale_v3',720,1280,1)
