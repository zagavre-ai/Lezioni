from engine import *
OUT='/home/claude/assets/out'
B=[('FEMENINO','A menudo -o → -a; algunas palabras no cambian y otras son irregulares.'),
('PLURAL','Vocal + -s; consonante + -es; -z → -ces.'),
('INTERROGATIVOS','¿Cómo?, ¿de dónde?, ¿dónde?, ¿qué?, ¿cuántos?, ¿por qué?, ¿quién?'),
('PRONOMBRES SUJETO','yo, tú, él/ella/usted, nosotros/as, vosotros/as, ellos/ellas/ustedes; a menudo se omiten.'),
('SER / TENER','SER: identidad, origen y características. TENER: posesión y edad.'),
('PRESENTE REGULAR','Quitar -ar/-er/-ir y añadir la terminación correspondiente.'),
('REFLEXIVOS','me, te, se, nos, os, se + verbo conjugado.')]
Y=[50,277,504,731];W=600;H=205
pos=[];items=[];svg=''
items.append(('<div style="width:400px;height:150px;background:var(--blue);color:#fff;box-shadow:0 14px 36px rgba(11,21,48,.10);display:flex;align-items:center;justify-content:center;text-align:center;font-family:BG;font-weight:800;font-size:46px;line-height:1.05">¿De dónde<br>eres?</div>',0.3,.6));pos.append('position:absolute;left:760px;top:405px;z-index:3')
for i,(l,t) in enumerate(B):
    left=i<4
    x=60 if left else 1260;y=Y[i] if left else Y[i-4]
    my=y+H//2
    x1=x+W if left else x;x0=760 if left else 1160
    ln='<svg style="position:absolute;left:0;top:0;width:1920px;height:1080px" data-g="%d"><line x1="%d" y1="%d" x2="%d" y2="%d" stroke="#2060AF" stroke-width="6"/></svg>'%(i+1,x0,480,x1,my)
    items.append(('<div style="width:%dpx;height:%dpx;border:1px solid #D5DCE8;border-radius:16px;box-shadow:0 14px 36px rgba(11,21,48,.10);background:#fff;padding:18px 26px"><span class="lb" style="font-size:20px">[%s]</span><div style="font-weight:700;font-size:26px;line-height:1.3;margin-top:12px">%s</div></div>'%(W,H,l,t),1.6+i*1.4,.6));pos.append('position:absolute;left:%dpx;top:%dpx;z-index:2'%(x,y))
    svg+=ln
items.append(('<div style="width:%dpx;height:%dpx;border:2px dashed #9AA6BC;border-radius:16px;background:rgba(32,96,175,.07);padding:18px 26px"><span class="lb" style="font-size:20px">[FRASES CLAVE]</span><div style="font-weight:800;font-size:25px;line-height:1.4;margin-top:12px">«Me llamo…» · «Soy de…» · «Vivo en…» · «Estudio…» · «Tengo… años» · «Me levanto a las…»</div></div>'%(W,H),11.6,.6));pos.append('position:absolute;left:1260px;top:731px;z-index:2')
body=svg+wrap(items,pos)
render('PO08_mappa-finale',1920,1080,15,items,"",1,OUT,body)
