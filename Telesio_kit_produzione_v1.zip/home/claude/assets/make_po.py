from engine import *
OUT='/home/claude/assets/out'
LG=gen.LG
from v4 import V4
CSS="""
#root{background:#fff}
.hd{position:absolute;left:80px;right:80px;top:52px;height:72px;border-bottom:1.5px solid #C9D0DC}
.hd img{height:52px}
.ft{position:absolute;left:80px;right:80px;top:982px;border-top:1.5px solid #C9D0DC;padding-top:14px;font-family:'DM';font-size:21px;color:var(--blue);font-weight:500;display:flex;justify-content:space-between}
.ey{position:absolute;left:80px;top:134px}.ey .lb{font-size:24px}
.tt{position:absolute;left:80px;top:214px;font-family:'BG';font-weight:800;font-size:66px;letter-spacing:-.02em;line-height:1.05}
.bar{position:absolute;left:80px;top:308px;width:108px;height:5px;background:var(--ink)}
.bd{position:absolute;left:80px;top:340px;width:1760px;display:flex;flex-direction:column;gap:0}
.tr{display:grid;border:0;border-bottom:2px solid var(--ink);border-left:3px solid var(--ink);border-right:3px solid var(--ink);font-weight:800;font-size:29px}
.tr>div{padding:10px 22px;border-right:2px solid var(--ink);line-height:1.25}
.tr>div:last-child{border-right:0}
.tr>div:first-child{background:var(--blue);color:#fff}
.tr.h{border-top:3px solid var(--ink)}.tr.h>div{background:var(--ink);color:#fff;font-size:22px;letter-spacing:.1em;text-transform:uppercase;padding:12px 22px}
.tr.last{border-bottom:3px solid var(--ink)}
.note{margin-top:26px;border:1px solid #D5DCE8;border-radius:16px;box-shadow:0 14px 36px rgba(11,21,48,.10);background:rgba(32,96,175,.07);padding:18px 28px 20px;font-weight:700;font-size:28px;line-height:1.35;margin-right:9px}
.note .lb{font-size:20px;margin-bottom:10px;display:inline-block}
.two{display:grid;grid-template-columns:1fr 1fr;gap:34px}
.card{border:1px solid #D5DCE8;border-radius:16px;box-shadow:0 14px 36px rgba(11,21,48,.10);padding:22px 30px;background:#fff;margin-right:9px;margin-bottom:9px}
.card h3{font-family:'BG';font-weight:800;font-size:54px;line-height:1;margin:12px 0 14px}
.card p{font-weight:700;font-size:30px;line-height:1.35;margin-bottom:8px}
"""+V4
def page(name,eyebrow,title,items,dur,tweak=''):
    # items: (html,t0,fade) per il corpo
    head='<div class="hd"><img src="data:image/svg+xml;base64,%s"></div><div class="ey"><span class="lb">%s</span></div><div class="tt">%s</div><div class="bar"></div><div class="ft"><span>SPAGNOLO</span><span></span></div>'%(LG,eyebrow,title)
    body='<div class="bd">'+wrap(items)+'</div>'
    render(name,1920,1080,dur,items,CSS+tweak,1,OUT,head+body)
def tr(cells,cols,cls=''):
    return '<div class="tr %s" style="grid-template-columns:%s">%s</div>'%(cls,cols,''.join('<div>%s</div>'%c for c in cells))
def table(name,eyebrow,title,header,rows,cols,dur,note=None,r0=0.8,dt=0.8,fs=None,note_t=None,tweak=''):
    it=[(tr(header,cols,'h'),0.3,.5)]
    for i,r in enumerate(rows):it.append((tr(r,cols,'last' if i==len(rows)-1 else ''),r0+i*dt,.5))
    if note:it.append((note,note_t or (r0+len(rows)*dt+0.4),.6))
    page(name,eyebrow,title,it,dur,(".tr{font-size:%dpx}"%fs if fs else '')+tweak)
def nt(label,text):return '<div class="note"><span class="lb">[%s]</span><br>%s</div>'%(label,text)
# PO02
table('PO02_plurale','[REPASO]','Formación del plural',['Regla / Regola','Ejemplos / Esempi'],
 [['Vocal + -s','chica → chica<mark>s</mark>; libro → libro<mark>s</mark>'],['Consonante + -es','doctor → doctor<mark>es</mark>; profesor → profesor<mark>es</mark>'],['-z → -ces','luz → lu<mark>ces</mark>; lápiz → lápi<mark>ces</mark>'],['-s átona: normalmente invariable','el lunes → los lunes']],
 '34% 66%',12,nt('CONCORDANCIA','La concordancia cambia también el artículo y el adjetivo: el chico simpático → los chicos simpáticos; la estudiante nueva → las estudiantes nuevas.'),r0=1.0,dt=1.2,fs=32,note_t=6.5)
# PO03
table('PO03_interrogativos','[REPASO]','Interrogativos',['Forma','Uso','Ejemplo'],
 [['¿Quién? / ¿Quiénes?','persona','¿Quién es? / ¿Quiénes son?'],['¿Qué?','cosa, actividad o definición','¿Qué estudias?'],['¿Cuál? / ¿Cuáles?','elección o identificación','¿Cuál es tu teléfono?'],['¿Dónde?','lugar','¿Dónde vives?'],['¿De dónde?','origen','¿De dónde eres?'],['¿Cómo?','manera, descripción o nombre','¿Cómo te llamas?'],['¿Cuándo?','momento','¿Cuándo estudias?'],['¿Cuánto/a/os/as?','cantidad; concuerda con el sustantivo','¿Cuántos años tienes?'],['¿Por qué?','motivo','¿Por qué estudias español?']],
 '29% 33% 38%',12,nt('IMPORTANTE','«¿De dónde eres?» pregunta por el origen; «¿Dónde vives?» pregunta por el lugar de residencia.'),r0=0.8,dt=0.6,fs=28,note_t=6.6,tweak=".tr>div{padding:7px 18px}.note{margin-top:20px;padding:12px 24px 14px;font-size:27px}.tr.h>div{padding:8px 18px}")
# PO04
note2='<div class="two">'+nt('VOSOTROS / USTEDES','«Vosotros/as» se usa sobre todo en España; «ustedes» es habitual en América Latina.')+nt('OMISIÓN','En español el pronombre sujeto puede omitirse: «Yo vivo en Roma» / «Vivo en Roma».')+'</div>'
table('PO04_pronombres','[REPASO]','Pronombres sujeto',['Persona','Pronombre sujeto','Equivalente aproximado'],
 [['1.ª singular','yo','io'],['2.ª singular','tú','tu informal'],['3.ª singular','él / ella / usted','lui / lei / forma de cortesía'],['1.ª plural','nosotros / nosotras','noi'],['2.ª plural','vosotros / vosotras','voi, sobre todo en España'],['3.ª plural','ellos / ellas / ustedes','loro / ustedes']],
 '24% 36% 40%',12,note2,r0=0.8,dt=0.7,fs=28,note_t=5.8,tweak=".tr>div{padding:8px 20px}.note{padding:12px 22px 14px;font-size:24px;margin-top:20px}.two{gap:26px}")
# PO05
it=[('<div class="two"><div class="card"><span class="lb">[SER]</span><h3>SER</h3><p>identificar a una persona</p><p>indicar el origen</p><p>describir características</p><p style="margin-top:18px;color:var(--blue)">Soy estudiante.<br>Soy de Italia.<br>Somos simpáticos.</p></div><div class="card"><span class="lb">[TENER]</span><h3>TENER</h3><p>posesión</p><p>edad</p><p style="margin-top:18px;color:var(--blue)">Tengo un libro.<br>Tengo quince años.</p></div></div>',0.6,.7),
 (nt('ATENCIÓN','En español decimos «Tengo quince años», no <span style="background:var(--hl);text-decoration:line-through;text-decoration-thickness:4px">«Soy quince años»</span>.'),6.2,.6)]
page('PO05_ser-tener','[REPASO]','Verbos SER y TENER',it,12,".bd{top:330px}")
# PO06
table('PO06_presente-regular','[REPASO]','Presente de indicativo: verbos regulares',['Persona','-AR: HABLAR','-ER: COMER','-IR: VIVIR'],
 [['yo','habl<mark>o</mark>','com<mark>o</mark>','viv<mark>o</mark>'],['tú','habl<mark>as</mark>','com<mark>es</mark>','viv<mark>es</mark>'],['él / ella / usted','habl<mark>a</mark>','com<mark>e</mark>','viv<mark>e</mark>'],['nosotros/as','habl<mark>amos</mark>','com<mark>emos</mark>','viv<mark>imos</mark>'],['vosotros/as','habl<mark>áis</mark>','com<mark>éis</mark>','viv<mark>ís</mark>'],['ellos / ellas / ustedes','habl<mark>an</mark>','com<mark>en</mark>','viv<mark>en</mark>']],
 '31% 23% 23% 23%',12,None,r0=1.0,dt=1.1,fs=32)
