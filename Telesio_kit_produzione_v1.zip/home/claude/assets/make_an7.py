from lib_long import *
import json,os,sys
OUT='/home/claude/assets/out2'
# tempi di inizio di ciascuna frase della voce (secondi nel clip); se esiste vo_an07.json (tempi reali) li usa
TS=[0.8,6.0,13.0,20.5,29.0,39.0,49.0]; D=60
if os.path.exists('/home/claude/v5/vo/an07_times.json'):
    J=json.load(open('/home/claude/v5/vo/an07_times.json'));TS=J['starts'];D=J['dur']
def cap(v,t0,t1,txt):
    v.add('<div style="background:#EEF0F4;border-left:8px solid #2060AF;padding:14px 30px;font-weight:700;font-size:36px;line-height:1.3;width:1760px">%s</div>'%txt,'left:80px;top:862px;z-index:10',t0,.5,t1)
def pair(v,y,t0,t1,m,f,dt=.0,fs=84):
    v.add('<div style="display:flex;align-items:center;gap:36px"><div class="card" style="padding:14px 38px"><span class="hero" style="font-size:%dpx">%s</span></div><div class="hero" style="font-size:%dpx;color:var(--blue)">→</div><div class="card" style="padding:14px 38px"><span class="hero" style="font-size:%dpx">%s</span></div></div>'%(fs,m,fs,fs,f),'left:200px;top:%dpx;z-index:10'%y,t0+dt,.6,t1)
def rule(v,t0,t1,lab,txt):
    v.add('<span class="lb">%s</span>'%lab,'left:80px;top:150px;z-index:10',t0,.5,t1)
    v.add('<div style="background:var(--ink);color:#fff;font-family:BG;font-weight:800;font-size:96px;padding:12px 48px;border-radius:16px;display:inline-block">%s</div>'%txt,'left:200px;top:230px;z-index:10',t0+.2,.5,t1)
v=V();header(v)
EN=[TS[i+1]-0.3 if i<6 else D-0.5 for i in range(7)]
# 1 introduzione
v.add('<span class="lb">[FEMENINO]</span>','left:80px;top:150px;z-index:10',TS[0],.5,EN[0])
v.add('<div class="hero" style="font-size:200px">El femenino</div>','left:200px;top:330px;z-index:10',TS[0]+.4,.8,EN[0])
cap(v,TS[0],EN[0],'Il femminile in spagnolo: guardiamo le regole <b>una alla volta</b>.')
# 2 -o -> -a
rule(v,TS[1],EN[1],'[REGLA 1]','-o → -a')
pair(v,470,TS[1],EN[1],'el chic<mark>o</mark>','la chic<mark>a</mark>',2.85)
cap(v,TS[1],EN[1],'Le parole in <b>-o</b> cambiano in <b>-a</b>.')
# 3 -or -> -ora
rule(v,TS[2],EN[2],'[REGLA 2]','-or → -ora')
pair(v,470,TS[2],EN[2],'el profes<mark>or</mark>','la profes<mark>ora</mark>',2.75)
cap(v,TS[2],EN[2],'Le parole in <b>-or</b> aggiungono una <b>-a</b>.')
# 4 consonante + a
rule(v,TS[3],EN[3],'[REGLA 3]','consonante + a')
pair(v,470,TS[3],EN[3],'el doct<mark>or</mark>','la doct<mark>ora</mark>',3.9)
cap(v,TS[3],EN[3],'Alcune parole che finiscono per <b>consonante</b> aggiungono una <b>-a</b>.')
# 5 invariabili
rule(v,TS[4],EN[4],'[REGLA 4]','-e / -ista: igual')
pair(v,440,TS[4],EN[4],'el estudiant<mark>e</mark>','la estudiant<mark>e</mark>',3.9,74)
pair(v,640,TS[4],EN[4],'el art<mark>ista</mark>','la art<mark>ista</mark>',6.6,74)
cap(v,TS[4],EN[4],'Le parole in <b>-e</b> e molte in <b>-ista</b> <b>non cambiano</b>: cambia solo l’articolo.')
# 6 irregulares
rule(v,TS[5],EN[5],'[REGLA 5]','irregulares')
for i,(m,f) in enumerate([('el hombre','la mujer'),('el padre','la madre'),('el actor','la actriz')]):
    pair(v,400+i*140,TS[5],EN[5],m,f,[2.1,4.1,6.0][i],70)
cap(v,TS[5],EN[5],'Alcune forme sono <b>irregolari</b>: vanno imparate.')
# 7 concordancia
rule(v,TS[6],EN[6],'[CONCORDANCIA]','anche l’aggettivo')
pair(v,470,TS[6],EN[6],'el chico simpátic<mark>o</mark>','la chica simpátic<mark>a</mark>',1.7,64)
cap(v,TS[6],EN[6],'Anche l’<b>aggettivo</b> si accorda: <b>el chico simpático, la chica simpática</b>.')
v.render('AN07_Femenino_v1',1920,1080,D,CSS,OUT)
