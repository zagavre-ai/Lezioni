exec(open('/home/claude/assets/make_po.py').read().split('# PO02')[0])
table('PO01_femenino','[REPASO]','Formación del femenino',['Regla','Ejemplo'],
 [['-o → -a','el chic<mark>o</mark> → la chic<mark>a</mark>'],['-or → -ora','el profesor → la profesor<mark>a</mark>'],['Algunas consonantes + -a','el doctor → la doctor<mark>a</mark>'],['-e u otras terminaciones: pueden permanecer iguales','el estudiante → la estudiante'],['Formas irregulares','el actor → la actriz']],
 '42% 58%',12,nt('CONCORDANCIA','El adjetivo concuerda con el sustantivo: el chico simpático → la chica simpática.'),r0=0.9,dt=1.1,fs=30,note_t=7.0,tweak=".tr>div{padding:9px 22px}.note{margin-top:22px;font-size:27px}")
table('PO07_reflexivos','[REPASO]','Verbos reflexivos',['Persona','LLAMARSE','LEVANTARSE'],
 [['yo','me llamo','me levanto'],['tú','te llamas','te levantas'],['él / ella / usted','se llama','se levanta'],['nosotros/as','nos llamamos','nos levantamos'],['vosotros/as','os llamáis','os levantáis'],['ellos / ellas / ustedes','se llaman','se levantan']],
 '30% 35% 35%',12,nt('ESTRUCTURA','[pronombre reflexivo] + [verbo conjugado]: me, te, se, nos, os, se.'),r0=0.9,dt=0.8,fs=29,note_t=6.6,tweak=".tr>div{padding:8px 20px}.note{margin-top:20px;font-size:26px}")
