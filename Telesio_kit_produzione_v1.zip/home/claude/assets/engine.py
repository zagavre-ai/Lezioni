import sys,os,shutil,subprocess,json
sys.path.insert(0,'/home/claude/gen')
import gen
from playwright.sync_api import sync_playwright
BASE=gen.CSS_FONTS+"""
:root{--ink:#0B1530;--blue:#2060AF;--hl:#FFE600;--soft:#EEF0F4}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#fff;font-family:'FG';color:var(--ink);line-height:1.25}
.it{opacity:0}
mark{background:linear-gradient(transparent 48%,var(--hl) 48%);color:inherit;padding:0 .08em}
.lb{display:inline-block;font-family:'FG';font-weight:800;letter-spacing:.14em;text-transform:uppercase;background:rgba(32,96,175,.10);color:var(--blue);padding:.32em .95em;border-radius:999px;font-size:.62em}
.bg{font-family:'BG';font-weight:800;letter-spacing:-.01em}
.dm{font-family:'FG';font-weight:800}
b{font-weight:800}
"""
import re
def strip_lb(h):return re.sub(r'(<span class="lb"[^>]*>)\[([^\]]*)\](</span>)',r'\1\2\3',h)
def render(name,w,h,dur,items,css,scale,outdir,body_extra=''):
    """items: list of (html, t0, fade). Ogni item e' un elemento assoluto/flusso con classe it."""
    html='<!doctype html><meta charset=utf-8><style>%s%s</style><body><div id=root style="width:%dpx;height:%dpx;position:relative;overflow:hidden;background:#fff">%s</div>'%(BASE,css,w,h,body_extra)
    # gli item sono gia' dentro body_extra con id it0..itn
    t0s=[(i[1],i[2]) for i in items]
    os.makedirs(outdir+'/'+name,exist_ok=True)
    fr=outdir+'/'+name+'/f';shutil.rmtree(fr,ignore_errors=True);os.makedirs(fr)
    html=strip_lb(html)
    open(outdir+'/'+name+'/p.html','w').write(html)
    N=int(round(dur*30));seen={};
    with sync_playwright() as p:
        b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":w,"height":h},device_scale_factor=scale)
        pg.goto('file://'+os.path.abspath(outdir+'/'+name+'/p.html'));pg.evaluate("document.fonts.ready")
        pg.evaluate("window.T0=%s"%json.dumps(t0s))
        pg.evaluate("""window.setT=function(t){var k=[];window.T0.forEach(function(a,i){var o=Math.max(0,Math.min(1,(t-a[0])/a[1]));o=o*o*(3-2*o);o=Math.round(o*100)/100;document.querySelectorAll('#it'+i+',[data-g="'+i+'"]').forEach(function(e){e.style.opacity=o;if(e.tagName!='TD'&&e.tagName!='TH'&&e.tagName!='TR')e.style.transform='translateY('+((1-o)*8)+'px)'});k.push(o)});return k.join(',')}""")
        last=None
        for n in range(N):
            k=pg.evaluate("setT(%f)"%(n/30.0))
            fn='%s/%05d.png'%(fr,n+1)
            if k in seen:os.link(seen[k],fn)
            else:
                pg.screenshot(path=fn);seen[k]=fn
        b.close()
    out=outdir+'/'+name+'.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','30','-i',fr+'/%05d.png','-c:v','libx264','-preset','slow','-crf','12','-pix_fmt','yuv420p','-r','30','-movflags','+faststart',out],check=True)
    shutil.copy('%s/%05d.png'%(fr,N),outdir+'/'+name+'_finale.png')
    shutil.rmtree(fr);print(name,len(seen),'stati')
def wrap(items,pos=None):
    """items: lista di (html,t0,fade) -> html con id it{i}; l'html passa gia' le classi/posizione"""
    return ''.join('<div class="it" id="it%d" style="%s">%s</div>'%(i,(pos[i] if pos else ''),h) for i,(h,t,f) in enumerate(items))
