from lib_long import *
v=V();header(v)
D=325.056;OUT='/home/claude/assets/out2'
def sq(i,x,y,t,t1,s=150):v.add('<div class="sq" style="width:%dpx;height:%dpx;font-size:%dpx">%d</div>'%(s,s,int(s*.5),i),'left:%dpx;top:%dpx;z-index:10'%(x,y),t,.5,t1)
# A titolo 0-24.5
t1=24.5
v.add('<span class="lb">[RIEPILOGO]</span>','left:140px;top:250px;z-index:10',.6,.6,t1)
v.add('<div class="hero" style="font-size:150px">Spagnolo:<br>fondamenti</div>','left:140px;top:320px;z-index:10',1.4,.9,t1)
v.add('<div style="width:130px;height:8px;background:var(--hl)"></div>','left:140px;top:640px;z-index:10',3,.5,t1)
v.add('<div style="font-weight:700;font-size:46px">Sei tappe per costruire la lingua</div>','left:140px;top:675px;z-index:10',3.4,.7,t1)
for i in range(6):sq(i+1,1060+(i%3)*250,330+(i//3)*250,5+i*2.6,t1)
# B indice 24.5-40.75
t1=40.75;head(v,24.5,t1,'[PERCORSO]','Le sei tappe')
names=['Basi: genere e numero','Domande e pronomi','I verbi Ser e Tener','Presente indicativo','Verbi riflessivi','Sintesi personale']
for i,n in enumerate(names):
    v.add('<div class="card"><span class="lb">[%d]</span><h3>%s</h3></div>'%(i+1,n),'left:%dpx;top:%dpx;width:540px;z-index:10'%(80+(i%3)*610,340+(i//3)*290),26.5+i*2.1,.6,t1)
    v.add('','',0,.01)
for k in range(6):pass
# C cap1
chapter(v,40.75,46.25,1,6,'Basi: genere e numero','Le fondamenta delle parole')
# D chico/chica 46.25-58.5
hero(v,46.25,58.5,'[GENERE]','¿<mark>Chico</mark> o <mark>chica</mark>?',fs=170,w=1600,y=400,x=160)
v.add('<div style="font-weight:700;font-size:44px"><span class="dm" style="color:var(--blue)">-o</span> → <span class="dm" style="color:var(--blue)">-a</span> &nbsp;·&nbsp; il genere cambia la parola</div>','left:160px;top:640px;z-index:10',51.5,.7,58.5)
# E femminile 58.5-80.5
table(v,58.5,80.5,'[GENERE E NUMERO]','Il femminile',['Regola','Esempio'],
 [['-o diventa -a','chico → chic<mark>a</mark>'],['-or + a','profesor → profesor<mark>a</mark>'],['Alcune parole restano uguali','el estudiante / la estudiante'],['Irregolari','hombre → mujer'],['Gli aggettivi concordano','el chico simpático / la chica simpática']],'38% 62%',61,3.4,fs=42,pad=34)
# F plurale 80.5-101.25
table(v,80.5,101.25,'[GENERE E NUMERO]','Il plurale',['Regola','Esempio'],
 [['Vocale + -s','libro → libro<mark>s</mark>'],['Consonante + -es','profesor → profesor<mark>es</mark>'],['-z diventa -ces','luz → lu<mark>ces</mark>'],['-s atona: resta invariabile','el lunes → los lunes']],'38% 62%',83,3.6,fs=44,pad=38)
# G cap2
chapter(v,101.25,106.75,2,6,'Domande e pronomi','Il progetto strutturale')
# H interrogativi 106.75-126
table(v,106.75,126,'[DOMANDE E PRONOMI]','Gli interrogativi',['Forma','Uso','Esempio'],
 [['¿Quién?','persona','¿Quién es?'],['¿Qué?','cosa','¿Qué estudias?'],['¿Dónde?','luogo','¿Dónde vives?'],['¿De dónde?','origine','¿De dónde eres?'],['¿Cómo?','modo','¿Cómo te llamas?'],['¿Cuántos?','quantità','¿Cuántos años tienes?']],'28% 28% 44%',108.8,2.4,fs=40,pad=30)
# I pronomi 126-148
table(v,126,148,'[DOMANDE E PRONOMI]','I pronomi soggetto',['Persona','Pronome','Equivalente'],
 [['1.ª singolare','yo','io'],['2.ª singolare','tú','tu'],['3.ª singolare','él / ella / usted','lui / lei / Lei'],['1.ª plurale','nosotros / nosotras','noi'],['2.ª plurale','vosotros / vosotras','voi'],['3.ª plurale','ellos / ellas / ustedes','loro']],'26% 40% 34%',128.5,2.3,fs=36,pad=22,
 note='<div class="note" style="display:flex;gap:40px;align-items:center;padding:12px 26px"><span class="lb">[SPAGNA / AMERICA LATINA]</span><span style="font-size:27px">«vosotros» in Spagna · «ustedes» in America Latina</span></div>',note_t=142.5)
# J cap3
chapter(v,148,154,3,6,'I verbi Ser e Tener','Identità e possesso')
# K 154-160 due card
t1=160
v.add('<span class="lb">[SER E TENER]</span>','left:80px;top:150px;z-index:10',154.4,.5,t1)
v.add('<div class="card" style="width:820px"><span class="lb">[SER]</span><h3>Identità</h3><p>chi sei, da dove vieni, come sei</p></div>','left:100px;top:330px;z-index:10',154.8,.6,t1)
v.add('<div class="card" style="width:820px"><span class="lb">[TENER]</span><h3>Possesso</h3><p>che cosa hai, quanti anni hai</p></div>','left:1000px;top:330px;z-index:10',157,.6,t1)
# L esempi SER 160-164.0 ; M esempi TENER 164-170.75
def exs(t0,t1,eb,title,lines,ts):
    head(v,t0,t1,eb,title)
    for i,(l,t) in enumerate(zip(lines,ts)):
        v.add('<div class="card" style="width:1000px;padding:20px 34px"><span class="hero" style="font-size:64px">%s</span></div>'%l,'left:100px;top:%dpx;z-index:10'%(340+i*150),t,.45,t1)
exs(160,164,'[SER E TENER]','Esempi con SER',['<mark>Soy</mark> estudiante.','<mark>Soy</mark> de Italia.','<mark>Somos</mark> simpáticos.'],[160.5,161.5,162.5])
exs(164,170.75,'[SER E TENER]','Esempi con TENER',['<mark>Tengo</mark> un libro.','<mark>Tengo</mark> quince años.'],[165,167.4])
# N età 170.75-175.75
t1=175.75
v.add('<span class="lb">[ATTENZIONE]</span>','left:210px;top:290px;z-index:10',171,.5,t1)
v.add('<div class="hero" style="font-size:84px;max-width:1500px">Per l\'età si usa <mark>TENER</mark>, non SER.</div>','left:210px;top:360px;z-index:10',171.3,.7,t1)
v.add('<div class="card" style="width:560px"><span class="mk" style="background:#B3261E">✗</span><p style="font-size:44px;margin-top:14px">Soy quince años</p></div>','left:210px;top:640px;z-index:10',172.8,.5,t1)
v.add('<div class="card" style="width:560px"><span class="mk" style="background:#1B6B3A">✓</span><p style="font-size:44px;margin-top:14px"><mark>Tengo</mark> quince años</p></div>','left:900px;top:640px;z-index:10',173.8,.5,t1)
# O tabella ser/tener 175.75-187
table(v,175.75,187,'[SER E TENER]','SER e TENER al presente',['Persona','SER','TENER'],
 [['yo','soy','tengo'],['tú','eres','tienes'],['él / ella / usted','es','tiene'],['nosotros / nosotras','somos','tenemos'],['vosotros / vosotras','sois','tenéis'],['ellos / ellas / ustedes','son','tienen']],'36% 32% 32%',177.3,1.35,fs=40,pad=28)
# P cap4
chapter(v,187,193,4,6,'Presente indicativo','I verbi regolari')
# Q 3 passaggi 193-207.5
t1=207.5;head(v,193,t1,'[PRESENTE INDICATIVO]','Tre passaggi')
st=[('1','Togli','-ar, -er, -ir'),('2','Identifica','il soggetto'),('3','Aggiungi','la desinenza giusta')]
for i,(n,a,b) in enumerate(st):
    v.add('<span class="lb">[%s]</span><h3>%s</h3><p>%s</p>'%(n,a,b),'left:%dpx;top:340px;width:540px;z-index:10'%(80+i*610),195+i*3.4,.6,t1) if False else None
    v.add('<div class="card" style="width:520px"><span class="lb">[%s]</span><h3>%s</h3><p>%s</p></div>'%(n,a,b),'left:%dpx;top:340px;z-index:10'%(100+i*620),195.2+i*3.4,.6,t1)
    if i<2:v.add('<div style="font-family:BG;font-weight:800;font-size:90px;color:var(--blue)">→</div>','left:%dpx;top:400px;z-index:10'%(640+i*620),196.4+i*3.4,.5,t1)
v.add('<div class="note" style="font-size:42px"><span class="lb">[ESEMPIO]</span><br>camin<b>ar</b> → camin- → camin<mark>o</mark></div>','left:100px;top:700px;width:1100px;z-index:10',203,.7,t1)
# R coniugazione 207.5-227
table(v,207.5,227,'[PRESENTE INDICATIVO]','Verbi regolari: -ar, -er, -ir',['Persona','HABLAR','COMER','VIVIR'],
 [['yo','hablo','como','vivo'],['tú','hablas','comes','vives'],['él / ella / usted','habla','come','vive'],['nosotros / nosotras','hablamos','comemos','vivimos'],['vosotros / vosotras','habláis','coméis','vivís'],['ellos / ellas / ustedes','hablan','comen','viven']],'31% 23% 23% 23%',209.3,2.6,fs=40,pad=28)
# S cap5
chapter(v,227,231.75,5,6,'Verbi riflessivi','Azioni verso l\'interno')
# T definizione 231.75-246.25
t1=246.25;head(v,231.75,t1,'[VERBI RIFLESSIVI]','Che cos\'è un verbo riflessivo')
v.add('<div style="font-weight:700;font-size:44px;line-height:1.35;max-width:1500px">Il soggetto e il destinatario dell\'azione <mark>coincidono</mark>. Si usano questi pronomi:</div>','left:80px;top:340px;z-index:10',233,.7,t1)
for i,p in enumerate(['me','te','se','nos','os','se']):
    v.add('<div class="sq" style="width:210px;height:140px;font-size:64px">%s</div>'%p,'left:%dpx;top:560px;z-index:10'%(100+i*280),236+i*0.9,.5,t1)
v.add('<div class="note" style="font-size:40px"><span class="lb">[ESEMPIO]</span><br>me levanto = mi alzo</div>','left:100px;top:790px;width:900px;z-index:10',242,.7,t1)
# U llamarse levantarse 246.25-262
table(v,246.25,262,'[VERBI RIFLESSIVI]','LLAMARSE e LEVANTARSE',['Persona','LLAMARSE','LEVANTARSE'],
 [['yo','me llamo','me levanto'],['tú','te llamas','te levantas'],['él / ella / usted','se llama','se levanta'],['nosotros / nosotras','nos llamamos','nos levantamos'],['vosotros / vosotras','os llamáis','os levantáis'],['ellos / ellas / ustedes','se llaman','se levantan']],'34% 33% 33%',248.2,2.1,fs=40,pad=28)
# V cap6
chapter(v,262,269.5,6,6,'Sintesi personale','Mettere tutto insieme')
# W sintesi 269.5-287.75
table(v,269.5,287.75,'[SINTESI]','Che cosa ricordare',['Contenuto','Ricorda'],
 [['Femminile','spesso -o diventa -a'],['Plurale','vocale + -s; consonante + -es'],['Domande','¿Cómo? ¿De dónde? ¿Qué?'],['Pronomi','yo, tú, él, nosotros…'],['Ser / Tener','identità / possesso'],['Presente','togli -ar/-er/-ir + desinenza'],['Riflessivi','me, te, se + verbo']],'28% 72%',272,2.1,fs=38,pad=24)
# X frase modello 287.75-306.25
t1=306.25
v.add('<span class="lb">[FRASE MODELLO]</span>','left:150px;top:210px;z-index:10',288.1,.5,t1)
v.add('<div class="hero" style="font-size:78px;max-width:1650px;line-height:1.2">«Hola, <span style="color:var(--blue)">me</span> llamo Leo, <span style="color:var(--blue)">soy</span> de Italia y <span style="color:var(--blue)">tengo</span> quince años, <span style="color:var(--blue)">vivo</span> en Roma.»</div>','left:150px;top:290px;z-index:10',290.4,.8,t1)
for i,(l,tx,tt) in enumerate([('PRONOME','me',296.6),('VERBO SER','soy',297.8),('VERBO TENER','tengo',298.9),('PRESENTE','vivo',300.1)]):
    v.add('<div class="note" style="font-size:40px;padding:14px 24px"><span class="lb">[%s]</span><br><b>%s</b></div>'%(l,tx),'left:%dpx;top:660px;width:380px;z-index:10'%(150+i*430),tt,.6,t1)
# Y chiusura 306.25-325.06
t1=D+1
hero(v,306.25,t1,'[ORA TOCCA A TE]','¿Cómo te <mark>llamas</mark><br>y de <mark>dónde</mark> eres?',fs=130,w=1600,y=340,x=210)
v.render('Fondamenti_v4',1920,1080,D,CSS,OUT,audio='/home/claude/assets/src/fond.mp4')
