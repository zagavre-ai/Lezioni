from engine import *
OUT='/home/claude/assets/out';os.makedirs(OUT,exist_ok=True)
CSS="""#root{box-shadow:inset 0 0 0 1px #D5DCE8;border-radius:16px}
.pad{position:absolute;inset:14px 14px 12px;display:flex;flex-direction:column;gap:8px}
.ttl{font-family:'BG';font-weight:800;font-size:19px;line-height:1.1;letter-spacing:-.01em}
.row{display:flex;gap:9px;align-items:flex-start}
.n{flex:0 0 26px;height:26px;border-radius:50%;background:var(--blue);color:#fff;font-family:'BG';font-weight:800;font-size:16px;display:flex;align-items:center;justify-content:center;position:relative}
.rw{font-weight:700;font-size:16px;line-height:1.2;padding-top:3px}
.ln{position:absolute;left:11px;top:26px;width:4px;height:var(--h);background:var(--blue)}
.rule{font-family:'FG';font-weight:800;font-size:13px;color:var(--blue);letter-spacing:.04em}
.ex{font-weight:800;font-size:18px}
.sep{border-top:1px solid #DDE3EE;padding-top:6px}
.big{font-family:'BG';font-weight:800;font-size:46px;line-height:1;letter-spacing:-.02em}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.tile{border:1px solid #D5DCE8;border-radius:10px;padding:6px 8px}.tile small{display:block;font-family:'FG';font-weight:800;font-size:10px;color:var(--blue)}.tile b{font-size:17px}
table{border-collapse:separate;border-spacing:0;width:100%;border:1px solid #DDE3EE;border-radius:10px;overflow:hidden}td,th{border:0;border-bottom:1px solid #E6EAF1;padding:3px 6px;font-size:13px;font-weight:700;text-align:left}
th{background:var(--ink);color:#fff;font-size:12px}td:first-child{background:rgba(32,96,175,.07);color:var(--blue);font-weight:800}
"""
def build(name,dur,items,css=''):
    pad='<div class="pad">'+wrap(items)+'</div>'
    render(name,329,390,dur,items,CSS+css,2,OUT,pad)
# IS00 road map
steps=['Formación del femenino','Formación del plural','Interrogativos','Pronombres sujeto','Verbos SER y TENER','Presente de indicativo: verbos regulares','Verbos reflexivos']
it=[('<div class="ttl">En esta unidad aprenderás a…</div>',0.2,.5)]
for i,s in enumerate(steps):
    ln='<div class="ln" style="--h:18px"></div>' if i<6 else ''
    it.append(('<div class="row"><div class="n">%d%s</div><div class="rw">%s</div></div>'%(i+1,ln,s),0.9+i*1.1,.5))
build('IS00_roadmap',10,it,".pad{gap:15px}.ttl{font-size:20px}")
# IS01
it=[('<span class="lb">[REGLA]</span>',0.3,.5),('<div class="big">-<mark>o</mark> → -<mark>a</mark></div>',1.2,.6),
 ('<div class="sep"><div class="ex" style="font-size:24px">el chic<mark>o</mark> → la chic<mark>a</mark></div></div>',3.6,.6),
 ('<div class="sep"><div class="ex" style="font-size:24px">alt<mark>o</mark> → alt<mark>a</mark></div></div>',6.0,.6)]
build('IS01_o-a',10,it,".pad{gap:18px;justify-content:center}")
# IS02
rows=[('-o → -a','el chic<mark>o</mark> → la chic<mark>a</mark>'),('-or → -ora','el profesor → la profesor<mark>a</mark>'),('Algunas consonantes + -a','el doctor → la doctor<mark>a</mark>'),('-e u otras terminaciones: pueden permanecer iguales','el estudiante → la estudiante'),('Formas irregulares','el actor → la actriz')]
it=[('<div class="ttl">Formación del femenino</div>',0.2,.5)]
for i,(r,e) in enumerate(rows):it.append(('<div class="sep"><div class="rule">%s</div><div class="ex">%s</div></div>'%(r,e),1.0+i*2.0,.6))
build('IS02_femenino',12,it,".pad{gap:12px}")
# IS03
rows=[('Vocal + -s','chica → chica<mark>s</mark>'),('Consonante + -es','doctor → doctor<mark>es</mark>'),('-z → -ces','luz → lu<mark>ces</mark>'),('-s átona: normalmente invariable','el lunes → los lunes')]
it=[('<div class="ttl">Formación del plural</div>',0.2,.5)]
for i,(r,e) in enumerate(rows):it.append(('<div class="sep"><div class="rule">%s</div><div class="ex" style="font-size:19px">%s</div></div>'%(r,e),1.0+i*2.5,.6))
build('IS03_plural',12,it,".pad{gap:14px}")
# IS04
rows=[('¿Quién?','persona'),('¿Dónde?','lugar'),('¿De dónde?','origen'),('¿Cómo?','manera, descripción o nombre'),('¿Por qué?','motivo')]
it=[('<div class="ttl">Interrogativos</div>',0.2,.5)]
for i,(r,e) in enumerate(rows):it.append(('<div class="sep" style="display:flex;justify-content:space-between;align-items:baseline;gap:8px"><span class="bg" style="font-size:24px;color:var(--ink)"><span style="color:var(--blue)">¿</span>%s<span style="color:var(--blue)">?</span></span><span class="rule" style="text-align:right;font-size:12px">%s</span></div>'%(r[1:-1],e),1.0+i*2.2,.6))
it.append(('<div class="rule" style="font-size:12px"><mark>Los interrogativos llevan tilde.</mark></div>',12.6,.6))
build('IS04_interrogativos',15,it,".pad{gap:10px}")
# IS05
P=[('1.ª singular','yo'),('2.ª singular','tú'),('3.ª singular','él / ella / usted'),('1.ª plural','nosotros / nosotras'),('2.ª plural','vosotros / vosotras'),('3.ª plural','ellos / ellas / ustedes')]
it=[('<div class="ttl">Pronombres sujeto</div>',0.2,.5)]
order=[0,3,1,4,2,5]
for j,i in enumerate(order):it.append(('<div class="tile"><small>%s</small><b>%s</b></div>'%P[i],0.9+j*1.2,.5))
pos=['']+['']*6
css=".tiles{display:grid}"
# griglia 2 colonne: usiamo flex-wrap
def build_grid():
    pad='<div class="pad"><div id="it0" class="it">'+it[0][0]+'</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;grid-auto-rows:78px">'+''.join('<div class="it" id="it%d">%s</div>'%(i,it[i][0]) for i in range(1,7))+'</div></div>'
    render('IS05_pronombres',329,390,10,it,CSS+".pad{gap:12px}.tile b{font-size:16px}.tile{height:78px;display:flex;flex-direction:column;justify-content:center}",2,OUT,pad)
build_grid()
# IS06
it=[('<span class="lb">[ESPAÑA]</span>',0.3,.5),('<div class="bg" style="font-size:30px;margin-top:-4px">vosotros/as</div>',1.0,.5),
 ('<div style="font-size:16px;font-weight:700">«Vosotros/as» se usa sobre todo en España.</div>',2.0,.6),
 ('<div class="sep"><span class="lb">[AMÉRICA LATINA]</span></div>',5.0,.5),('<div class="bg" style="font-size:30px;margin-top:-4px">ustedes</div>',5.7,.5),
 ('<div style="font-size:16px;font-weight:700">«Ustedes» es habitual en América Latina y también se utiliza como forma de cortesía en España.</div>',6.7,.6)]
build('IS06_vosotros-ustedes',12,it,".pad{gap:10px}.bg mark{padding:0}")
# IS07
S=[('yo','soy','tengo'),('tú','eres','tienes'),('él / ella / usted','es','tiene'),('nosotros/as','somos','tenemos'),('vosotros/as','sois','tenéis'),('ellos / ellas / ustedes','son','tienen')]
rows7=''.join('<tr class="it" data-g="%d"><td>%s</td><td>%s</td><td>%s</td></tr>'%(i+1,a,('<mark>%s</mark>'%b) if i==0 else b,('<mark>%s</mark>'%c) if i==0 else c) for i,(a,b,c) in enumerate(S))
it=[('<div class="ttl">SER · TENER</div>',0.2,.5)]+[('',1.0+i*1.4,.5) for i in range(6)]
pad='<div class="pad"><div id="it0" class="it">'+it[0][0]+'</div><table><tr><th>Persona</th><th>SER</th><th>TENER</th></tr>'+rows7+'</table></div>'
render('IS07_ser-tener',329,390,12,it,CSS+"td{font-size:12px;padding:5px 5px}.pad{gap:10px}td:not(:first-child){background:#fff;font-size:14px}",2,OUT,pad.replace('<tr class="it" id="it','<tr class="it" id="it'))
# IS08
it=[('<div class="ttl">Presente regular</div>',0.2,.5),
 ('<div class="row"><div class="n">1</div><div class="rw">quitamos -ar, -er o -ir</div></div>',1.0,.5),
 ('<div class="ex" style="font-size:28px;padding-left:35px">habl<span style="background:var(--hl);text-decoration:line-through;text-decoration-thickness:3px">ar</span></div>',2.4,.5),
 ('<div class="row"><div class="n">2</div><div class="rw">añadimos la terminación correspondiente a la persona</div></div>',5.0,.5),
 ('<div class="ex" style="font-size:19px;padding-left:35px;line-height:1.5">hablar → habl<mark>o</mark><br>comer → com<mark>o</mark><br>vivir → viv<mark>o</mark></div>',7.2,.6)]
build('IS08_taglia-desinenza',12,it,".pad{gap:10px}")
# IS09
T=[('yo',['habl<mark>o</mark>','com<mark>o</mark>','viv<mark>o</mark>']),('tú',['habl<mark>as</mark>','com<mark>es</mark>','viv<mark>es</mark>']),('él / ella / usted',['habl<mark>a</mark>','com<mark>e</mark>','viv<mark>e</mark>'])]
it=[('',0.2,.5),('',1.0,.5),('',3.5,.5),('',6.0,.5)]
hd=''.join('<th class="it" data-g="%d">%s</th>'%(j+1,t) for j,t in enumerate(['-AR: HABLAR','-ER: COMER','-IR: VIVIR']))
body=''.join('<tr><td>%s</td>%s</tr>'%(a,''.join('<td class="it" data-g="%d" style="background:#fff;color:var(--ink);font-size:15px">%s</td>'%(j+1,x) for j,x in enumerate(b))) for a,b in T)
pad='<div class="pad"><div class="it ttl" id="it0">-AR · -ER · -IR</div><table><tr><th>Persona</th>'+hd+'</tr>'+body+'</table></div>'
render('IS09_tre-gruppi',329,390,12,it,CSS+".pad{gap:14px}th{font-size:11px;padding:5px 4px}td{padding:12px 4px}td:first-child{font-size:12px}",2,OUT,pad)
# IS10
it=[('<div class="ttl">Verbos reflexivos</div>',0.2,.5),
 ('<div class="sep"><div class="rule">estructura</div><div class="ex" style="font-size:16px;line-height:1.4"><span style="border:2px solid var(--ink);padding:1px 5px">[pronombre reflexivo]</span><br><span style="color:var(--blue);font-size:22px;font-weight:800">+</span><br><span style="border:2px solid var(--ink);padding:1px 5px">[verbo conjugado]</span></div></div>',1.0,.6),
 ('<div class="bg" style="font-size:30px"><mark>me</mark> llamo</div>',4.0,.6),
 ('<div class="sep"><div class="rule">pronombres</div><div class="ex" style="font-size:18px">me, te, se, nos, os, se</div></div>',6.5,.6),
 ('<div class="ex" style="font-size:15px;line-height:1.5">te llamas<br>se llama</div>',8.2,.6)]
build('IS10_reflexivos',10,it,".pad{gap:10px}")
