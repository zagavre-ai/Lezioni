from lib_long import *
v=V();header(v)
D=324.0;OUT='/home/claude/assets/out2'
# G1 titolo
t1=22.5
v.add('<span class="lb">[GRAMMATICA]</span>','left:140px;top:250px;z-index:10',.6,.6,t1)
v.add('<div class="hero" style="font-size:132px">Genere e plurali<br>in spagnolo</div>','left:140px;top:320px;z-index:10',1.4,.9,t1)
v.add('<div style="width:130px;height:8px;background:var(--hl)"></div>','left:140px;top:640px;z-index:10',3,.5,t1)
v.add('<div style="font-weight:700;font-size:46px">Decifrare il codice delle parole</div>','left:140px;top:675px;z-index:10',3.4,.7,t1)
for i,(a,b) in enumerate([('-o','-a'),('-s','-es'),('z','c')]):
    v.add('<div class="sq" style="width:300px;height:130px;font-size:58px">%s → %s</div>'%(a,b),'left:1250px;top:%dpx;z-index:10'%(330+i*180),6+i*3.5,.5,t1)
# G2 domanda
hero(v,22.5,46,'[PARTIAMO DA UNA DOMANDA]','Come diventa plurale<br>la parola <mark>luz</mark>?',fs=120,w=1600,y=400,x=200)
# G3
chapter(v,46,50,1,5,'Maschile e femminile','Decifrare il codice')
# G4 card chico/chica
t1=75;head(v,50,t1,'[GENERE]','Maschile e femminile')
v.add('<div class="card" style="width:820px"><span class="lb">[MASCHILE]</span><h3>el <mark>chico</mark> simpático</h3></div>','left:100px;top:360px;z-index:10',52,.6,t1)
v.add('<div class="card" style="width:820px"><span class="lb">[FEMMINILE]</span><h3>la <mark>chica</mark> simpática</h3></div>','left:1000px;top:360px;z-index:10',60,.6,t1)
v.add('<div class="note" style="font-size:36px"><span class="lb">[CONCORDANZA]</span><br>Articolo, nome e aggettivo cambiano insieme.</div>','left:100px;top:700px;width:1200px;z-index:10',68,.7,t1)
# G5 tabella femminile
table(v,75,106.25,'[GENERE]','Il femminile',['Regola','Esempio'],
 [['-o → -a','chico → chic<mark>a</mark>'],['-or → -ora','profesor → profesor<mark>a</mark>'],['Invariabile','el estudiante / la estudiante'],['Irregolare','hombre → mujer']],'34% 66%',78,6,fs=36,pad=30)
# G6 passaggi
t1=126.25;head(v,106.25,t1,'[CONCORDANZA]','Tre elementi da accordare')
st=[('1','Articolo','es. el → la'),('2','Sostantivo','chico → chica'),('3','Aggettivo','simpático → simpática')]
for i,(n,a,b) in enumerate(st):
    v.add('<div class="card" style="width:520px"><span class="lb">[%s]</span><h3>%s</h3><p>%s</p></div>'%(n,a,b),'left:%dpx;top:340px;z-index:10'%(100+i*620),108.5+i*5,.6,t1)
    if i<2:v.add('<div style="font-family:BG;font-weight:800;font-size:90px;color:var(--blue)">→</div>','left:%dpx;top:400px;z-index:10'%(640+i*620),110+i*5,.5,t1)
v.add('<div class="note" style="font-size:40px"><span class="lb">[ESEMPIO]</span><br><mark>el chico simpático</mark> → <mark>la chica simpática</mark></div>','left:100px;top:700px;width:1400px;z-index:10',121,.7,t1)
# G7
chapter(v,126.25,129.25,2,5,'Formazione del plurale','Salire di livello')
# G8 plurale
table(v,129.25,156,'[PLURALE]','Vocale o consonante',['Regola','Esempio'],
 [['Vocale + -s','chica → chica<mark>s</mark>'],['Consonante + -es','doctor → doctor<mark>es</mark>']],'34% 66%',132,8,fs=40,pad=36,
 note='<div class="note" style="font-size:36px"><span class="lb">[ESEMPIO]</span><br>profesor → profesor<mark>es</mark></div>',note_t=148)
# G9
chapter(v,156,161.75,3,5,'La lettera Z','L\'eccezione VIP')
# G10 z->c
t1=179.25;head(v,161.75,t1,'[ECCEZIONE]','z diventa c')
v.add('<div class="hero" style="font-size:230px;color:var(--blue)">z → c</div>','left:200px;top:330px;z-index:10',163,.8,t1)
v.add('<div class="card" style="width:900px"><span class="lb">[ESEMPIO]</span><p style="font-size:60px;margin-top:10px" class="hero">luz → lu<mark>ces</mark></p></div>','left:200px;top:690px;z-index:10',170,.7,t1)
v.add('<div style="font-size:150px;line-height:1">⚠</div>','left:1500px;top:380px;z-index:10;color:#B8860B',166,.6,t1)
# G11 card luz/lapiz
t1=198.25;head(v,179.25,t1,'[ECCEZIONE]','Esempi con la z')
for i,(a,b) in enumerate([('una luz','dos lu<mark>ces</mark>'),('un lápiz','dos lápi<mark>ces</mark>')]):
    v.add('<div class="card" style="width:820px"><span class="lb">[SINGOLARE → PLURALE]</span><h3 style="font-size:64px">%s</h3><h3 style="font-size:64px;margin-top:0">→ %s</h3></div>'%(a,b),'left:%dpx;top:360px;z-index:10'%(100+i*900),181+i*7,.6,t1)
# G12
chapter(v,198.25,202,4,5,'Trova l\'errore','Il test finale')
# G13
hero(v,202,218,'[TROVA L\'ERRORE]','«Las <mark>chica</mark> altas»:<br>è corretto?',fs=120,w=1600,y=400,x=200)
# G14 concordanza
t1=238.5;head(v,218,t1,'[CONCORDANZA]','Tutto al plurale')
v.add('<div class="card" style="width:820px"><span class="mk" style="background:#B3261E">✗</span><h3 style="font-size:64px">las <mark>chica</mark> altas</h3><p>il nome è rimasto al singolare</p></div>','left:100px;top:340px;z-index:10',219.5,.6,t1)
v.add('<div class="card" style="width:820px"><span class="mk" style="background:#1B6B3A">✓</span><h3 style="font-size:64px">las <mark>chicas</mark> altas</h3><p>articolo, nome e aggettivo concordano</p></div>','left:1000px;top:340px;z-index:10',226,.6,t1)
v.add('<div class="note" style="font-size:36px"><span class="lb">[REGOLA]</span><br>Se cambia uno, cambiano tutti: articolo + nome + aggettivo.</div>','left:100px;top:720px;width:1500px;z-index:10',232,.7,t1)
# G15
hero(v,238.5,250,'[SECONDO ERRORE]','¿Los <mark>estudiante</mark><br>nuevos?',fs=120,w=1600,y=400,x=200)
# G16 +s
t1=268.5;head(v,250,t1,'[PLURALE]','Si aggiunge -s')
v.add('<div class="hero" style="font-size:150px">estudiante <span style="color:var(--blue)">+ s</span></div>','left:160px;top:350px;z-index:10',252,.8,t1)
v.add('<div class="hero" style="font-size:110px">→ estudiante<mark>s</mark></div>','left:160px;top:560px;z-index:10',257,.8,t1)
v.add('<div class="card" style="width:1100px"><span class="mk" style="background:#1B6B3A">✓</span> &nbsp;<span class="hero" style="font-size:60px">los estudiante<mark>s</mark> nuevos</span></div>','left:160px;top:760px;z-index:10',262,.7,t1)
# G17
chapter(v,268.5,271.5,5,5,'Schema padroneggiato','Sintesi finale')
# G18
t1=296.5
hero(v,271.5,t1,'[SINTESI]','No basta cambiar el <mark>artículo</mark>.<br>Comprueba también el <mark>sustantivo</mark> y el adjetivo.',fs=72,w=1600,y=330,x=150)
for i,(a,b) in enumerate([('ARTÍCULO','las'),('SUSTANTIVO','chicas'),('ADJETIVO','altas')]):
    v.add('<div class="card" style="width:480px;padding:18px 28px"><span class="lb">[%s]</span><h3 style="font-size:64px;margin-bottom:0">%s</h3></div>'%(a,b),'left:%dpx;top:680px;z-index:10'%(150+i*560),284+i*3,.6,t1)
# G19
hero(v,296.5,D+1,'[PENSACI]','Come si forma il plurale<br>di «<mark>el lunes</mark>» se finisce con <mark>-s</mark>?',fs=84,w=1650,y=360,x=150)
v.render('Genere_Plurali_v3',1920,1080,D,CSS,OUT,audio='/home/claude/assets/src/gen.mp4')
