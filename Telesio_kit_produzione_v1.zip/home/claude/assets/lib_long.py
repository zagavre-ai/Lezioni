from engine2 import *
from v4 import V4
LG=gen.LG
CSS="""
.hd{position:absolute;left:80px;right:80px;top:52px;height:72px;border-bottom:1.5px solid #C9D0DC}
.hd img{height:52px}
.ft{position:absolute;left:80px;right:80px;top:982px;border-top:1.5px solid #C9D0DC;padding-top:14px;font-family:'DM';font-size:21px;color:var(--blue);font-weight:500}
.tt{font-family:'BG';font-weight:800;font-size:66px;letter-spacing:-.02em;line-height:1.05;white-space:nowrap}
.bar{width:108px;height:5px;background:var(--ink)}
.lb{font-size:24px}
.tr{display:grid;border-bottom:2px solid var(--ink);border-left:3px solid var(--ink);border-right:3px solid var(--ink);font-weight:800;font-size:32px}
.tr>div{padding:var(--p,11px) 24px;border-right:2px solid var(--ink);line-height:1.25}
.tr>div:last-child{border-right:0}
.tr>div:first-child{background:var(--blue);color:#fff}
.tr.h{border-top:3px solid var(--ink)}.tr.h>div{background:var(--ink);color:#fff;font-size:24px;letter-spacing:.1em;text-transform:uppercase;padding:13px 24px}
.tr.last{border-bottom:3px solid var(--ink)}
.note{border:1px solid #D5DCE8;border-radius:16px;box-shadow:0 14px 36px rgba(11,21,48,.10);background:rgba(32,96,175,.07);padding:18px 28px 20px;font-weight:700;font-size:30px;line-height:1.35}
.note .lb{font-size:20px;margin-bottom:10px;display:inline-block}
.card{border:1px solid #D5DCE8;border-radius:16px;box-shadow:0 14px 36px rgba(11,21,48,.10);padding:26px 34px;background:#fff}
.card h3{font-family:'BG';font-weight:800;font-size:60px;line-height:1.02;margin:14px 0 14px}
.card p{font-weight:700;font-size:32px;line-height:1.35}
.hero{font-family:'BG';font-weight:800;letter-spacing:-.02em;line-height:1.12}
.chap{background:var(--blue);color:#fff}
.sq{background:var(--blue);color:#fff;font-family:'BG';font-weight:800;display:flex;align-items:center;justify-content:center;box-shadow:8px 8px 0 var(--ink)}
.bad{color:#B3261E}.ok{color:#1B6B3A}
.mk{display:inline-flex;width:56px;height:56px;align-items:center;justify-content:center;font-weight:800;font-size:38px;color:#fff;border:1px solid #D5DCE8;border-radius:16px}
"""+V4
def T(c,cols,cls='',st=''):return '<div class="tr %s" style="grid-template-columns:%s;%s">%s</div>'%(cls,cols,st,''.join('<div>%s</div>'%x for x in c))
def header(v):
    v.add('<div class="hd"><img src="data:image/svg+xml;base64,%s"></div><div class="ft">SPAGNOLO</div>'%LG,'left:0;top:0;width:1920px;height:1080px;z-index:5',0,.01)
def head(v,t0,t1,eyebrow,title,fo=.4):
    v.add('<span class="lb">%s</span>'%eyebrow,'left:80px;top:150px;z-index:10',t0+.15,.5,t1,fo)
    v.add('<div class="tt">%s</div><div class="bar" style="margin-top:20px"></div>'%title,'left:80px;top:196px;z-index:10',t0+.15,.5,t1,fo)
def table(v,t0,t1,eyebrow,title,header_,rows,cols,r0,dt,fs=None,y=330,note=None,note_t=None,pad=None):
    head(v,t0,t1,eyebrow,title)
    st='left:80px;top:%dpx;width:1760px;z-index:10'%y
    css=''
    fsz=fs or 32;p=(pad or 22)//2;sty='font-size:%dpx;--p:%dpx'%(fsz,p)
    v.add(T(header_,cols,'h',sty+';'),st,t0+.4,.5,t1)
    rh=(fs or 32)*1.25+(pad or 22)+2
    hh=fsz*1.25+(pad or 22)+4
    for i,r in enumerate(rows):
        v.add(T(r,cols,'last' if i==len(rows)-1 else '',sty),'left:80px;top:%dpx;width:1760px;z-index:10'%(y+hh+i*rh),r0+i*dt,.5,t1)
    if note:v.add(note,'left:80px;top:%dpx;width:1750px;z-index:10'%(y+hh+len(rows)*rh+34),note_t,.6,t1)
def chapter(v,t0,t1,n,tot,title,sub):
    v.add('','left:0;top:0;width:1920px;height:1080px;z-index:50;background:#2060AF',t0,.35,t1,.35)
    v.add('<div style="font-family:FG;font-weight:800;font-size:22px;letter-spacing:.16em;color:#fff;background:rgba(255,255,255,.16);border-radius:999px;display:inline-block;padding:8px 22px">CAPITOLO %d / %d</div>'%(n,tot),'left:140px;top:330px;z-index:51',t0+.3,.5,t1,.35)
    v.add('<div style="font-family:BG;font-weight:800;font-size:760px;line-height:.8;color:rgba(255,255,255,.08);letter-spacing:-.04em">%d</div>'%n,'left:1180px;top:200px;z-index:50',t0+.2,.8,t1,.35)
    v.add('<div class="hero" style="font-size:118px;color:#fff;max-width:1500px">%s</div>'%title,'left:140px;top:410px;z-index:51',t0+.5,.6,t1,.35)
    v.add('<div style="width:130px;height:7px;border-radius:4px;background:var(--hl)"></div>','left:140px;top:%dpx;z-index:51'%(410+ (240 if len(title)>26 else 130)+30),t0+.9,.5,t1,.35)
    v.add('<div style="font-weight:700;font-size:46px;color:#fff">%s</div>'%sub,'left:140px;top:%dpx;z-index:51'%(410+(240 if len(title)>26 else 130)+70),t0+1.1,.6,t1,.35)
def hero(v,t0,t1,label,html,fs=96,w=1500,y=380,x=210):
    v.add('<span class="lb">%s</span>'%label,'left:%dpx;top:%dpx;z-index:10'%(x,y-70),t0+.2,.5,t1)
    v.add('<div class="hero" style="font-size:%dpx;max-width:%dpx">%s</div>'%(fs,w,html),'left:%dpx;top:%dpx;z-index:10'%(x,y),t0+.5,.7,t1)