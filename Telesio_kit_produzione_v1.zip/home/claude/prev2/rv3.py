import subprocess,os,shutil
from playwright.sync_api import sync_playwright
K=2.5;FPS=30;N=180
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1280,"height":720})
    pg.goto("file:///home/claude/prev2/page.html")
    pg.evaluate("async()=>{await document.fonts.load('800 100px \"Bricolage Grotesque\"');await document.fonts.load('500 30px \"DM Mono\"');await document.fonts.load('700 40px Figtree');await new Promise(r=>{if(LG.complete)r();else LG.onload=r})}")
    for id,nm in (("sp","spagnolo"),("en","inglese"),("le","letteratura")):
        d=f"fr_{id}";shutil.rmtree(d,ignore_errors=True);os.makedirs(d)
        for i in range(N):
            pg.evaluate(f"draw('{id}',{i/FPS*K})");pg.screenshot(path=f"{d}/{i:04d}.png")
        subprocess.run(["ffmpeg","-y","-loglevel","error","-framerate","30","-i",f"{d}/%04d.png","-i",f"a_{id}.wav","-filter_complex","[1:a]atempo=2.0,atempo=1.25[a]","-map","0:v","-map","[a]","-t","6","-c:v","libx264","-crf","18","-pix_fmt","yuv420p","-c:a","aac","-b:a","160k",f"anteprima_{nm}.mp4"],check=True)
        shutil.rmtree(d);print(nm,flush=True)
    b.close()
