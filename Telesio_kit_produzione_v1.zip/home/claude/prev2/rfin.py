import subprocess,os,shutil
from playwright.sync_api import sync_playwright
import sys
ID,NM=sys.argv[1],sys.argv[2]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080})
    pg.goto("file:///home/claude/prev2/page_full.html")
    pg.evaluate("async()=>{await document.fonts.load('800 100px \"Bricolage Grotesque\"');await document.fonts.load('500 30px \"DM Mono\"');await new Promise(r=>{if(LG.complete)r();else LG.onload=r})}")
    d="fr_"+ID;shutil.rmtree(d,ignore_errors=True);os.makedirs(d)
    for i in range(150):
        pg.evaluate(f"draw('{ID}',{i/30})");pg.screenshot(path=f"{d}/{i:04d}.png")
    subprocess.run(["ffmpeg","-y","-loglevel","error","-framerate","30","-i",f"{d}/%04d.png","-i",f"a_{ID}.wav","-c:v","libx264","-preset","medium","-crf","15","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-ar","48000","-t","5","-movflags","+faststart",f"sigla_{NM}_premium_15s.mp4"],check=True)
    shutil.rmtree(d);b.close()
