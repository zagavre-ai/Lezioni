# Sigle "Minimalismo Immersivo Neoumanista" — FILOSOFIA e PSICOLOGIA
Regia esecutiva · durata 15,0 s ciascuna · Centro Studi Telesio · bozza per approvazione Direzione

---

## 0. Note di posizionamento (da leggere prima)

1. **Linea separata dalla Matrice v3.** Le sigle Intro/Outro già consegnate (fondo bianco a quadretti, inchiostro #0B1530) restano il sistema per le lezioni. Queste due sono una **linea "Premium / Brand"** (fondo Vantablack) pensata per promozione, presentazione dei corsi, apertura di moduli. Per non rompere la coerenza, il lockup finale riusa gli elementi fissi di marca: **logo Telesio, evidenziatore #FFE600, Bricolage Grotesque 800, DM Mono per le etichette [..]**.
2. **Inclusività BES/DSA = vincolo di regia, non optional.** Il look "neon su nero" è il più a rischio per fotosensibilità, abbagliamento e affaticamento. Regole inderogabili nel §1.4.
3. **Nessuna voce, nessun testo lungo.** La sigla si capisce senza audio (sordi, DSA con elaborazione uditiva) e senza leggere più di 2 parole per scena.

---

## 1. Specifiche tecniche comuni

### 1.1 Formato
| Parametro | Valore |
|---|---|
| Risoluzione master | 3840×2160 (UHD), consegna anche 1920×1080 |
| Frame rate | 30 fps (progressivo). Nessun 24p: i movimenti lenti devono restare fluidi |
| Codec consegna | ProRes 422 HQ (master) + H.264 CRF 16, yuv420p, AAC 192 kbps 48 kHz (web/LMS) |
| Colore | Rec.709, gamma 2.4, nessun HDR (evita clipping su monitor scolastici) |
| Safe area | titoli entro 90% centrale; lockup finale entro 80% |
| Durata | 15,00 s esatti (450 frame). Variante estesa 20 s: §6 |

### 1.2 Palette
| Ruolo | Valore | Uso |
|---|---|---|
| Vantablack | #000000 (mai sotto: niente "crushed" oltre il 0 IRE) | Sfondo assoluto |
| Acciaio spazzolato | #8A94A6 → #D8DEE9 (gradiente anisotropo) | Superfici metalliche |
| Vetro | bianco 6–12% opacità + bordo 1 px bianco 40% | Lastre trasparenti |
| **FILOSOFIA – accento** | Ciano ghiaccio #35E0FF + punto caldo bianco #F4FBFF | Luce neon, spigoli |
| **PSICOLOGIA – accento** | Corallo-magenta #FF3D7F + ciano #35E0FF come controluce | Luce neon, riflessi |
| **Costante di marca** | Giallo evidenziatore #FFE600 | Solo parola-chiave nel titolo e sottolineatura finale |

Regola: **max 1 accento neon dominante per inquadratura** (+ il bianco). Il giallo compare **solo** negli ultimi 3 secondi.

### 1.3 Look vettoriale/ottico
- Modellazione 3D pulita o motion vettoriale con **bevel 0,5 px**, antialiasing 16× MSAA, nessun grain, nessuna texture di rumore, nessun motion blur oltre 180° shutter (preferibile 90°).
- Materiali: **vetro** (IOR 1.5, rugosità 0, spessore 6–20 mm, bordo smerigliato 1 px); **acciaio spazzolato** (rugosità anisotropa 0.25, direzione fibre allineata agli assi); **specchio** (riflessione 100% con fresnel, nero profondo riflesso).
- Illuminazione: 1 key light direzionale stretta (spot 8°) + 1 rim neon. **Ombre nette** (soft shadow raggio 0). Fasci volumetrici sottili (volume light, densità 0.02), mai nebbia diffusa.
- Camera: lente 50–85 mm equivalente, **zero shake**, curve di movimento **ease-in-out cubic** (o sinusoidale), velocità costante nei dolly. Nessun jump cut: soli stacchi "match-cut geometrico".

### 1.4 Accessibilità BES/DSA e sicurezza fotosensibile (OBBLIGATORIA)
- **Nessun lampeggio > 3 volte/secondo**, nessuna variazione di luminanza > 20% in meno di 330 ms (WCAG 2.3.1). Il "flash di luce" è sostituito da **sweep di luce di almeno 400 ms**.
- Niente pattern ad alta frequenza spaziale (strisce fitte, scacchiere piccole) a pieno schermo in movimento.
- Contrasto testo/sfondo ≥ 12:1 (bianco su Vantablack = 21:1). Titoli ≥ 96 px a 1080p, peso 800, interlinea 1.1, **mai in maiuscolo corsivo, mai testo su riflessi o su fasci di luce**.
- Testo fermo **≥ 1,5 s** prima di sparire; massimo 2 elementi testuali simultanei.
- Movimenti di camera **lenti: max 8°/s di rotazione, max 12% del quadro/s di traslazione** (vestibolare/chinetosi).
- Audio: nessun picco improvviso; transienti attenuati (attack ≥ 5 ms sul sub), niente sibili > 8 kHz sopra −30 dBFS; **nessun contenuto informativo solo sonoro**.
- Consegnare **versione "Reduced Motion"** (opzionale ma raccomandata): stessi 15 s con camera fissa e solo dissolvenze (§6).
- Sottotitoli: non necessari (nessuna voce); per l'LMS aggiungere **descrizione audio testuale** (§7).

### 1.5 Sound design comune
- **Tempo: 128 BPM, 4/4 → 8 battute = 15,000 s esatti.** Tutto è quantizzato alla griglia (1 beat = 0,46875 s; 1 battuta = 1,875 s).
- Tonalità: **La minore → modo dorico (A–B–C–D–E–F#–G)**, tappeto ampio e pulito.
- Livelli: master **−16 LUFS integrati, true peak ≤ −1 dBTP**; sub sotto 40 Hz filtrato (HPF 30 Hz); stereo con mono-compatibilità verificata.
- Struttura: **Apertura 0–1,9 s** (silenzio + impulso) → **Costruzione 1,9–9,4 s** → **Apice 9,4–13,1 s** → **Risoluzione 13,1–15,0 s** (coda corta, niente riverbero > 1,2 s).
- Hard core "rigore scientifico": **kick secco sintetico (stile 808 asciutto, senza distorsione)** + **click di metronomo di precisione** + **sequenza di 16esimi quasi impercettibile (tipo "pulse")** tra −24 e −18 dBFS. Mai riempimenti, mai drop pesante.

---

## 2. SIGLA 1 — FILOSOFIA
**Concetto:** *il pensiero come architettura mentale simmetrica, lucida e tagliente.* Un'unica linea di luce costruisce un tempio logico simmetrico (colonne di vetro, architrave d'acciaio) che, visto dall'alto, diventa un'**asse di simmetria perfetta**. Dall'ordine nasce una domanda: **il punto interrogativo come ultima colonna.**
**Accento:** ciano ghiaccio #35E0FF. **Camera:** dolly frontale lento + una discesa a piombo ("pianta del pensiero").
**Parola-chiave del titolo:** *"PENSA"* → **FILOSOFIA** con *"Filo"* o l'intera parola evidenziata in #FFE600 (a scelta Direzione; default: evidenziatore sotto l'intera parola).

### 2.1 Scenografia
Spazio infinito nero con **pavimento a specchio nero** (riflessi netti, 100%). Al centro un'**asse verticale invisibile** su cui tutto è simmetrico. Elementi:
- **6 colonne di vetro stratificato** (sezione quadrata 40 cm, altezza 8 m), 3 per lato, bordo smerigliato ciano.
- **Architrave d'acciaio spazzolato** (1 lastra lunga) che le attraversa.
- **Filo di luce ciano** (tubo 4 mm) che "disegna" lo schema.
- **Cuneo di luce direzionale** (key a 8°) che entra da sinistra a 30° e taglia le colonne creando ombre nette sul pavimento.

### 2.2 Storyboard secondo per secondo
| Tempo | Inquadratura / Camera | Azione | Luce | Testo | Suono (128 BPM) |
|---|---|---|---|---|---|
| **0:00–0:01** | Nero totale, camera fissa | Silenzio visivo. Al frame 12 un **punto ciano** (4 px) appare al centro | Solo il punto, 100% | — | Silenzio. Al frame 12: **click metronomo** secco (rim shot sintetico), −12 dBFS |
| **0:01–0:02** | Dolly in lentissimo (2%) | Il punto si allunga in un **filo di luce verticale** che sale per 6 m (ease-out) | Il filo illumina di riflesso il pavimento specchiato | — | Entra **sub-pad La** (A1), fade-in 1,9 s; click a ogni beat, −24 dBFS |
| **0:02–0:03** | Camera fissa, frontale | Il filo si **biforca simmetricamente** in orizzontale: due linee che corrono a sinistra e a destra fino a ±4 m | Ciano pulito, riflessi netti sul vetro del pavimento | — | **Kick** entra sul beat 1 della battuta 2 (1,875 s), secco, −10 dBFS |
| **0:03–0:04** | Pan orizzontale 0°, dolly in 3% | Le due linee generano **le 6 colonne di vetro** a "crescita" (scala da 0 a 100%, sequenza simmetrica da fuori verso dentro) | Il key a 8° illumina la prima colonna sinistra | — | Pluck **La–Mi** (arp 1/8), filtro passa-basso che si apre | 
| **0:04–0:05** | Dolly in ancora, vista da 1,6 m | Le colonne completano. Le **ombre nette** si allungano sul pavimento a specchio | Fascio direzionale taglia lo spazio | — | Si aggiunge **hat chiuso 16esimi**, −28 dBFS |
| **0:05–0:06** | Camera si alza lentamente (4°) | Entra l'**architrave d'acciaio**: scivola da sinistra, si ferma di colpo (decelerazione cubica) sopra le colonne | Riflesso speculare tagliente (linea bianca 2 px) corre sul metallo da sinistra a destra in 0,8 s | — | **Whoosh fine** (rumore filtrato) 0,6 s, poi **hit** sul beat 1 di battuta 4 (5,625 s) |
| **0:06–0:07** | Camera in alto 12° | Il tempio è completo e simmetrico. Un **secondo filo ciano** attraversa l'architrave e delinea il frontone | Luce rim ciano sugli spigoli | **[FILOSOFIA]** in DM Mono, 28 px, piccolo, in basso a sinistra (entra con wipe da sinistra 0,4 s) | Pad si apre; si aggiunge **pad alto** (accordi La–Do–Mi) |
| **0:07–0:08** | Camera ruota di 8° verso l'alto | Le colonne **si riflettono verso il basso**: il pavimento diventa un secondo tempio capovolto (simmetria su due assi) | Riflessi 100%, luce neutra | — | Kick 4-on-the-floor (tutti i beat), −9 dBFS |
| **0:08–0:09** | Camera sale in verticale (discesa speculare) iniziando il **top-down** | La telecamera inizia a **ruotare di 90° in 3 s** (da frontale a vista dall'alto) | Fascio a piombo dal soffitto | — | **Riser** filtrato, 3 s, da 400 Hz a 3 kHz, volume −24 → −14 dBFS |
| **0:09–0:10** | Top-down (completa a 0:11) | Dall'alto il tempio è una **croce di luce**: assi X e Y, simmetria perfetta | Linee ciano 2 px su Vantablack | — | Riser continua; rullo di **snare sintetico** pulito 1/16 negli ultimi 2 beat |
| **0:10–0:11** | Top-down fissa | Le colonne appaiono come **6 quadrati di vetro** sulla griglia. Al centro **si apre un vuoto** (spazio per l'ultima colonna) | Fascio verticale puntuale illumina il vuoto | — | Riser sale. Al beat 1 della battuta 6 (9,375 s) : **hit pieno** (kick + clap secco + stab di sintetizzatore La) |
| **0:11–0:12** | Top-down, zoom in 6% | Il vuoto riceve **la settima forma: un punto interrogativo** disegnato dal filo ciano (tratto 6 px, geometrico, sezioni di cerchio perfette) | Il filo pulsa con luminanza costante (**no flash**) | — | Pausa di 1 beat (colpo secco, poi silenzio quasi totale a −40 dBFS per 0,47 s) – effetto "pensiero" |
| **0:12–0:13** | Camera risale rapida ma lineare, torna frontale in 1,2 s | Il "?" diventa una colonna di vetro con riflesso a specchio. Tutta l'architettura converge verso il centro (scala 100 → 80%) | Ciano tagliente | — | **Ripartenza**: kick + pad aperto, accordo La min9 |
| **0:13–0:14** | Frontale, fissa | Tutto scompare in un **taglio di luce verticale** (sweep di 600 ms, non flash). Resta una linea ciano che si allarga come titolo | Linea 100% bianca-ciano | **FILOSOFIA** in Bricolage Grotesque 800, bianco, 140 px; barra evidenziatore #FFE600 che si disegna da sinistra a destra in 0,5 s sotto la parola | Chord stab pulito La min, risonanza breve |
| **0:14–0:15** | Fissa | Appare sotto: **"[PENSIERO CRITICO]"** in DM Mono 32 px + logo Telesio bianco (dissolvenza 0,4 s). Tutto tiene fermo per **1,2 s** | Luce uniforme, nessun riflesso | **FILOSOFIA / [PENSIERO CRITICO] / logo** | Coda: ultimo accordo che decade; fade-out audio da 14,6 s a 15,0 s |

### 2.3 Prompt per generatori video AI (se usati per i singoli shot)
Usare AI solo per **bozze/animatic**; il master finale va fatto in 3D/vettoriale per garantire "zero rumore". Formato prompt: `[soggetto] + [materiali] + [luce] + [camera] + [esclusioni]`.
- **Shot A (0:02–0:05):** *"Perfectly symmetrical architecture made of layered glass columns and a brushed steel lintel on a black mirror floor, absolute black background, single narrow directional light beam from the left casting razor-sharp shadows, thin cyan neon line tracing the structure, slow frontal dolly in, mathematically precise motion, 4K, clean vector aesthetic."* **Negative:** *noise, grain, film texture, fog, smoke, lens flare, people, text, shaky camera, flicker, strobing.*
- **Shot B (0:08–0:11):** *"Top-down view of a perfect symmetrical cross of cyan light lines on pure black, six glass squares arranged symmetrically, specular reflections, slow camera rotation, ultra clean."* **Negative:** *same + chromatic aberration, blur, motion blur.*
- **Shot C (0:11–0:12):** *"A geometric question mark drawn by a thin cyan neon line made of perfect circular arcs, pure black background, glass reflection below, static camera."*

---

## 3. SIGLA 2 — PSICOLOGIA
**Concetto:** *la mente come spazio geometrico controllato: un labirinto di riflessi e trasparenze che trova ordine.* Un cubo di vetro viene percorso da una luce corallo che **si perde** in un labirinto di lastre specchiate; con un **movimento di camera** le lastre si allineano e il caos diventa un **unico profilo** (la sagoma geometrica di una testa/mente, astratta, senza volto).
**Accento:** corallo-magenta #FF3D7F, controluce ciano #35E0FF. **Camera:** orbita lenta (arco di 90°) + un push-in finale.
**Tipografia:** PSICOLOGIA in Bricolage Grotesque 800; parola-chiave evidenziata in #FFE600.

### 3.1 Scenografia
Spazio nero con pavimento a specchio nero. **Un cubo di vetro 3×3×3 m** (bordi smerigliati) al centro. Dentro: **9 lastre di vetro specchiato** (riflessione 60%) ruotate a angoli irregolari (caos controllato, a multipli di 15°). Una **sfera di luce corallo** (diametro 8 cm) si muove nel cubo. Un **controluce ciano** da dietro crea bordi sottili.

### 3.2 Storyboard secondo per secondo
| Tempo | Inquadratura / Camera | Azione | Luce | Testo | Suono (128 BPM) |
|---|---|---|---|---|---|
| **0:00–0:01** | Nero, fissa | Al frame 12 un **bordo di luce ciano** (linea 2 px, 1 m) taglia il nero in diagonale | Linea 100% | — | Silenzio; **click metronomo** al frame 12 (come Sigla 1, identità comune) |
| **0:01–0:02** | Dolly in 2% | La linea diventa il **bordo superiore del cubo di vetro**: i 12 spigoli si disegnano in sequenza (stroke-draw 1,0 s) | Spigoli ciano, interni neri | — | Sub-pad **Re** (D1) in fade-in, click a ogni beat −24 dBFS |
| **0:02–0:03** | Camera fissa 3/4 alta | Il cubo si "riempie": dal basso sale il **vetro con riflessi**, appaiono le **9 lastre** una a una con rotazioni irregolari | Key a 8° da destra, ombre nette sul pavimento | — | **Kick** entra sul beat 1 della battuta 2, −10 dBFS |
| **0:03–0:04** | Orbita a sinistra, 8°/s | La **sfera corallo** entra dal fondo del cubo, rimbalza (movimento lineare con rimbalzi a 90°) sulle lastre | Riflessi corallo sulle lastre specchiate | — | Pluck **Re–La**, delay a 1/8 (eco pulita, 2 ripetizioni) |
| **0:04–0:05** | Orbita continua | Ogni rimbalzo **moltiplica la luce**: la sfera si riflette in 4, poi 8 punti (il labirinto di riflessi) | Moltiplicazione progressiva senza flash (aumento graduale 20%) | — | Hat 16esimi −28 dBFS; **noise sweep** corto |
| **0:05–0:06** | Orbita continua | **Caos controllato:** decine di riflessi corallo e ciano, linee di luce che si incrociano nel cubo. Nessun elemento supera la soglia di luminanza (limite 85% IRE) | Contrasti netti | — | Hit sul beat 1 della battuta 4 (5,625 s), arpeggio più fitto (1/16) |
| **0:06–0:07** | Camera si ferma, push-in 6% | Una **lastra centrale** ruota di 15° e un riflesso corallo la attraversa creando un **raggio** diritto | Raggio corallo, nettissimo | **[PSICOLOGIA]** in DM Mono 28 px in basso a sinistra (wipe 0,4 s) | Pad alto (accordi Re–Fa–La) entra |
| **0:07–0:08** | Push-in | Il raggio **colpisce la lastra successiva**, che ruota a sua volta (reazione a catena) | Ordine che nasce | — | Kick 4-on-the-floor −9 dBFS |
| **0:08–0:09** | Camera si ferma 3/4 | **Le lastre iniziano ad allinearsi** una dopo l'altra, snap a 0°/90° con decelerazione cubica (ogni 0,25 s) | I riflessi si ricompongono in linee parallele | — | **Riser** da 400 Hz a 3 kHz, 3 s, −24 → −14 dBFS |
| **0:09–0:10** | Orbita inversa a 12°/s fino a vista frontale | Le lastre allineate formano **un unico profilo laterale** (sagoma geometrica astratta di testa, soltanto linee e piani, senza volto) | Controluce ciano disegna il bordo | — | Riser continua. Snare 1/16 negli ultimi 2 beat |
| **0:10–0:11** | Frontale | Il profilo si completa; la **sfera corallo** si ferma al centro del profilo, come "punto di consapevolezza" | Fascio puntuale verso la sfera | — | Beat 1 battuta 6 (9,375 s): **hit pieno** (kick + clap + stab Re) |
| **0:11–0:12** | Frontale, zoom 5% | **Respiro:** la sfera pulsa **una volta, lentamente** (luminanza +15%, in 1,0 s, ease-in-out) | Ritmo calmo | — | Pausa quasi silenziosa 0,47 s (−40 dBFS), poi sub-bass pulsante a 60 BPM |
| **0:12–0:13** | Frontale | Le lastre **si dissolvono in sequenza** lasciando solo il profilo di luce ciano e la sfera corallo | Linee fini, nero profondo | — | Ripartenza: kick + accordo Re min9 |
| **0:13–0:14** | Frontale | Sweep di luce verticale (600 ms) rivela il titolo: **PSICOLOGIA** in Bricolage Grotesque 800, bianco, 140 px; evidenziatore #FFE600 sotto la parola (0,5 s) | Luce uniforme | **PSICOLOGIA** | Chord stab pulito Re min |
| **0:14–0:15** | Fissa | Sotto: **"[MENTE E COMPORTAMENTO]"** DM Mono 32 px + logo Telesio bianco (dissolvenza 0,4 s). Tenuta ferma **1,2 s** | Uniforme | **PSICOLOGIA / [MENTE E COMPORTAMENTO] / logo** | Coda accordo; fade-out 14,6–15,0 s |

### 3.3 Prompt per generatori video AI (bozze/animatic)
- **Shot A (0:02–0:05):** *"A perfect glass cube on a black mirror floor, inside it nine tilted mirrored glass panels, a small coral-pink light sphere bouncing between them producing sharp reflections, slow 90-degree orbit camera, pure black background, razor-sharp shadows, clean vector aesthetic, 4K."* **Negative:** *noise, grain, fog, smoke, bloom, lens flare, faces, people, brain imagery, text, flicker.*
- **Shot B (0:08–0:11):** *"Glass panels sliding and snapping into alignment, forming a single abstract geometric head profile made only of straight planes, cyan rim light, coral light sphere at the center, pure black background, frontal view, perfectly clean."* **Negative:** *realistic face, skin, eyes, gore, flicker.*

---

## 4. Sound design — specifiche di produzione

| Livello | Sigla 1 FILOSOFIA | Sigla 2 PSICOLOGIA |
|---|---|---|
| Tonalità | La dorico | Re dorico |
| Sub-pad | A1 sinusoide + saturazione tape lieve | D1 sinusoide |
| Pluck | Pluck a dente di sega filtrato, arp La–Mi–Si | Pluck a impulso, arp Re–La–Mi |
| Pad alto | Accordo La min add9, onda a vetro (FM leggera) | Accordo Re min add9 |
| Hard core | Click metronomo + kick 808 secco + 16esimi di hat chiuso | Idem, con **delay a 1/8** sui pluck |
| Texture | Whoosh fine 0,6 s all'ingresso architrave | Noise sweep 0,4 s su moltiplicazione riflessi |
| Riser | 3 s, passa-banda 400 Hz→3 kHz | Idem |
| Pausa "pensiero" | 0,47 s a −40 dBFS | Idem, con sub-bass a 60 BPM |
| Stab finale | La min | Re min |

**Identità comune (la "firma"):** stesso **click di metronomo al frame 12** e stessa struttura ritmica 8 battute. Così le due sigle sono riconoscibili come famiglia e allineate al sound logo delle sigle di lezione (accordo di quattro note Do–Mi–Sol–Do: può essere citato come ultima nota della coda se la Direzione vuole la continuità).

**Mix & consegna:** stem separati (musica, FX, click) + master stereo. 48 kHz / 24 bit WAV. Loudness −16 LUFS, true peak ≤ −1 dBTP, nessun clipping, nessuna voce.

---

## 5. Checklist di produzione

**Pre-produzione**
- [ ] Approvazione Direzione di: parola-chiave evidenziata, sottotitoli **[PENSIERO CRITICO]** e **[MENTE E COMPORTAMENTO]**, uso del giallo.
- [ ] Conferma che la linea "Premium" può convivere con la Matrice v3 bianca delle lezioni.
- [ ] Logo Telesio bianco (PNG/SVG) e font Bricolage Grotesque 800 + DM Mono forniti.

**Produzione**
- [ ] Animatic a bassa risoluzione con audio guida (128 BPM) per la verifica dei tempi.
- [ ] Render 3D/vettoriale 4K, 30 fps, 16× AA.
- [ ] Compositing: sweep di luce, riflessi, titoli.
- [ ] Mix audio e sincronizzazione sui punti chiave: **0:00,4 click / 1,875 s kick / 5,625 s hit / 9,375 s hit pieno / 13,1 s accordo / 15,0 s fine**.

**Controllo qualità**
- [ ] Test fotosensibilità (Harding/PEAT o equivalente): nessun flash oltre soglia.
- [ ] Contrasto testi ≥ 12:1, titoli ≥ 96 px a 1080p.
- [ ] Verifica su schermo piccolo (telefono, luminosità 50%) e su proiettore da aula.
- [ ] Loudness e true peak misurati.
- [ ] Prova con almeno 2 studenti BES/DSA (feedback su affaticamento visivo).

---

## 6. Varianti

- **Reduced Motion (15 s):** camera ferma, tutte le transizioni come dissolvenze di 600 ms, nessuna rotazione. Stesso audio con kick attenuato di 4 dB.
- **Estesa 20 s:** aggiungere **5 s** dopo 0:12 : in Filosofia un secondo "giro" di top-down con 2 colonne di vetro in più; in Psicologia un'orbita completa attorno al profilo. Audio: 10 battute a 128 BPM = 18,75 s + coda di 1,25 s.
- **Versione verticale 9:16 (social):** ricentrare l'asse di simmetria; il titolo in 2 righe da 130 px.

---

## 7. Descrizione testuale per accessibilità (alt/audiodescrizione)
- **Filosofia:** *"Su fondo nero, una linea di luce azzurra costruisce un tempio simmetrico fatto di colonne di vetro. Visto dall'alto forma una croce di luce; l'ultima colonna è un punto interrogativo. Compare la scritta FILOSOFIA, con sottolineatura gialla, e il logo Centro Studi Telesio."*
- **Psicologia:** *"Un cubo di vetro contiene lastre specchiate disordinate in cui rimbalza una sfera di luce rosa. Le lastre si allineano e formano il profilo astratto di una testa. Compare la scritta PSICOLOGIA, con sottolineatura gialla, e il logo Centro Studi Telesio."*

---

## 8. Rischi e note
1. **I generatori AI di video** non garantiscono simmetria matematica, zero rumore e riflessi precisi: usarli per animatic, non per il master. Verificare le licenze d'uso commerciale prima di impiegare materiale generato.
2. **Costo/tempo:** il master 3D richiede un artista 3D (Blender/Cinema 4D, motore Cycles/Redshift) o un motion designer After Effects con plugin 3D; stima 3–5 giorni per sigla.
3. **Rapporto con la Matrice v3:** se la Direzione preferisce un'unica identità, si può produrre una versione "Matrice" (fondo bianco, inchiostro #0B1530) di queste stesse sigle.
4. Le parole [PENSIERO CRITICO] e [MENTE E COMPORTAMENTO] sono proposte: da confermare.
