const W=1920,H=1080;
const cv=document.getElementById('c'),c=cv.getContext('2d');
function mk(){const e=document.createElement('canvas');e.width=W;e.height=H;return e}
const sc=mk(),rf=mk(),s=sc.getContext('2d');
function cl(x){return Math.min(1,Math.max(0,x))}
function seg(t,a,b){return cl((t-a)/(b-a))}
function eo(x){return 1-Math.pow(1-x,3)}
function eio(x){return x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2}
function lerp(a,b,x){return a+(b-a)*x}
function line(g,x1,y1,x2,y2,col,w,glow,a){g.save();g.globalAlpha=a==null?1:a;g.strokeStyle=col;g.lineWidth=w;g.lineCap='round';if(glow){g.shadowColor=col;g.shadowBlur=glow}g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.restore()}
function poly(g,pts,p,col,w,glow,a){let L=0,sl=[];for(let i=1;i<pts.length;i++){const d=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);sl.push(d);L+=d}
 let rem=p*L;if(rem<=0)return;g.save();g.globalAlpha=a==null?1:a;g.strokeStyle=col;g.lineWidth=w;g.lineJoin='round';g.lineCap='round';if(glow){g.shadowColor=col;g.shadowBlur=glow}
 g.beginPath();g.moveTo(pts[0][0],pts[0][1]);
 for(let i=1;i<pts.length&&rem>0;i++){const d=sl[i-1];if(rem>=d){g.lineTo(pts[i][0],pts[i][1]);rem-=d}else{const k=rem/d;g.lineTo(pts[i-1][0]+(pts[i][0]-pts[i-1][0])*k,pts[i-1][1]+(pts[i][1]-pts[i-1][1])*k);rem=0}}
 g.stroke();g.restore()}
function arcPts(cx,cy,r,a0,a1,n){const o=[];for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n;o.push([cx+r*Math.cos(a),cy+r*Math.sin(a)])}return o}
function dot(g,x,y,r,col,glow,a){g.save();g.globalAlpha=a==null?1:a;g.fillStyle=col;g.shadowColor=col;g.shadowBlur=glow||0;g.beginPath();g.arc(x,y,r,0,7);g.fill();g.restore()}
function composite(fy,ra,over){
 c.setTransform(1,0,0,1,0,0);c.globalAlpha=1;c.fillStyle='#000';c.fillRect(0,0,W,H);
 c.drawImage(sc,0,0);
 if(ra>0){const r=rf.getContext('2d');r.globalCompositeOperation='source-over';r.clearRect(0,0,W,H);r.save();r.translate(0,2*fy);r.scale(1,-1);r.drawImage(sc,0,0);r.restore();
  r.globalCompositeOperation='destination-in';const g=r.createLinearGradient(0,fy,0,fy+320);g.addColorStop(0,'rgba(0,0,0,.45)');g.addColorStop(1,'rgba(0,0,0,0)');r.fillStyle=g;r.fillRect(0,fy,W,H-fy);r.globalCompositeOperation='source-over';
  c.globalAlpha=ra;c.drawImage(rf,0,0);c.globalAlpha=1;
  const lg=c.createLinearGradient(0,0,W,0);lg.addColorStop(0,'rgba(255,255,255,0)');lg.addColorStop(.5,'rgba(255,255,255,'+(.28*ra)+')');lg.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=lg;c.fillRect(0,fy,W,2)}
 if(over)over(c)}
function title(g,lines,size,base0,lead,p,glowdot){g.save();g.font='800 '+size+'px "Bricolage Grotesque"';g.letterSpacing=(size*.05)+'px';g.fillStyle='#fff';let wmax=0;
 lines.forEach((tx,i)=>{const w=g.measureText(tx).width-size*.05;wmax=Math.max(wmax,w);const x=960-w/2;const pr=cl(p*lines.length-i);if(pr<=0)return;g.save();g.beginPath();g.rect(x-10,base0+i*lead-size,(w+20)*pr,size*1.3);g.clip();g.fillText(tx,x,base0+i*lead);g.restore();
  if(glowdot&&pr>0&&pr<1)dot(g,x-10+(w+20)*pr,base0+i*lead-size*.35,6,'#fff',22)});g.restore();return wmax}
function lock(g,t,wmax,barY,label,labelY,logoY){const pb=eo(seg(t,13,13.5));g.fillStyle='#FFE600';g.fillRect(960-wmax/2,barY,wmax*pb,14);
 g.save();g.globalAlpha=seg(t,13.3,13.8);g.fillStyle='#fff';g.font='500 32px "DM Mono"';g.letterSpacing='5px';g.textAlign='center';g.fillText(label,960,labelY);g.restore();
 const a=seg(t,14,14.4);if(a>0&&window.LG){g.save();g.globalAlpha=a;g.drawImage(window.LG,960-165,logoY,330,109);g.restore()}}

/* ---------- SPAGNOLO ---------- */
function spagnolo(t){
 const R='#FF1E3C',FY=840;s.setTransform(1,0,0,1,0,0);s.clearRect(0,0,W,H);
 const sunK=eio(seg(t,9.8,11.2));const sx=960,sy=t<9.8?lerp(900,520,eo(seg(t,6,7.2))):lerp(520,380,sunK);let sr=lerp(190,14,sunK);if(t>12.4)sr*=1+.12*Math.sin((t-12.4)*Math.PI*1.2);
 const sunA=seg(t,6,6.4);
 if(sunA>0){s.save();s.beginPath();s.rect(0,0,W,FY);s.clip();
  const ra=t<10?1:1;
  if(t>7){const p=eo(seg(t,7,7.8)),fade=1-seg(t,9.2,10);for(let k=0;k<8;k++){const a=k*Math.PI/4+Math.PI/8;line(s,sx,sy,sx+Math.cos(a)*900*p,sy+Math.sin(a)*900*p,R,2,10,.5*fade)}}
  s.globalAlpha=sunA;s.fillStyle='rgba(255,30,60,'+lerp(.16,.9,sunK)+')';s.beginPath();s.arc(sx,sy,sr,0,7);s.fill();
  s.strokeStyle=R;s.lineWidth=5;s.shadowColor=R;s.shadowBlur=30;s.stroke();s.restore()}
 // blades
 const bladeA=1-seg(t,4.2,5.2);
 if(t>3&&bladeA>0){for(let k=0;k<8;k++){const a=k*Math.PI/4+Math.PI/8,tx=960+Math.cos(a)*420,ty=860+Math.sin(a)*420*.22;const h=300*eo(seg(t,3+.08*k,3.8+.08*k));s.save();s.globalAlpha=bladeA;s.fillStyle='rgba(255,255,255,.07)';s.fillRect(tx-5,ty-h,10,h);s.restore();line(s,tx-5,ty,tx-5,ty-h,'#fff',2,8,bladeA);line(s,tx+5,ty,tx+5,ty-h,'#fff',2,8,bladeA)}}
 // arch
 const pA=eo(seg(t,4,5.2)),aout=1-seg(t,9.8,10.8),ex=1+.25*eio(seg(t,8,9.3));
 if(pA>0&&aout>0){for(let k=2;k>=0;k--){const kk=seg(t,4.6+k*.5,5.4+k*.5);if(k>0&&kk<=0)continue;const sca=(1+.12*k)*ex;const base=[[810,840],[810,667]].concat(arcPts(960,520,210,2.367,2*Math.PI+.775,60)).concat([[1110,667],[1110,840]]);
  const pts=base.map(p=>[960+(p[0]-960)*sca,840+(p[1]-840)*sca]);const al=[1,.55,.3][k]*aout;
  if(k==0&&pA>.99){s.save();s.globalAlpha=aout;s.fillStyle='rgba(255,255,255,.045)';s.beginPath();pts.forEach((p,i)=>i?s.lineTo(p[0],p[1]):s.moveTo(p[0],p[1]));s.fill();s.restore()}
  poly(s,pts,k==0?pA:eo(kk),'#fff',k==0?4:3,12,al)}}
 composite(FY,1-seg(t,9,10.2),g=>{
  if(t>=.4&&t<2.6){dot(g,960,860,5,'#fff',16,seg(t,.4,.5)*(1-seg(t,2.2,2.6)))}
  if(t>1&&t<2.6){const p=eo(seg(t,1,2));line(g,960,860,960-420*p,860,'#fff',3,10,1-seg(t,2.2,2.6));line(g,960,860,960+420*p,860,'#fff',3,10,1-seg(t,2.2,2.6))}
  if(t>2){const p=eo(seg(t,2,3)),fa=1-seg(t,9.4,10.4);[45,0].forEach(a0=>{const pts=[];for(let k=0;k<=4;k++){const a=(a0+90*k)*Math.PI/180;pts.push([960+Math.cos(a)*420,860+Math.sin(a)*420*.22])}poly(g,pts,p,'#fff',2.5,8,fa)})}
  // glyphs
  const ga=eo(seg(t,10,11));if(ga>0){g.save();g.globalAlpha=ga*(1);g.fillStyle=R;g.shadowColor=R;g.shadowBlur=14;g.font='800 340px "Bricolage Grotesque"';g.textAlign='center';g.fillText('¿',lerp(-200,250,ga),660);g.fillText('¡',lerp(2120,1670,ga),660);g.restore()}
  const w=title(g,['SPAGNOLO'],170,600,0,eo(seg(t,11,12)));
  lock(g,t,w||760,628,'[UNITÀ SPAGNOLO]',710,790)})}

/* ---------- INGLESE ---------- */
const HI=[220,340,280,440,320,400,260],TI=[2,2.25,2.5,4,4.3,5,5.25];
function inglese(t){
 const B='#2B4BFF',FY=800;s.setTransform(1,0,0,1,0,0);s.clearRect(0,0,W,H);
 const mp=eio(seg(t,8.4,10)),conv=eio(seg(t,10,10.8)),pa=1-seg(t,10.8,11.1);
 if(t>1.6&&pa>0){for(let i=0;i<7;i++){const q=eo(seg(t-TI[i],0,.7));if(q<=0)continue;
   let x=960+(i-3)*210,y=0,w=100,h=HI[i];let xo=0,yo=0;if(i<3)xo=-(1-q)*(x+200);else if(i<5)yo=-(1-q)*1000;else xo=(1-q)*(2100-x);
   let X=x-w/2+xo,Y=FY-h+yo,Wd=w,Hh=h;
   if(mp>0){const bx=960-450+(i%2?1:-1)*260*Math.sin(Math.PI*seg(t,9.8,10.6)),by=lerp(330+i*68,540,conv);X=lerp(X,bx,mp);Y=lerp(Y,by,mp);Wd=lerp(100,900,mp);Hh=lerp(h,lerp(22,4,conv),mp)}
   s.save();s.globalAlpha=pa;const gr=s.createLinearGradient(X,0,X+Wd,0);gr.addColorStop(0,'#4A5366');gr.addColorStop(.35,'#E6EBF5');gr.addColorStop(.7,'#8A94A6');gr.addColorStop(1,'#3A4152');
   if(mp>.6){s.fillStyle='#C7CEDB'}else s.fillStyle=gr;s.fillRect(X,Y,Wd,Hh);s.strokeStyle=B;s.lineWidth=3;s.shadowColor=B;s.shadowBlur=10;s.beginPath();s.moveTo(X,Y);s.lineTo(X+Wd,Y);s.lineTo(X+Wd,Y+Hh);s.stroke();s.restore()}}
 composite(FY,1-seg(t,8.6,9.6),g=>{
  if(t>=.4){const hy=lerp(540,800,eio(seg(t,1.2,2.2)));const hd=eo(seg(t,.4,1.2))*1920;line(g,0,hy,hd,hy,B,4,16,(t<1.4?1:.4)*(1-seg(t,8.6,9.6)))}
  if(t>1.4){const p=eo(seg(t,1.4,2.4)),a=1-seg(t,9,10);[[400,1080],[1000,1080],[1700,1080]].forEach(b=>line(g,1600,800,1600+(b[0]-1600)*p,800+280*p,B,3,12,.9*a))}
  if(t>6.8){const gp=eo(seg(t,6.8,8)),ga=1-seg(t,8.6,9.4);if(ga>0){g.save();g.globalAlpha=ga*.3;g.beginPath();g.rect(330,0,1260*gp,H);g.clip();g.strokeStyle='#fff';g.lineWidth=1;for(let y=400;y<=800;y+=100){g.beginPath();g.moveTo(330,y);g.lineTo(1590,y);g.stroke()}for(let i=0;i<7;i++){const x=960+(i-3)*210;g.beginPath();g.moveTo(x,800-HI[i]);g.lineTo(x,800);g.stroke()}g.restore()}}
  const w=title(g,['INGLESE'],170,600,0,eo(seg(t,11,12)));
  if(t>12&&t<12.7){const p=eo(seg(t,12,12.6));line(g,960-w/2,606,960-w/2+w*p,606,B,3,14,1-seg(t,12.4,12.7))}
  lock(g,t,w||700,628,'[ENGLISH SYSTEM]',710,790)})}

/* ---------- LETTERATURA ---------- */
function mono(g,x,p,al){const x0=x-65,x1=x+65,yb=820,yt=260;if(p<=0)return;
 const A=[[x0,yb],[x0,yt],[x1,yt],[x1,yb],[x0,yb]],Bq=[[x0,yt],[x0+24,yt-14],[x1+24,yt-14],[x1+24,yb-14],[x1,yb]];
 if(p>.9){g.save();g.globalAlpha=al*seg(p,.9,1);g.fillStyle='rgba(255,255,255,.05)';g.fillRect(x0,yt,130,560);g.fillStyle='rgba(255,255,255,.09)';g.beginPath();g.moveTo(x1,yt);g.lineTo(x1+24,yt-14);g.lineTo(x1+24,yb-14);g.lineTo(x1,yb);g.fill();g.fillStyle='rgba(255,255,255,.13)';g.beginPath();g.moveTo(x0,yt);g.lineTo(x0+24,yt-14);g.lineTo(x1+24,yt-14);g.lineTo(x1,yt);g.fill();g.restore()}
 poly(g,A,eo(seg(p,0,.7)),'#2B4BFF',3,10,al);poly(g,Bq,eo(seg(p,.5,1)),'#2B4BFF',3,10,al)}
function vtext(g,txt,x,p,a){if(p<=0||a<=0)return;g.save();g.globalAlpha=a;g.translate(x,540);g.rotate(-Math.PI/2);g.font='700 44px "Figtree"';g.letterSpacing='14px';g.fillStyle='#fff';g.shadowColor='#fff';g.shadowBlur=8;const w=g.measureText(txt).width-14;g.beginPath();g.rect(-w/2-6,-40,(w+12)*p,70);g.clip();g.fillText(txt,-w/2,14);g.restore()}
function letteratura(t){
 const FY=820;s.setTransform(1,0,0,1,0,0);s.clearRect(0,0,W,H);
 const conv=eio(seg(t,8,10)),sp=lerp(300,130,conv),ma=1-seg(t,10.3,10.9);
 const xs=i=>960+(i-2)*sp;
 if(ma>0)for(let i=0;i<5;i++)mono(s,xs(i),seg(t-(2+.35*i),0,.9),ma);
 composite(FY,1-seg(t,10,10.8),g=>{
  if(t>=.4&&t<2.6){dot(g,120,540,5,'#fff',16,seg(t,.4,.5))}
  if(t>1){const p=eo(seg(t,1,1.8)),a=t<7?.55:.55*(1-seg(t,7,7.4));line(g,120,540,120+1800*p,540,'#fff',3,14,a)}
  vtext(g,'DANTE',xs(0),eo(seg(t,5,6)),1-seg(t,7.6,8.2));vtext(g,'PETRARCA',xs(1),eo(seg(t,6,7)),1-seg(t,7.6,8.2));vtext(g,'LEOPARDI',xs(2),eo(seg(t,6.4,7.4)),1-seg(t,7.6,8.2));
  if(t>7&&t<8.6){const p=eo(seg(t,7,7.8));line(g,0,240,1920*p,240+660*p,'#fff',3,18,1-seg(t,8,8.6))}
  const w=title(g,['LETTERATURA','ITALIANA'],120,470,130,eo(seg(t,11,12)),true);
  lock(g,t,w||1000,625,'[ANALISI TESTUALE]',720,800)})}

/* ---------- FINALE (5 s, per tutte le materie) ---------- */
function finale(t){
 s.setTransform(1,0,0,1,0,0);s.clearRect(0,0,W,H);
 composite(1000,0,g=>{
  if(t<1.0){const a=seg(t,.25,.4)*(1-seg(t,.9,1.0));dot(g,960,520,6,'#fff',18,a)}
  if(t>.3&&t<1.4){const p=eo(seg(t,.3,1.0));line(g,960-420*p,520,960+420*p,520,'#fff',3,12,1-seg(t,1.1,1.4))}
  const w=title(g,["GRAZIE PER L'ATTENZIONE"],104,500,0,eo(seg(t,1.1,2.0)));
  const pb=eo(seg(t,1.9,2.4));g.fillStyle='#FFE600';g.fillRect(960-w/2,540,w*pb,12);
  const a=seg(t,2.6,3.1);if(a>0&&window.LG){g.save();g.globalAlpha=a;g.drawImage(window.LG,960-165,640,330,109);g.restore()}
 })}
window.draw=function(id,t){({sp:spagnolo,en:inglese,le:letteratura,fi:finale})[id](t)};

