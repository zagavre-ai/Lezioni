import numpy as np, wave
SR=48000;B=60/128
def N(d):return int(d*SR)
def env(n,a,d):
    t=np.arange(n)/SR;return np.minimum(t/a,1)*np.exp(-t/d)
def tone(f,d,a=.004,dec=.25,h=((1,1),(2,.35),(3,.12))):
    n=N(d);t=np.arange(n)/SR;return sum(A*np.sin(2*np.pi*f*k*t) for k,A in h)*env(n,a,dec)
def kick():
    n=N(.35);t=np.arange(n)/SR;f=140*np.exp(-t*28)+48;return np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*9)
def clap(seed=3):
    n=N(.2);r=np.random.RandomState(seed).randn(n);return r*np.exp(-np.arange(n)/SR*28)
def hat():
    n=N(.06);r=np.diff(np.random.RandomState(1).randn(n),prepend=0);return r*np.exp(-np.arange(n)/SR*70)
def click():
    n=N(.03);t=np.arange(n)/SR;return np.sin(2*np.pi*2400*t)*np.exp(-t*220)
def put(b,x,t,g=1):
    i=N(t)
    if i<len(b):b[i:i+len(x)]+=x[:len(b)-i]*g
def riser(d):
    n=N(d);r=np.random.RandomState(9).randn(n);tt=np.linspace(0,1,n);y=np.zeros(n);a=0
    for i in range(n):
        cc=.02+.4*tt[i]**2;a+=cc*(r[i]-a);y[i]=a
    return y/np.max(np.abs(y))*tt**2
def pad(freqs,t0,t1,b,g):
    n=N(t1-t0);t=np.arange(n)/SR;e=np.minimum(t/.8,1)*np.minimum((t1-t0-t)/.3,1)
    y=sum(np.sin(2*np.pi*f*t)+.4*np.sin(2*np.pi*f*2.003*t) for f in freqs)*e/len(freqs);put(b,y,t0,g)
def make(root,notes,chord,style,bells=()):
    b=np.zeros(N(15));put(b,click(),.4,.5)
    sub=np.zeros(N(13.1));t=np.arange(len(sub))/SR;put(b,np.sin(2*np.pi*root*t)*np.minimum(t/1.9,1)*.35,1.9,1)
    for k in range(4,28):
        tk=k*B
        if tk>13.1:break
        if style!='le' or k%2==0:put(b,kick(),tk,.7)
        if tk>=5.6 and style=='sp' and (k%8) in(0,3,6) :put(b,clap(),tk,.14)
        if style=='en' and k%2==1 and tk>3:put(b,clap(),tk,.14)
    for k in range(8,20):
        if style=='en' or style=='sp':put(b,hat(),k*B/2*2,.08)
    if style!='le':
        for j,k in enumerate(range(0,26)):
            tk=3.0+k*B/2
            if tk>9.4:break
            put(b,tone(notes[j%len(notes)],.5,dec=.2),tk,.18)
    else:
        for j,tk in enumerate(np.arange(3.0,9.4,B*2)):put(b,tone(notes[j%len(notes)],1.2,dec=.5),tk,.22)
        for tb in bells:put(b,tone(587.3,1.6,dec=.6,h=((1,1),(2.76,.3),(5.4,.1))),tb,.2)
    put(b,riser(2.9),6.5,.35)
    for th in(5.625,9.375):put(b,kick(),th,.9);put(b,clap(),th,.2)
    pad(chord,5.6,11.4,b,.10);pad(chord,11.72,15,b,.12)
    b[N(11.5):N(11.72)]*=.1
    put(b,tone(chord[0]*2,1.0,dec=.3),13.125,.25)
    f=np.ones_like(b);n=N(.4);f[-n:]=np.linspace(1,0,n);b*=f
    return b/np.max(np.abs(b))*.8
def save(name,x):
    s=(np.stack([x,x],1)*32767).astype('<i2');w=wave.open(name,'wb');w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(s.tobytes());w.close()
save('a_sp.wav',make(55,[220,233.08,261.63,329.63,233.08,261.63],[220,261.63,329.63],'sp'))
save('a_en.wav',make(82.4,[164.8,196,246.9,293.7,246.9,196],[164.8,246.9,293.7,370],'en'))
save('a_le.wav',make(73.4,[146.8,220,174.6,220],[146.8,174.6,220],'le',bells=(5.3,6.3,6.7)))
print('ok')
