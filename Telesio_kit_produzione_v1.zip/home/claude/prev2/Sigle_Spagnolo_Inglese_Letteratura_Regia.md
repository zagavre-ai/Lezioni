# Sigle "Minimalismo Immersivo Neoumanista" — SPAGNOLO · INGLESE · LETTERATURA ITALIANA
Documento esecutivo di regia · 15,0 s ciascuna · Centro Studi Telesio · bozza per approvazione Direzione
Famiglia con le sigle FILOSOFIA e PSICOLOGIA (stessa griglia sonora, stessa struttura di lockup finale).

---

## 1. Specifiche comuni

### 1.1 Tecniche
| Parametro | Valore |
|---|---|
| Master | 3840×2160 (UHD), 16:9, **60 fps** progressivo, 450 → **900 frame** per sigla |
| Consegne derivate | 1920×1080 a 30 fps (LMS/web) e 1920×1080 a 60 fps |
| Codec | ProRes 422 HQ (master) · H.264 CRF 16 yuv420p AAC 192 kbps 48 kHz (web) · H.265 per UHD |
| Colore | Rec.709, gamma 2.4, SDR. Vantablack = RGB 0,0,0 (nessun banding: dithering solo sui gradienti dei fasci, mai grana visibile) |
| Aspetto | Vettoriale/3D pulito: AA 16×, bevel 0,5 px a 1080p, nessun grain, nessuna texture, motion blur max 90° |
| Durata | 15,000 s. Variante estesa 20 s: §6 |
| Safe area | titoli nel 90% centrale; lockup finale nell'80% |

### 1.2 Colore
| Ruolo | Valore |
|---|---|
| Sfondo | Vantablack #000000 |
| Bianco ottico | #FFFFFF (laser, spigoli, titoli) |
| Blu elettrico | #2B4BFF |
| Rosso acido | #FF1E3C |
| Acciaio spazzolato | #8A94A6 → #D8DEE9 (anisotropo) |
| Vetro | bianco 6–12% + bordo 1 px bianco 40% |
| **Costante di marca** | Giallo evidenziatore #FFE600: **solo** la barra sotto il titolo finale (comune a tutte le sigle Telesio) |

Regola: **un solo accento dominante per inquadratura** (+ bianco). Rosso acido e blu elettrico non compaiono mai insieme nella stessa inquadratura, tranne dove indicato.

### 1.3 Tipografia
- Titolo: **Montserrat ExtraBold 800** (alternativa: Inter 800), tutto maiuscolo, tracking +6% (+80), 150 px a 1080p (≈300 px in UHD), interlinea 1,1.
- Etichette: **Inter Medium** o DM Mono 500, 30 px, tracking +10%, tra parentesi quadre.
- Se la Direzione vuole la continuità con le slide: sostituire il titolo con Bricolage Grotesque 800 (già in uso).
- Mai testo su riflessi, su fasci di luce o su superfici in movimento; testo sempre su nero puro.

### 1.4 Illuminazione e camera (comuni)
- 1 key light direzionale stretta (spot 8°) + 1 rim neon di colore materia; ombre nette (raggio 0), fasci volumetrici sottili (densità 0,02), nessuna nebbia.
- Pavimento a specchio nero, riflessione 100% con dissolvenza nei primi 300 px. Il titolo **non** si riflette.
- Camera 50–85 mm, nessun shake. Curve ease-in-out cubic. Rotazione max 8°/s, traslazione max 12% del quadro/s.

### 1.5 Accessibilità BES/DSA (obbligatoria)
- Nessun lampeggio > 3 al secondo; nessuna variazione di luminanza > 20% in meno di 330 ms. Gli "scatti di luce" sono **sweep di almeno 400 ms**.
- Contrasto testo/sfondo ≥ 12:1; testo fermo ≥ 1,5 s; max 2 elementi testuali contemporanei.
- Niente pattern a righe fitte in movimento a tutto schermo.
- Audio: nessun picco improvviso, attacco dei transienti ≥ 5 ms, nessun contenuto informativo solo sonoro.
- Consegnare la versione **Reduced Motion** (§6) e la **descrizione testuale** (§7).
- Nota sul "rosso acido": è saturo e affatica. Usarlo solo su linee fini e punti luce (max 8% del quadro), mai su aree piene.

### 1.6 Sound design comune
- **128 BPM, 4/4 → 8 battute = 15,000 s.** Inizio battute: 0 · 1,875 · 3,750 · 5,625 · 7,500 · 9,375 · 11,250 · 13,125 s. Beat = 0,46875 s.
- Struttura: Apertura 0–1,9 · Costruzione 1,9–9,4 · Apice 9,4–13,1 · Risoluzione 13,1–15,0.
- **Firma comune:** click di metronomo secco al frame 24 (0,4 s a 60 fps) in tutte le sigle.
- Hard core scientifico: kick 808 secco senza distorsione, click di precisione, 16esimi di hat a −28 dBFS. Niente drop pesanti, nessuna voce.
- Master −16 LUFS integrati, true peak ≤ −1 dBTP, 48 kHz / 24 bit, HPF 30 Hz, compatibilità mono verificata. Stem: musica, FX, click.
- Fade-out da 14,6 a 15,0 s, coda di riverbero ≤ 1,2 s.

---

## 2. SIGLA 1 — SPAGNOLO
**Concetto:** il calore geometrico della cultura ispanica reso in vetro luminescente. La **geometria degli azulejo e dell'arte andalusa** (stella a otto punte, archi a ferro di cavallo) si costruisce come struttura di vetro; un **sole rosso acido** nasce dietro le lastre, e i **segni ¿ ¡** diventano le due parentesi che incorniciano la parola.
**Accento:** rosso acido #FF1E3C + bianco ottico. **Camera:** dolly frontale lento + una salita ad arco.
**Tonalità:** La frigio (A–B♭–C–D–E–F–G), il colore sonoro "spagnolo" senza folklore.

### 2.1 Scenografia
Nero assoluto con pavimento a specchio. Al centro un **portale ad arco a ferro di cavallo** in vetro stratificato (3 lastre sovrapposte, bordo ciano-bianco). Dietro, un **disco rosso acido** (diametro 1,2 m, luce propria) che non illumina mai per primo ma "esce" dai contorni delle lastre. Sul pavimento una **stella a otto punte** incisa da linee di luce bianca.

### 2.2 Storyboard
| Tempo | Camera / Inquadratura | Azione | Luce | Testo | Suono |
|---|---|---|---|---|---|
| **0:00–0:01** | Nero, fissa | Al frame 24 un **punto bianco** (3 px) al centro | Solo il punto | — | Silenzio; **click** al frame 24 (−12 dBFS) |
| **0:01–0:02** | Dolly in 2% | Il punto emette **due linee** (sinistra e destra, 1,2 m) che si piegano a 45° verso il basso: base di un quadrato | Bianco puro | — | Sub-pad La entra (fade 1,9 s); click ad ogni beat −24 dBFS |
| **0:02–0:03** | Fissa, 3/4 alta | Una seconda linea, ruotata di 45°, completa la **stella a otto punte** sul pavimento (stroke-draw 0,9 s) | Riflessi netti sul pavimento | — | **Kick** entra a 1,875 s, −10 dBFS |
| **0:03–0:04** | Dolly in 4% | Dalle punte della stella salgono **8 sottili lame di vetro** (altezza 3 m), in sequenza oraria | Key a 8° da sinistra, ombre nette | — | Pluck frigio **La–Si♭** (arp 1/8), −14 dBFS |
| **0:04–0:05** | Orbita 6°/s a sinistra | Le lame **si incurvano** (morph geometrico) e formano l'**arco a ferro di cavallo** | Bordo bianco corre sulle curve in 0,8 s (sweep, non flash) | — | Hat 16esimi −28 dBFS; clap sintetico secco sui beat 2 e 4 | 
| **0:05–0:06** | Orbita continua | Entrano **le tre lastre di vetro** a strati; sfasamento di 3 cm tra loro (rifrazione) | Riflessi speculari sulle superfici | — | Hit a 5,625 s; pattern ritmico **3-3-2** di clap (richiamo flamenco, solo come ritmo) |
| **0:06–0:07** | Camera si ferma, dolly in 6% | Dietro l'arco **si accende il disco rosso**: sorge dal basso verso l'alto in 1,2 s, mai pieno (viene "tagliato" dalle lastre) | Rosso acido su linee fini; il disco è un anello + riempimento 20% | **[ESPAÑOL]** DM Mono 30 px in basso a sinistra (wipe 0,4 s) | Pad alto (accordi La–Do–Mi, modo frigio) entra |
| **0:07–0:08** | Push-in | Dal disco partono **raggi laser rossi** che attraversano le tre lastre e proiettano ombre nette di stelle sul pavimento | Fasci direzionali netti | — | Kick 4-on-the-floor −9 dBFS |
| **0:08–0:09** | Camera sale ad arco, 15° | L'arco **si apre** come un libro: le lastre ruotano verso l'esterno (130°) rivelando uno spazio nero | Rim rosso sugli spigoli | — | **Riser** 3 s, passa-banda 400 Hz → 3 kHz, −24 → −14 dBFS |
| **0:09–0:10** | Top-down parziale | I raggi si raccolgono in due punti: in alto a sinistra e in basso a destra | Punti rossi 6 px | — | Riser continua; snare 1/16 negli ultimi 2 beat |
| **0:10–0:11** | Frontale | I due punti diventano i segni **¿** e **¡** (tratto 8 px, archi di cerchio perfetti), che scorrono ai lati dello schermo | Rosso acido, glow 12 px | — | Hit pieno a 9,375 s (kick + clap + stab La) |
| **0:11–0:12** | Frontale, zoom 5% | Tra i due segni **si disegna il titolo**, lettera per lettera (clip da sinistra, 0,6 s). Le lastre svaniscono | Titolo bianco puro, nessuna luce sopra | **SPAGNOLO** in Montserrat 800 | Pluck rapidi su ogni lettera (9 note, 1/16), poi silenzio di 1 beat a −40 dBFS |
| **0:12–0:13** | Fissa | Il disco rosso si ritira nel centro e diventa un **punto rosso fisso sopra la parola**, a metà tra ¿ e ¡: pulsazione lenta (+12% in 1,0 s) | Ritmo calmo | — | Ripartenza: kick + accordo La frigio add9 |
| **0:13–0:14** | Fissa | **Barra gialla #FFE600** si disegna sotto SPAGNOLO (0,5 s). Sotto, **[UNITÀ SPAGNOLO]** DM Mono 32 px | Uniforme | **SPAGNOLO / [UNITÀ SPAGNOLO]** | Chord stab pulito |
| **0:14–0:15** | Fissa | **Logo Telesio bianco** (dissolvenza 0,4 s), tutto fermo per 1,2 s. Fade a nero solo dell'audio | Uniforme | **logo** | Coda; fade audio 14,6–15,0 s |

### 2.3 Prompt AI (solo per bozze/animatic)
- *"Horseshoe arch portal made of three layers of glass on a black mirror floor, thin glowing white geometric eight-pointed star etched in light on the floor, acid red sun disc rising behind the glass, razor-sharp shadows, slow orbiting camera, absolute black background, clean vector aesthetic, 4K."*
  **Negative:** *people, flamenco dancers, guitars, sombreros, fog, grain, noise, text, lens flare, flicker.*

---

## 3. SIGLA 2 — INGLESE
**Concetto:** dinamismo internazionale e precisione strutturale anglosassone. **Prismi di acciaio spazzolato** scorrono su binari di luce, riflettono una linea di orizzonte e si allineano come in una **griglia tecnica**: il movimento è **lineare, ad alta velocità e perfettamente fluido**.
**Accento:** blu elettrico #2B4BFF + bianco ottico. **Camera:** travelling laterale lineare (velocità costante) che diventa dolly frontale.
**Tonalità:** Mi minore pentatonica con 9ª, suono pulito e "da broadcast".

### 3.1 Scenografia
Nero assoluto, **pavimento a specchio** con **tre binari di luce blu** (linee da 3 px, convergenti a un punto di fuga). Sopra, **7 prismi rettangolari di acciaio spazzolato** (sezione 40×40 cm, lunghezze diverse 1–4 m) sospesi a diversa altezza. Una **griglia sottile bianca** (spessore 1 px, passo 1 m) appare solo quando i prismi si allineano.

### 3.2 Storyboard
| Tempo | Camera / Inquadratura | Azione | Luce | Testo | Suono |
|---|---|---|---|---|---|
| **0:00–0:01** | Nero, fissa | Al frame 24 una **linea blu** (4 px) taglia lo schermo da sinistra a destra in 0,5 s | Blu elettrico, 100% | — | Silenzio; **click** al frame 24 |
| **0:01–0:02** | Travelling laterale, 3% del quadro/s | La linea si moltiplica in **tre binari** che convergono verso un punto di fuga a destra | Riflessi sul pavimento | — | Sub-pad Mi (E1) fade-in; click ad ogni beat |
| **0:02–0:03** | Travelling continua | **Il primo prisma** entra da sinistra a velocità costante, sullo scorrimento del binario centrale, si ferma **di colpo** (decelerazione cubica 0,4 s) | Bordo bianco corre in 0,6 s sull'acciaio | — | **Kick** a 1,875 s |
| **0:03–0:04** | Idem | **Secondo e terzo prisma** entrano a distanza di 0,25 s l'uno dall'altro, stesse curve | Rim blu | — | Pluck pulito **Mi–Sol** (arp 1/8) |
| **0:04–0:05** | Travelling rallenta, dolly in 3% | Prismi 4–5 **scorrono verticalmente** dal soffitto e si agganciano alla linea d'orizzonte | Ombre nette, fascio a 8° | — | Hat 16esimi −28 dBFS; clap sul beat 2 e 4 |
| **0:05–0:06** | Dolly in | Gli ultimi due prismi **ruotano su sé stessi** di 90° (precisione assoluta) e si bloccano | Riflessi speculari | — | Hit a 5,625 s; whoosh breve 0,5 s |
| **0:06–0:07** | Camera si ferma frontale | I 7 prismi formano una **silhouette orizzontale ordinata** (un "skyline" astratto): altezze crescenti, spaziatura perfetta | Luce rim blu su ogni spigolo | **[ENGLISH]** DM Mono 30 px in basso a sinistra (wipe 0,4 s) | Pad alto (accordi Mi min9) |
| **0:07–0:08** | Frontale | Appare la **griglia bianca** sottile che si espande da un prisma all'altro (draw in 0,8 s) | Bianco 1 px | — | Kick 4-on-the-floor −9 dBFS |
| **0:08–0:09** | Camera sale lenta 6° | Sul pavimento la **linea d'orizzonte specchiata** diventa un secondo skyline capovolto: simmetria perfetta | Riflesso 100% | — | **Riser** 3 s, 400 Hz → 3 kHz |
| **0:09–0:10** | Top-down parziale | I prismi **si coricano** come lancette: diventano 7 linee parallele su un piano | Fascio verticale puntuale | — | Riser continua; snare 1/16 ultimi 2 beat |
| **0:10–0:11** | Frontale | Le 7 linee **scorrono orizzontalmente** a velocità diverse e si ricompongono come barre di una griglia tipografica | Blu elettrico | — | **Hit pieno** a 9,375 s |
| **0:11–0:12** | Zoom 5% | Dalla griglia emergono, per sottrazione di luce, le lettere di **INGLESE** (le barre diventano i tratti verticali/orizzontali delle lettere) | Bianco puro nel testo | **INGLESE** (Montserrat 800) | Pluck su ogni lettera; silenzio −40 dBFS di 1 beat |
| **0:12–0:13** | Fissa | Un **sweep di luce** (600 ms, da sinistra a destra) attraversa la parola senza modificare la luminosità del testo (solo bordo) | Ritmo calmo | — | Ripartenza: kick + accordo Mi min9 |
| **0:13–0:14** | Fissa | **Barra gialla #FFE600** sotto INGLESE (0,5 s) + **[ENGLISH SYSTEM]** DM Mono 32 px | Uniforme | **INGLESE / [ENGLISH SYSTEM]** | Chord stab |
| **0:14–0:15** | Fissa | **Logo Telesio bianco** (dissolvenza 0,4 s), tenuta ferma 1,2 s | Uniforme | **logo** | Coda; fade audio 14,6–15,0 s |

### 3.3 Prompt AI (bozze)
- *"Seven brushed steel rectangular prisms of different lengths sliding on glowing electric blue light rails over a black mirror floor, aligning into a perfectly ordered abstract skyline, laser-sharp reflections, linear camera tracking shot, absolute black background, clean precise geometry, 4K."*
  **Negative:** *buildings with details, flags, Big Ben, people, fog, grain, noise, text, flicker.*

---

## 4. SIGLA 3 — LETTERATURA ITALIANA
**Concetto:** classicità e profondità della tradizione in chiave high-tech. **Monoliti di vetro trasparente** (come steli/colonne) e **fasci laser bianchi che scolpiscono le parole nello spazio**.
**Accento:** bianco ottico (laser) + blu elettrico sui bordi del vetro. **Camera:** dolly molto lento + orbita di 60°, più solenne delle altre.
**Tonalità:** Re dorico con pedale basso (D1) e pad corale sintetico: più profondo e solenne.

### 4.1 Scenografia
Nero assoluto, pavimento a specchio. **Cinque monoliti di vetro trasparente** (40×40×300 cm), disposti su un arco ellittico; i loro spigoli hanno un bordo luminoso blu elettrico sottile. Il **laser bianco** (sorgente fuori campo a sinistra) taglia lo spazio in fasci dritti, **scolpendo** i testi sul vetro per riflessione/rifrazione.

### 4.2 Storyboard
| Tempo | Camera / Inquadratura | Azione | Luce | Testo | Suono |
|---|---|---|---|---|---|
| **0:00–0:01** | Nero, fissa | Al frame 24 un **punto bianco** a sinistra, fuori centro | Solo il punto | — | Silenzio; **click** al frame 24 |
| **0:01–0:02** | Fissa | Il punto emette un **fascio laser orizzontale** sottile (3 px) che attraversa lo schermo in 0,8 s | Bianco puro; riflesso sul pavimento | — | Pedale **Re** (D1) in fade-in, 1,9 s |
| **0:02–0:03** | Dolly in 2% | Il laser colpisce il vuoto: **il primo monolito di vetro** compare come contorno luminoso (stroke-draw 1,0 s) | Bordo blu, interni trasparenti | — | **Kick** a 1,875 s, −10 dBFS |
| **0:03–0:04** | Dolly in | **Secondo e terzo monolito** si materializzano, uno dopo l'altro (0,3 s) | Ombre nette sul pavimento | — | Pluck lento **Re–La** (1/4), eco |
| **0:04–0:05** | Orbita 8°/s a destra | **Quarto e quinto monolito** completano l'arco. Il laser rifratto crea **fasci incrociati** dentro il vetro | Linee bianche sottili nel vetro | — | Hat 16esimi −28 dBFS |
| **0:05–0:06** | Orbita continua | Il laser **scolpisce sul primo monolito un solo nome: "DANTE"**, in linee sottilissime di luce (draw lettera per lettera 0,8 s) | Testo bianco *sul vetro*, riflesso attenuato | **DANTE** (Montserrat 500, 56 px, tracking +20%) | Hit a 5,625 s; tocco di **campana sintetica** pura (D5), −18 dBFS |
| **0:06–0:07** | Orbita rallenta | **"PETRARCA"** sul secondo monolito, **"LEOPARDI"** sul terzo (a distanza di 0,4 s). Il primo nome si dissolve | Bianco puro | **PETRARCA · LEOPARDI** | Pad corale entra (accordi Re–Fa–La) |
| **0:07–0:08** | Camera si ferma, push-in 5% | Il nome sul terzo si dissolve. Il laser **taglia in diagonale** tutti e cinque i monoliti, proiettando ombre nette sul pavimento | Fascio direzionale netto | — | Kick 4-on-the-floor −9 dBFS |
| **0:08–0:09** | Camera sale lentamente 10° | I monoliti **ruotano su sé stessi di 45°** in modo sincrono (precisione assoluta) | Riflessi speculari sugli spigoli | — | **Riser** 3 s, 400 Hz → 3 kHz |
| **0:09–0:10** | Top-down parziale | I monoliti **convergono** verso il centro e si allineano come **colonne di un portico** | Fascio a piombo | — | Riser continua; snare ultimi 2 beat |
| **0:10–0:11** | Frontale | I cinque monoliti sono perfettamente affiancati, formano **una parete di vetro** (200×300 cm) | Bordo blu continuo | — | **Hit pieno** a 9,375 s; pedale più profondo |
| **0:11–0:12** | Frontale, zoom 4% | Il laser **scolpisce sulla parete il titolo: LETTERATURA / ITALIANA** (due righe) lettera per lettera (1,0 s). La parete di vetro svanisce lasciando solo il testo | Bianco puro, nero totale intorno | **LETTERATURA / ITALIANA** (Montserrat 800, 130 px) | Pluck rapidi su ogni lettera, poi silenzio −40 dBFS 1 beat |
| **0:12–0:13** | Fissa | **Respiro di luce**: bordo del testo con sweep di 600 ms da sinistra a destra (solo contorno, il testo non cambia di luminanza) | Calmo | — | Ripartenza: kick + accordo Re min9 |
| **0:13–0:14** | Fissa | **Barra gialla #FFE600** sotto ITALIANA (0,5 s) + **[ANALISI TESTUALE]** DM Mono 32 px | Uniforme | **LETTERATURA ITALIANA / [ANALISI TESTUALE]** | Chord stab pieno |
| **0:14–0:15** | Fissa | **Logo Telesio bianco** (dissolvenza 0,4 s), fermo 1,2 s | Uniforme | **logo** | Coda corale; fade audio 14,6–15,0 s |

### 4.3 Prompt AI (bozze)
- *"Five transparent glass monoliths arranged on an elliptical arc over a black mirror floor, thin electric blue edge glow, a single white laser beam cutting across the dark space and etching thin glowing letters into the glass, razor-sharp shadows, slow solemn orbit, absolute black background, ultra clean, 4K."*
  **Negative:** *ancient ruins, marble, books, quill, people, fog, grain, noise, flicker, lens flare.*

---

## 5. Tabella riassuntiva sound design

| Elemento | SPAGNOLO | INGLESE | LETTERATURA |
|---|---|---|---|
| Scala | La frigio | Mi minore pentatonica + 9ª | Re dorico |
| Sub / pedale | A1 sinusoide | E1 sinusoide | D1 sinusoide + armonica 2 |
| Pluck | Dente di sega filtrato, arp 1/8 | Pluck pulito, arp 1/8 | Pluck lento 1/4 con eco |
| Pad alto | La–Do–Mi, onda a vetro (FM) | Mi min9, saw filtrata | Pad corale sintetico, formanti "aa/oo" |
| Ritmica | Clap 3-3-2 sui beat | Clap 2 e 4, hat pulito | Kick e basso, quasi senza hat |
| Texture | Raggi laser: sweep acuto 0,4 s | Whoosh 0,5 s sui prismi | Campana sintetica pura D5 sui nomi |
| Pausa "pensiero" | 0,47 s a −40 dBFS | Idem | Idem |
| Stab finale | La frigio add9 | Mi min9 | Re min9 |

Firma comune: **click metronomo al frame 24**, 128 BPM, riser a 6,5–9,375 s, hit pieno a 9,375 s, silenzio di un beat a 11,5 s, ripartenza a 11,72 s.

---

## 6. Varianti
- **Reduced Motion (15 s):** camera ferma, solo dissolvenze di 600 ms, niente rotazioni né orbite; kick −4 dB.
- **Estesa 20 s:** inserire 5 s dopo 0:10 (10 battute): in SPAGNOLO una seconda apertura dell'arco con un frame di azulejo; in INGLESE un secondo passaggio dei prismi in verticale; in LETTERATURA un nome in più ("MANZONI") sul quarto monolito. Audio: 10 battute + coda 1,25 s.
- **9:16 verticale (social):** titolo su due righe, asse ricentrato.
- **Lockup comune:** per un'unica "famiglia" Telesio, i 3+2 titoli finali condividono: stessa posizione, barra gialla, etichetta DM Mono, logo bianco.

---

## 7. Descrizione testuale (accessibilità)
- **Spagnolo:** *"Su fondo nero, linee di luce bianca disegnano una stella a otto punte e un arco di vetro. Dietro l'arco sorge un disco rosso. Compaiono i segni ¿ e ¡ ai lati e la scritta SPAGNOLO con sottolineatura gialla, poi il logo Centro Studi Telesio."*
- **Inglese:** *"Su fondo nero, prismi d'acciaio scorrono su binari di luce blu e si allineano formando una linea ordinata. Compare la scritta INGLESE con sottolineatura gialla e il logo Centro Studi Telesio."*
- **Letteratura Italiana:** *"Su fondo nero, un raggio laser bianco scolpisce i nomi Dante, Petrarca e Leopardi su cinque lastre di vetro, che si uniscono in una parete. Compare la scritta LETTERATURA ITALIANA con sottolineatura gialla e il logo Centro Studi Telesio."*

---

## 8. Checklist di produzione

**Pre-produzione**
- [ ] Approvazione Direzione: accenti, nomi su monoliti (Dante, Petrarca, Leopardi), etichette [ESPAÑOL]/[ENGLISH]/[ANALISI TESTUALE], uso del giallo.
- [ ] Font (Montserrat, DM Mono) e logo Telesio bianco forniti in vettoriale.
- [ ] Animatic con audio guida a 128 BPM.

**Produzione**
- [ ] 3D/vettoriale in UHD 60 fps (Blender Cycles/Redshift o After Effects + 3D), 16× AA.
- [ ] Compositing: sweep, riflessi, titoli (senza riflesso).
- [ ] Audio: sincronizzazione su **0,4 · 1,875 · 5,625 · 9,375 · 11,72 · 13,125 · 15,0 s**.

**Controllo qualità**
- [ ] Test fotosensibilità (nessun flash oltre soglia).
- [ ] Contrasto ≥ 12:1 e titoli leggibili su telefono a luminosità 50%.
- [ ] Loudness −16 LUFS / true peak ≤ −1 dBTP.
- [ ] Prova con 2 studenti BES/DSA.

---

## 9. Rischi e note
1. **Generatori AI video:** non garantiscono geometria esatta, simmetria e assenza di rumore; adatti solo ad animatic. Verificare licenze commerciali.
2. **4K a 60 fps:** render pesante (900 frame per sigla); preventivare una render farm o un tempo di 4–6 ore per sigla.
3. **Rosso acido:** è il colore più affaticante; resta su linee fini (vedi §1.5).
4. **Nomi sui monoliti:** i soli nomi sono scelte editoriali; si possono sostituire (es. con "PAROLA", "VERSO", "STORIA").
5. **Coerenza di sistema:** le sigle di lezione (fondo bianco, 4 s + 5 s) restano il sistema operativo; queste sono la linea Premium/Brand (promo, apertura moduli).
