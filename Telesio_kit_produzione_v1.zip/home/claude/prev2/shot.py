import sys
from playwright.sync_api import sync_playwright
ts=[float(x) for x in sys.argv[1:]]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1280,"height":720})
    errs=[];pg.on("pageerror",lambda e:errs.append(str(e)));pg.goto("file:///home/claude/prev2/page.html")
    pg.evaluate("async()=>{await document.fonts.load('800 100px \"Bricolage Grotesque\"');await document.fonts.load('500 30px \"DM Mono\"');await document.fonts.load('700 40px Figtree');await new Promise(r=>{if(LG.complete)r();else LG.onload=r})}")
    for id in ("sp","en","le"):
        for t in ts:
            pg.evaluate(f"draw('{id}',{t})");pg.screenshot(path=f"/home/claude/prev2/f_{id}_{t}.png")
    print(errs);b.close()
