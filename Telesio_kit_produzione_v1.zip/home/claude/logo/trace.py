import numpy as np
from PIL import Image
from skimage import measure
from scipy.ndimage import gaussian_filter
im=np.array(Image.open('src.png').convert('RGBA')).astype(float)
a=im[...,3]/255.
print('colori opachi:',np.unique(im[a>.95][:,:3].astype(int),axis=0)[:5],a.shape)
ys,xs=np.where(a>.5);x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max();print(x0,x1,y0,y1)
m=gaussian_filter(a,1.5)
cs=measure.find_contours(m,0.5)
print(len(cs))
# --- Schneider
def bez(c,t):
    mt=1-t;return (mt**3)[:,None]*c[0]+(3*mt*mt*t)[:,None]*c[1]+(3*mt*t*t)[:,None]*c[2]+(t**3)[:,None]*c[3]
def fit_one(P,t,t1,t2):
    A1=(3*(1-t)**2*t)[:,None]*t1;A2=(3*(1-t)*t*t)[:,None]*t2
    C=np.array([[np.sum(A1*A1),np.sum(A1*A2)],[np.sum(A1*A2),np.sum(A2*A2)]])
    p0,p3=P[0],P[-1]
    tmp=P-(((1-t)**3+3*(1-t)**2*t)[:,None]*p0+((3*(1-t)*t*t+t**3))[:,None]*p3)
    X=np.array([np.sum(A1*tmp),np.sum(A2*tmp)])
    det=C[0,0]*C[1,1]-C[0,1]*C[1,0]
    seg=np.linalg.norm(p3-p0)
    if abs(det)>1e-12:
        al=(X[0]*C[1,1]-X[1]*C[0,1])/det;ar=(C[0,0]*X[1]-C[1,0]*X[0])/det
    else:al=ar=0
    if al<1e-6*seg or ar<1e-6*seg or al>0.8*seg or ar>0.8*seg:al=ar=seg/3
    return np.array([p0,p0+t1*al,p3+t2*ar,p3])
def cparam(P):
    d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(P,axis=0),axis=1))];return d/d[-1]
def reparam(c,P,t):
    d1=3*(c[1:]-c[:-1]);d2=2*(d1[1:]-d1[:-1])
    out=t.copy()
    for i,(p,u) in enumerate(zip(P,t)):
        mt=1-u;q=bez(c,np.array([u]))[0]
        q1=(mt*mt)*d1[0]+2*mt*u*d1[1]+u*u*d1[2];q2=mt*d2[0]+u*d2[1]
        num=np.dot(q-p,q1);den=np.dot(q1,q1)+np.dot(q-p,q2)
        out[i]=u if abs(den)<1e-12 else min(1,max(0,u-num/den))
    return out
from scipy.spatial import cKDTree
def dense_ok(c,P,err):
    tr=cKDTree(P);d,_=tr.query(bez(c,np.linspace(0,1,120)));return d.max()<err*1.3
def fit(P,t1,t2,err,depth=0):
    if len(P)==2:
        d=np.linalg.norm(P[1]-P[0])/3;return [np.array([P[0],P[0]+t1*d,P[1]+t2*d,P[1]])]
    t=cparam(P);c=fit_one(P,t,t1,t2)
    for _ in range(6):
        e=np.linalg.norm(bez(c,t)-P,axis=1);i=int(np.argmax(e))
        if e[i]<err and dense_ok(c,P,err):return [c]
        if e[i]>err*16:break
        t=reparam(c,P,t);c=fit_one(P,t,t1,t2)
    e=np.linalg.norm(bez(c,t)-P,axis=1);i=int(np.argmax(e))
    if e[i]<err and dense_ok(c,P,err):return [c]
    i=min(max(i,1),len(P)-2)
    tc=P[i-1]-P[i+1];tc/=np.linalg.norm(tc)+1e-12
    return fit(P[:i+1],t1,tc,err,depth+1)+fit(P[i:],-tc,t2,err,depth+1)
def unit(v):
    n=np.linalg.norm(v);return v/n if n>1e-9 else v
def corners(P,k=28,ang=40):
    n=len(P);idx=[]
    for i in range(n):
        a=P[i]-P[(i-k)%n];b=P[(i+k)%n]-P[i]
        cosv=np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-12)
        if np.degrees(np.arccos(np.clip(cosv,-1,1)))>ang:idx.append(i)
    # mantieni il massimo locale di ogni gruppo
    out=[];grp=[]
    for i in idx:
        if grp and i-grp[-1]>k:out.append(grp);grp=[]
        grp.append(i)
    if grp:out.append(grp)
    res=[]
    for g in out:
        best=max(g,key=lambda i:np.degrees(np.arccos(np.clip(np.dot(P[i]-P[(i-k)%n],P[(i+k)%n]-P[i])/(np.linalg.norm(P[i]-P[(i-k)%n])*np.linalg.norm(P[(i+k)%n]-P[i])+1e-12),-1,1))))
        res.append(best)
    return sorted(set(res))
def path_of(P,err=1.2):
    P=P[:-1] if np.allclose(P[0],P[-1]) else P
    # sottocampiona leggermente
    P=P[::3] if len(P)>600 else P
    n=len(P);cs=corners(P)
    segs=[]
    if not cs:
        # chiuso liscio: spezza in 4 sezioni
        cs=[0,n//4,n//2,3*n//4];smooth=True
    else:smooth=False
    d=''
    for j,i in enumerate(cs):
        k=cs[(j+1)%len(cs)]
        S=np.vstack([P[i:],P[:k+1]]) if k<=i else P[i:k+1]
        if len(S)<2:continue
        if smooth:
            t1=unit(P[(i+3)%n]-P[(i-3)%n]);t2=-unit(P[(k+3)%n]-P[(k-3)%n])
        else:
            t1=unit(S[min(6,len(S)-1)]-S[0]);t2=unit(S[max(len(S)-7,0)]-S[-1])
        for c in fit(S,t1,t2,err):
            if not d:d='M%.2f %.2f'%tuple(c[0])
            d+='C%.2f %.2f %.2f %.2f %.2f %.2f'%(*c[1],*c[2],*c[3])
    return d+'Z'
D=''
for c in cs:
    if len(c)<12:continue
    P=c[:,::-1]-np.array([x0,y0])   # (x,y)
    D+=path_of(P)
W=x1-x0+1;H=y1-y0+1
open('paths.txt','w').write(D)
print('path len',len(D),'W,H',W,H)
for name,col in (('blu','#2060AF'),('bianco','#FFFFFF'),('inchiostro','#0B1530')):
    open(f'Telesio_logo_{name}.svg','w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}"><title>Centro Studi Telesio</title><path fill="{col}" fill-rule="evenodd" d="{D}"/></svg>')
