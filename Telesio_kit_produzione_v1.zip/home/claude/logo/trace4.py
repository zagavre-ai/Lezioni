import numpy as np,cv2
from PIL import Image
from skimage import measure
from scipy.ndimage import gaussian_filter
UP=8
I0=Image.open('src2.png').convert('RGBA');I0=I0.resize((I0.width*UP,I0.height*UP),Image.BICUBIC)
a=np.array(I0)[...,3]/255.
ys,xs=np.where(a>.5);x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max()
m=gaussian_filter(a,2.5)
cs=[c for c in measure.find_contours(m,0.5) if len(c)>40]
EPS=2.6;SH=52
def f(v):return '%.2f'%(v/UP)
def path(P):
    P=P[:-1] if np.allclose(P[0],P[-1]) else P
    V=cv2.approxPolyDP(P.astype(np.float32).reshape(-1,1,2),EPS,True).reshape(-1,2).astype(float)
    n=len(V)
    ang=[]
    for i in range(n):
        a_=V[i]-V[i-1];b_=V[(i+1)%n]-V[i]
        ang.append(np.degrees(abs(np.arctan2(a_[0]*b_[1]-a_[1]*b_[0],a_@b_))))
    sharp=[g>SH for g in ang]
    # punto di partenza: primo vertice netto, o punto medio
    if any(sharp):
        s=sharp.index(True);V=np.roll(V,-s,0);sharp=list(np.roll(sharp,-s));start=V[0];order=range(1,n+1)
    else:
        start=(V[0]+V[1])/2;order=range(1,n+1)
    d='M%s %s'%(f(start[0]),f(start[1]))
    cur=start
    for k in order:
        i=k%n;v=V[i];nx=V[(i+1)%n]
        if sharp[i]:
            d+='L%s %s'%(f(v[0]),f(v[1]))
        else:
            e=nx if sharp[(i+1)%n] else (v+nx)/2
            if not any(sharp) and k==n:e=start
            d+='Q%s %s %s %s'%(f(v[0]),f(v[1]),f(e[0]),f(e[1]))
    return d+'Z'
D=''.join(path(c[:,::-1]-np.array([x0,y0])) for c in cs)
W=(x1-x0+1)/UP;H=(y1-y0+1)/UP
for name,col in (('blu','#2060AF'),('bianco','#FFFFFF'),('inchiostro','#0B1530')):
    open(f'Telesio_logo_{name}.svg','w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.2f} {H:.2f}"><title>Centro Studi Telesio</title><path fill="{col}" fill-rule="evenodd" d="{D}"/></svg>')
print(len(D),D.count('Q')+D.count('L'),W,H)
