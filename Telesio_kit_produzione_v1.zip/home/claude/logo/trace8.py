import numpy as np,cv2
from PIL import Image
from skimage import measure
from scipy.ndimage import gaussian_filter
UP=1
I0=Image.open('src.png').convert('RGBA')
a=np.array(I0)[...,3]/255.
ys,xs=np.where(a>.5);x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max()
m=gaussian_filter(a,2.5)
cs=[c for c in measure.find_contours(m,0.5) if len(c)>40]
EPS=1.6;SH=52
def f(v):return '%.2f'%(v/UP)
def path(P):
    P=P[:-1] if np.allclose(P[0],P[-1]) else P
    V=cv2.approxPolyDP(P.astype(np.float32).reshape(-1,1,2),EPS,True).reshape(-1,2).astype(float)
    n=len(V)
    ang=[]
    for i in range(n):
        a_=V[i]-V[i-1];b_=V[(i+1)%n]-V[i]
        ang.append(np.degrees(abs(np.arctan2(a_[0]*b_[1]-a_[1]*b_[0],a_@b_))))
    sharp=[g>SH for g in ang]
    R=30.0
    def un(v):
        n_=np.linalg.norm(v);return v/n_ if n_>1e-9 else v
    d=''
    for i in range(n):
        v=V[i];pv=V[i-1];nx=V[(i+1)%n]
        if sharp[i]:
            pi=po=v
        else:
            lp=np.linalg.norm(v-pv);ln=np.linalg.norm(nx-v)
            RR=1e9 if ang[i]<30 else R
            pi=v-un(v-pv)*min(RR,lp/2);po=v+un(nx-v)*min(RR,ln/2)
        if i==0:d+='M%s %s'%(f(pi[0]),f(pi[1]))
        else:d+='L%s %s'%(f(pi[0]),f(pi[1]))
        if not sharp[i]:d+='Q%s %s %s %s'%(f(v[0]),f(v[1]),f(po[0]),f(po[1]))
    return d+'Z'
D=''.join(path(c[:,::-1]-np.array([x0,y0])) for c in cs)
W=(x1-x0+1)/UP;H=(y1-y0+1)/UP
for name,col in (('blu','#2060AF'),('bianco','#FFFFFF'),('inchiostro','#0B1530')):
    open(f'Telesio_logo_{name}.svg','w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.2f} {H:.2f}"><title>Centro Studi Telesio</title><path fill="{col}" fill-rule="evenodd" d="{D}"/></svg>')
print(len(D),D.count('Q')+D.count('L'),W,H)
