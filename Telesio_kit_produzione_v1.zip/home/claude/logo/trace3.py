import numpy as np
from PIL import Image
from skimage import measure
from scipy.ndimage import gaussian_filter
from scipy.interpolate import splprep,splev
UP=8
I0=Image.open('src2.png').convert('RGBA');I0=I0.resize((I0.width*UP,I0.height*UP),Image.BICUBIC)
a=np.array(I0)[...,3]/255.
ys,xs=np.where(a>.5);x0,x1,y0,y1=xs.min(),xs.max(),ys.min(),ys.max()
m=gaussian_filter(a,3.0)
cs=[c for c in measure.find_contours(m,0.5) if len(c)>40]
print(len(cs))
def turn(P,k):
    n=len(P);A=P-np.roll(P,k,0);B=np.roll(P,-k,0)-P
    cr=A[:,0]*B[:,1]-A[:,1]*B[:,0];dt=(A*B).sum(1);return np.degrees(np.abs(np.arctan2(cr,dt)))
def smooth_closed(P,s):
    tck,u=splprep([P[:,0],P[:,1]],s=s,per=True,k=3);return tck
def pieces(P):
    P=P[:-1] if np.allclose(P[0],P[-1]) else P
    # ricampiona uniformemente a 1 px
    d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.vstack([P,P[:1]]),axis=0),axis=1))];L=d[-1]
    t=np.linspace(0,L,int(L),endpoint=False);Q=np.c_[np.interp(t,d,np.r_[P[:,0],P[0,0]]),np.interp(t,d,np.r_[P[:,1],P[0,1]])]
    k=int(0.9*UP*1.2)+2
    tu=turn(Q,k)
    cand=np.where(tu>34)[0]
    cor=[]
    if len(cand):
        grp=[[cand[0]]]
        for i in cand[1:]:
            (grp[-1].append(i) if i-grp[-1][-1]<=k else grp.append([i]))
        if len(grp)>1 and grp[0][0]==0 and grp[-1][-1]>=len(Q)-k:grp[0]=grp[-1]+grp[0];grp.pop()
        cor=sorted(set(int(g[np.argmax(tu[g])]) for g in grp))
    return Q,cor
def bezpath(pts):
    # pts: lista di nodi (n,2) aperta -> Catmull-Rom->Bezier
    n=len(pts);o=[]
    for i in range(n-1):
        p0=pts[max(i-1,0)];p1=pts[i];p2=pts[i+1];p3=pts[min(i+2,n-1)]
        c1=p1+(p2-p0)/6 if i>0 else p1+(p2-p1)/3
        c2=p2-(p3-p1)/6 if i<n-2 else p2-(p2-p1)/3
        o.append((c1,c2,p2))
    return o
def nodes_adaptive(S,dmax=260,ang=5.0):
    # S: punti densi lungo una curva aperta; sceglie nodi per curvatura cumulata e lunghezza
    keep=[0];acc=0;last=0
    for i in range(1,len(S)-1):
        a=S[i]-S[i-1];b=S[i+1]-S[i]
        acc+=np.degrees(abs(np.arctan2(a[0]*b[1]-a[1]*b[0],a@b)))
        if acc>ang or i-last>dmax:keep.append(i);acc=0;last=i
    keep.append(len(S)-1);return S[keep]
def f(v):return '%.2f'%(v/UP)
D=''
for c in cs:
    P=c[:,::-1]-np.array([x0,y0])
    Q,cor=pieces(P);n=len(Q)
    if not cor:
        # chiuso liscio: spline periodica, nodi adattivi, chiusura ciclica
        tck=smooth_closed(Q[::2],len(Q[::2])*1.0)
        S=np.c_[splev(np.linspace(0,1,len(Q),endpoint=False),tck)].T if False else np.array(splev(np.linspace(0,1,len(Q)+1),tck)).T
        N=nodes_adaptive(S[:-1] if False else S)
        N[-1]=N[0]
        # chiusa: Catmull-Rom ciclico
        M=N[:-1];m=len(M);o=[]
        for i in range(m):
            p0=M[(i-1)%m];p1=M[i];p2=M[(i+1)%m];p3=M[(i+2)%m]
            o.append((p1+(p2-p0)/6,p2-(p3-p1)/6,p2))
        D+='M%s %s'%(f(M[0][0]),f(M[0][1]))+''.join('C%s %s %s %s %s %s'%(f(a[0]),f(a[1]),f(b[0]),f(b[1]),f(e[0]),f(e[1])) for a,b,e in o)+'Z'
    else:
        D+='M%s %s'%(f(Q[cor[0]][0]),f(Q[cor[0]][1]))
        for j,i in enumerate(cor):
            k=cor[(j+1)%len(cor)]
            idx=np.arange(i,k+1) if k>i else np.r_[np.arange(i,n),np.arange(0,k+1)]
            S=Q[idx]
            if len(S)>12:
                try:
                    tck,_=splprep([S[:,0],S[:,1]],s=len(S)*0.6,k=3);S=np.array(splev(np.linspace(0,1,len(S)),tck)).T
                except Exception:pass
            N=nodes_adaptive(S)
            for a,b,e in bezpath(N):D+='C%s %s %s %s %s %s'%(f(a[0]),f(a[1]),f(b[0]),f(b[1]),f(e[0]),f(e[1]))
        D+='Z'
W=(x1-x0+1)/UP;H=(y1-y0+1)/UP
for name,col in (('blu','#2060AF'),('bianco','#FFFFFF'),('inchiostro','#0B1530')):
    open(f'Telesio_logo_{name}.svg','w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.2f} {H:.2f}"><title>Centro Studi Telesio</title><path fill="{col}" fill-rule="evenodd" d="{D}"/></svg>')
print(len(D),W,H)
