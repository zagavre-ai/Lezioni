import re,json
src=open('/home/claude/v5/consegna_v5/Esercizi_Spagnolo_Lez1_anteprima.html').read()
tl=json.load(open('/tmp/timeline.json'))
T={n:s for n,s,d in tl}
Q0=[669.0,996.0,1466.0,1864.0,2174.0,2419.0,2567.5]
stops=[q+1.8 for q in Q0]
tops=[0.0,172.0]+[q+4.5 for q in Q0[:6]]
# ---- esercizi.html (motore esistente, adattato all'incorporamento) ----
e=src
def rep(a,b,cnt=1):
    global e
    assert e.count(a)==cnt,(e.count(a),a[:60]);e=e.replace(a,b)
rep("(function(){var w=window,n=0;while(w&&!w.API&&w.parent&&w.parent!==w&&n<10){w=w.parent;n++}API=(w&&w.API)||(window.opener&&window.opener.API)||null;","(function(){var w=window,n=0;API=null;try{while(w&&!w.API&&w.parent&&w.parent!==w&&n<10){w=w.parent;n++}API=(w&&w.API)||null}catch(e){API=null}try{if(!API&&window.opener&&window.opener.API)API=window.opener.API}catch(e){}")
rep('var cur=1;var lastInput=null;','var cur=(location.hash.match(/q=(\\d+)/)||[0,1])[1]*1;var lastInput=null;var EMB=(window.parent!==window);if(EMB)document.documentElement.className="emb";')
rep('function tabs(){var t=document.getElementById(\'tabs\');','function tabs(){var t=document.getElementById(\'tabs\');if(EMB){t.style.display=\'none\';return}')
rep('function save(){try{','function save(){try{if(EMB)parent.postMessage({telesio:"state",first:FIRST,done:DONE},"*")}catch(e){}try{')
rep('render();\n</script>','''window.addEventListener('message',function(m){var d=m.data||{};if(d.telesio==='open'){cur=d.quiz;render();window.scrollTo(0,0);var h=document.querySelector('h1');if(h){h.setAttribute('tabindex','-1');h.focus()}}
 if(d.telesio==='restore'){FIRST=d.first||FIRST;DONE=d.done||DONE;render()}});
render();
try{if(EMB){var mx={};E.forEach(function(x){mx[x.quiz]=(mx[x.quiz]||0)+maxPts(x)});parent.postMessage({telesio:'ready',max:mx,names:Q},'*')}}catch(e){}
</script>''')
rep('</style></head>','h1:focus{outline:none}html.emb header,html.emb #foot{display:none}html.emb,html.emb body{height:100%;overflow:hidden}html.emb body{background:#fff;display:flex;flex-direction:column}html.emb main{flex:1;min-height:0;overflow-y:auto;max-width:none;margin:0;padding:0 22px 0}html.emb #view>div:first-child{position:sticky;top:0;z-index:6;margin:0 -22px 14px;padding:12px 22px 10px;background:linear-gradient(115deg,#0B1530,#1b3d7a);color:#fff}html.emb #view>div:first-child h1{color:#fff;font-size:26px;margin:0}html.emb #view>div:first-child .sub{color:#5BD6F0;margin:2px 0 0;font-weight:700}html.emb .act{position:sticky;bottom:0;z-index:6;background:#fff;margin:14px -22px 0;padding:10px 22px;border-top:1px solid var(--line);box-shadow:0 -6px 16px rgba(11,21,48,.08)}html.emb .score{min-height:0}</style></head>')
open('esercizi.html','w').write(e)
# ---- index.html (lettore) ----
fonts=''.join(re.findall(r'@font-face\{[^}]*\}',src))
logo=re.search(r'<header><img src="([^"]+)"',src).group(1)
P=open('player_tpl.html').read()
P=P.replace('/*FONTS*/',fonts).replace('{{LOGO}}',logo).replace('{{STOPS}}',json.dumps(stops)).replace('{{TOPS}}',json.dumps(tops))
open('index.html','w').write(P)
print(stops,tops)
