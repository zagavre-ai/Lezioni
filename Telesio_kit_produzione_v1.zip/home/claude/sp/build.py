#!/usr/bin/env python3
# Costruisce, dal testo Word della docente, la videodispensa 16:9 e la dispensa A4 orizzontale
# (stesse slide, stessi tagli) sul modello ufficiale Telesio.
import copy, re, sys, json
import docx
from docx.table import Table
from docx.text.paragraph import Paragraph
from pptx import Presentation
from pptx.util import Emu
from lxml import etree
from PIL import ImageFont

MODEL = '/home/claude/kit/01_Modelli/2_Videolezione_16-9_modello.pptx'
FR = '/home/claude/kit/01_Modelli/loghi_font/LiberationSans-Regular.ttf'
FB = '/home/claude/kit/01_Modelli/loghi_font/LiberationSans-Bold.ttf'
NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main'}
A = '{%s}' % NS['a']

# ---------------------------------------------------------------- geometria (px su 1920 di larghezza)
CW_V = 1393            # colonna contenuti video (x 80 -> 1473)
CW_A = 1760            # colonna contenuti A4 (x 80 -> 1840)
TOP = 386
BOT_V = 953            # limite inferiore contenuti, video
A4_W, A4_H = 10692000, 7560000
H_A4 = 1920 * 210 / 297          # altezza A4 in px di progetto (1357.6)
DELTA = H_A4 - 1080              # spazio in piu' in verticale
S_A4 = A4_W / 12192000           # 0.877
FS = 32                          # corpo 16 pt = 32 px di progetto
FT = 30                          # tabelle 15 pt = 30 px
LH = 1.875                  # interlinea del corpo (x dimensione carattere)
SPC = 16                         # spazio dopo il paragrafo (8 pt)

_fonts = {}
def font(px, bold=False):
    k = (round(px), bold)
    if k not in _fonts:
        _fonts[k] = ImageFont.truetype(FB if bold else FR, round(px))
    return _fonts[k]

def wrap_lines(runs, width, px, indent=0):
    """runs = [(testo, bold)] -> numero di righe a quella larghezza"""
    words = []
    for t, b in runs:
        for w in re.findall(r'\S+\s*', t):
            words.append((w, b))
    if not words:
        return 1
    lines, cur = 1, 0.0
    avail = width - indent
    for w, b in words:
        wl = font(px, b).getlength(w.rstrip())
        full = font(px, b).getlength(w)
        if cur + wl > avail and cur > 0:
            lines += 1; cur = 0.0
        cur += full
    return lines

# ---------------------------------------------------------------- lettura del Word
def parse_docx(path):
    d = docx.Document(path)
    items = []
    for el in d.element.body.iterchildren():
        tag = el.tag.split('}')[1]
        if tag == 'p':
            p = Paragraph(el, d)
            txt = p.text.strip()
            sty = p.style.name
            if sty.startswith('Heading 1'):
                if txt: items.append(('h1', txt))
                continue
            if sty.startswith('Heading 2'):
                if txt: items.append(('h2', txt))
                continue
            if not txt: continue
            runs = []
            for r in p.runs:
                if r.text:
                    runs.append((r.text, bool(r.bold)))
            # unisco i run con lo stesso grassetto
            m = []
            for t, b in runs:
                if m and m[-1][1] == b: m[-1] = (m[-1][0] + t, b)
                else: m.append((t, b))
            items.append(('title' if sty == 'Title' else 'p', m))
        elif tag == 'tbl':
            t = Table(el, d)
            rows = []
            for r in t.rows:
                seen, cells = [], []
                for c in r.cells:
                    if id(c._tc) in seen: continue
                    seen.append(id(c._tc)); cells.append(c.text.strip())
                rows.append(cells)
            items.append(('table', rows))
    return items

CORREZIONI = []
def applica_correzioni(items):
    out = []
    h2s = [v for k, v in items if k == 'h2']
    for kind, val in items:
        if kind in ('p', 'title'):
            t = plain(val)
            if t.startswith('11. ¿Hay un hotel'):
                val = [('1' + t[2:], False)]; CORREZIONI.append('"11. ¿Hay un hotel?" -> "1. ¿Hay un hotel?"')
            elif t == '.':
                CORREZIONI.append('tolto un punto isolato su una riga'); continue
            elif '..' in t and '...' not in t:
                val = [(t.replace('..', '.'), False)]; CORREZIONI.append('doppio punto: "%s"' % t[:60])
        elif kind == 'table':
            nr = []
            for r in val:
                rr = []
                for c in r:
                    c2 = re.sub(r'\b(g|gu) fi (j|g)\b', r'\1 → \2', c)
                    if c2 != c: CORREZIONI.append('freccia persa nel Word: "%s" -> "%s"' % (c, c2))
                    rr.append(c2)
                nr.append(rr)
            val = nr
        elif kind == 'h2':
            v = val
            if re.match(r'Actividad 4\.4', v) and not any(h.startswith('Actividad 4.3') for h in h2s):
                val = v.replace('4.4', '4.3', 1); CORREZIONI.append('numerazione saltata: "Actividad 4.4" -> "Actividad 4.3"')
            if re.search(r'\d—', val):
                val = re.sub(r'(\d)—', r'\1 —', val); CORREZIONI.append('spazio mancante prima del trattino in "%s"' % v)
        out.append((kind, val))
    return out

def plain(runs):
    return ''.join(t for t, b in runs).strip()

def only_underscores(s):
    return bool(s) and not s.replace('_', '').replace(' ', '').strip()

# ---------------------------------------------------------------- piano delle slide
def plan(items, materia):
    """Restituisce (info_copertina, lista_pagine). Le pagine sono uguali per video e A4."""
    info = {'materia': materia, 'theme': '', 'argomenti': [], 'intro': None}
    pages = []
    i = 0
    n = len(items)
    # --- testata
    head = []
    while i < n and items[i][0] not in ('h1',):
        head.append(items[i]); i += 1
    for kind, val in head:
        if kind == 'title':
            t = plain(val)
            t = re.sub(r'(?i)^lezione di spagnolo\s*', '', t).strip()
            if t: info['theme'] = t
        elif kind == 'p':
            t = plain(val)
            if re.match(r'(?i)^lezione di', t): continue
            m = re.match(r'(?i)^argomento\s*\d+\s*:\s*(.*)$', t)
            if m: continue
            if t.upper().startswith('DISPENSA'): continue
            if not info['theme'] and t.isupper(): info['theme'] = t
        elif kind == 'table':
            info['intro'] = val
    # --- sezioni
    sections = []
    cur = None
    while i < n:
        kind, val = items[i]
        if kind == 'h1':
            cur = {'title': val, 'items': []}; sections.append(cur)
        else:
            cur['items'].append((kind, val))
        i += 1
    info['argomenti'] = [re.sub(r'^\d+\.\s*', '', s['title']) for s in sections if not s['title'].lower().startswith('síntesis')]
    return info, sections

def capacity_text(blocks, cw, avail):
    """altezza che occupano i blocchi di testo (px di progetto)"""
    h = 0
    for kind, runs in blocks:
        ind = 54 if kind == 'bullet' else 0
        nl = wrap_lines(runs, cw, FS, ind)
        h += nl * FS * LH + SPC
    return h

def col_widths(rows, W):
    nc = max(len(r) for r in rows)
    nat = []
    for c in range(nc):
        mx = 0
        for ri, r in enumerate(rows):
            t = r[c] if c < len(r) else ''
            if only_underscores(t): t = 'x' * 12
            mx = max(mx, font(FT, ri == 0).getlength(t))
        nat.append(min(mx, 0.62 * W) + 44)
    tot = sum(nat)
    w = [max(110, x / tot * W) for x in nat]
    k = W / sum(w)
    return [x * k for x in w]

def natural_total(rows, W):
    nc = max(len(r) for r in rows); tot = 0
    for c in range(nc):
        mx = 0
        for ri, r in enumerate(rows):
            t = r[c] if c < len(r) else ''
            if only_underscores(t): t = 'x' * 12
            mx = max(mx, font(FT, ri == 0).getlength(t))
        tot += min(mx, 0.62 * W) + 44
    return tot

def row_height(cells, widths, hdr):
    mx = 1
    for c, t in enumerate(cells):
        if only_underscores(t): t = ''
        nl = wrap_lines([(t, hdr)], widths[c] - 44, FT) if t else 1
        mx = max(mx, nl)
    return max(50, mx * FT * 1.149 + 16) if mx > 1 else 50

def table_height(rows, widths):
    return sum(row_height(r, widths, i == 0) for i, r in enumerate(rows))

# ---------------------------------------------------------------- impaginazione
def split_text_blocks(blocks, cw, avail):
    if capacity_text(blocks, cw, avail) > avail:
        k = next((i for i, b in enumerate(blocks) if b[0] == 'bullet'), None)
        if k and k > 0 and capacity_text(blocks[:k], cw, avail) <= avail and capacity_text(blocks[k:], cw, avail) <= avail:
            return [list(blocks[:k]), list(blocks[k:])]
    pages, cur, h = [], [], 0
    for b in blocks:
        bh = capacity_text([b], cw, avail)
        if cur and h + bh > avail:
            pages.append(cur); cur, h = [], 0
        cur.append(b); h += bh
    if cur: pages.append(cur)
    return pages

ITEM = re.compile(r'^(\d+[A-Za-z]?[\.\)]|[A-Z][\.\)])\s')
def is_sub(t):
    letters = re.sub(r'[^A-Za-zÁÉÍÓÚÑáéíóúñ]', '', t)
    return len(t) < 45 and len(letters) >= 4 and t == t.upper() and not ITEM.match(t)

def clean_lines(paras):
    """unisce le righe spezzate a meta' frase; ritorna blocchi ('p'|'bullet'|'sub', runs)"""
    out = []
    for runs in paras:
        t = plain(runs)
        if not t or t == '.': continue
        if only_underscores(t): continue
        if t.startswith('•'):
            out.append(['bullet', [(re.sub(r'^[•]\s*', '', t), False)]]); continue
        if is_sub(t):
            out.append(['sub', [(t, True)]]); continue
        prev = out[-1] if out else None
        if prev and prev[0] == 'p' and len(plain(prev[1])) >= 80 and not re.search(r'[.!?»”]\s*$', plain(prev[1])) \
           and not ITEM.match(t) and not re.match(r'^(ITALIANO|ESPAÑOL)', t):
            prev[1] = prev[1] + [(' ', False)] + list(runs)
            continue
        out.append(['p', list(runs)])
    return [tuple(x) for x in out]

def build_pages(sections, cw=CW_V, avail=BOT_V - TOP):
    pages = []
    for si, sec in enumerate(sections, 1):
        title = sec['title']
        is_syn = title.lower().startswith('síntesis')
        row = '%02d · %s' % (si, re.sub(r'^\d+\.\s*', '', title))
        its = sec['items']
        # raggruppo per H2
        groups = [(None, [])]
        for kind, val in its:
            if kind == 'h2': groups.append((val, []))
            else: groups[-1][1].append((kind, val))
        for gi, (h2, gitems) in enumerate(groups):
            ptitle = h2 if h2 else title
            # sequenza di blocchi
            seq = []   # ('text', blocks) | ('table', rows)
            buf = []
            for kind, val in gitems:
                if kind == 'p': buf.append(val)
                elif kind == 'table':
                    if buf: seq.append(('text', clean_lines(buf))); buf = []
                    seq.append(('table', val))
            if buf: seq.append(('text', clean_lines(buf)))
            seq = [s for s in seq if not (s[0] == 'text' and not s[1])]
            if not seq: continue
            # note dopo tabella: testo che segue una tabella nel gruppo senza H2 di attivita' => commento
            j = 0
            made = []
            while j < len(seq):
                k, v = seq[j]
                if k == 'table':
                    rows = v
                    note = None
                    if j + 1 < len(seq) and seq[j + 1][0] == 'text' and not (h2 and re.match(r'(?i)actividad', h2)):
                        note = seq[j + 1][1]; j += 1
                    made.append(('table', rows, note))
                else:
                    made.append(('text', v, None))
                j += 1
            # attivita' con testo prima/dopo tabella: pagina mista
            for mi, (k, v, note) in enumerate(made):
                if k == 'text':
                    nxt = made[mi + 1] if mi + 1 < len(made) else None
                    prv = made[mi - 1] if mi > 0 else None
                    if h2 and re.match(r'(?i)actividad', h2) and ((nxt and nxt[0] == 'table') or (prv and prv[0] == 'table')):
                        continue  # gestito con la tabella
                    for blocks in split_text_blocks(v, cw, avail):
                        pages.append({'type': 'text', 'row': row, 'title': ptitle, 'blocks': blocks})
                else:
                    pre = made[mi - 1][1] if (mi > 0 and made[mi - 1][0] == 'text' and h2 and re.match(r'(?i)actividad', h2)) else None
                    post = made[mi + 1][1] if (mi + 1 < len(made) and made[mi + 1][0] == 'text' and h2 and re.match(r'(?i)actividad', h2)) else None
                    pages.extend(table_pages(row, ptitle, v, note, pre, post, cw, avail))
    return pages

def table_pages(row, title, rows, note, pre, post, cw, avail):
    out = []
    hdr, body = rows[0], rows[1:]
    ncols = max(len(r) for r in rows)
    side = bool(note) and ncols <= 2 and natural_total(rows, cw) <= 0.62 * cw
    W = round(cw * 0.60) if side else cw
    widths = col_widths(rows, W)
    pre_h = (capacity_text(pre, cw, avail) + 20) if pre else 0
    post_h = (capacity_text(post, cw, avail) + 20) if post else 0
    note_below_h = (capacity_text(note, cw, avail) + 20) if (note and not side) else 0
    hh = row_height(hdr, widths, True)
    # suddivisione righe
    chunks, cur, h = [], [], hh
    limit = avail - pre_h
    for r in body:
        rh = row_height(r, widths, False)
        if cur and h + rh > limit:
            chunks.append(cur); cur, h = [], hh; limit = avail
        cur.append(r); h += rh
    if cur: chunks.append(cur)
    for ci, ch in enumerate(chunks):
        last = ci == len(chunks) - 1
        pg = {'type': 'table', 'row': row, 'title': title, 'header': hdr, 'rows': ch, 'widths': widths,
              'side': side, 'W': W, 'note': note if side or (note and last) else None,
              'pre': pre if ci == 0 else None, 'post': None}
        used = hh + sum(row_height(r, widths, False) for r in ch) + (pre_h if ci == 0 else 0)
        if post and last:
            if used + post_h <= avail: pg['post'] = post
            else:
                out.append(pg)
                for blocks in split_text_blocks(post, cw, avail):
                    out.append({'type': 'text', 'row': row, 'title': title, 'blocks': blocks})
                continue
        if note and not side and last:
            if used + note_below_h > avail:
                pg['note'] = None
                out.append(pg)
                for blocks in split_text_blocks(note, cw, avail):
                    out.append({'type': 'text', 'row': row, 'title': title, 'blocks': blocks})
                continue
        out.append(pg)
    return out

# ---------------------------------------------------------------- costruzione PPTX
class Deck:
    def __init__(self, mode, materia_doc, label_cover):
        self.mode = mode
        self.a4 = (mode == 'a4')
        self.K = (A4_W / 1920.0) if self.a4 else 6350.0       # EMU per px di progetto
        self.f = (0.5 * S_A4) if self.a4 else 0.5             # pt per px di progetto
        self.cw = CW_A if self.a4 else CW_V
        self.bot = (BOT_V + DELTA) if self.a4 else BOT_V
        self.prs = Presentation(MODEL)
        # modello: tengo il numero di pagina e svuoto le slide
        self.num_tpl = None
        for sh in self.prs.slides[2].shapes:
            if 'Slide Number' in sh.name:
                self.num_tpl = copy.deepcopy(sh._element)
        sl = self.prs.slides._sldIdLst
        for sid in list(sl):
            self.prs.part.drop_rel(sid.rId); sl.remove(sid)
        self.docente = materia_doc
        self.label_cover = label_cover
        if self.a4:
            self.to_a4()
        self.fix_layout_text()

    def E(self, v): return int(round(v * self.K))
    def PT(self, px): return int(round(px * self.f * 100))

    # --- A4 orizzontale: ridimensiono layout e master, tolgo la zona webcam, testo a tutta larghezza
    def to_a4(self):
        prs = self.prs
        prs.slide_width, prs.slide_height = A4_W, A4_H
        def scale_sz(el):
            for e in el.iter():
                if 'sz' in e.attrib and e.tag.startswith(A):
                    e.set('sz', str(int(round(int(e.get('sz')) * S_A4))))
        scale_sz(prs.slide_master._element)
        for sh in prs.slide_master.shapes:
            self._tx_shape(sh, 'master')
        for lay in prs.slide_layouts:
            scale_sz(lay._element)
            cover = lay.name == 'Copertina'
            for sh in list(lay.shapes):
                if sh.left is None: continue
                x, y, w, h = [v / 6350.0 for v in (sh.left, sh.top, sh.width, sh.height)]
                if sh.name == 'Shape 2' and abs(x - 1516) < 2:     # riquadro webcam
                    sh._element.getparent().remove(sh._element); continue
                if cover:
                    dy = 0 if y <= 460 else (DELTA / 2 if y < 950 else DELTA)
                else:
                    dy = DELTA if y >= 900 else 0
                # larghezze a tutta pagina
                if not cover:
                    if sh.is_placeholder:
                        idx = sh.placeholder_format.idx
                        if idx in (106, 107): w = CW_A
                        if idx == 109:
                            w = 920 if lay.name == 'Testo e box' else CW_A; h = h + DELTA
                        if idx == 110: x, w = 1060, 780
                sh.left, sh.top = self.E(x), self.E(y + dy)
                sh.width, sh.height = self.E(w), self.E(h)

    def _tx_shape(self, sh, where):
        pass

    def fix_layout_text(self):
        for lay in self.prs.slide_layouts:
            for sh in lay.shapes:
                if not sh.has_text_frame: continue
                t = sh.text_frame.text.strip()
                def put(newt):
                    p = sh.text_frame.paragraphs[0]
                    rs = p.runs
                    rs[0].text = newt
                    for r in rs[1:]: r.text = ''
                if t == 'TITOLO DELLA LEZIONE' and sh.name == 'Text 4' and lay.name != 'Copertina':
                    put('SPAGNOLO')
                elif t.startswith('Nome Materia') and lay.name != 'Copertina':
                    put(self.docente)
                elif t == 'VIDEOLEZIONE':
                    put(self.label_cover)

    # --- utilita' XML
    def run(self, text, px, bold=False, color='tx1', lang='es-ES'):
        r = etree.SubElement(etree.Element(A + 'dummy'), A + 'r')
        rpr = etree.SubElement(r, A + 'rPr', lang=lang, sz=str(self.PT(px)), dirty='0')
        if bold: rpr.set('b', '1')
        sf = etree.SubElement(rpr, A + 'solidFill')
        if re.match(r'^[0-9A-Fa-f]{6}$', color): etree.SubElement(sf, A + 'srgbClr', val=color)
        else: etree.SubElement(sf, A + 'schemeClr', val=color)
        t = etree.SubElement(r, A + 't'); t.text = text
        return r

    def para(self, runs, px=FS, bullet=False, color='tx1', lnspc=140000, after=8, algn=None, num=False, marL=None):
        p = etree.Element(A + 'p')
        ppr = etree.SubElement(p, A + 'pPr')
        if bullet or num:
            ppr.set('marL', str(self.E(54))); ppr.set('indent', str(-self.E(54)))
        else:
            ppr.set('marL', '0'); ppr.set('indent', '0')
        if algn: ppr.set('algn', algn)
        ls = etree.SubElement(ppr, A + 'lnSpc'); etree.SubElement(ls, A + 'spcPct', val=str(lnspc))
        if after:
            sa = etree.SubElement(ppr, A + 'spcAft'); etree.SubElement(sa, A + 'spcPts', val=str(int(round(after * 100 * (S_A4 if self.a4 else 1)))))
        if bullet:
            etree.SubElement(ppr, A + 'buSzPct', val='100000'); etree.SubElement(ppr, A + 'buChar', char='•')
        else:
            etree.SubElement(ppr, A + 'buNone')
        for t, b, *c in runs:
            col = c[0] if c else color
            p.append(self.run(t, px, b, col))
        return p

    def set_paras(self, shape, paras):
        tx = shape._element.txBody
        for p in tx.findall(A + 'p'): tx.remove(p)
        for p in paras: tx.append(p)

    def new_slide(self, layout_name):
        lay = [l for l in self.prs.slide_layouts if l.name == layout_name][0]
        s = self.prs.slides.add_slide(lay)
        return s

    def ph(self, slide, idx):
        for sh in slide.placeholders:
            if sh.placeholder_format.idx == idx: return sh
        return None

    def add_num(self, slide):
        el = copy.deepcopy(self.num_tpl)
        spPr = el.find('{%s}spPr' % NS['p'])
        for c in list(spPr): spPr.remove(c)           # eredita la posizione dal layout
        slide.shapes._spTree.append(el)

    def head(self, slide, row, title):
        rs = self.ph(slide, 106); ts = self.ph(slide, 107)
        self.set_paras(rs, [self.para([(row, True, 'accent2')], 24, lnspc=100000, after=0)])
        pp = self.para([(title, True, 'tx2')], 56, lnspc=115000, after=0)
        self.set_paras(ts, [pp])

    # --- pagine
    def cover(self, info):
        s = self.new_slide('Copertina')
        t = self.ph(s, 105); m = self.ph(s, 109); a = self.ph(s, 112)
        self.set_paras(t, [self.para([(info['materia'].upper(), True, 'tx2')], 64, lnspc=115000, after=0)])
        self.set_paras(m, [self.para([(info['docente_full'], False, 'accent2')], FS, lnspc=100000, after=0)])
        ps = []
        apx = FS if len(info['argomenti']) <= 5 else 28
        for x in info['argomenti']:
            p = self.para([(x, False)], apx, num=True, after=6)
            ppr = p.find(A + 'pPr')
            for c in list(ppr):
                if c.tag in (A + 'buNone',): ppr.remove(c)
            etree.SubElement(ppr, A + 'buSzPct', val='100000'); etree.SubElement(ppr, A + 'buFont', typeface='+mj-lt')
            etree.SubElement(ppr, A + 'buAutoNum', type='arabicPeriod')
            ps.append(p)
        self.set_paras(a, ps)
        return s

    def text_slide(self, row, title, blocks):
        s = self.new_slide('Testo')
        self.head(s, row, title)
        body = self.ph(s, 109)
        self.set_paras(body, self.blocks_xml(blocks))
        self.add_num(s)
        return s

    def blocks_xml(self, blocks):
        out = []
        for kind, runs in blocks:
            if kind == 'sub':
                out.append(self.para([(t, True, 'accent2') for t, b in runs], FS)); continue
            rr = [(t, b) for t, b in runs]
            out.append(self.para(rr, FS, bullet=(kind == 'bullet')))
        return out

    def textbox(self, slide, x, y, w, h, paras, name='Testo'):
        tb = slide.shapes.add_textbox(self.E(x), self.E(y), self.E(w), self.E(h))
        tb.name = name
        tx = tb._element.txBody
        bp = tx.find(A + 'bodyPr')
        for k, v in (('wrap', 'square'), ('lIns', '0'), ('tIns', '0'), ('rIns', '0'), ('bIns', '0')): bp.set(k, v)
        for c in list(bp): bp.remove(c)
        self.set_paras(tb, paras)
        return tb

    def table_slide(self, pg):
        s = self.new_slide('Solo titolo')
        self.head(s, pg['row'], pg['title'])
        y = TOP
        if pg['pre']:
            h = capacity_text(pg['pre'], self.cw, 9999)
            self.textbox(s, 80, y, self.cw, h, self.blocks_xml(pg['pre']), 'Testo attivita')
            y += h + 20
        W = pg['W'] if not self.a4 else (round(self.cw * 0.60) if pg['side'] else self.cw)
        widths = pg['widths'] if not self.a4 else col_widths([pg['header']] + pg['rows'], W)
        # nel video i tagli sono quelli calcolati; in A4 le colonne si adattano alla pagina piu' larga
        self.add_table(s, 80, y, widths, pg['header'], pg['rows'], pg['widths'] if self.a4 else widths)
        th = table_height([pg['header']] + pg['rows'], widths)
        if pg['side'] and pg['note']:
            nx = 80 + W + 43
            self.textbox(s, nx, TOP, self.cw - W - 43, 400, self.note_xml(pg['note']), 'Commento tabella')
        elif pg['note']:
            self.textbox(s, 80, y + th + 28, self.cw, 200, self.note_xml(pg['note']), 'Commento tabella')
        if pg['post']:
            self.textbox(s, 80, y + th + 28, self.cw, 300, self.blocks_xml(pg['post']), 'Testo attivita')
        self.add_num(s)
        return s

    def note_xml(self, blocks):
        out = []
        for kind, runs in blocks:
            rr = []
            for t, b in runs:
                if not rr and ':' in t and not b and len(t.split(':')[0]) < 40:
                    lead, rest = t.split(':', 1)
                    rr.append((lead + ':', True, 'accent2')); rr.append((rest, False))
                else:
                    rr.append((t, b))
            out.append(self.para(rr, FS, bullet=(kind == 'bullet')))
        return out

    def add_table(self, slide, x, y, widths, hdr, rows, est_widths):
        allrows = [hdr] + rows
        nc = len(widths)
        gf = slide.shapes.add_table(len(allrows), nc, self.E(x), self.E(y), self.E(sum(widths)), self.E(60 * len(allrows)))
        gf.name = 'Tabella'
        tbl = gf._element.graphic.graphicData.tbl
        tblPr = tbl.find(A + 'tblPr')
        for k in list(tblPr.attrib): del tblPr.attrib[k]
        for c in list(tblPr): tblPr.remove(c)
        grid = tbl.find(A + 'tblGrid')
        for gc, w in zip(grid.findall(A + 'gridCol'), widths): gc.set('w', str(self.E(w)))
        trs = tbl.findall(A + 'tr')
        for ri, tr in enumerate(trs):
            tr.set('h', str(self.E(row_height(allrows[ri], est_widths if len(est_widths) == nc else widths, ri == 0))))
            for ci, tc in enumerate(tr.findall(A + 'tc')):
                t = allrows[ri][ci] if ci < len(allrows[ri]) else ''
                if only_underscores(t): t = ''
                self.fill_cell(tc, t, ri == 0, ci == 0)
        return gf

    def fill_cell(self, tc, text, hdr, first):
        for c in list(tc): tc.remove(c)
        tx = etree.SubElement(tc, A + 'txBody')
        etree.SubElement(tx, A + 'bodyPr'); etree.SubElement(tx, A + 'lstStyle')
        p = etree.SubElement(tx, A + 'p')
        ppr = etree.SubElement(p, A + 'pPr', marL='0', indent='0'); etree.SubElement(ppr, A + 'buNone')
        color = '0A1D37' if hdr else ('003366' if first else '1A1A1A')
        if text:
            r = self.run(text, FT, hdr, color)
            rpr = r.find(A + 'rPr')
            for tg, cs in (('latin', '0'), ('ea', '-122'), ('cs', '-120')):
                etree.SubElement(rpr, A + tg, typeface='Arial', charset=cs)
            p.append(r)
        end = etree.SubElement(p, A + 'endParaRPr', lang='es-ES', sz=str(self.PT(FT)))
        tcpr = etree.SubElement(tc, A + 'tcPr', marL=str(self.E(20)), marR=str(self.E(20)), marT='0', marB='0', anchor='ctr')
        for side in ('lnL', 'lnR', 'lnT', 'lnB'):
            ln = etree.SubElement(tcpr, A + side, w='9525', cap='flat', cmpd='sng', algn='ctr')
            sf = etree.SubElement(ln, A + 'solidFill'); etree.SubElement(sf, A + 'srgbClr', val='CBD5E1')
            etree.SubElement(ln, A + 'prstDash', val='solid')
        if hdr:
            sf = etree.SubElement(tcpr, A + 'solidFill'); etree.SubElement(sf, A + 'srgbClr', val='F8F9FA')

    def closing(self):
        s = self.new_slide('Immagine')
        self.head(s, 'Fine della lezione', "Grazie per l'attenzione")
        b = self.ph(s, 109)
        if b is not None: b._element.getparent().remove(b._element)
        self.add_num(s)

    def save(self, path, title):
        self.prs.core_properties.title = title
        self.prs.core_properties.language = 'it-IT'
        self.prs.save(path)

# ---------------------------------------------------------------- lezione intera
def build_lesson(docx_path, out_base, materia='Spagnolo', docente='Prof.ssa Romina Gisel Luna'):
    items = applica_correzioni(parse_docx(docx_path))
    info, sections = plan(items, materia)
    pages = build_pages(sections)
    docente_full = '%s – %s' % (materia, docente)
    info['docente_full'] = docente_full
    res = {}
    for mode in ('video', 'a4'):
        label = 'DISPENSA DIDATTICA' if mode == 'a4' else 'VIDEOLEZIONE'
        d = Deck(mode, docente_full, label)
        d.cover(info)
        if info['intro']:
            rows = info['intro']
            title = rows[0][0]
            bl = [('bullet', [(r[0], False)]) for r in rows[1:]]
            d.text_slide(info['theme'] or materia.upper(), title, bl)
        for pg in pages:
            if pg['type'] == 'text': d.text_slide(pg['row'], pg['title'], pg['blocks'])
            else: d.table_slide(pg)
        if mode == 'video': d.closing()
        name = out_base + ('_videodispensa_16-9.pptx' if mode == 'video' else '_dispensa_A4.pptx')
        d.save(name, '%s – %s' % (materia, 'Videodispensa' if mode == 'video' else 'Dispensa'))
        res[mode] = name
    res['correzioni'] = list(CORREZIONI); CORREZIONI.clear()
    return res, info, pages

if __name__ == '__main__':
    r, info, pages = build_lesson(sys.argv[1], sys.argv[2])
    print(r); print(info['theme'], info['argomenti']); print(len(pages), 'pagine di contenuto')
