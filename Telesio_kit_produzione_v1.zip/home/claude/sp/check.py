import sys, glob, os, re, collections, subprocess
import numpy as np
from PIL import Image
import docx
from pptx import Presentation
n=sys.argv[1]
os.makedirs('chk',exist_ok=True)
for f in glob.glob('chk/*'): os.remove(f)
subprocess.run(['pdftoppm','-r','144','-png',f'pdf/Spagnolo_Lez{n}_videodispensa_16-9.pdf','chk/v'])
subprocess.run(['pdftoppm','-scale-to-x','1920','-scale-to-y','-1','-png',f'pdf/Spagnolo_Lez{n}_dispensa_A4.pdf','chk/a'])
bad=[]
for f in sorted(glob.glob('chk/v-*.png'))[1:]:
    im=np.array(Image.open(f).convert('L'))
    z=im[420:975,1490:1900]
    if (z<200).sum()>30: bad.append((os.path.basename(f),'webcam-zone'))
    if (im[958:978,80:1840]<200).sum()>0: bad.append((os.path.basename(f),'sotto-limite'))
for f in sorted(glob.glob('chk/a-*.png'))[1:]:
    im=np.array(Image.open(f).convert('L'))
    if (im[1236:1255,80:1840]<200).sum()>0: bad.append((os.path.basename(f),'A4 sotto-limite'))
print('overflow:',bad)
d=docx.Document(f'/home/claude/sp/Spagnolo_Lez{n}.docx'); txt=[p.text for p in d.paragraphs]
for t in d.tables:
    for r in t.rows:
        seen=[]
        for c in r.cells:
            if id(c._tc) in seen: continue
            seen.append(id(c._tc)); txt.append(c.text)
def words(s): return collections.Counter(re.findall(r"[\wÀ-ÿ'’\-→]+",re.sub(r'_+',' ',s).lower()))
S=words(' '.join(txt)); out=[]
p=Presentation(f'Spagnolo_Lez{n}_dispensa_A4.pptx')
for sl in p.slides:
    for sh in sl.shapes:
        if sh.has_text_frame: out.append(sh.text_frame.text)
        if sh.has_table:
            for r in sh.table.rows:
                for c in r.cells: out.append(c.text)
O=words(' '.join(out)); print('mancanti:',dict(S-O))
