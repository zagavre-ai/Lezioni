import numpy as np,wave
SR=48000
def note(f,d,amp=.5,dec=5.0,harm=((1,1),(2,.35),(3,.15),(4,.06)),att=.004):
    t=np.arange(int(SR*d))/SR;y=sum(a*np.sin(2*np.pi*f*h*t) for h,a in harm)
    env=np.minimum(t/att,1)*np.exp(-dec*t);return y*env*amp
def bell(f,d,amp=.4):
    t=np.arange(int(SR*d))/SR
    y=np.sin(2*np.pi*f*t)+.5*np.sin(2*np.pi*f*2.76*t)*np.exp(-6*t)+.3*np.sin(2*np.pi*f*5.4*t)*np.exp(-9*t)
    return y*np.minimum(t/.003,1)*np.exp(-3.2*t)*amp
def place(buf,y,t0):
    i=int(t0*SR);buf[i:i+len(y)]+=y[:len(buf)-i]
def swoosh(d,f0,f1,amp=.25,seed=1):
    rng=np.random.default_rng(seed);n=int(SR*d);x=rng.standard_normal(n)
    from numpy.fft import rfft,irfft
    X=rfft(x);fr=np.fft.rfftfreq(n,1/SR);t=np.linspace(0,1,len(fr))
    # banda che sale/scende nel tempo: approssimo con due filtri e crossfade
    out=np.zeros(n);seg=8
    for s in range(seg):
        a,b=s*n//seg,(s+1)*n//seg;fc=f0+(f1-f0)*(s/(seg-1))
        Y=rfft(x);m=np.exp(-((fr-fc)/(fc*.5))**2);y=irfft(Y*m,n)
        w=np.zeros(n);w[a:b]=1;w=np.convolve(w,np.hanning(int(SR*.04)),'same')/np.hanning(int(SR*.04)).sum()
        out+=y*w
    env=np.sin(np.linspace(0,np.pi,n))**1.5
    out=out/np.max(np.abs(out))*env*amp;return out
def pad(freqs,d,amp=.12):
    t=np.arange(int(SR*d))/SR;y=sum(np.sin(2*np.pi*f*t)+.4*np.sin(2*np.pi*f*2*t) for f in freqs)
    return y*np.minimum(t/.25,1)*np.minimum((d-t)/.6,1)*amp/len(freqs)
def save(name,y,rev=True):
    y=np.concatenate([y,np.zeros(SR)]);
    y=y/max(1,np.max(np.abs(y))/.8)
    pcm=(np.clip(y,-1,1)*32767).astype('<i2');w=wave.open(f'snd/{name}_raw.wav','wb');w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.write_frames if False else w.writeframes(pcm.tobytes());w.close()
    import subprocess
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',f'snd/{name}_raw.wav','-af','aecho=0.8:0.6:60|120:0.35|0.2,lowpass=f=9000,aformat=channel_layouts=stereo','-ar','48000',f'snd/{name}.wav'],check=True)
C5,D5,E5,G5,A5,C6,E6,G6=523.25,587.33,659.25,783.99,880,1046.5,1318.5,1568
# J_quiz: arpeggio ascendente allegro + scintillio
b=np.zeros(int(SR*2.2))
for i,f in enumerate([C5,E5,G5,C6]):place(b,bell(f,1.2,.38),.0+.11*i)
place(b,bell(E6,1.2,.3),.5);place(b,bell(G6,1.4,.22),.62);place(b,swoosh(.5,800,5000,.12),0);save('quiz',b)
# J_repaso: due colpi di campanello + swoosh
b=np.zeros(int(SR*2.2));place(b,swoosh(.55,300,3500,.22,2),0);place(b,bell(G5,1.3,.4),.4);place(b,bell(C6,1.5,.4),.62);place(b,pad([C5,G5,E5],1.6,.18),.4);save('repaso',b)
# J_titolo: swoosh + colpo basso + chime breve
b=np.zeros(int(SR*1.6));place(b,swoosh(.6,400,4200,.25,3),0);place(b,note(110,.9,.5,4,((1,1),(2,.4))),.45);place(b,bell(E5,1.0,.25),.5);save('titolo',b)
# J_finale: motivo di 5 note + accordo
b=np.zeros(int(SR*4.2))
for i,f in enumerate([C5,E5,G5,A5,C6]):place(b,bell(f,1.4,.36),.15*i+.1)
place(b,pad([C5,E5,G5,C6],3.2,.28),.7);place(b,bell(G6,2.2,.28),.9);place(b,bell(C6*2,2.4,.2),1.0);place(b,swoosh(.9,300,6000,.2,5),0);save('finale',b)
# J_trans: swoosh breve (transizione)
b=np.zeros(int(SR*.9));place(b,swoosh(.6,500,3800,.28,7),0);save('trans',b)
print('ok')
