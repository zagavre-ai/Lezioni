import asm2
asm2.clip('S0','/home/claude/lez1/sigla_iniziale.mkv'.replace('.mkv','.mp4'));asm2.clip('S9','/home/claude/lez1/sigla_finale.mp4')
BL,seq=asm2.build()
for k,v in BL.items():asm2.block(k,*v)
print('blocks ok')
