import sys,json,os
sys.path.insert(0,'/home/claude/v5');sys.path.insert(0,'/home/claude/v5/vo')
from vo.compose9 import compose_file
import po9
P=json.load(open('vo/p5_phr.json'))
names=sys.argv[1:] or ['PO02','PO03','PO04','PO05','PO06','PO07']
meta=json.load(open('po9/meta.json')) if os.path.exists('po9/meta.json') else {}
for k in names:
    m=compose_file('vo/p5.wav',P[k],k,f'voci/{k}.wav',dur=44.0)
    meta[k]=m
    po9.render_po(k,k,m['times'],44.0,'po9',scale=0.5,cards=(k=='PO05'))
json.dump(meta,open('po9/meta.json','w'))
