import sys;sys.path.insert(0,'/home/claude/v5')
import asr,seg
a,b=float(sys.argv[1]),float(sys.argv[2])
for s,e in seg.segs(a,b):
    x=asr.load(seg.AUD,max(0,s-0.25),e+0.25)
    print(s,e,'|',asr.transcribe(x,50262),flush=True)
