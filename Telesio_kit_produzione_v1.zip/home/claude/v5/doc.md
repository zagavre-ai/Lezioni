# Rifacimento v5 – Spagnolo Lez. 1 (31-10-2026)

Modifiche richieste da Sara dopo la visione dell'anteprima, ora applicate.

**Slide (Matrice v4, restano chiare)**
- Tolta la scritta in alto a destra; il nome della prof è in basso a sinistra accanto a «SPAGNOLO»; la banda gialla resta.
- Riquadro della docente più grande (21,5 cqw) con angoli arrotondati, integrato nella slide.
- Scheda 2 «En esta unidad aprenderás a…»: nel video si compone con gli argomenti mentre la prof li nomina (39–60 s) e li evidenzia nel secondo passaggio in spagnolo (109–152 s). Nella dispensa A4 c'è la tabella già finita.

**Interludi scuri (Premium Edutainment)**
- Sfondo blu notte, luci in movimento, grana, vignettatura, numero gigante, titoli che salgono con maschera, vetro, barra di avanzamento.
- Scheda titolo per ognuno dei 7 argomenti, con transizione in entrata e in uscita (cerchio) e jingle.
- Scheda quiz con jingle a ogni gruppo di attività.
- Scheda REPASO con equalizzatore e didascalie, jingle, slot per la voce (copioni in Copioni_voce_Lez1).
- Riepilogo finale bilingue spagnolo/italiano con jingle, dopo la sintesi della docente e prima dell'animazione Fondamenti.

**Struttura**
Sigla → intro → [titolo → docente → (repaso → schema/animazione) → quiz] ×7 → sintesi docente → riepilogo bilingue → Fondamenti → sigla finale.
Genere e Plurali è ora il riepilogo dopo il plurale. Le tabelline sotto la prof (IS) sono state tolte. Gli attacchi cadono nei silenzi dell'audio della docente (silencedetect).

**Aperto**
- Voci dei repaso e del riepilogo finale (da registrare con lo strumento voce, file voci/<codice>.wav).
- Video originale 1080p della docente per il montaggio finale.
- PO02 (formazione del plurale) non è nella sequenza: Genere e Plurali lo copre. Da rimettere se serve.
- Approvazioni Direzione: Matrice v4, durata oltre 60 min, taglio delle Actividad.

## Aggiornamento v6 (31-10-2026, sera)
- Inizio argomento 1: prima la scheda titolo, poi la prof parte dal contenuto (tagliato «va bene, cominciamo con…»).
- Fine di ogni spiegazione: taglio nell'ultimo silenzio prima dell'annuncio dell'esercizio («entonces antes de hacer…», «muy bien, adiós», «bueno ahora vamos a ver…»), con 0,15 s di margine.
- Transizioni di ingresso e uscita di 1,0–1,3 s; le schede scure restano ferme e senza animazioni durante la transizione; i jingle partono a transizione finita.
- Repaso rinominati «Pillola di grammatica».
- Tutte le slide con tabella o testo si compongono riga per riga: la riga compare al più tardi a intervalli di 3,5 s e si evidenzia quando la prof ne parla (tempi dai sottotitoli).
- Voci: le animazioni con voce (Genere e Plurali, Fondamenti, SER/TENER) usano l'audio originale degli Appunti; per i repaso (R2–R7) e il riepilogo finale serve una registrazione nuova con lo stesso strumento. File voci/<codice>.wav, copioni in Copioni_voce_Lez1.
