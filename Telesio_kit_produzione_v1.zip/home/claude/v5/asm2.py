import re,subprocess,sys,os,json
FF='ffmpeg'
HD=os.environ.get('HD')=='1'
SRC='/home/claude/orig/all.mkv' if HD else '/mnt/user-data/uploads/anteprima_per_Claude.mp4'
AUD='/home/claude/orig/audio_clean.wav' if os.environ.get('HD')=='1' else '/mnt/user-data/attachments/6f0ad356-eb6e-5e82-bb5b-b32ac31c8256/0743a8c5-audio_per_Claude.m4a'
GAIN=open('/home/claude/lez1/work/gain.txt').read().strip()
H='/home/claude/v5';W=H+('/wHD' if HD else '/w');SL=H+('/png_hd/%s' if HD else '/png_p/%s')
SV=('sv_hd' if HD else 'sv');DK=('dk_hd' if HD else 'dk');PO=('po9_hd' if HD else 'po9');INTRO=('intro_1080.mp4' if HD else 'intro_540.mp4')
WH=(1920,1080) if HD else (960,540)
O='/home/claude/assets/out/';O2='/home/claude/assets/out2/'
DUR=3631.6
os.makedirs(W,exist_ok=True)
VF='fps=30,scale=%d:%d:flags=lanczos,setsar=1,format=yuv420p'%WH
ENC=['-c:v','libx264','-preset',('ultrafast' if HD else 'veryfast'),'-crf',('17' if HD else '21'),'-pix_fmt','yuv420p','-r','30','-g','60','-threads','2']
AP=['-c:a','pcm_s16le','-ar','48000','-ac','2']
def run(cmd):subprocess.run(cmd,check=True)
def sec(t):
    p=t.split(':');return float(p[0])*3600+float(p[1])*60+float(p[2])
rows=[]
for l in open('/home/claude/lez1/tempi.txt'):
    l=l.split('#')[0].strip()
    if not l or l.startswith('WEBCAM'):continue
    a=l.split();rows.append((sec(a[0]),a[2]))
SIL=[(float(a),float(b),float(c)) for a,b,c in re.findall(r'silence_start: ([\d.]+)\n.*?silence_end: ([\d.]+) \| silence_duration: ([\d.]+)',open('/home/claude/asm/sil.txt').read(),re.S)]
def cutp(x):
    c=sorted((abs((a+b)/2-x),(a+b)/2) for a,b,d in SIL if abs((a+b)/2-x)<8 and d>=0.4)
    return round(c[0][1],2) if c else x
F9=[163.2,953.9,1552.8,2296.7,2841.6,3196.2,3418.1]
ACT=[600,1219.6,1962.1,2626.1,3031,3312.1,3497]
def cut_before(target,lo=9,minlen=0.45):
    c=[(a,b) for a,b,d in SIL if d>=minlen and b<=target+0.35 and a>=target-lo]
    if not c:return round(target-1,2)
    a,b=max(c);return round(min(a+0.15,b-0.1),2)
def cut_after(target,hi=6,minlen=0.3):
    c=[(a,b) for a,b,d in SIL if d>=minlen and a>=target and a<=target+hi]
    if not c:return target
    a,b=min(c);return round(b-0.1,2)
CP={x:cutp(x) for x in F9+ACT+[3569.1]}
CP['I_END']=156.7;CP['A_START']=cut_after(173.0)
for x,tg in zip(ACT,[595,1215,1957,2626,3031,3312,3497]):CP[x]=cut_before(tg)
INTRO_T0=20.0
SVM=json.load(open(H+'/'+SV+'/meta.json')) if os.path.exists(H+'/'+SV+'/meta.json') else {}
def img_at(t):
    if t<INTRO_T0:return rows[0][1]
    if t<163.2:return 'INTRO'
    im=[im for tt,im in rows if tt<=t][-1];n=int(im[:2])
    return ('SV%d'%n) if str(n) in SVM else im
def dur(f):
    return float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f],capture_output=True,text=True).stdout)
def pieces(a,b,f9=None):
    cuts=[a,b]+[t for t,_ in rows if a<t<b]+[x for x in (INTRO_T0,163.2) if a<x<b]
    cuts=sorted(set(round(c,3) for c in cuts));out=[]
    for s0,e0 in zip(cuts,cuts[1:]):
        if e0-s0<0.034:continue
        mid=(s0+e0)/2;lk=max(mid,f9) if f9 else mid
        out.append((s0,e0,img_at(lk)))
    return out
def block(name,a,b,f9=None):
    out=f'{W}/{name}.mkv'
    if os.path.exists(out):return out
    parts=[]
    for i,(s0,e0,img) in enumerate(pieces(a,b,f9)):
        n=int(round((e0-a)*30))-int(round((s0-a)*30))
        if n<1:continue
        o=f'{W}/{name}_{i:03d}.mkv'
        if HD:
            cam="[1:v]fps=30:start_time=0,crop=1028:772:506:194,scale=412:310:flags=lanczos,hqdn3d=2:1.5:4:3,colorchannelmixer=bb=1.04,eq=contrast=1.05:saturation=1.06,unsharp=5:5:0.4,format=yuva420p[c0];[c0][2:v]alphamerge[c]"
        else:
            cam="[1:v]fps=30:start_time=0,crop=514:386:253:97,scale=206:155:flags=lanczos,hqdn3d=1.5:1.5:3:3,format=yuva420p[c0];[c0][2:v]alphamerge[c]"
        cmd=[FF,'-y','-loglevel','error','-nostdin']
        if img=='INTRO':cmd+=['-ss','%.3f'%(s0-INTRO_T0),'-i',H+'/'+INTRO]
        elif img.startswith('SV'):
            nn=img[2:];cmd+=['-ss','%.3f'%max(0,s0-SVM[nn][0]),'-i',H+'/'+SV+'/sv%02d.mp4'%int(nn)]
        else:cmd+=['-loop','1','-framerate','30','-i',SL%img]
        cmd+=['-ss','%.3f'%s0,'-i',SRC,'-loop','1','-framerate','30','-i',H+('/mask_cam_hd.png' if HD else '/mask_cam.png')]
        fc=f"[0:v]scale={WH[0]}:{WH[1]},setsar=1[bg];{cam};[bg][c]overlay={714*(2 if HD else 1)}:{74*(2 if HD else 1)},format=yuv420p[v]"
        run(cmd+['-filter_complex',fc,'-map','[v]','-frames:v',str(n),'-an']+ENC+[o]);parts.append(o)
    open(f'{W}/{name}_v.txt','w').write(''.join("file '%s'\n"%p for p in parts))
    run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',f'{W}/{name}_v.txt','-c','copy',f'{W}/{name}_v.mkv'])
    af=f"highpass=f=80,volume={GAIN}dB,alimiter=limit=0.89,aresample=48000,aformat=channel_layouts=stereo"
    run([FF,'-y','-loglevel','error','-nostdin','-ss','%.3f'%a,'-t','%.3f'%(b-a),'-i',AUD,'-af',af]+AP+[f'{W}/{name}_a.wav'])
    run([FF,'-y','-loglevel','error','-i',f'{W}/{name}_v.mkv','-i',f'{W}/{name}_a.wav','-c:v','copy','-c:a','copy','-t','%.3f'%(b-a),out]);print(name,flush=True)
    return out
SND=H+'/snd/%s.wav'
def mixaud(name,jingle,joff,dur_s,voff=None):
    """audio del clip scuro/animazione: jingle (+ voce se presente in voci/<name>.wav)"""
    ins=['-f','lavfi','-t','%.3f'%dur_s,'-i','anullsrc=r=48000:cl=stereo']
    fl='[1:a]anull[b0]';k=2;lab=['b0']
    if jingle:
        ins+=['-i',SND%jingle];fl+=f';[{k}:a]adelay={int(joff*1000)}|{int(joff*1000)},volume={0.5 if os.path.exists(f'{H}/voci/{name}.wav') else 0.9}[b{k}]';lab.append(f'b{k}');k+=1
    vf=f'{H}/voci/{name}.wav'
    if os.path.exists(vf):
        ins+=['-i',vf];fl+=f';[{k}:a]adelay={int((voff if voff is not None else LT+0.9)*1000)}|{int((voff if voff is not None else LT+0.9)*1000)},aformat=channel_layouts=stereo[b{k}]';lab.append(f'b{k}');k+=1
    fl+=';'+''.join(f'[{l}]' for l in lab)+f'amix=inputs={len(lab)}:normalize=0:duration=first,aformat=channel_layouts=stereo[a]'
    return ins,fl
LT=1.3
def dark_clip(name,vid,jingle,joff):
    out=f'{W}/{name}.mkv'
    if os.path.exists(out):return out
    d=dur(vid)+2*LT;ins,fl=mixaud(name,jingle,joff+LT,d)
    run([FF,'-y','-loglevel','error','-nostdin','-i',vid]+ins+['-filter_complex',f'[0:v]tpad=start_mode=clone:start_duration={LT}:stop_mode=clone:stop_duration={LT},fps=30[v];'+fl,'-map','[v]','-map','[a]','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-r','30','-g','60']+AP+['-t','%.3f'%d,out]);return out
def clip(name,src,fade=False,jingle=None,joff=0):
    out=f'{W}/{name}.mkv'
    if os.path.exists(out):return out
    d0=dur(src);d=d0+2*LT
    has='audio' in subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type','-of','csv=p=0',src],capture_output=True,text=True).stdout
    vf=VF+(f',fade=t=in:st=0:d=0.4:color=white,fade=t=out:st={d0-0.4}:d=0.4:color=white' if fade else '')+f',tpad=start_mode=clone:start_duration={LT}:stop_mode=clone:stop_duration={LT}'
    if has:
        ms=int(LT*1000)
        run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-vf',vf,'-af',f'aresample=48000,aformat=channel_layouts=stereo,adelay={ms}|{ms},apad=pad_dur={LT}']+ENC+AP+['-t','%.3f'%d,out])
    else:
        ins,fl=mixaud(name,jingle,joff+LT,d,voff=LT)
        run([FF,'-y','-loglevel','error','-nostdin','-i',src]+ins+['-filter_complex',f'[0:v]{vf}[v];'+fl,'-map','[v]','-map','[a]']+ENC+AP+['-t','%.3f'%d,out])
    return out
def still_clip(name,png,d):
    out=f'{W}/{name}.mkv'
    if os.path.exists(out):return out
    run([FF,'-y','-loglevel','error','-nostdin','-loop','1','-framerate','30','-t',str(d),'-i',png,'-f','lavfi','-t',str(d),'-i','anullsrc=r=48000:cl=stereo','-vf',VF,'-map','0:v','-map','1:a']+ENC+AP+[out]);return out
def piece(src,a,b,out):
    if os.path.exists(out):return out
    n=int(round((b-a)*30))
    run([FF,'-y','-loglevel','error','-nostdin','-ss','%.4f'%a,'-i',src,'-t','%.4f'%(b-a),'-vf','fps=30','-frames:v',str(n)]+ENC+AP+[out]);return out
def xf(ta,tb,d,kind,out):
    if os.path.exists(out):return out
    run([FF,'-y','-loglevel','error','-nostdin','-i',ta,'-i',tb,'-filter_complex',f'[0:v][1:v]xfade=transition={kind}:duration={d}:offset={dur(ta)-d:.4f}[v];[0:a][1:a]acrossfade=d={d}:c1=tri:c2=tri[a]','-map','[v]','-map','[a]']+ENC+AP+[out]);return out

XK={'toT':('circleopen',1.3),'fromT':('circleclose',1.3),'toR':('wipeleft',1.2),'toQ':('zoomin',1.2),'fromQ':('circleclose',1.3),'def':('fade',1.0),'toFIN':('wipeleft',1.2)}
def build(only=None):
    BL={'BI':(0,CP['I_END'],None),'BA':(CP['A_START'],CP[600],163.2),'B1':(CP[953.9],CP[1219.6],953.9),'B2':(CP[1552.8],CP[1962.1],1552.8),'B3':(CP[2296.7],CP[2626.1],2296.7),'B4':(CP[2841.6],CP[3031],2841.6),'B5':(CP[3196.2],CP[3312.1],3196.2),'B6':(CP[3418.1],CP[3497],3418.1),'B7':(CP[3569.1],DUR,None)}
    seq=[]  # (nome, tipo)
    def add(n,t):seq.append((n,t))
    add('BI','L');add('T1','T');add('BA','L');add('R1','R');add('AN07','A');add('Q1','Q')
    add('T2','T');add('B1','L');add('R2','R');add('PO02','A');add('Q2','Q')
    add('T3','T');add('B2','L');add('R3','R');add('PO03','A');add('Q3','Q')
    add('T4','T');add('B3','L');add('R4','R');add('PO04','A');add('Q4','Q')
    add('T5','T');add('B4','L');add('R5','R');add('AN05','A');add('PO05','A');add('Q5','Q')
    add('T6','T');add('B5','L');add('R6','R');add('AN06','A');add('PO06','A');add('Q6','Q')
    add('T7','T');add('B6','L');add('R7','R');add('PO07','A');add('Q7','Q')
    add('B7','L');add('FIN','F');add('FOND','A')
    return BL,seq
def make_seg(n,BL):
    if n in BL:return block(n,*BL[n])
    if n.startswith('T'):return dark_clip(n,f'{H}/'+DK+f'/{n}.mp4','titolo',.45)
    if n.startswith('Q'):return dark_clip(n,f'{H}/'+DK+f'/{n}.mp4','quiz',.5)
    if n.startswith('R'):return dark_clip(n,f'{H}/'+DK+f'/{n}.mp4','repaso',.4)
    if n=='FIN':return dark_clip(n,f'{H}/'+DK+'/FIN.mp4','finale',.4)
    F={'AN07':O2+'AN07_Femenino_v1.mp4','AN05':O2+'AN05_SER-TENER_v3.mp4','AN06':O2+'AN06_Presente-regular_v4.mp4','FOND':O2+'Fondamenti_v4.mp4','PO03':H+'/'+PO+'/PO03.mp4','PO04':H+'/'+PO+'/PO04.mp4','PO05':H+'/'+PO+'/PO05.mp4','PO06':H+'/'+PO+'/PO06.mp4','PO07':H+'/'+PO+'/PO07.mp4','PO02':H+'/'+PO+'/PO02.mp4'}
    return clip(n,F[n])
def joint_kind(a,b):
    ta,tb=a[1],b[1]
    if tb=='T' and ta in('L',):return XK['toT']
    if ta=='T':return XK['fromT']
    if tb=='R':return XK['toR']
    if tb=='Q' and ta in('L','A'):return XK['toQ']
    if ta=='Q':return XK['fromQ']
    if tb=='F':return XK['toFIN']
    return XK['def']

def pad_head(src,name,d=LT):
    out=f'{W}/{name}_ph.mkv'
    if os.path.exists(out):return out
    ms=int(d*1000);D=dur(src)+d
    run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-vf',f'tpad=start_mode=clone:start_duration={d}','-af',f'adelay={ms}|{ms}']+ENC+AP+['-t','%.3f'%D,out]);return out
def pad_tail(src,name,d=1.8):
    out=f'{W}/{name}_pt.mkv'
    if os.path.exists(out):return out
    D=dur(src)+d
    run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-vf',f'tpad=stop_mode=clone:stop_duration={d}','-af',f'apad=pad_dur={d}']+ENC+AP+['-t','%.3f'%D,out]);return out
def pad_sigla_cp(src,out_name,png):
    out=f'{W}/{out_name}.mkv'
    if os.path.exists(out):return out
    run([FF,'-y','-loglevel','error','-i',src,'-loop','1','-framerate','30','-i',png,'-filter_complex','[1:v]format=rgba,fade=t=in:st=0.3:d=0.4:alpha=1,fade=t=out:st=4.3:d=0.4:alpha=1[p];[0:v][p]overlay=0:0:shortest=1:format=auto,format=yuv420p[v]','-map','[v]','-map','0:a','-c:a','copy']+ENC+['-t','%.3f'%dur(src),out]);return out
def assemble(out_mp4):
    BL,seq=build();segs=[make_seg(n,BL) for n,_ in seq]
    for i,(n,t) in enumerate(seq):
        if t=='L' and i>0 and seq[i-1][1]=='T':segs[i]=pad_head(segs[i],n)
        if n=='B7':segs[i]=pad_tail(segs[i],n)
    J=[joint_kind(seq[i],seq[i+1]) for i in range(len(seq)-1)]
    # S0 -> BI con xfade 1.8
    final=[]
    for i,(n,t) in enumerate(seq):
        d_in=J[i-1][1] if i>0 else 0;d_out=J[i][1] if i<len(J) else 0
        D=dur(segs[i])
        if i==0:d_in=0
        m=piece(segs[i],d_in,D-d_out,f'{W}/{n}_mid.mkv')
        final.append(m)
        if i<len(J):
            nn=seq[i+1][0];Dn=dur(segs[i+1])
            ta=piece(segs[i],D-J[i][1],D,f'{W}/{n}_tail.mkv');hb=piece(segs[i+1],0,J[i][1],f'{W}/{nn}_head.mkv')
            final.append(xf(ta,hb,J[i][1],J[i][0],f'{W}/J_{n}_{nn}.mkv'))
    return final
if __name__=='__main__':
    step=sys.argv[1]
    if step=='sigla':
        for k,f in {'S0':'/home/claude/lez1/sigla_iniziale.mp4','S9':'/home/claude/lez1/sigla_finale.mp4'}.items():clip(k,f);print(k)
    if step=='go':
        fin=assemble(None)
        # sigla iniziale -> BI (xfade 1.8) viene fatta sul primo mid
        S0=f'{W}/S0.mkv';BI0=fin[0]
        run([FF,'-y','-loglevel','error','-i',S0,'-i',BI0,'-filter_complex','[0:v][1:v]xfade=transition=fade:duration=1.8:offset=15.76[v];[0:a][1:a]acrossfade=d=1.8[a]','-map','[v]','-map','[a]']+ENC+AP+[f'{W}/S0BI_raw.mkv'])
        S9c=pad_sigla_cp(f'{W}/S9.mkv','S9c',H+('/cp/pill_1080.png' if HD else '/cp/pill_540.png'))   # avviso di copyright sulla sigla FINALE
        L=[f'{W}/S0BI_raw.mkv']+fin[1:]+[S9c]
        open(f'{W}/all.txt','w').write(''.join("file '%s'\n"%p for p in L))
        run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',f'{W}/all.txt',*(['-c:v','libx264','-preset','fast','-crf','19','-maxrate','12M','-bufsize','24M','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',H+'/Spagnolo_Lez1_VIDEO_1080p.mp4'] if HD else ['-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart',H+'/Spagnolo_Lez1_ANTEPRIMA_v10_540p.mp4'])]);print('final ok')
