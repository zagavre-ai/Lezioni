# Copioni voce narrante – Spagnolo Lez. 1 (¿De dónde eres?)

Ogni copione è già cronometrato sulla scheda scura corrispondente. Registrate la voce e salvate il file come `voci/<CODICE>.wav` (o .mp3): il montaggio la inserisce da solo a 0,9 s dall'inizio della scheda, sopra il jingle. Durata massima = durata della scheda.

| Codice | Dove | Durata scheda | Testo da leggere |
|---|---|---|---|
| R2 | Dopo il plurale, prima dell'animazione Genere e Plurali | 11.4 s | Facciamo un riepilogo di quello che hai appena visto: il femminile e il plurale. Guarda l'animazione e ripeti le regole ad alta voce. |
| R3 | Dopo Interrogativos, prima dello schema | 9.4 s | Ripassiamo insieme le parole interrogative: ¿qué?, ¿quién?, ¿dónde?, ¿cómo?. Osserva lo schema e prova a formare una domanda. |
| R4 | Dopo Pronombres sujeto, prima dello schema | 10.6 s | Repaso dei pronomi soggetto: yo, tú, él, ella, nosotros, vosotros, ellos. Guarda lo schema e di' ogni pronome ad alta voce. |
| R5 | Dopo SER y TENER, prima di animazione e schema | 9.8 s | Repaso dei verbi SER e TENER. Guarda l'animazione e poi lo schema riassuntivo: prova a coniugarli a voce alta. |
| R6 | Dopo Presente regolari, prima di animazione e schema | 9.8 s | Repaso del presente dei verbi regolari: i tre gruppi in -ar, -er, -ir. Guarda l'animazione e ripeti le desinenze. |
| R7 | Dopo Verbos reflexivos, prima dello schema | 9.8 s | Repaso dei verbi riflessivi: ricorda il pronome davanti al verbo, per esempio me llamo, te llamas. Guarda lo schema. |
| FIN | Riepilogo finale, dopo la sintesi della docente | 10.0 s | Resumen de la lección. Riepilogo della lezione: ricapitoliamo insieme i sette argomenti che hai studiato. ¡Y ahora, repasemos juntos! |

Note: il riepilogo finale (FIN) è bilingue: spagnolo e italiano nello stesso copione. Le animazioni AN05 e AN06 oggi sono mute con didascalie: per la voce servono i testi delle didascalie (nella dispensa delle animazioni).
