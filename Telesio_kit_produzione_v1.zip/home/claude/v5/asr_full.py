import sys,json;sys.path.insert(0,'/home/claude/v5')
import asr,numpy as np
f=sys.argv[1];out=sys.argv[2];win=float(sys.argv[3]) if len(sys.argv)>3 else 12.0;lo=float(sys.argv[4]) if len(sys.argv)>4 else 0;hi=float(sys.argv[5]) if len(sys.argv)>5 else 1e9
x=asr.load(f);T=len(x)/16000;res=[]
t=lo
with open(out,'w') as o:
    while t<min(T,hi):
        seg=x[int(t*16000):int((t+win)*16000)]
        txt=asr.transcribe(seg) if np.abs(seg).max()>0.01 else ''
        o.write(json.dumps({'t':t,'txt':txt},ensure_ascii=False)+'\n');o.flush();t+=win
