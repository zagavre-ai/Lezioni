import json,subprocess,numpy as np
P=json.load(open('vo/p5_phr.json'));M=json.load(open('po9/meta.json'))
MOD={('PO04',3):(142.21,143.81),('PO04',6):(157.52,159.59),('PO05',0):(176.95,183.14),('PO05',4):(199.99,202.34),
     ('PO06',2):(234.24,236.99),('PO06',5):(254.46,257.79),('PO06',6):(260.99,265.71),('PO07',6):(317.10,321.18)}
for k in ['PO04','PO05','PO06','PO07']:
    st=M[k]['starts'];L=P[k];ins=['-f','lavfi','-t','44','-i','anullsrc=r=48000:cl=mono'];fl='[0:a]anull[b]';lab=['b'];pl=[]
    for i,((a,b),t) in enumerate(zip(L,st)):
        ac,bc=MOD.get((k,i),(a,b))
        t2=t-(a-ac);s=max(0,ac-0.07);e=bc+0.15
        ins+=['-ss','%.3f'%s,'-t','%.3f'%(e-s),'-i','vo/_n5.wav']
        fl+=f';[{i+1}:a]afade=t=in:d=0.02,afade=t=out:st={e-s-0.08:.3f}:d=0.08,adelay={int(t2*1000)}|{int(t2*1000)}[p{i}]';lab.append(f'p{i}')
        pl.append((round(t2,2),round(t2+e-s,2)))
    for i in range(len(pl)-1):
        if pl[i][1]>pl[i+1][0]-0.03:print('OVERLAP',k,i,pl[i],pl[i+1])
    fl+=';'+''.join(f'[{l}]' for l in lab)+f'amix=inputs={len(lab)}:normalize=0:duration=first[a]'
    subprocess.run(['ffmpeg','-y','-loglevel','error']+ins+['-filter_complex',fl,'-map','[a]','-ar','48000','-ac','1','-t','44',f'voci/{k}.wav'],check=True)
    print(k,pl)
# AN06 patch
import numpy as np
def ld(p):return np.frombuffer(subprocess.run(['ffmpeg','-v','error','-i',p,'-ac','1','-ar','48000','-f','f32le','-'],capture_output=True).stdout,np.float32).copy()
c=ld('voci/_bak1/AN06.wav');p=ld('/tmp/p4n.wav');sr=48000
seg=p[int(7.30*sr):int(7.65*sr)].copy();n=int(0.04*sr);seg[-n:]*=np.linspace(1,0,n)
a=int(8.10*sr);c[a:a+len(seg)]=seg
subprocess.run(['ffmpeg','-y','-loglevel','error','-f','f32le','-ar','48000','-ac','1','-i','-','voci/AN06.wav'],input=c.tobytes(),check=True)
print('AN06 patched')
