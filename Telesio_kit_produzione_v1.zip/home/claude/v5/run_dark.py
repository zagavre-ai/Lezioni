import json,re,sys,os
sys.path.insert(0,'.')
import dark
SC=float(sys.argv[1]) if len(sys.argv)>1 else .5
OUT=sys.argv[2] if len(sys.argv)>2 else 'dk'
TT=[('01',['Formación','del femenino'],'el chico → la chica',128),('02',['Formación','del plural'],'libro → libros',128),('03',['Interrogativos'],'¿qué? ¿quién? ¿dónde?',150),('04',['Pronombres','sujeto'],'yo · tú · él / ella',128),('05',['Verbos','SER y TENER'],'yo soy · yo tengo',128),('06',['Presente de indicativo','verbos regulares'],'hablo · como · vivo',108),('07',['Verbos','reflexivos'],'me llamo · me levanto',128)]
Q=[('Femminile','Actividad 1A','6 punti · trasforma al femminile'),('Plurale','Actividad 2A e 2B','10 punti · forma el plural e detecta el error'),('Interrogativos','Actividad 3A e 3B','11 punti · completa las preguntas e relaciona'),('Pronombres','Actividad 4A','5 punti · elige el pronombre'),('SER y TENER','Actividad 5A e 5B','12 punti · SER o TENER e construye frases'),('Verbi regolari','Actividad 6A e 6B','15 punti · conjuga los verbos e completa el texto'),('Verbi riflessivi','Actividad 7A e 7B','10 punti · pronombre reflexivo e forma verbal')]
SCR={'R1':('Femminile','Facciamo un riepilogo di quello che hai appena visto: il femminile. Guarda l\'animazione e ripeti le regole ad alta voce.'),
'R2':('Plurale','Ripassiamo insieme la formazione del plurale. Guarda lo schema e ripeti le regole ad alta voce.'),
'R3':('Interrogativos','Ripassiamo insieme le parole interrogative: ¿qué?, ¿quién?, ¿dónde?, ¿cómo?. Osserva lo schema e prova a formare una domanda.'),
'R4':('Pronombres sujeto','Repaso dei pronomi soggetto: yo, tú, él, ella, nosotros, vosotros, ellos. Guarda lo schema e di\' ogni pronome ad alta voce.'),
'R5':('SER y TENER','Repaso dei verbi SER e TENER. Guarda l\'animazione e poi lo schema riassuntivo: prova a coniugarli a voce alta.'),
'R6':('Verbos regulares','Repaso del presente dei verbi regolari: i tre gruppi in -ar, -er, -ir. Guarda l\'animazione e ripeti le desinenze.'),
'R7':('Verbos reflexivos','Repaso dei verbi riflessivi: ricorda il pronome davanti al verbo, per esempio me llamo, te llamas. Guarda lo schema.')}
FIN='Resumen de la lección. Riepilogo della lezione: ricapitoliamo insieme i sette argomenti che hai studiato. ¡Y ahora, repasemos juntos!'
def caps(text,dur,a0=1.0,b0=.6):
    ss=[s.strip() for s in re.split(r'(?<=[.!?])\s+',text) if s.strip()];tot=sum(len(s) for s in ss);t=a0;out=[]
    span=dur-a0-b0
    for s in ss:
        d=span*len(s)/tot;out.append([round(t,2),round(t+d,2),s]);t+=d
    return out
SP={}
for i,(n,l,e,fs) in enumerate(TT):SP['T%d'%(i+1)]={'type':'title','num':n,'total':7,'lines':l,'ex':e,'fs':fs,'dur':3.6,'lineY':720 if len(l)==2 else 600}
for i,(t,a,p) in enumerate(Q):SP['Q%d'%(i+1)]={'type':'quiz','topic':t,'act':a,'pts':p,'dur':4.0}
for k,(t,s) in SCR.items():
    vf=f'/home/claude/v5/voci/{k}.wav'
    import subprocess as _sp
    vd=float(_sp.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',vf],capture_output=True,text=True).stdout) if os.path.exists(vf) else None
    STD=13.0
    vv=vd if vd else max(6.0,len(s.split())/2.6)
    d=STD
    SP[k]={'type':'repaso','kicker':'Pillola di grammatica','topic':t,'caps':caps(s,d,a0=0.9,b0=max(0.4,STD-0.9-vv)),'dur':d,'script':s}
vf='/home/claude/v5/voci/FIN.wav'
import subprocess as _sp
FD=round(float(_sp.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',vf],capture_output=True,text=True).stdout)+0.9+0.8,2) if os.path.exists(vf) else 10.0
SP['FIN']={'type':'final','dur':FD,'items':[['Formación del femenino','Il femminile'],['Formación del plural','Il plurale'],['Interrogativos','Le parole interrogative'],['Pronombres sujeto','I pronomi soggetto'],['Verbos SER y TENER','I verbi ser e tener'],['Presente: verbos regulares','Il presente dei verbi regolari'],['Verbos reflexivos','I verbi riflessivi']],'sub':'¡Repasemos juntos lo que hemos aprendido!<br><span style="color:#5BD6F0">Ripassiamo insieme ciò che abbiamo imparato.</span>','script':FIN}
json.dump(SP,open('scripts_dark.json','w'),ensure_ascii=False,indent=1)
os.makedirs(OUT,exist_ok=True)
for k in (sys.argv[3:] or SP):
    if os.path.exists(f'{OUT}/{k}.mp4'):continue
    dark.render(SP[k],f'{OUT}/{k}',SC);print(k,flush=True)
