import sys,os,json,shutil,subprocess
from playwright.sync_api import sync_playwright
SC=float(sys.argv[1]) if len(sys.argv)>1 else 0.5
OUT=sys.argv[2] if len(sys.argv)>2 else 'intro_540'
T0,T1=20.0,163.2
G=[30,32.5,34]
R=[39.0,40.6,43.0,45.6,48.0,56.0,60.0]
HL=[(109,112),(112,120),(120,124),(124,129),(129,138),(138,143),(143,152)]
def ease(x):
    x=max(0,min(1,x));return 1-(1-x)**3
def state(t):
    st={'g':[ease((t-a)/0.5) for a in G],'m':ease((t-37.8)/0.5),'r':[ease((t-a)/0.55) for a in R],'h':[1 if a<=t<b else 0 for a,b in HL]}
    return st
JS="""(s)=>{
document.querySelectorAll('[data-g]').forEach(e=>{const v=s.g[+e.dataset.g];e.style.opacity=v;e.style.transform='translateX('+((1-v)*-24)+'px)'});
const m=document.getElementById('mapa');m.style.opacity=s.m;m.style.transform='translateY('+((1-s.m)*18)+'px)';
document.querySelectorAll('[data-r]').forEach(e=>{const i=+e.dataset.r;const v=s.r[i];e.style.opacity=v;e.style.transform='translateY('+((1-v)*14)+'px)';
 e.classList.toggle('hl',!!s.h[i])});
}"""
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080},device_scale_factor=SC)
    pg.goto('file:///home/claude/gen/video.html');pg.evaluate("document.fonts.ready")
    pg.add_style_tag(content=".tbl div.hl{background:#FFF08A!important;transition:none} .tbl div{transition:none}")
    pg.evaluate("""()=>{const sh=document.querySelectorAll('.sheet');sh.forEach((s,i)=>{if(i!=1)s.style.display='none'});}""")
    el=pg.query_selector_all('.sheet')[1]
    os.makedirs(OUT,exist_ok=True);cache={};n=0
    for i in range(int((T1-T0)*30)):
        t=T0+i/30;st=state(t);k=json.dumps(st)
        if k not in cache:
            pg.evaluate(JS,st);f=f'{OUT}/u{len(cache):05d}.png';el.screenshot(path=f);cache[k]=f
        fn=f'{OUT}/f{i:05d}.png'
        if os.path.exists(fn):os.remove(fn)
        os.link(cache[k],fn)
    b.close()
print(len(cache),'unici')
subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','30','-i',f'{OUT}/f%05d.png','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',f'{OUT}.mp4'],check=True)
