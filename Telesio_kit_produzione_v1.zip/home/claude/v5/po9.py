"""Schemi guidati (pillole): le righe compaiono e si evidenziano seguendo la voce.
uso: render_po(name, spec, times, dur, outdir, scale)
times = {'rows':[(a,h0,h1),...], 'note':(a,h0,h1)|None}  (secondi dall'inizio del clip)
"""
import sys,os,json,shutil,subprocess
sys.path.insert(0,'/home/claude/assets');sys.path.insert(0,'/home/claude/gen')
exec(open('/home/claude/assets/make_po.py').read().split('# PO02')[0].replace("OUT='/home/claude/assets/out'","OUT='/tmp/po9_unused'"))
# da qui: CSS, page, tr, nt, table, V4, LG (svg) ...
from playwright.sync_api import sync_playwright

SPEC={}
SPEC['PO02']=dict(eyebrow='[PILLOLA DI GRAMMATICA]',title='Formación del plural',cols='34% 66%',fs=32,header=['Regla / Regola','Ejemplos / Esempi'],
  rows=[['Vocal + -s','chica → chica<mark>s</mark>; libro → libro<mark>s</mark>'],['Consonante + -es','doctor → doctor<mark>es</mark>; profesor → profesor<mark>es</mark>'],['-z → -ces','luz → lu<mark>ces</mark>; lápiz → lápi<mark>ces</mark>'],['-s átona: normalmente invariable','el lunes → los lunes']],
  note=nt('CONCORDANCIA','La concordancia cambia también el artículo y el adjetivo: el chico simpático → los chicos simpáticos; la estudiante nueva → las estudiantes nuevas.'),tweak='')
SPEC['PO03']=dict(eyebrow='[PILLOLA DI GRAMMATICA]',title='Interrogativos',cols='29% 33% 38%',fs=28,header=['Forma','Uso','Ejemplo'],
  rows=[['¿Quién? / ¿Quiénes?','persona','¿Quién es? / ¿Quiénes son?'],['¿Qué?','cosa, actividad o definición','¿Qué estudias?'],['¿Cuál? / ¿Cuáles?','elección o identificación','¿Cuál es tu teléfono?'],['¿Dónde?','lugar','¿Dónde vives?'],['¿De dónde?','origen','¿De dónde eres?'],['¿Cómo?','manera, descripción o nombre','¿Cómo te llamas?'],['¿Cuándo?','momento','¿Cuándo estudias?'],['¿Cuánto/a/os/as?','cantidad; concuerda con el sustantivo','¿Cuántos años tienes?'],['¿Por qué?','motivo','¿Por qué estudias español?']],
  note=nt('IMPORTANTE','«¿De dónde eres?» pregunta por el origen; «¿Dónde vives?» pregunta por el lugar de residencia.'),
  tweak=".tr>div{padding:6px 18px}.note{margin-top:16px;padding:10px 24px 12px;font-size:27px}.tr.h>div{padding:7px 18px}")
note2='<div class="two">'+nt('VOSOTROS / USTEDES','«Vosotros/as» se usa sobre todo en España; «ustedes» es habitual en América Latina.')+nt('OMISIÓN','En español el pronombre sujeto puede omitirse: «Yo vivo en Roma» / «Vivo en Roma».')+'</div>'
SPEC['PO04']=dict(eyebrow='[PILLOLA DI GRAMMATICA]',title='Pronombres sujeto',cols='24% 36% 40%',fs=28,header=['Persona','Pronombre sujeto','Equivalente aproximado'],
  rows=[['1.ª singular','yo','io'],['2.ª singular','tú','tu informal'],['3.ª singular','él / ella / usted','lui / lei / forma de cortesía'],['1.ª plural','nosotros / nosotras','noi'],['2.ª plural','vosotros / vosotras','voi, sobre todo en España'],['3.ª plural','ellos / ellas / ustedes','loro / ustedes']],
  note=note2,tweak=".tr>div{padding:8px 20px}.note{padding:12px 22px 14px;font-size:24px;margin-top:20px}.two{gap:26px}")
SPEC['PO06']=dict(eyebrow='[PILLOLA DI GRAMMATICA]',title='Presente de indicativo: verbos regulares',cols='31% 23% 23% 23%',fs=32,header=['Persona','-AR: HABLAR','-ER: COMER','-IR: VIVIR'],
  rows=[['yo','habl<mark>o</mark>','com<mark>o</mark>','viv<mark>o</mark>'],['tú','habl<mark>as</mark>','com<mark>es</mark>','viv<mark>es</mark>'],['él / ella / usted','habl<mark>a</mark>','com<mark>e</mark>','viv<mark>e</mark>'],['nosotros/as','habl<mark>amos</mark>','com<mark>emos</mark>','viv<mark>imos</mark>'],['vosotros/as','habl<mark>áis</mark>','com<mark>éis</mark>','viv<mark>ís</mark>'],['ellos / ellas / ustedes','habl<mark>an</mark>','com<mark>en</mark>','viv<mark>en</mark>']],
  note=nt('REGLA','Se quita -ar / -er / -ir y se añade la terminación de la persona.'),tweak=".tr>div{padding:9px 22px}.note{margin-top:22px;font-size:27px}")
SPEC['PO07']=dict(eyebrow='[PILLOLA DI GRAMMATICA]',title='Verbos reflexivos',cols='30% 35% 35%',fs=29,header=['Persona','LLAMARSE','LEVANTARSE'],
  rows=[['yo','me llamo','me levanto'],['tú','te llamas','te levantas'],['él / ella / usted','se llama','se levanta'],['nosotros/as','nos llamamos','nos levantamos'],['vosotros/as','os llamáis','os levantáis'],['ellos / ellas / ustedes','se llaman','se levantan']],
  note=nt('ESTRUCTURA','[pronombre reflexivo] + [verbo conjugado]: me, te, se, nos, os, se.'),tweak=".tr>div{padding:8px 20px}.note{margin-top:20px;font-size:26px}")
CARDS='<div class="two"><div class="card" data-u="0"><span class="lb">[SER]</span><h3>SER</h3><p>identificar a una persona</p><p>indicar el origen</p><p>describir características</p><p style="margin-top:18px;color:var(--blue)">Soy estudiante.<br>Soy de Italia.<br>Somos simpáticos.</p></div><div class="card" data-u="1"><span class="lb">[TENER]</span><h3>TENER</h3><p>posesión</p><p>edad</p><p style="margin-top:18px;color:var(--blue)">Tengo un libro.<br>Tengo quince años.</p></div></div>'

EASE="function e(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)}"
JS=("(t)=>{"+EASE+"""
var k=[];document.querySelectorAll('[data-ap]').forEach(function(el){
 var a=+el.dataset.ap,h0=el.dataset.h0===undefined?null:+el.dataset.h0,h1=el.dataset.h1===undefined?null:+el.dataset.h1;
 var v=Math.round(e((t-a)/0.5)*100)/100;el.style.opacity=v;el.style.transform='translateY('+((1-v)*12)+'px)';
 var h=0;if(h0!==null){h=Math.round(e((t-h0)/0.25)*(1-e((t-h1)/0.25))*100)/100}
 var cells=el.classList.contains('tr')?[].slice.call(el.children):[el];
 cells.forEach(function(c){if(!c.parentElement.classList.contains('h')&&!c.classList.contains('h'))c.style.background=h>0?'rgba(255,230,0,'+(0.55*h)+')':''});
 k.push(v,h)});return k.join(',')}""")

def build_html(name,sp,times,cards=False):
    head='<div class="hd"><img src="data:image/svg+xml;base64,%s"></div><div class="ey"><span class="lb">%s</span></div><div class="tt">%s</div><div class="bar"></div><div class="ft"><span>SPAGNOLO</span><span></span></div>'%(LG,sp['eyebrow'],sp['title'])
    if cards:
        (a0,h00,h01),(a1,h10,h11)=times['rows'][:2]
        c0='<div class="card" data-ap="%s" data-h0="%s" data-h1="%s"><span class="lb">[SER]</span><h3>SER</h3><p>identificar a una persona</p><p>indicar el origen</p><p>describir características</p><p style="margin-top:18px;color:var(--blue)">Soy estudiante.<br>Soy de Italia.<br>Somos simpáticos.</p></div>'%(a0,h00,h01)
        c1='<div class="card" data-ap="%s" data-h0="%s" data-h1="%s"><span class="lb">[TENER]</span><h3>TENER</h3><p>posesión</p><p>edad</p><p style="margin-top:18px;color:var(--blue)">Tengo un libro.<br>Tengo quince años.</p></div>'%(a1,h10,h11)
        body='<div class="bd" style="top:348px"><div class="two">'+c0+c1+'</div>'
        if times.get('note'):
            a=times['note'][0]
            body+='<div data-ap="%s">%s</div>'%(a,nt('ATENCIÓN','En español decimos «Tengo quince años», no <span style="background:var(--hl);text-decoration:line-through;text-decoration-thickness:4px">«Soy quince años»</span>.'))
        body+='</div>'
    else:
        body='<div class="bd">'
        body+='<div class="tr h" data-ap="0.2" style="grid-template-columns:%s">%s</div>'%(sp['cols'],''.join('<div>%s</div>'%c for c in sp['header']))
        n=len(sp['rows'])
        for i,r in enumerate(sp['rows']):
            a,h0,h1=times['rows'][i]
            body+='<div class="tr %s" data-ap="%s" data-h0="%s" data-h1="%s" style="grid-template-columns:%s">%s</div>'%('last' if i==n-1 else '',a,h0,h1,sp['cols'],''.join('<div>%s</div>'%c for c in r))
        if sp.get('note') and times.get('note'):
            a,h0,h1=times['note'];body+='<div data-ap="%s">%s</div>'%(a,sp['note'])
        body+='</div>'
    css=CSS+(".tr{font-size:%dpx}"%sp['fs'] if sp.get('fs') else '')+sp.get('tweak','')+"[data-ap]{opacity:0}"
    return '<!doctype html><meta charset=utf-8><style>%s%s</style><body><div id=root style="width:1920px;height:1080px;position:relative;overflow:hidden;background:#fff">%s</div>'%(BASE,css,head+body)

def render_po(name,key,times,dur,outdir,scale=0.5,cards=False):
    sp=SPEC.get(key,{'eyebrow':'[PILLOLA DI GRAMMATICA]','title':'Verbos SER y TENER','fs':0})
    html=strip_lb(build_html(name,sp,times,cards))
    d=f'{outdir}/{name}';shutil.rmtree(d,ignore_errors=True);os.makedirs(d+'/f')
    open(d+'/p.html','w').write(html)
    N=int(round(dur*30));seen={}
    with sync_playwright() as p:
        b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={'width':1920,'height':1080},device_scale_factor=scale)
        pg.goto('file://'+os.path.abspath(d+'/p.html'));pg.evaluate("document.fonts.ready")
        for n in range(N):
            k=pg.evaluate(JS,n/30.0);fn='%s/f/%05d.png'%(d,n+1)
            if k in seen:os.link(seen[k],fn)
            else:pg.screenshot(path=fn);seen[k]=fn
        b.close()
    out=f'{outdir}/{name}.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','30','-i',d+'/f/%05d.png','-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-r','30','-movflags','+faststart',out],check=True)
    shutil.copy('%s/f/%05d.png'%(d,N),f'{outdir}/{name}_finale.png');shutil.rmtree(d+'/f');print(name,len(seen),'stati')
    return out
