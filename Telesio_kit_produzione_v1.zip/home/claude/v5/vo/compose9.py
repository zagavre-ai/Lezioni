"""Compone la voce guidata di uno schema: inserisce le pause per la ripetizione e
restituisce i tempi di ogni frase (per far comparire/evidenziare le righe).
compose_file(src, phr, key, out_wav, dur=40.0) -> dict con 'times' per il renderer
phr = [(a,b)] frasi (secondi nel file sorgente). Le frasi 'riga' ripetibili hanno pausa lunga.
"""
import subprocess,json
LEAD=0.9
END_HOLD=3.0
# quali frasi sono "da ripetere" (pausa lunga) e come si mappano sulle righe dello schema
LAYOUT={
 'PO02':dict(rep=[1,2,3,4],rows=[1,2,3,4],note=5),
 'PO03':dict(rep=list(range(1,10)),rows=list(range(1,10)),note=10),
 'PO04':dict(rep=list(range(1,7)),rows=list(range(1,7)),note=7),
 'PO05':dict(rep=[1,2,3,5,6],cards=[(0,3),(4,6)],note=7),
 'PO06':dict(rep=list(range(1,7)),rows=list(range(1,7)),note=7),
 'PO07':dict(rep=list(range(1,7)),rows=list(range(1,7)),note=7),
}
def layout(durs,rep,total_voice):
    """sceglie le pause: chi si ripete ha pausa proporzionale; il totale arriva a total_voice"""
    n=len(durs);base=[(d+1.2) if i in rep else 0.7 for i,d in enumerate(durs)]
    fixed=sum(durs)+LEAD
    lo,hi=0.2,2.0
    for _ in range(40):
        s=(lo+hi)/2
        tot=fixed+sum(b*(s if i in rep else 1.0) for i,b in enumerate(base))
        if tot>total_voice:hi=s
        else:lo=s
    s=lo
    gaps=[b*(s if i in rep else 1.0) for i,b in enumerate(base)]
    st=[];t=LEAD
    for d,g in zip(durs,gaps):
        st.append(round(t,3));t+=d+g
    return st,gaps,s
def compose_file(src,phr,key,out_wav,dur=40.0,norm='vo/_n5.wav'):
    L=LAYOUT[key]
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',src,'-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','48000','-ac','1',norm],check=True)
    durs=[(b-a)+0.22 for a,b in phr]
    st,gaps,s=layout(durs,set(L['rep']),dur-END_HOLD-0.6)
    ins=['-f','lavfi','-t',str(dur),'-i','anullsrc=r=48000:cl=mono'];fl='[0:a]anull[b]';lab=['b']
    for i,((a,b),t) in enumerate(zip(phr,st)):
        a=max(0,a-0.07);b=b+0.15
        ins+=['-ss','%.3f'%a,'-t','%.3f'%(b-a),'-i',norm]
        fl+=f';[{i+1}:a]afade=t=in:d=0.02,afade=t=out:st={b-a-0.08:.3f}:d=0.08,adelay={int(t*1000)}|{int(t*1000)}[p{i}]';lab.append(f'p{i}')
    fl+=';'+''.join(f'[{l}]' for l in lab)+f'amix=inputs={len(lab)}:normalize=0:duration=first[a]'
    subprocess.run(['ffmpeg','-y','-loglevel','error']+ins+['-filter_complex',fl,'-map','[a]','-ar','48000','-ac','1','-t',str(dur),out_wav],check=True)
    ends=[st[i]+durs[i] for i in range(len(st))]
    nxt=lambda i:(st[i+1]-0.1) if i+1<len(st) else ends[i]+1.0
    T={}
    if 'rows' in L:
        T['rows']=[(max(0.3,st[i]-0.25),st[i]-0.05,nxt(i)) for i in L['rows']]
    if 'cards' in L:
        T['rows']=[(max(0.3,st[a]-0.3),st[a]-0.05,st[b+1]-0.1) for a,b in L['cards']]
    if L.get('note') is not None:
        i=L['note'];T['note']=(max(0.3,st[i]-0.3),st[i],ends[i]+1.0)
    return {'times':T,'starts':st,'gaps':[round(g,2) for g in gaps],'scale':round(s,2),'voice_end':round(ends[-1],2)}
