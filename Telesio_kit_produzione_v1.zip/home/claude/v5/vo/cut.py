import re,subprocess,sys
def blocks(wav,n=-40,d=0.1):
    out=subprocess.run(['ffmpeg','-nostdin','-i',wav,'-af',f'silencedetect=n={n}dB:d={d}','-f','null','-'],capture_output=True,text=True).stderr
    S=[(float(a),float(b)) for a,b in re.findall(r'silence_start: ([\d.\-]+)\n?.*?silence_end: ([\d.]+)',out,re.S)]
    D=float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',wav],capture_output=True,text=True).stdout)
    B=[];p=0
    for a,b in S:
        a=max(a,0)
        if a-p>0.06:B.append((round(p,2),round(a,2)))
        p=b
    if D-p>0.06:B.append((round(p,2),round(D,2)))
    return B,D
def runs(B,mx=0.8,gap=0.9):
    R=[];cur=[]
    for i,(a,b) in enumerate(B):
        short=(b-a)<mx and (b-a)>0.3
        if short and (not cur or a-B[cur[-1]][1]<gap):cur.append(i)
        else:
            if cur:R.append(cur)
            cur=[i] if short else []
    if cur:R.append(cur)
    return R
if __name__=='__main__':
    B,D=blocks(sys.argv[1]);print(round(D,2),len(B))
    for r in runs(B):print(len(r),B[r[0]][0],B[r[-1]][1])
    for i,(a,b) in enumerate(B):print(i,a,b,round(b-a,2))
