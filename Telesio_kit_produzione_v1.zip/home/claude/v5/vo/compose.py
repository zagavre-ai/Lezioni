import subprocess,sys
def compose(src,phr,times,out,total=50.0):
    """phr: lista (a,b) nel file sorgente; times: secondi di inizio nell'animazione"""
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',src,'-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','48000','-ac','1','vo/_n.wav'],check=True)
    ins=['-f','lavfi','-t',str(total),'-i','anullsrc=r=48000:cl=mono'];fl='[0:a]anull[b]';lab=['b']
    for i,((a,b),t) in enumerate(zip(phr,times)):
        a=max(0,a-0.07);b=b+0.15
        ins+=['-ss','%.3f'%a,'-t','%.3f'%(b-a),'-i','vo/_n.wav']
        fl+=f';[{i+1}:a]afade=t=in:d=0.02,afade=t=out:st={b-a-0.08:.3f}:d=0.08,adelay={int(t*1000)}|{int(t*1000)}[p{i}]';lab.append(f'p{i}')
    fl+=';'+''.join(f'[{l}]' for l in lab)+f'amix=inputs={len(lab)}:normalize=0:duration=first[a]'
    subprocess.run(['ffmpeg','-y','-loglevel','error']+ins+['-filter_complex',fl,'-map','[a]','-ar','48000','-ac','1','-t',str(total),out],check=True)
if __name__=='__main__':
    ph=[(0,1.67),(5.19,6.77),(10.25,11.75),(15.21,16.89),(20.37,21.43),(24.91,25.8),(29.24,30.48),(33.98,37.05),(40.59,41.4),(44.83,46.14),(49.48,54.58)]
    tm=[0.8,2.6,6.1,9.6,15.8,18.8,21.8,25.8,35.8,39.2,43.4]
    compose('vo/p3.wav',ph,tm,'voci/AN05.wav')
