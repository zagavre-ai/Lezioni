# Pacchetto voci – Spagnolo Lez. 1 «¿De dónde eres?»

## 0. METODO A UNA SOLA GENERAZIONE (da usare per primo)

Si genera **un solo audio** con la stringa qui sotto. Poi lo taglio io nei punti indicati dai marcatori. **Non togliere i marcatori dal testo e non cambiarli.**

### NOTA DEI MARCATORI PER IL TAGLIO (da non dimenticare)
- Il marcatore è la parola **«Taglio»** pronunciata più volte di seguito, con il punto dopo ogni parola.
- **5 volte di fila** = fine di un file (cambio di voce: R2 → R3 → … → FIN → AN05 → AN06).
- **3 volte di fila** = cambio di frase dentro AN05 e AN06 (serve a posizionare ogni frase sulla grafica).
- Il montaggio trova i marcatori cercando nell'audio gruppi di parole brevissime ravvicinate. Nessun'altra frase del testo è fatta così. Per questo nel testo non ci sono elenchi di parole brevi con la virgola: sono scritti di seguito (esempio: «hablo hablas habla…»).
- Controllo: devo trovare 8 gruppi da 5 e 16 gruppi da 3 (se i numeri non tornano, rigenero solo quel pezzo).
- Prima della consegna all'audio finale le parole «Taglio» vengono sempre tolte.
- **Regola per le lezioni future:** stesso marcatore, stessi numeri (5 = file, 3 = frase). Va scritto in ogni nuovo pacchetto voci.

### Stringa da incollare (una sola riga)
```
Facciamo un riepilogo di quello che hai appena visto: il femminile e il plurale. Guarda l'animazione e ripeti le regole ad alta voce. Taglio. Taglio. Taglio. Taglio. Taglio. Ripassiamo insieme le parole interrogative: ¿qué?, ¿quién?, ¿dónde?, ¿cómo?. Osserva lo schema e prova a formare una domanda. Taglio. Taglio. Taglio. Taglio. Taglio. Repaso dei pronomi soggetto: yo, tú, él, ella, nosotros, vosotros, ellos. Guarda lo schema e di' ogni pronome ad alta voce. Taglio. Taglio. Taglio. Taglio. Taglio. Repaso dei verbi SER e TENER. Guarda l'animazione e poi lo schema riassuntivo: prova a coniugarli a voce alta. Taglio. Taglio. Taglio. Taglio. Taglio. Repaso del presente dei verbi regolari: i tre gruppi in ar, er, ir. Guarda l'animazione e ripeti le desinenze. Taglio. Taglio. Taglio. Taglio. Taglio. Repaso dei verbi riflessivi: ricorda il pronome davanti al verbo, per esempio me llamo, te llamas. Guarda lo schema. Taglio. Taglio. Taglio. Taglio. Taglio. Resumen de la lección. Riepilogo della lezione: ricapitoliamo insieme i sette argomenti che hai studiato. ¡Y ahora, repasemos juntos! Taglio. Taglio. Taglio. Taglio. Taglio. SER si usa per: Taglio. Taglio. Taglio. identificare una persona, Taglio. Taglio. Taglio. indicare la provenienza, Taglio. Taglio. Taglio. e descrivere caratteristiche. Taglio. Taglio. Taglio. Soy estudiante. Taglio. Taglio. Taglio. Soy de Italia. Taglio. Taglio. Taglio. Somos simpáticos. Taglio. Taglio. Taglio. TENER indica il possesso e si usa per l'età. Taglio. Taglio. Taglio. Tengo un libro. Taglio. Taglio. Taglio. Tengo quince años. Taglio. Taglio. Taglio. In spagnolo diciamo «Tengo quince años», non «Soy quince años». Taglio. Taglio. Taglio. Taglio. Taglio. Per coniugare un verbo regolare al presente, togliamo ar, er o ir, e aggiungiamo la desinenza corretta. Taglio. Taglio. Taglio. Poi aggiungiamo la terminazione della persona: hablar, hablo. Taglio. Taglio. Taglio. hablo hablas habla hablamos habláis hablan. Taglio. Taglio. Taglio. I verbi in er e ir hanno desinenze simili, ma non identiche. Taglio. Taglio. Taglio. Uguali: yo, tú, él, ellos. Diverse: nosotros e vosotros. Taglio. Taglio. Taglio. Hablo italiano. Como en casa. Vivo en una ciudad. Estudiamos español.
```

### Durate attese (circa 2,5 parole al secondo)
| File | Durata attesa | Spazio disponibile |
|---|---|---|
| R2 | 9 s | 9,9 s |
| R3 | 8,4 s (misurato sul file di prova) | 7,9 s: allungo la scheda |
| R4 | 8,5 s | 9,1 s |
| R5 | 7,5 s | 8,3 s |
| R6 | 8 s | 8,3 s |
| R7 | 8 s | 8,3 s |
| FIN | 8 s | 8,5 s |
| AN05 | frasi da 1 a 4 s, ognuna nel suo punto | 50 s |
| AN06 | frasi da 2 a 7 s, ognuna nel suo punto | 50 s |

Quando le durate reali superano lo spazio, allungo le schede. Nelle animazioni AN05 e AN06, se una frase è più lunga o più corta del previsto, rifaccio apparire gli elementi ai tempi reali della voce (nome e tempi delle singole parole di «hablo hablas habla…»).

### Impostazioni consigliate nello strumento
- Stessa voce per tutta la stringa. Ritmo normale, nessun effetto.
- Se la parola «Taglio» viene letta con tono diverso a ogni volta va bene; l'importante è che sia distinta e breve.

---

## 1. Istruzioni generali (da incollare nello strumento)

- **Ruolo:** voce narrante di una videolezione di spagnolo per ragazzi delle superiori, italiana. Una sola voce per tutti i file, sempre la stessa.
- **Lingua:** italiano, con parole e frasi in spagnolo inserite nel testo.
- **Pronuncia:** le parole in spagnolo vanno lette con pronuncia spagnola corretta (ad esempio «¿qué?», «¿dónde?», «vosotros», «nosotros»). Tutto il resto in italiano.
- **Tono:** caldo, chiaro, vivace ma non urlato. Ritmo calmo, circa 2,4 parole al secondo. Nessuna musica, nessun effetto.
- **Pause:** `[pausa 0.4]` indica mezzo secondo circa di silenzio. Le frasi in spagnolo da ripetere vanno lette lentamente, con un respiro prima.
- **Punteggiatura:** «¿…?» e «¡…!» indicano l'intonazione, non vanno letti.

## 2. Specifiche tecniche del file

- Formato WAV (PCM 16 bit), 48 kHz, mono o stereo.
- Volume: circa −16 LUFS, picco massimo −1 dB. Stesso livello per tutti i file.
- Nessun silenzio all'inizio (togliere gli spazi vuoti): il montaggio aggiunge l'attacco.
- Il file non deve superare la durata massima indicata per ogni voce.
- Nome del file = codice, ad esempio `R2.wav`. Cartella: `voci/`.

## 3. Voci delle pillole di grammatica e del riepilogo

Il file parte 0,9 s dopo che la scheda si è composta. La durata massima è quella che la scheda lascia libera prima della dissolvenza.

| Codice | Dopo quale argomento | Durata massima | Testo |
|---|---|---|---|
| R2 | Plurale (prima dell'animazione Genere e Plurali) | 9.9 s | Facciamo un riepilogo di quello che hai appena visto: il femminile e il plurale. [pausa 0.4] Guarda l'animazione e ripeti le regole ad alta voce. |
| R3 | Interrogativos | 7.9 s | Ripassiamo insieme le parole interrogative: ¿qué?, ¿quién?, ¿dónde?, ¿cómo?. [pausa 0.4] Osserva lo schema e prova a formare una domanda. |
| R4 | Pronombres sujeto | 9.1 s | Repaso dei pronomi soggetto: yo, tú, él, ella, nosotros, vosotros, ellos. [pausa 0.4] Guarda lo schema e di' ogni pronome ad alta voce. |
| R5 | Verbos SER y TENER | 8.3 s | Repaso dei verbi SER e TENER. [pausa 0.4] Guarda l'animazione e poi lo schema riassuntivo: prova a coniugarli a voce alta. |
| R6 | Presente: verbos regulares | 8.3 s | Repaso del presente dei verbi regolari: i tre gruppi in -ar, -er, -ir. [pausa 0.4] Guarda l'animazione e ripeti le desinenze. |
| R7 | Verbos reflexivos | 8.3 s | Repaso dei verbi riflessivi: ricorda il pronome davanti al verbo, per esempio me llamo, te llamas. [pausa 0.4] Guarda lo schema. |
| FIN | Riepilogo finale della lezione (bilingue) | 8.5 s | Resumen de la lección. [pausa 0.4] Riepilogo della lezione: ricapitoliamo insieme i sette argomenti che hai studiato. [pausa 0.4] ¡Y ahora, repasemos juntos! |

Nota sul riepilogo finale: la prima frase è in spagnolo, la seconda in italiano, l'ultima di nuovo in spagnolo. Leggi «Resumen de la lección» e «¡Y ahora, repasemos juntos!» con pronuncia spagnola.

## 4. Voci delle animazioni mute

Per queste due il file deve durare quanto l'animazione (50 s) e le frasi devono partire ai tempi indicati. Tempi in secondi dall'inizio dell'animazione, tolleranza ±0,5 s. Se lo strumento non permette di posizionare le frasi, genera le frasi una per una e uniscile con spazi di silenzio calcolati sulla colonna «Inizio».

Il file parte esattamente all'inizio dell'animazione: il tempo 0 del file è il tempo 0 dell'animazione.

**AN05 – SER y TENER (50 s)**

| Inizio | Testo |
|---|---|
| 0,8 | SER si usa per: |
| 2,6 | identificare una persona, |
| 6,1 | indicare la provenienza, |
| 9,6 | e descrivere caratteristiche. |
| 15,8 | Soy estudiante. |
| 18,8 | Soy de Italia. |
| 21,8 | Somos simpáticos. |
| 25,8 | TENER indica il possesso e si usa per l'età. |
| 35,8 | Tengo un libro. |
| 39,2 | Tengo quince años. |
| 43,4 | In spagnolo diciamo «Tengo quince años», non «Soy quince años». |
| 47 → 50 | (silenzio: compare la tabella) |

**AN06 – Presente dei verbi regolari (50 s)**

| Inizio | Testo |
|---|---|
| 0,8 | Per coniugare un verbo regolare al presente, togliamo -ar, -er o -ir, e aggiungiamo la desinenza corretta. |
| 14,8 | Poi aggiungiamo la terminazione della persona: hablar, hablo. |
| 24,8 | hablo, |
| 26,2 | hablas, |
| 27,6 | habla, |
| 29,0 | hablamos, |
| 30,4 | habláis, |
| 31,8 | hablan. |
| 34,8 | I verbi in -er e -ir hanno desinenze simili, ma non identiche. |
| 40,5 | Uguali: yo, tú, él, ellos. Diverse: nosotros e vosotros. |
| 44,4 | Hablo italiano. Como en casa. Vivo en una ciudad. Estudiamos español. |

## 5. Dove vanno i file

Metti i 9 file nella cartella `voci/` con i nomi R2, R3, R4, R5, R6, R7, FIN, AN05, AN06 (estensione .wav). Io li monto sopra i jingle e rifaccio l'anteprima.
