# Blocco per il brief tecnico – Videolezioni Centro Studi Telesio
Aggiornato al 01-11-2026. Pronto da incollare. Le voci marcate **[DA CONFERMARE]** sono proposte mie, da approvare dalla Direzione.

---

## 1. Le «pillole di grammatica»

**Cosa sono.** Sono brevi inserti prodotti dalla squadra (non registrati dal docente) che ripassano una sola regola subito dopo la spiegazione e prima dell'esercizio. Hanno una voce narrante e una grafica animata. Compaiono alla fine di ogni argomento, sempre nello stesso punto e con lo stesso schema.

**A cosa servono.**
1. Fissano la regola appena spiegata, con un ripasso attivo («guarda e ripeti ad alta voce»).
2. Fanno da ponte tra la teoria e l'esercizio interattivo.
3. Danno ritmo alle lezioni lunghe: dopo molti minuti di parlato arriva un cambio visivo.
4. Aiutano chi ha BES/DSA: la regola è sintetica, ordinata in tabella, letta ad alta voce, con il tempo per ripetere.
5. Sono riusabili come contenuto a sé (anteprima del corso, ripasso prima dell'esame).

**Struttura standard (uguale per tutte).**
| Momento | Durata | Cosa si vede e si sente |
|---|---|---|
| 1. Scheda introduttiva scura | 13 s | Etichetta «Pillola di grammatica», nome dell'argomento, sottotitolo della voce. Jingle breve. La voce annuncia il ripasso. |
| 2. Schema chiaro animato | 37 s | Tabella o schema dell'argomento. Le righe compaiono e si evidenziano in giallo una alla volta, a ritmo della voce. Dopo ogni riga la voce lascia una pausa perché lo studente ripeta. |
| 3. Schema fermo | 3 s | Tutto lo schema visibile, nessuna voce, tempo di lettura. |

Durata totale standard: **55 s** per tutte le pillole (scheda 13 s + schema 37 s + 3 s di schema fermo). Fa eccezione solo il **riepilogo finale** (che chiude la lezione, bilingue, con una durata sua).
Le transizioni di ingresso e di uscita sono quelle del sistema (dissolvenze di 1,0–1,3 s).

**Come guida la voce.** La voce non legge lo schema: lo conduce. Dice la parola, lascia una pausa e passa alla successiva. Per esempio, nei pronomi: «yo» (pausa) «tú» (pausa) «él, ella» (pausa)… La pausa dura circa 2,5 s per parola o gruppo breve.

**Formato di consegna.**
- Dentro la videolezione: sono già montate nel punto giusto.
- Come file separati: video 1920×1080, 30 fps, H.264, audio AAC 48 kHz a −16 LUFS, con nome `Materia_LezNN_PGnn_argomento.mp4` **[DA CONFERMARE]**.
- Fermo immagine dello schema finale (PNG 1920×1080) per la dispensa.
- Versione verticale 9:16 per cellulare: accantonata; si farà dopo, con la voce.

**Regole di contenuto.** Solo contenuti del docente (nessuna regola nuova). Spagnolo con accenti e segni ¿ ? esatti. Nessun marchio esterno. Nessun lampeggio.

---

## 2. Struttura della lezione e tempi per sezione

**Principio.** Lezione da 60 minuti, 7 argomenti, stessa gabbia per tutti. Questa è una **prova sul materiale che abbiamo**: per le registrazioni già fatte rispettiamo questa scaletta dove possibile; il video del docente non si taglia, salvo le Actividad lette a voce, già decise (opzione B).

### 2.1 Scaletta di una lezione (target per le nuove registrazioni) **[DA CONFERMARE]**
| Parte | Tempo del docente | Cosa aggiunge il montaggio |
|---|---|---|
| Sigla | – | 15 s + dissolvenza 1,8 s + avviso di copyright (§6) |
| Introduzione | 4:30 | Scheda che si costruisce: 7 argomenti e obiettivi |
| Argomenti 1–4 (descrittivi) | 7:00 ciascuno = 28:00 | Titolo (4 s), schemi in sincrono con il parlato, pillola (45 s), animazione dove serve, esercizio interattivo |
| Argomenti 5–7 (verbi, più difficili) | 8:30 ciascuno = 25:30 | Come sopra, con animazione di approfondimento (50–60 s) |
| Sintesi finale del docente (in spagnolo) | 2:00 | Poi riepilogo bilingue con voce narrante |
| Finale | – | 5 s |
| **Totale docente** | **60:00** | + inserti ≈ 9–10 minuti + tempo degli esercizi (a carico dello studente) |

### 2.2 Struttura di ogni argomento
1. Titolo dell'argomento (scheda scura con testo in movimento): 4 s.
2. Spiegazione del docente: 3:00–4:00.
3. Esempi dal docente: 1:30–2:00.
4. Frase di chiusura netta + 3 s di silenzio.
5. Pillola di grammatica: 55 s.
6. Animazione di approfondimento (solo argomenti difficili): 50–60 s.
7. Esercizio interattivo: il video si ferma, il tempo è dello studente.

### 2.3 La prova della Lezione 1 di Spagnolo (stato attuale)
| Argomento | Parlato attuale | Target | Come lo compensiamo |
|---|---|---|---|
| Introduzione | 2:37 | 4:30 | Scheda che si costruisce |
| 1 Femminile | 6:56 | 7:00 | in linea |
| 2 Plurale | 4:17 | 7:00 | Animazione «Genere e Plurali» (5:27) |
| 3 Interrogativos | 6:40 | 7:00 | in linea |
| 4 Pronombres | 5:28 | 7:00 | Pillola + schema guidato |
| 5 SER y TENER | 3:08 | 8:30 | Pillola + animazione + schema guidato |
| 6 Presente regolare | 1:55 | 8:30 | Pillola + animazione + schema guidato |
| 7 Riflessivi | 1:18 | 8:30 | Pillola + schema guidato |
| Sintesi | 1:02 | 2:00 | Riepilogo bilingue + animazione di ripasso |

Si vede che la registrazione è sbilanciata: i primi quattro argomenti sono lunghi e gli ultimi tre troppo corti. Il montaggio riequilibra con inserti, ma una nuova registrazione con questi tempi è la soluzione vera.

---

## 3. Guida per i docenti alle riprese

### 3.1 Prima di registrare
1. **Software:** registrazione a schermo intero in OBS, 1920×1080, 30 fps, 15.000–20.000 kbps (oppure qualità «indistinguibile»).
2. **Webcam:** impostata a 1920×1080 nelle proprietà della sorgente. Non usare lo zoom digitale.
3. **Inquadratura:** viso e spalle, occhi sul terzo superiore dell'immagine, un po' di spazio sopra la testa. Il montaggio ritaglia stretto sul viso: una ripresa troppo larga lo rende piccolo.
4. **Luce:** davanti al viso, mai alle spalle né di lato. Idealmente **luce a tre punti** (principale a 45° di lato, luce di riempimento morbida dall'altro lato, luce di contro dietro). Se se ne ha una sola: finestra o lampada frontale morbida, leggermente più alta degli occhi.
5. **Fondale:** semplice e ordinato, senza finestre bruciate né oggetti che si muovono. **Sfondo sfocato:** si ottiene allontanandosi dal fondale di almeno 1,5 m e avvicinando il viso alla camera. In alternativa si può usare lo sfondo sfocato del software di registrazione **[DA CONFERMARE sul risultato reale]**.
6. **Abbigliamento:** tinta unita, evitare bianco puro, nero totale e righe fitte.
7. **Audio:** microfono vicino alla bocca (20–30 cm), in una stanza senza eco. Cuffie per ascoltare il livello. Niente ventole o condizionatori vicini.
8. **Prima di cominciare:** 3–4 secondi di silenzio dopo l'avvio.

### 3.2 Come strutturare il parlato
1. **Ogni argomento comincia con F9 e con 3 s di silenzio.** Il montaggio inserisce qui il titolo; la voce riparte dal contenuto.
2. **Niente «va bene, cominciamo con…», «ok», «allora»**: si parte dal contenuto («La formación del femenino…»).
3. **Niente intercalari** («eh», «hmm»). Pause pulite.
4. **Leggere le righe delle tabelle nell'ordine in cui compaiono** e dire la prima parola di ogni riga («yo… tú… él…»). Il montaggio evidenzia la riga mentre il docente la nomina.
5. **Chiudere con una frase finale netta + 3 s di silenzio.** Il montaggio taglia in quel silenzio e inserisce la pillola e l'esercizio.
6. **Esercizi (Actividad):** non si leggono a voce. Si usa **una frase fissa**, sempre uguale, seguita da 3 s di silenzio **[formula da decidere con la Direzione; proposta: «Ora metti alla prova quello che hai imparato.»]**.
7. **Una slide = un F9.** Numero di F9 = numero di slide − 1. Solo avanti con le slide. Se i conti non tornano ci fermiamo: mai tempi stimati.
8. **Sintesi finale in spagnolo** (la spiegazione resta in italiano o bilingue **[DA DECIDERE]**). Il riepilogo bilingue lo aggiunge il montaggio; il docente non lo annuncia.
9. Dopo l'ultimo F9, restare fermi 3–4 s prima di fermare la registrazione.

### 3.3 Cosa fa la squadra
Per ogni nuova lezione forniamo al docente il punto esatto dove cadrà ogni inserto, così ogni silenzio è previsto. Le voci delle pillole e del riepilogo non sono del docente.

---

## 4. Standard di post-produzione

### 4.1 Correzione colore (solo sull'immagine del docente)
- Bilanciamento del bianco al 50% verso il neutro: guadagno di ogni canale = limite(1 + 0,5·(M/c − 1), 0,85, 1,20).
- Luminosità media portata verso 112/255 (gamma tra 0,90 e 1,25).
- Contrasto 1,04, saturazione 1,03, riduzione del rumore leggera, nitidezza leggera.
- Si applica dopo il ridimensionamento al riquadro.
- **Limiti dichiarati:** la correzione non crea luce che non c'è. Una ripresa con luce sbagliata (per esempio controluce) si migliora solo in parte; per questo la guida di ripresa (§3) è obbligatoria.

### 4.2 Pulizia audio
- Taglio delle frequenze basse (80 Hz), riduzione del fruscio, livellamento a **−16 LUFS** con picco massimo −1,5 dBTP, limitatore.
- Pause lunghe ripulite dal rumore residuo.
- **Stato:** per le anteprime il fruscio di fondo può essere ancora percepibile. La catena definitiva va messa a punto su audio vero ed è da approvare con la Direzione prima della consegna. Le anteprime non fanno fede.
- Le voci narranti (pillole, riepilogo, animazioni) sono livellate sullo stesso valore, così non c'è differenza di volume tra docente e narrazione.

### 4.3 Riquadro del docente
- Formato 4:3, in alto a destra, angoli arrotondati, bordo blu notte sottile e ombra netta Blu Telesio.
- Banda gialla con il nome sotto il riquadro, sempre visibile; **il nome compare solo qui**, in basso accanto alla materia. Non compare nelle sigle e nel finale.
- Ritaglio stretto sul viso, immagine con correzione colore (§4.1).
- **Luce a tre punti e sfondo sfocato** sono requisiti di ripresa (§3.1): in montaggio non si possono creare in modo affidabile. Se la Direzione vuole lo sfondo sfocato anche sulle riprese già fatte, serve un test su video vero: **[DA CONFERMARE]**.

---

## 5. Pillole, animazioni e ponti: elenco degli inserti
| Tipo | Funzione | Durata | Voce |
|---|---|---|---|
| Titolo argomento | Cambio argomento | 4 s | no (jingle) |
| Pillola di grammatica | Ripasso guidato | 45 s | sì |
| Animazione di approfondimento | Spiegazione visiva dei temi difficili | 50–60 s | sì |
| Animazione lunga (es. Genere e Plurali) | Copre argomenti ripetitivi | ≈ 5:30 | sì |
| Esercizio interattivo | Quiz con feedback | tempo dello studente | no |
| Riepilogo finale | Mappa bilingue della lezione | 14 s + ripasso | sì |

---

## 6. Avviso di copyright dopo la sigla
Alla fine della sigla, nel piè di pagina, compare una scritta piccola chiamata **<u>avviso di copyright</u>** (anche detto **<u>disclaimer</u>** o nota legale).

Testo proposto **[DA CONFERMARE con la Direzione / consulente legale]**:
> © Centro Studi Telesio. Tutti i contenuti riprodotti in questa videolezione (testi, grafiche, animazioni, voci e registrazioni) sono di proprietà del Centro Studi Telesio. È vietata la riproduzione, anche parziale, senza autorizzazione scritta.

Specifiche proposte: in basso al centro, entro la zona sicura; bianco su fondo scuro; dissolvenza in entrata e uscita; resta circa 5 s, a partire da 2 s prima della fine della sigla fino a 3 s dopo l'inizio della lezione. **Eccezione dichiarata alla regola dei 28 px minimi** (obbligo di leggibilità), perché è un testo legale e non didattico: corpo 24 px su 1080, contrasto massimo.

---

## 7. Impaginazione: regole da controllare su ogni file
- **Margini:** 80 px a sinistra e a destra; contenuti fino a y 953; linea del piè di pagina a y 982.
- **Zona sicura video:** verificata su tutte le 29 slide della Lezione 1: nessun testo esce dai margini di 80 px a sinistra e a destra (4,2% della larghezza) né dalla fascia verticale 20–1030 px. Attenzione: 80 px è meno del 5% (96 px) della «zona sicura» televisiva; per un lettore web e per il PDF non è un problema, ma è un'eccezione dichiarata **[DA CONFERMARE]**. Anche la dispensa A4 resta dentro i margini.
- **Riquadro docente:** niente contenuto a destra di x 1473 (zona del riquadro).
- **Interlinea:** unica per tutti, 1,4 nel corpo, titoli 1,05–1,1.
- **Tabelle:** mai spezzate. Se non entrano si riducono padding, interlinea e corpo; il minimo leggibile è 0,82 del normale.
- **Testo minimo:** 28 px sulle slide 16:9 (eccezione: avviso di copyright).
- **Contrasto** almeno 12:1 nelle sigle; mai il colore come unico segnale.
- **Dispensa A4 orizzontale:** identica alla slide ma senza riquadro docente.
- **Logo:** sempre quello vettoriale ricostruito (blu, bianco, inchiostro), mai l'immagine a pixel.

---

## 8. Cose ancora da decidere con la Direzione
1. Durata oltre i 60 minuti (con gli inserti la Lezione 1 resta sotto, ma il target nuovo li somma).
2. Formula fissa per annunciare gli esercizi.
3. Spiegazione bilingue o solo in spagnolo.
4. Matrice grafica v4.
5. Testo definitivo dell'avviso di copyright.
6. Trattamento dello sfondo (sfocato) sulle riprese già fatte.
