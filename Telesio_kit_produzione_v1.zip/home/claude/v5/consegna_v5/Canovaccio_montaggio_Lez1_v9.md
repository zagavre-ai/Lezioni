# Canovaccio del montaggio – Spagnolo Lez. 1 (v9, 01-11-2026)
Tempi del video montato **senza la sigla di 15 s** (sommare 0:15 sul lettore). T = titolo di argomento (4 s). Gli esercizi sono pausa del lettore: il tempo è dello studente.

| Dal | Elemento | Durata |
|---|---|---|
| 0:00 | Docente + scheda introduttiva (7 temi, obiettivi) | 2:35 |
| 2:35 | Titolo argomento 1 | 0:04 |
| 2:40 | Docente + slide: tema 1, femminile (fino a 9:50 originale) | 6:54 |
| 9:34 | Pillola di grammatica: femminile (con voce) | 0:14 |
| 9:49 | Animazione «Genere e Plurali» | 5:25 |
| 15:14 | Esercizio 1 (Actividad 1A) | 0:05 |
| 15:20 | Titolo argomento 2 | 0:04 |
| 15:25 | Docente + slide: tema 2, plurale | 4:15 |
| 19:40 | Pillola: plurale (con voce) | 0:14 |
| 19:54 | Schema guidato: plurale | 0:45 |
| 20:40 | Esercizio 2 (2A, 2B) | 0:05 |
| 20:45 | Titolo argomento 3 | 0:04 |
| 20:50 | Docente + slide: tema 3, interrogativos | 6:38 |
| 27:29 | Pillola: interrogativos | 0:14 |
| 27:43 | Schema guidato: interrogativos | 0:45 |
| 28:29 | Esercizio 3 (3A, 3B) | 0:05 |
| 28:34 | Titolo argomento 4 | 0:04 |
| 28:39 | Docente + slide: tema 4, pronombres | 5:26 |
| 34:05 | Pillola: pronombres | 0:14 |
| 34:20 | Schema guidato: pronomi | 0:45 |
| 35:05 | Esercizio 4 (4A) | 0:05 |
| 35:11 | Titolo argomento 5 | 0:04 |
| 35:16 | Docente + slide: tema 5, ser y tener | 3:06 |
| 38:23 | Pillola: ser y tener | 0:14 |
| 38:37 | Animazione ser/tener | 0:51 |
| 39:29 | Schema guidato: ser/tener | 0:45 |
| 40:14 | Esercizio 5 (5A, 5B) | 0:05 |
| 40:19 | Titolo argomento 6 | 0:04 |
| 40:24 | Docente + slide: tema 6, presente regolare | 1:53 |
| 42:18 | Pillola: verbi regolari | 0:14 |
| 42:33 | Animazione -ar/-er/-ir | 0:59 |
| 43:32 | Schema guidato: presente regolare | 0:45 |
| 44:18 | Esercizio 6 (6A, 6B) | 0:05 |
| 44:23 | Titolo argomento 7 | 0:04 |
| 44:28 | Docente + slide: tema 7, riflessivi | 1:17 |
| 45:45 | Pillola: riflessivi | 0:14 |
| 46:00 | Schema guidato: riflessivi | 0:45 |
| 46:45 | Esercizio 7 (7A, 7B) | 0:05 |
| 46:50 | Docente: Síntesis final | 1:01 |
| 47:52 | Riepilogo finale bilingue (voce) | 0:12 |
| 48:05 | Animazione di ripasso finale | 5:27 |

Durata totale circa 53:32 più 15 s di sigla e 5 s di finale (esercizi esclusi).
