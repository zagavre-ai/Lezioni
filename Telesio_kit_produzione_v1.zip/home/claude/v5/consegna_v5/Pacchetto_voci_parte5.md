# Parte 5 – nuove voci (pillole guidate)

Genera **un solo audio** con la stringa in fondo. Non togliere né cambiare le parole «Taglio»: servono a me per tagliare. Tre «Taglio» dividono le frasi dentro un file; cinque dividono un file dall'altro.

## R1
1. Facciamo un riepilogo di quello che hai appena visto: il femminile. Guarda l'animazione e ripeti le regole ad alta voce.

## R2p
1. Ripassiamo insieme la formazione del plurale. Guarda lo schema e ripeti le regole ad alta voce.

## PO02
1. Ascolta e ripeti.
2. Vocal más ese: chica, chicas; libro, libros.
3. Consonante más es: doctor, doctores; profesor, profesores.
4. Z se transforma en ces: luz, luces; lápiz, lápices.
5. Le parole che finiscono in s non accentata non cambiano: el lunes, los lunes.
6. Anche articolo e aggettivo si accordano: el chico simpático, los chicos simpáticos.

## PO03
1. Ascolta e ripeti.
2. ¿Quién?
3. ¿Qué?
4. ¿Cuál?
5. ¿Dónde?
6. ¿De dónde?
7. ¿Cómo?
8. ¿Cuándo?
9. ¿Cuánto?
10. ¿Por qué?
11. Attenzione: ¿de dónde eres? chiede l'origine; ¿dónde vives? chiede dove abiti.

## PO04
1. Ascolta e ripeti.
2. Yo.
3. Tú.
4. Él, ella, usted.
5. Nosotros, nosotras.
6. Vosotros, vosotras.
7. Ellos, ellas, ustedes.
8. Ricorda: vosotros si usa soprattutto in Spagna, ustedes in America Latina. Il pronome soggetto si può anche omettere.

## PO05
1. SER si usa per identificare una persona, indicare la provenienza e descrivere caratteristiche.
2. Soy estudiante.
3. Soy de Italia.
4. Somos simpáticos.
5. TENER indica il possesso e l'età.
6. Tengo un libro.
7. Tengo quince años.
8. Attenzione: non si dice «Soy quince años».

## PO06
1. Ascolta e ripeti.
2. Yo: hablo, como, vivo.
3. Tú: hablas, comes, vives.
4. Él, ella, usted: habla, come, vive.
5. Nosotros: hablamos, comemos, vivimos.
6. Vosotros: habláis, coméis, vivís.
7. Ellos, ellas, ustedes: hablan, comen, viven.
8. Ricorda: si toglie ar, er, ir e si aggiunge la desinenza.

## PO07
1. Ascolta e ripeti.
2. Yo: me llamo, me levanto.
3. Tú: te llamas, te levantas.
4. Él, ella, usted: se llama, se levanta.
5. Nosotros: nos llamamos, nos levantamos.
6. Vosotros: os llamáis, os levantáis.
7. Ellos, ellas, ustedes: se llaman, se levantan.
8. Ricorda: pronome riflessivo più verbo coniugato.

## Stringa unica da incollare

Facciamo un riepilogo di quello che hai appena visto: il femminile. Guarda l'animazione e ripeti le regole ad alta voce. Taglio. Taglio. Taglio. Taglio. Taglio. Ripassiamo insieme la formazione del plurale. Guarda lo schema e ripeti le regole ad alta voce. Taglio. Taglio. Taglio. Taglio. Taglio. Ascolta e ripeti. Taglio. Taglio. Taglio. Vocal más ese: chica, chicas; libro, libros. Taglio. Taglio. Taglio. Consonante más es: doctor, doctores; profesor, profesores. Taglio. Taglio. Taglio. Z se transforma en ces: luz, luces; lápiz, lápices. Taglio. Taglio. Taglio. Le parole che finiscono in s non accentata non cambiano: el lunes, los lunes. Taglio. Taglio. Taglio. Anche articolo e aggettivo si accordano: el chico simpático, los chicos simpáticos. Taglio. Taglio. Taglio. Taglio. Taglio. Ascolta e ripeti. Taglio. Taglio. Taglio. ¿Quién? Taglio. Taglio. Taglio. ¿Qué? Taglio. Taglio. Taglio. ¿Cuál? Taglio. Taglio. Taglio. ¿Dónde? Taglio. Taglio. Taglio. ¿De dónde? Taglio. Taglio. Taglio. ¿Cómo? Taglio. Taglio. Taglio. ¿Cuándo? Taglio. Taglio. Taglio. ¿Cuánto? Taglio. Taglio. Taglio. ¿Por qué? Taglio. Taglio. Taglio. Attenzione: ¿de dónde eres? chiede l'origine; ¿dónde vives? chiede dove abiti. Taglio. Taglio. Taglio. Taglio. Taglio. Ascolta e ripeti. Taglio. Taglio. Taglio. Yo. Taglio. Taglio. Taglio. Tú. Taglio. Taglio. Taglio. Él, ella, usted. Taglio. Taglio. Taglio. Nosotros, nosotras. Taglio. Taglio. Taglio. Vosotros, vosotras. Taglio. Taglio. Taglio. Ellos, ellas, ustedes. Taglio. Taglio. Taglio. Ricorda: vosotros si usa soprattutto in Spagna, ustedes in America Latina. Il pronome soggetto si può anche omettere. Taglio. Taglio. Taglio. Taglio. Taglio. SER si usa per identificare una persona, indicare la provenienza e descrivere caratteristiche. Taglio. Taglio. Taglio. Soy estudiante. Taglio. Taglio. Taglio. Soy de Italia. Taglio. Taglio. Taglio. Somos simpáticos. Taglio. Taglio. Taglio. TENER indica il possesso e l'età. Taglio. Taglio. Taglio. Tengo un libro. Taglio. Taglio. Taglio. Tengo quince años. Taglio. Taglio. Taglio. Attenzione: non si dice «Soy quince años». Taglio. Taglio. Taglio. Taglio. Taglio. Ascolta e ripeti. Taglio. Taglio. Taglio. Yo: hablo, como, vivo. Taglio. Taglio. Taglio. Tú: hablas, comes, vives. Taglio. Taglio. Taglio. Él, ella, usted: habla, come, vive. Taglio. Taglio. Taglio. Nosotros: hablamos, comemos, vivimos. Taglio. Taglio. Taglio. Vosotros: habláis, coméis, vivís. Taglio. Taglio. Taglio. Ellos, ellas, ustedes: hablan, comen, viven. Taglio. Taglio. Taglio. Ricorda: si toglie ar, er, ir e si aggiunge la desinenza. Taglio. Taglio. Taglio. Taglio. Taglio. Ascolta e ripeti. Taglio. Taglio. Taglio. Yo: me llamo, me levanto. Taglio. Taglio. Taglio. Tú: te llamas, te levantas. Taglio. Taglio. Taglio. Él, ella, usted: se llama, se levanta. Taglio. Taglio. Taglio. Nosotros: nos llamamos, nos levantamos. Taglio. Taglio. Taglio. Vosotros: os llamáis, os levantáis. Taglio. Taglio. Taglio. Ellos, ellas, ustedes: se llaman, se levantan. Taglio. Taglio. Taglio. Ricorda: pronome riflessivo più verbo coniugato.
