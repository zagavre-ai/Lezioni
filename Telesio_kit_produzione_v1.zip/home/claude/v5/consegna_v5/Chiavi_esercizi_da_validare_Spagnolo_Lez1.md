# Chiavi di risposta da validare – Spagnolo Lez. 1
I testi degli esercizi sono identici al Word della docente. **Il Word non contiene le soluzioni**: le risposte qui sotto sono ricavate dalle regole della lezione e vanno confermate dalla Prof.ssa Romina Gisel Luna prima della consegna.

## Actividad 1A · Pasa al femenino
- el profesor simpático → **la profesora simpática**
- el médico italiano → **la médica italiana**
- el actor famoso → **la actriz famosa**
- el estudiante trabajador → **la estudiante trabajadora**
- el chico alto → **la chica alta**
- el artista español → **la artista española**

## Actividad 2A · Forma el plural
- la chica alta → **las chicas altas**
- el profesor español → **los profesores españoles**
- la luz roja → **las luces rojas**
- el estudiante nuevo → **los estudiantes nuevos**
- el libro interesante → **los libros interesantes**
- la actriz famosa → **las actrices famosas**

## Actividad 2B · Detecta el error
- Las chica altas. → **errata**, correzione: Las chicas altas.
- Los profesores españoles. → **corretta**
- Las luces rojas. → **corretta**
- Los estudiante nuevos. → **errata**, correzione: Los estudiantes nuevos.

## Actividad 3A · Completa las preguntas
- ¿___ te llamas? → **cómo**
- ¿___ eres? → **de dónde**
- ¿___ vives? → **dónde**
- ¿___ años tienes? → **cuántos**
- ¿___ estudias? → **qué**
- ¿___ estudias español? → **por qué**
- ¿___ es la profesora? → **quién**

## Actividad 3B · Relaciona pregunta y respuesta
- 1. ¿Cómo te llamas? → **B** (B. Me llamo Elena.)
- 2. ¿Dónde vives? → **A** (A. Vivo en Roma.)
- 3. ¿De dónde eres? → **D** (D. Soy de Argentina.)
- 4. ¿Cuántos años tienes? → **C** (C. Tengo dieciséis años.)

## Actividad 4A · Elige el pronombre
- Hablo de mí: ___ soy estudiante. → **yo**
- Hablo contigo: ___ eres de Italia. → **tú**
- Hablo de Ana: ___ vive en Madrid. → **ella**
- Hablo de mí y de mis compañeros: ___ estudiamos español. → **nosotros** (accettato anche: nosotras)
- Hablo de varias personas: ___ son profesores. → **ellos** (accettato anche: ellas)
- Domanda aperta: risposta libera, non assegna punti.

## Actividad 5A · Elige SER o TENER
- Yo ______ estudiante. → **soy**
- Tú ______ dieciséis años. → **tienes**
- Nosotros ______ de Italia. → **somos**
- Ellas ______ dos hermanos. → **tienen**
- Mi profesor ______ simpático. → **es**
- Vosotros ______ un libro. → **tenéis**
- Usted ______ de España. → **es**
- Ellos ______ veinte años. → **tienen**

## Actividad 5B · Construye frases
- yo / estudiante → **Yo soy estudiante.** (accettato anche: soy estudiante.)
- nosotros / de Italia → **Nosotros somos de Italia.** (accettato anche: somos de Italia.)
- ella / quince años → **Ella tiene quince años.** (accettato anche: tiene quince años.)
- ellos / dos libros → **Ellos tienen dos libros.** (accettato anche: tienen dos libros.)

## Actividad 6A · Conjuga los verbos
- yo (hablar) → **hablo**
- tú (comer) → **comes**
- nosotros (vivir) → **vivimos**
- ellos (estudiar) → **estudian**
- ella (trabajar) → **trabaja**
- vosotros (leer) → **leéis**
- usted (escribir) → **escribe**
- nosotras (escuchar) → **escuchamos**

## Actividad 6B · Completa el texto
- Spazio 1 (vivir) → **vivo**
- Spazio 2 (estudiar) → **estudio**
- Spazio 3 (hablar) → **hablo**
- Spazio 4 (comer) → **come**
- Spazio 5 (escuchar) → **escuchamos**
- Spazio 6 (leer) → **leen**
- Spazio 7 (escribir) → **escriben**

## Actividad 7A · Completa con el pronombre reflexivo
- Yo ______ llamo Marco. → **me**
- Tú ______ levantas temprano. → **te**
- Ella ______ llama Sara. → **se**
- Nosotros ______ levantamos a las siete. → **nos**
- Vosotros ______ llamáis Pablo y Luis. → **os**
- Ellos ______ levantan a las ocho. → **se**

## Actividad 7B · Elige la forma verbal
- Yo · Yo me ______ Ana. (llamarse) → **llamo**
- Tú · Tú te ______ a las siete. (levantarse) → **levantas**
- Él · Él se ______ Carlos. (llamarse) → **llama**
- Nosotras · Nosotras nos ______ temprano. (levantarse) → **levantamos**

Punteggio: 1 punto per risposta giusta, 69 punti totali (4A: la domanda aperta non è punteggiata). Gli accenti contano: una parola senza accento non dà punto, ma il quiz lo segnala.
