# Parte 6 – voce dell'animazione sul femminile (nuova)

Genera **un solo audio** con la stringa in fondo. Non togliere né cambiare le parole «Taglio»: servono a me per tagliare. Tre «Taglio» dividono le frasi.

## AN07 – Il femminile
1. Il femminile in spagnolo: guardiamo le regole una alla volta.
2. Le parole in o cambiano in a: el chico, la chica.
3. Le parole in or aggiungono una a: el profesor, la profesora.
4. Anche alcune parole che finiscono per consonante aggiungono una a: el doctor, la doctora.
5. Le parole in e e molte parole in ista non cambiano: el estudiante, la estudiante; el artista, la artista.
6. Alcune forme sono irregolari: el hombre, la mujer; el padre, la madre; el actor, la actriz.
7. Anche l'aggettivo si accorda: el chico simpático, la chica simpática.

## Stringa unica (da incollare)

Il femminile in spagnolo: guardiamo le regole una alla volta. Taglio. Taglio. Taglio. Le parole in o cambiano in a: el chico, la chica. Taglio. Taglio. Taglio. Le parole in or aggiungono una a: el profesor, la profesora. Taglio. Taglio. Taglio. Anche alcune parole che finiscono per consonante aggiungono una a: el doctor, la doctora. Taglio. Taglio. Taglio. Le parole in e e molte parole in ista non cambiano: el estudiante, la estudiante; el artista, la artista. Taglio. Taglio. Taglio. Alcune forme sono irregolari: el hombre, la mujer; el padre, la madre; el actor, la actriz. Taglio. Taglio. Taglio. Anche l'aggettivo si accorda: el chico simpático, la chica simpática.
