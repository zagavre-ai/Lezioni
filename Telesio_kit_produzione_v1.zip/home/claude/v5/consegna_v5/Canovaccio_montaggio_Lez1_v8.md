# Canovaccio del montaggio – Spagnolo Lez. 1 «¿De dónde eres?» (v8)
Tempi del video montato, sigla di 15 s esclusa (sommare 0:15 per il tempo sul lettore). D = docente, S = slide dinamica, I = interludio scuro con titolo, ES = esercizio interattivo, R = pillola di grammatica con voce, A = animazione.

| Dal | Elemento | Durata | Contenuto |
|---|---|---|---|
| 00:00 | D+S | 2:37 | Introduzione: scheda che si costruisce (7 temi e obiettivi) |
| 02:35 | I | 6 s | Titolo tema 1 – Femenino |
| 02:40 | D+S | 6:56 | Tema 1 – formazione del femminile (fino a 9:50 circa) |
| 09:35 | ES | | Esercizio 1A |
| 09:40 | I + D+S | 4:17 | Tema 2 – plurale |
| 14:00 | R | 13 s | Pillola: femenino y plural |
| 14:12 | A | 5:27 | Animazione Genere e Plurali |
| 19:38 | ES | | Esercizio 2 |
| 19:43 | I + D+S | 6:40 | Tema 3 – interrogativos |
| 26:26 | R + A | 28 s | Pillola interrogativos + animazione |
| 26:53 | ES | | Esercizio 3 |
| 26:58 | I + D+S | 5:28 | Tema 4 – pronombres |
| 32:30 | R + A | 31 s | Pillola pronomi + animazione |
| 32:59 | ES | | Esercizio 4 |
| 33:04 | I + D+S | 3:08 | Tema 5 – ser y tener |
| 36:16 | R + A + A | 1:16 | Pillola + animazione ser/tener + animazione guidata |
| 37:33 | ES | | Esercizio 5 |
| 37:38 | I + D+S | 1:55 | Tema 6 – presente regular |
| 39:36 | R + A + A | 1:15 | Pillola + animazione -ar/-er/-ir + animazione guidata |
| 41:02 | ES | | Esercizio 6 |
| 41:07 | I + D+S | 1:18 | Tema 7 – reflexivos |
| 42:29 | R + A | 28 s | Pillola + animazione |
| 42:55 | ES | | Esercizio 7 |
| 43:00 | D+S | 1:02 | Síntesis final della docente |
| 44:02 | R | 14 s | Riepilogo finale bilingue con voce |
| 44:14 | A | 5:28 | Animazione di ripasso finale |
| ≈ 49:42 | | | Finale 5 s |

Durata totale circa 49:45 più 15 s di sigla (esercizi esclusi: il lettore si ferma e il tempo è dello studente).

Punti da rivedere (feedback Sara 1-11):
1. Pillola femenino spostata prima dell'Esercizio 1A, a 9:50 del video originale.
2. Dopo l'introduzione delle pillole interrogativos e pronombres: voce narrante che guida (dice il pronome, pausa per la ripetizione, passa al successivo).
3. Schermata verbo tener: l'evidenza in spagnolo deve restare visibile più a lungo e sparire solo al cambio slide.
4. Logo vettoriale Telesio nelle sigle e nelle schermate.
