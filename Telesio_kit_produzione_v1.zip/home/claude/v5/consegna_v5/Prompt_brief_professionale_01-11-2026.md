# Prompt per creare il brief professionale – Videolezioni Centro Studi Telesio
Da incollare come primo messaggio in una nuova chat di questo progetto. Versione di lavoro del 01-11-2026: la correggiamo insieme dopo la prima bozza.

---

Ciao Claude. Sono Sara del Centro Studi Telesio (Milano). Devi scrivere il **brief professionale** del sistema di videolezioni che stiamo costruendo. Il brief deve poter essere dato a un grafico, a un montatore, a un fornitore di piattaforma e ai docenti, senza che nessuno debba chiedermi altro.

## 0. Come lavorare
1. **Prima di scrivere, leggi tutti i documenti del Progetto** (in particolare: `brief_finale_videolezioni`, `brief_tecnico_blocco_01-11-2026`, `workflow_standard_nuove_lezioni_31-10-2026`, `direttive_docenti_registrazione_31-10-2026`, `canovaccio_montaggio_spagnolo_lez1_v8_01-11-2026`, `script_scene_spagnolo_lez1_31-10-2026`, `piano_inserti_spagnolo_lez1_31-10-2026`, `linee_guida_maschera_video`, `sigle_premium_spagnolo_inglese_letteratura`, `stile_obiettivo_prova_reale_31-10-2026`, `regola_titoli_e_compiti`, `video_interattivi_scorm`). Poi riassumimi in 5 righe come procederai.
2. **Non inventare nulla.** Ogni dato deve venire dai documenti. Dove manca una decisione scrivi **[DA CONFERMARE]** e raccoglila nell'ultima sezione.
3. **Distingui sempre** tre stati: **deciso**, **proposto**, **non verificato**. Non scrivere che una cosa è «ottimizzata», «testata» o «definitiva» se nei documenti non risulta provata.
4. **Non nominare strumenti, marchi o software esterni** (nemmeno quelli che usiamo per le voci o il montaggio): scrivi «strumento vocale», «montaggio», «piattaforma».
5. Rispondimi in italiano, dandomi del «tu», in modo semplice e pratico: non sono una programmatrice.
6. Lavora per sezioni. Dopo ogni sezione fermati e chiedimi se va bene, **tranne** quando ti scrivo «vai senza fermarti».
7. Formato finale: un documento unico (Word e PDF), con indice, numerazione delle sezioni, tabelle e riquadri «Regola» e «Da confermare». Scrivi per chi legge una volta e deve applicare.

## 1. Sezioni del brief (nell'ordine)

### 1. Scopo e ambito
Cosa produciamo (videolezioni da 60 minuti, circa 300 lezioni, vecchie e nuove rifatte con la stessa matrice), per chi (studenti delle scuole superiori e vendita e-commerce, con attenzione a BES/DSA), dove (piattaforma SoluzioneFAD, SCORM 1.2). Glossario dei termini che useremo: sigla, argomento, slide dinamica, interludio, pillola di grammatica, animazione, ponte, esercizio interattivo, riepilogo finale.

### 2. Identità visiva
- **Palette** con codici esatti (HEX e, dove possibile, RGB e CMYK): bianco, Blu notte `#0B1530`, Blu Telesio `#2060AF`, giallo `#FFE600` solo come evidenziatore e banda del nome, grigi `#EEF0F4` e `#C9D0DC`. Aggiungi la regola d'uso di ogni colore e i colori **vietati** (viola, verde, crema/avorio, mattone).
- **Tipografia:** Bricolage Grotesque 800 per i titoli, Figtree per il testo, DM Mono per le etichette. Tabella con corpi minimi e massimi, interlinea, maiuscolo, spaziature.
- **Logo:** versioni (blu, bianco, inchiostro) in vettoriale; area di rispetto, dimensione minima, usi corretti e **usi vietati**. Includi una **prova logo**: una tabella con il logo su fondo bianco, blu notte, nero, giallo, foto, con indicazione di quale versione si usa su quale fondo.
- **Forme:** angoli arrotondati, filetti, ombre, evidenziatore a tratto. Cosa è vietato (post-it storti, corsivo decorativo, lampeggi).
- **Accessibilità e BES/DSA:** contrasto, testo minimo (28 px a 1920), tabelle mai spezzate, nessun colore come unico segnale, nessun limite di tempo nei quiz.

### 3. Struttura di una lezione
Scaletta con i **tempi per sezione** (introduzione, argomenti 1–4, argomenti 5–7, sintesi, finale), la struttura di ogni argomento (titolo, spiegazione, esempi, silenzio, pillola, animazione, esercizio) e come si riequilibra una lezione già registrata. Includi la tabella della Lezione 1 di Spagnolo (stato attuale / target / come compensiamo).

### 4. Elementi del video, uno per uno
Per ciascuno: funzione, durata standard, cosa si vede, cosa si sente, regole, esempio.
- Sigla (15 s) + dissolvenza 1,8 s + **avviso di copyright** (testo, posizione, durata).
- Introduzione con scheda che si costruisce.
- Riquadro docente e banda del nome.
- Slide dinamiche (righe che compaiono e si evidenziano; sottolineatura in spagnolo che resta fino al cambio slide; uguale su tutte).
- Titolo di argomento.
- **Pillole di grammatica** (cosa sono, a cosa servono, struttura in 3 momenti, durata uguale per tutte, voce guidata con pause per la ripetizione, formato di consegna).
- Animazioni di approfondimento e animazioni lunghe.
- Esercizio interattivo (come si annuncia, come si ferma il video).
- Riepilogo finale bilingue (l'unica eccezione di durata).
- Finale (5 s).
- Transizioni (tipo e durata di ciascuna) e jingle.

### 5. Audio e voce
Livello e criteri (−16 LUFS, picco −1,5 dBTP), pulizia del fruscio (stato: **da validare su audio originale**), voci narranti (come si producono, come si tagliano con i marcatori, come si controllano), musica e jingle, regole di sincronizzazione.

### 6. Ripresa: guida per i docenti
Impostazioni di registrazione, inquadratura, **luce a tre punti**, fondale e **sfondo sfocato** (requisiti di ripresa, non ottenibili in montaggio), abbigliamento, microfono, come parlare, F9, silenzi, formula per annunciare gli esercizi, sintesi in spagnolo. Aggiungi una **checklist di due minuti** che il docente può spuntare prima di registrare.

### 7. Correzione colore e post-produzione
Cosa si corregge, con quali parametri, con quali limiti dichiarati. Cosa non si può correggere in montaggio.

### 8. Slide e dispense
Slide 16:9 e dispensa A4 orizzontale (identiche, senza riquadro docente), gabbia con tutte le misure, margini, zona sicura (verificata: 80 px laterali, eccezione da confermare), interlinea, tabelle, piè di pagina (**solo MATERIA + docente**, mai il numero di lezione), nomi dei file.

### 9. Esercizi interattivi e SCORM 1.2
Tipi di esercizio, come si prendono dalle Actividad dei docenti (**esattamente**, senza cambiare testi né soluzioni), logica di punteggio, stati, tentativi, feedback (esito con simbolo e motivo), dati salvati, navigazione, accessibilità. Stato del collaudo su SoluzioneFAD: **non ancora eseguito**.

### 10. Flusso di produzione e controlli qualità
Passi in ordine (ingressi, tempi, inserti, quiz, montaggio, controllo, consegna), chi fa cosa, tempi stimati, **checklist di controllo** firmabile, convenzioni dei nomi dei file, cartella di consegna.

### 11. Risultato per materia
Una scheda per **Spagnolo**, **Inglese**, **Letteratura Italiana** (e le altre se presenti nei documenti): nome del docente, sigla, particolarità (per esempio audio dal libro in Inglese, con autorizzazione dell'editore), flusso di lavoro.

### 12. Stato reale e rischi
Tabella con tre colonne: **fatto e verificato**, **fatto ma non verificato**, **da fare**. Rischi (audio, riprese, durata oltre 60 minuti, collaudo SCORM, video originale 1080p non ancora disponibile).

### 13. Decisioni da prendere
Elenco numerato di tutti i **[DA CONFERMARE]**: durata oltre 60 minuti, formula fissa per annunciare gli esercizi, spiegazione bilingue o solo in spagnolo, matrice grafica v4, testo dell'avviso di copyright, trattamento dello sfondo, uso del cellulare come dispositivo di riferimento.

### 14. Appendici
Glossario, palette da stampare, tabella delle durate, esempio di `tempi.txt`, elenco dei file di consegna, schema delle transizioni.

## 2. Regole che valgono sempre
- Il video del docente **non si taglia mai** (unica eccezione decisa: le Actividad lette a voce, sostituite dagli esercizi interattivi).
- I contenuti dei docenti **non si cambiano**: solo refusi evidenti, sempre segnalati.
- Niente numero di lezione nei titoli, nelle sigle e nei piè di pagina (restano solo nei nomi dei file).
- Nessun marchio o logo di terzi visibile.
- Nessun lampeggio; contrasto alto; tabelle mai spezzate.
- Non promettere nel brief ciò che il prodotto non mantiene: «ottimizzato per cellulare», «scalabile» e «pulizia audio definitiva» non vanno scritti finché non sono verificati.

## 3. Consegna
Quando hai finito: dammi il documento, l'elenco delle sezioni dove hai dovuto scrivere **[DA CONFERMARE]**, e in una riga qualsiasi incoerenza trovata tra i documenti del Progetto.
