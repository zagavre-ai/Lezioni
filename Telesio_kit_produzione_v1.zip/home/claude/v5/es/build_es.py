import json,base64,os
Z='/home/claude/l1/fz/33157a64-Bricolage_GrotesqueDM_MonoFigtree/'
def b64(p):return base64.b64encode(open(p,'rb').read()).decode()
FONTS=''.join("@font-face{font-family:'%s';font-weight:%d;src:url(data:font/ttf;base64,%s)}"%(f,w,b64(Z+p)) for f,w,p in (
 ('BG',800,'Bricolage_Grotesque/static/BricolageGrotesque-ExtraBold.ttf'),('FG',400,'Figtree/static/Figtree-Regular.ttf'),('FG',500,'Figtree/static/Figtree-Medium.ttf'),('FG',700,'Figtree/static/Figtree-Bold.ttf'),('FG',800,'Figtree/static/Figtree-ExtraBold.ttf')))
LOGO=b64('/home/claude/logo/out/Telesio_logo_blu.svg')
# ---- Esercizi: testi IDENTICI al Word della docente. Le chiavi NON sono nel Word: sono proposte, da validare ----
def R(prompt,ans,hint,alt=None):return {'p':prompt,'a':ans,'h':hint,'alt':alt or []}
E=[
{'id':'1A','quiz':1,'title':'Actividad 1A · Pasa al femenino','type':'fill','cols':['Masculino','Femenino'],
 'items':[R('el profesor simpático','la profesora simpática','-or → -ora; el adjetivo concuerda.'),R('el médico italiano','la médica italiana','-o → -a, también en el adjetivo.'),R('el actor famoso','la actriz famosa','Forma irregular: actor → actriz.'),R('el estudiante trabajador','la estudiante trabajadora','«estudiante» no cambia; trabajador → trabajadora.'),R('el chico alto','la chica alta','-o → -a.'),R('el artista español','la artista española','«artista» no cambia; español → española.')],
 'note':'Recuerda / Ricorda: no basta con cambiar el artículo. Comprueba también el sustantivo y el adjetivo.'},
{'id':'2A','quiz':2,'title':'Actividad 2A · Forma el plural','type':'fill','cols':['Singular','Plural'],
 'items':[R('la chica alta','las chicas altas','Vocal + -s.'),R('el profesor español','los profesores españoles','Consonante + -es.'),R('la luz roja','las luces rojas','-z → -ces.'),R('el estudiante nuevo','los estudiantes nuevos','Vocal + -s.'),R('el libro interesante','los libros interesantes','Vocal + -s.'),R('la actriz famosa','las actrices famosas','-z → -ces.')]},
{'id':'2B','quiz':2,'title':'Actividad 2B · Detecta el error','type':'check','cols':['Frase','¿Correcta? Si no, corrige.'],
 'items':[R('Las chica altas.','Las chicas altas.','Vocal + -s en el sustantivo.'),R('Los profesores españoles.',None,'Correcta.'),R('Las luces rojas.',None,'Correcta.'),R('Los estudiante nuevos.','Los estudiantes nuevos.','Vocal + -s en el sustantivo.')]},
{'id':'3A','quiz':3,'title':'Actividad 3A · Completa las preguntas','type':'bank','bank':['cómo','dónde','de dónde','qué','cuántos','cuándo','por qué','quién'],'cols':['Pregunta incompleta','Respuesta'],
 'items':[{'p':'¿___ te llamas?','a':'cómo','r':'Me llamo Pablo.','h':'Pregunta por el nombre.'},{'p':'¿___ eres?','a':'de dónde','r':'Soy de Italia.','h':'Pregunta por el origen.'},{'p':'¿___ vives?','a':'dónde','r':'Vivo en Bari.','h':'Pregunta por el lugar de residencia.'},{'p':'¿___ años tienes?','a':'cuántos','r':'Tengo quince años.','h':'Cantidad.'},{'p':'¿___ estudias?','a':'qué','r':'Estudio español.','h':'Cosa o actividad.'},{'p':'¿___ estudias español?','a':'por qué','r':'Porque quiero aprender otro idioma.','h':'Motivo.'},{'p':'¿___ es la profesora?','a':'quién','r':'Es la señora García.','h':'Persona.'}]},
{'id':'3B','quiz':3,'title':'Actividad 3B · Relaciona pregunta y respuesta','type':'match',
 'qs':['1. ¿Cómo te llamas?','2. ¿Dónde vives?','3. ¿De dónde eres?','4. ¿Cuántos años tienes?'],'ans':['A. Vivo en Roma.','B. Me llamo Elena.','C. Tengo dieciséis años.','D. Soy de Argentina.'],'key':['B','A','D','C'],
 'hints':['Nombre.','Lugar de residencia.','Origen.','Edad.']},
{'id':'4A','quiz':4,'title':'Actividad 4A · Elige el pronombre','type':'fill','cols':['Situación','Pronombre'],
 'items':[R('Hablo de mí: ___ soy estudiante.','yo','Hablo de mí → yo.'),R('Hablo contigo: ___ eres de Italia.','tú','Hablo contigo → tú.'),R('Hablo de Ana: ___ vive en Madrid.','ella','Hablo de una mujer → ella.'),R('Hablo de mí y de mis compañeros: ___ estudiamos español.','nosotros','Nosotros / nosotras.',['nosotras']),R('Hablo de varias personas: ___ son profesores.','ellos','Ellos / ellas.',['ellas'])],
 'open':'Compara: «Yo estudio español» y «Estudio español». ¿Son correctas las dos? Explica por qué.','openref':'Referencia de la lección (Síntesis final): los pronombres sujeto a menudo se omiten.'},
{'id':'5A','quiz':5,'title':'Actividad 5A · Elige SER o TENER','type':'fill','cols':['Frase','Respuesta'],
 'items':[R('Yo ______ estudiante.','soy','SER: identidad.'),R('Tú ______ dieciséis años.','tienes','TENER: edad.'),R('Nosotros ______ de Italia.','somos','SER: origen.'),R('Ellas ______ dos hermanos.','tienen','TENER: posesión.'),R('Mi profesor ______ simpático.','es','SER: característica.'),R('Vosotros ______ un libro.','tenéis','TENER: posesión.'),R('Usted ______ de España.','es','SER: origen.'),R('Ellos ______ veinte años.','tienen','TENER: edad.')]},
{'id':'5B','quiz':5,'title':'Actividad 5B · Construye frases','type':'fill','intro':'Construye una frase completa con cada grupo de palabras.','cols':['Palabras','Frase'],
 'items':[R('yo / estudiante','Yo soy estudiante.','SER + identidad.',['soy estudiante.']),R('nosotros / de Italia','Nosotros somos de Italia.','SER + origen.',['somos de Italia.']),R('ella / quince años','Ella tiene quince años.','TENER + edad.',['tiene quince años.']),R('ellos / dos libros','Ellos tienen dos libros.','TENER + posesión.',['tienen dos libros.'])]},
{'id':'6A','quiz':6,'title':'Actividad 6A · Conjuga los verbos','type':'fill','cols':['Sujeto y verbo','Forma correcta'],
 'items':[R('yo (hablar)','hablo','-ar: -o.'),R('tú (comer)','comes','-er: -es.'),R('nosotros (vivir)','vivimos','-ir: -imos.'),R('ellos (estudiar)','estudian','-ar: -an.'),R('ella (trabajar)','trabaja','-ar: -a.'),R('vosotros (leer)','leéis','-er: -éis.'),R('usted (escribir)','escribe','-ir: -e.'),R('nosotras (escuchar)','escuchamos','-ar: -amos.')]},
{'id':'6B','quiz':6,'title':'Actividad 6B · Completa el texto','type':'cloze',
 'parts':['«Hola, me llamo Leo y ','(vivir)',' en Roma. Yo ','(estudiar)',' español y ','(hablar)',' italiano. Mi hermana ','(comer)',' en casa y nosotros ','(escuchar)',' música por la tarde. Mis amigos ','(leer)',' y ','(escribir)',' en español».'],
 'key':['vivo','estudio','hablo','come','escuchamos','leen','escriben'],'hints':['yo → -o.','yo → -o.','yo → -o.','ella → -e.','nosotros → -amos.','ellos → -en.','ellos → -en.']},
{'id':'7A','quiz':7,'title':'Actividad 7A · Completa con el pronombre reflexivo','type':'fill','cols':['Frase','Pronombre'],
 'items':[R('Yo ______ llamo Marco.','me','yo → me.'),R('Tú ______ levantas temprano.','te','tú → te.'),R('Ella ______ llama Sara.','se','ella → se.'),R('Nosotros ______ levantamos a las siete.','nos','nosotros → nos.'),R('Vosotros ______ llamáis Pablo y Luis.','os','vosotros → os.'),R('Ellos ______ levantan a las ocho.','se','ellos → se.')]},
{'id':'7B','quiz':7,'title':'Actividad 7B · Elige la forma verbal','type':'fill','cols':['Sujeto','Frase'],
 'items':[R('Yo · Yo me ______ Ana. (llamarse)','llamo','yo → -o.'),R('Tú · Tú te ______ a las siete. (levantarse)','levantas','tú → -as.'),R('Él · Él se ______ Carlos. (llamarse)','llama','él → -a.'),R('Nosotras · Nosotras nos ______ temprano. (levantarse)','levantamos','nosotras → -amos.')]},
]
QUIZ={1:'Femminile',2:'Plurale',3:'Interrogativos',4:'Pronombres',5:'SER y TENER',6:'Verbos regulares',7:'Verbos reflexivos'}
json.dump(E,open('/home/claude/v5/es/esercizi.json','w'),ensure_ascii=False,indent=1)
TPL=open('/home/claude/v5/es/player.html').read()
html=TPL.replace('/*FONTS*/',FONTS).replace('__LOGO__',LOGO).replace('__DATA__',json.dumps({'E':E,'Q':QUIZ},ensure_ascii=False))
open('/home/claude/v5/es/Esercizi_Spagnolo_Lez1_anteprima.html','w').write(html)
print(len(html)//1024,'KB',sum(len(e.get('items',e.get('key',[]))) for e in E))
