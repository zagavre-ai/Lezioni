import numpy as np,onnxruntime as ort,base64,subprocess,sys,json
D='/tmp/asr/sherpa-onnx-whisper-base/'
enc=ort.InferenceSession(D+'base-encoder.int8.onnx',providers=['CPUExecutionProvider'])
dec=ort.InferenceSession(D+'base-decoder.int8.onnx',providers=['CPUExecutionProvider'])
TOK=[base64.b64decode(l.split()[0]) for l in open(D+'base-tokens.txt')]
def hz2mel(f):
    f=np.asarray(f,float);m=f/(200/3);lg=np.log(6.4)/27;lo=1000/(200/3)
    return np.where(f>=1000,lo+np.log(np.maximum(f,1e-9)/1000)/lg,m)
def mel2hz(m):
    m=np.asarray(m,float);lg=np.log(6.4)/27;lo=1000/(200/3)
    return np.where(m>=lo,1000*np.exp(lg*(m-lo)),m*(200/3))
def filters(sr=16000,n_fft=400,n=80):
    fb=np.zeros((n,n_fft//2+1));fr=np.linspace(0,sr/2,n_fft//2+1)
    mp=mel2hz(np.linspace(hz2mel(0),hz2mel(sr/2),n+2))
    fd=np.diff(mp)
    for i in range(n):
        lo=(fr-mp[i])/fd[i];up=(mp[i+2]-fr)/fd[i+1]
        fb[i]=np.maximum(0,np.minimum(lo,up))
    enorm=2.0/(mp[2:n+2]-mp[:n]);fb*=enorm[:,None];return fb
FB=filters()
def logmel(x):
    x=np.concatenate([x,np.zeros(480000-len(x))])[:480000] if len(x)<480000 else x[:480000]
    xp=np.pad(x,200,mode='reflect');w=np.hanning(401)[:-1]
    n=1+(len(xp)-400)//160
    fr=np.lib.stride_tricks.as_strided(xp,(n,400),(xp.strides[0]*160,xp.strides[0]))*w
    S=np.abs(np.fft.rfft(fr,axis=1))**2
    S=S[:-1].T
    m=FB@S;l=np.log10(np.maximum(m,1e-10));l=np.maximum(l,l.max()-8.0);return ((l+4)/4).astype(np.float32)
def load(path,a=0,b=None):
    cmd=['ffmpeg','-v','error','-ss',str(a)]+(['-t',str(b-a)] if b else [])+['-i',path,'-ac','1','-ar','16000','-f','f32le','-']
    return np.frombuffer(subprocess.run(cmd,capture_output=True).stdout,dtype=np.float32)
def transcribe(x,lang=50274):
    if len(x)<1600:return ''
    mel=logmel(x)[None]
    ck,cv=enc.run(None,{'mel':mel})
    toks=[50258,lang,50359,50363];sk=np.zeros((6,1,448,512),np.float32);sv=sk.copy();off=0;out=[]
    cur=np.array([toks],dtype=np.int64)
    for _ in range(120):
        lg,sk,sv=dec.run(None,{'tokens':cur,'in_n_layer_self_k_cache':sk,'in_n_layer_self_v_cache':sv,'n_layer_cross_k':ck,'n_layer_cross_v':cv,'offset':np.array([off],dtype=np.int64)})
        off+=cur.shape[1];l=lg[0,-1].copy();l[[50257+i for i in range(1,0)]]=0
        t=int(l.argmax())
        if t==50257:break
        out.append(t);cur=np.array([[t]],dtype=np.int64)
    return b''.join(TOK[t] for t in out if t<50257).decode('utf8','ignore').strip()
if __name__=='__main__':
    p=sys.argv[1];lang=50262 if (len(sys.argv)>2 and sys.argv[2]=='es') else 50274
    x=load(p)
    for i in range(0,len(x),16000*28):print(transcribe(x[i:i+16000*28],lang))
