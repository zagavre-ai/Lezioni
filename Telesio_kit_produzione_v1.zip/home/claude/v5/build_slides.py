import sys,os,json,re,subprocess,shutil
sys.path.insert(0,'/home/claude/v5')
import asm2
from playwright.sync_api import sync_playwright
import os as _o
HD=_o.environ.get('HD')=='1'
SC=1.0 if HD else 0.5
SVD='sv_hd' if HD else 'sv'
SRT=json.load(open('/home/claude/v5/srt.json'))
seen=set();ES=[]
for s,x in SRT:
    if s in seen:continue
    seen.add(s);ES.append((s,x))   # primo = spagnolo
BL,seq=asm2.build()
rows=asm2.rows  # (tempo, 'NN.png')
manifest=json.load(open('/home/claude/gen/manifest.json'))['slides']
def norm(w):return re.sub(r'[^a-záéíóúñü]','',w.lower())
STOP=set('para como esto esta este pero porque cuando entonces también ejemplo ejemplos español regla reglas forma formas otras otros algunas algunos terminación terminaciones'.split())
def toks(t):
    return [w for w in (norm(x) for x in re.split(r'\s+',t)) if len(w)>=3 and w not in STOP][:6]
JSU="""()=>{
 const sh=document.querySelectorAll('.sheet')[%d];const bd=sh.querySelector('.bd');const U=[];
 for(const ch of bd.children){
  if(ch.classList.contains('tbl')){const nc=getComputedStyle(ch).gridTemplateColumns.split(' ').length;const cells=[...ch.children];
    for(let r=0;r*nc<cells.length;r++)U.push({k:'row',els:cells.slice(r*nc,(r+1)*nc).map((_,i)=>r*nc+i),tbl:true,txt:cells.slice(r*nc,(r+1)*nc).map(c=>c.textContent).join(' | '),hdr:r==0});}
  else if(ch.classList.contains('tx')){[...ch.children].forEach(p=>U.push({k:'p',txt:p.textContent}))}
  else if(ch.classList.contains('cols2')){[...ch.children].forEach(p=>U.push({k:'c',txt:p.textContent}))}
  else U.push({k:'blk',txt:ch.textContent});
 }
 return U.map(u=>({k:u.k,txt:u.txt,hdr:!!u.hdr}));}"""
def unit_times(n,ts,te,U):
    # n=len(U); tempi in secondi originali
    L=[(s,x) for s,x in ES if ts<=s<=te]
    T=[None]*len(U);prev=ts+0.8
    for i,u in enumerate(U):
        if u['hdr']:T[i]=ts+0.6;prev=max(prev,T[i]);continue
        cells=u['txt'].split(' | ');tk=toks(cells[0]) if u['k']=='row' else toks(u['txt'])
        if u['k']=='row' and len(cells)>1:tk+=toks(cells[1])[:2]
        for s,x in L:
            if s<prev-0.5:continue
            ws={norm(w) for w in x.split()}
            if any(t in ws for t in tk):T[i]=max(s-0.4,prev+0.7);prev=T[i];break
    # riempi i vuoti per interpolazione
    idx=[i for i,t in enumerate(T) if t is not None]
    if not idx:
        step=(te-ts-3)/max(1,len(U));T=[ts+0.8+i*step for i in range(len(U))]
    else:
        T[0]=T[0] if T[0] is not None else ts+0.8
        last=0
        for i in range(1,len(U)+1):
            if i==len(U) or T[i] is not None:
                a=T[last];b=T[i] if i<len(U) else min(te-2,a+ (len(U)-last)*4)
                for j in range(last+1,i):T[j]=a+(b-a)*(j-last)/(i-last)
                last=i
    for i in range(1,len(T)):T[i]=max(T[i],T[i-1]+0.6)
    return T

INF=1e9
SPECIAL={
 7:dict(TR=[971.6,974.5,987.2,1001.5,1027.5,1104.0],T=[971.6]+[INF]*5,
   iv={1:[(974.8,987.5),(1062.5,1066.6)],2:[(988.0,1001.6),(1066.7,1075.6)],3:[(1002.0,1027.6),(1076.0,1090.6)],4:[(1028.0,1049.5),(1091.4,1101.0)],5:[(1104.8,1160.0)]}),
 15:dict(TR=[2314.6,2316.3,2317.4,2318.3,2320.6,2323.3,2327.4,2332.7],T=[2314.6]+[INF]*7,
   iv={1:[(2316.8,2317.9),(2393.0,2402.0)],2:[(2317.9,2318.8),(2402.0,2415.0)],3:[(2318.8,2321.2),(2415.0,2429.0)],
       4:[(2321.2,2323.9),(2429.0,2438.0)],5:[(2323.9,2327.9),(2438.0,2450.0)],6:[(2327.9,2333.0),(2450.0,2489.0)],7:[(2519.0,2622.0)]}),
 18:dict(TR=[2919.6,2924.5,2928.0,2931.5,2935.0,2938.5,2942.0,2945.5],T=[2919.6]+[INF]*7,
   iv={1:[(2925.5,2927.8),(2944.5,2946.2)],2:[(2927.8,2930.8),(2946.2,2949.0)],3:[(2930.8,2933.8),(2949.0,2953.8)],
       4:[(2933.8,2936.8),(2953.8,2955.8)],5:[(2936.8,2939.8),(2955.8,2957.8)],6:[(2939.8,2943.5),(2957.8,2962.5)],7:[(3000.0,3030.0)]}),
 22:dict(TR=[3239.6,3241.5,3242.0,3242.5,3243.0,3243.5,3244.0,3289.5],T=[3239.6]+[INF]*7,
   cells={1:[(1,3249.2),(2,3265.9),(3,3275.7)],2:[(1,3252.0),(2,3267.5),(3,3277.1)],3:[(1,3255.8),(2,3268.7),(3,3278.7)],
          4:[(1,3257.5),(2,3269.8),(3,3280.6)],5:[(1,3259.8),(2,3271.3),(3,3282.5)],6:[(1,3261.8),(2,3273.2),(3,3284.1)]},
   colend={1:3263.8,2:3275.2,3:3286.9}),
 26:dict(TR=[3439.6,3444.5,3448.0,3451.5,3455.0,3458.5,3462.0,3465.5],T=[3439.6]+[INF]*7,
   cells={1:[(1,3468.0),(2,3470.5)],2:[(1,3473.0),(2,3474.6)],3:[(1,3476.8),(2,3479.6)],4:[(1,3481.0),(2,3483.4)],5:[(1,3485.7),(2,3488.2)],6:[(1,3490.9),(2,3493.0)]},
   colend={1:3494.8,2:3494.8},glob=1),
 29:dict(TR=[3569.7,3582.9,3590.3,3595.8,3601.5,3606.4,3612.7,3617.3,3621.2],T=[3569.7,3583.5,3590.8,3596.2,3602.0,3606.9,3613.1,3617.7,INF]),
}
def ease(x):
    x=max(0,min(1,x));return 1-(1-x)**3
JS="""(s)=>{
 const sh=window.SH;const bd=sh.querySelector('.bd');let ui=0;
 for(const ch of bd.children){
  if(ch.classList.contains('tbl')){const nc=getComputedStyle(ch).gridTemplateColumns.split(' ').length;const cells=[...ch.children];
    ch.style.opacity=s.u[ui].v;
    for(let r=0;r*nc<cells.length;r++){const u=s.u[ui++];cells.slice(r*nc,(r+1)*nc).forEach(c=>{c.style.opacity=u.v;c.style.transform='translateY('+((1-u.v)*12)+'px)';const ci=[...c.parentElement.children].indexOf(c)%nc;const hv=u.hc?u.hc[ci]:u.h;c.style.background=hv>0&&!c.classList.contains('h')?'rgba(255,230,0,'+(0.5*hv)+')':''})}}
  else if(ch.classList.contains('tx')){[...ch.children].forEach(p=>{const u=s.u[ui++];p.style.opacity=u.v;p.style.transform='translateY('+((1-u.v)*12)+'px)';p.style.background=u.h>0?'rgba(255,230,0,'+(0.42*u.h)+')':'';p.style.borderRadius='8px'})}
  else if(ch.classList.contains('cols2')){[...ch.children].forEach(p=>{const u=s.u[ui++];p.style.opacity=u.v;p.style.transform='translateY('+((1-u.v)*12)+'px)';p.style.background=u.h>0?'rgba(255,230,0,'+(0.35*u.h)+')':''})}
  else{const u=s.u[ui++];ch.style.opacity=u.v;ch.style.transform='translateY('+((1-u.v)*12)+'px)'}
 }}"""
def build(slide_no,ts,te,lo,hi,out,pg):
    a=max(ts,lo);b=min(te,hi)
    pg.evaluate("(i)=>{window.SH=document.querySelectorAll('.sheet')[i];document.querySelectorAll('.sheet').forEach((s,k)=>s.style.display=k==i?'':'none')}",slide_no-1)
    U=pg.evaluate(JSU%(slide_no-1))
    T=unit_times(len(U),ts,te,U)
    TR=[];
    for i,u in enumerate(U):
        r=ts+0.6 if u['hdr'] else min(T[i],ts+2.0+i*3.5)
        if TR:r=max(r,TR[-1]+0.5)
        TR.append(r)
    T=[max(T[i],TR[i]+0.3) if not U[i]['hdr'] else T[i] for i in range(len(U))]
    SPS={3:216.0,6:968.1,10:1569.5,14:2307.0,17:2862.5,21:3216.0,25:3427.5}
    if slide_no in SPS:
        for j,u in enumerate(U):
            if re.match(r'^\[?ESPAÑOL',u['txt']):
                T[j]=SPS[slide_no];TR[j]=min(TR[j],T[j]-0.5)
    OVR={4:{3:385.5,4:432.5,5:479.5,6:555.0},11:{9:1806.5,10:1921.0}}
    if slide_no in OVR:
        for j,v in OVR[slide_no].items():T[j]=v
        for j in range(1,len(T)):T[j]=max(T[j],T[j-1]+0.5)
    SP=SPECIAL.get(slide_no)
    if SP:
        assert len(SP['TR'])==len(U),(slide_no,len(U))
        TR=list(SP['TR']);T=list(SP['T']) if 'T' in SP else T
    json.dump({'n':slide_no,'T':T,'TR':TR,'U':[u['txt'][:40] for u in U]},open(f'{out}.json','w'))
    el=pg.query_selector_all('.sheet')[slide_no-1]
    shutil.rmtree(out,ignore_errors=True);os.makedirs(out);cache={};N=int((b-a)*30)
    for i in range(N):
        t=a+i/30;us=[]
        for j,u in enumerate(U):
            v=ease((t-TR[j])/0.55)
            nxt=T[j+1] if j+1<len(T) else 1e9
            lang=re.match(r'^\[?(ESPAÑOL|ITALIANO)',U[j]['txt'])
            if lang and lang.group(1)=='ITALIANO':h=0
            elif lang:h=ease((t-T[j]-0.25)/0.3)   # spagnolo: resta evidenziato fino al cambio slide
            else:h=ease((t-T[j]-0.25)/0.3)*(1-ease((t-nxt)/0.3)) if not u['hdr'] else 0
            if j==len(U)-1 and not u['hdr']:h=ease((t-T[j]-0.25)/0.3)*0.0+h
            d={'v':round(v,2),'h':round(h,2)}
            if SP and SP.get('iv') and j in SP['iv']:
                d['h']=round(max(ease((t-a0-0.2)/0.3)*(1-ease((t-b0)/0.25)) for a0,b0 in SP['iv'][j]),2)
            if SP and SP.get('cells') and j in SP['cells']:
                seqc=SP['cells'][j];hc=[0]*6;d['h']=0
                for (c,t0) in seqc:
                    allc=sorted(x[1] for r in SP['cells'].values() for x in r if (SP.get('glob') or x[0]==c))
                    nx=[x for x in allc if x>t0+0.01];t1=(nx[0]-0.05) if nx else SP.get('colend',{}).get(c,t0+3)
                    hv=ease((t-t0-0.15)/0.25)*(1-ease((t-t1)/0.2))
                    hc[c]=max(hc[c],hv)
                d['hc']=[round(x,2) for x in hc]
            us.append(d)
        k=json.dumps(us)
        if k not in cache:
            pg.evaluate(JS,{'u':us});f=f'{out}/u{len(cache):05d}.png';el.screenshot(path=f);cache[k]=f
        os.link(cache[k],f'{out}/f{i:05d}.png')
    subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','30','-i',f'{out}/f%05d.png','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',f'{out}.mp4'],check=True)
    shutil.rmtree(out,ignore_errors=True)
    return a,b
if __name__=='__main__':
    only=set(int(x) for x in sys.argv[1:])
    ranges=[(a,b) for k,(a,b,f) in BL.items()]
    os.makedirs(SVD,exist_ok=True);meta=json.load(open(SVD+'/meta.json')) if os.path.exists(SVD+'/meta.json') else {}
    with sync_playwright() as p:
        br=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=br.new_page(viewport={'width':1920,'height':1080},device_scale_factor=SC)
        pg.goto('file:///home/claude/gen/video.html');pg.evaluate("document.fonts.ready")
        for i,(t,img) in enumerate(rows):
            n=i+1;ts=t;te=rows[i+1][0] if i+1<len(rows) else 3631.6
            m=manifest[i]
            if n in (1,2) or str(m['title']).startswith('Actividad'):continue
            if only and n not in only:continue
            # intersezione con i blocchi
            lo=[max(ts,a) for a,b in ranges if min(te,b)>max(ts,a)];hi=[min(te,b) for a,b in ranges if min(te,b)>max(ts,a)]
            if not lo:continue
            a,b=build(n,ts,te,min(lo),max(hi),f'{SVD}/sv{n:02d}',pg);meta[str(n)]=(a,b);print(n,round(a,1),round(b,1),flush=True)
    json.dump(meta,open(SVD+'/meta.json','w'))
