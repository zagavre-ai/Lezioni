import sys,json;sys.path.insert(0,'/home/claude/v5')
import po9
M=json.load(open('po9/meta.json'))
for k in ['PO02','PO03','PO04','PO05','PO06','PO07']:
    po9.render_po(k,k,M[k]['times'],44.0,'po9_hd',scale=1.0,cards=(k=='PO05'))
