# Direttive per i docenti – nuove registrazioni video

Documento operativo, in aggiornamento. Valido per tutte le nuove registrazioni (OBS, docente a tutto schermo, marcatore F9). Nasce dalle correzioni sulla Lezione 1 di Spagnolo (31/10/2026).

## 1. Prima di registrare
- Webcam a 1920×1080 nelle proprietà della sorgente in OBS. Qualità «indistinguibile» oppure 15.000–20.000 kbps.
- Luce davanti al viso, non di lato né alle spalle. Fondo senza finestre bruciate.
- Aspettare 3–4 secondi di silenzio dopo l'avvio prima di parlare.
- Audio pulito, senza fruscio. Evitare gate di rumore troppo bruschi.

## 2. Come strutturare il parlato
1. **Ogni argomento comincia con F9 e con 3 secondi di silenzio.** Il montaggio inserisce qui il titolo dell'argomento: la voce deve ripartire dal contenuto.
2. **Non dire «va bene, cominciamo con…» né «ok» a inizio argomento.** Si parte direttamente dal contenuto: «La formación del femenino…».
3. **Niente intercalari** («eh», «hmm», «va bene», «ok», «allora»). Pause pulite al loro posto.
4. **Chiudere la spiegazione con una frase finale netta**, poi **3 secondi di silenzio** prima di qualsiasi altra cosa. Il montaggio taglia in quel silenzio e inserisce il quiz o il riepilogo.
5. **Non annunciare gli esercizi a voce** finché non avremo la formula fissa (vedi punto 6). Il quiz interattivo compare da solo.
6. **Formula per annunciare un esercizio (quando verrà attivata):** una sola frase breve, sempre uguale, seguita da 3 secondi di silenzio. Il testo definitivo lo decidiamo con la direzione.
7. **Leggere le righe delle tabelle nello stesso ordine in cui compaiono** e pronunciare la prima parola di ogni riga («yo… tú… él…»). Il montaggio evidenzia la riga mentre la docente la nomina.
8. **Una slide = un F9.** Il numero di F9 deve essere uguale al numero di slide meno uno. Se i segni non coincidono ci fermiamo e controlliamo: mai tempi stimati.
9. Andare solo avanti con le slide. F9 solo per i cambi.
10. Dopo l'ultimo F9, restare 3–4 secondi prima di fermare la registrazione.

## 3. Sintesi finale
- L'ultima parte della lezione è la **sintesi in spagnolo**. Dopo di essa il montaggio inserisce il riepilogo bilingue con voce narrante. La docente non deve annunciare il riepilogo.

## 4. Cosa fa la squadra
- Nelle nuove registrazioni forniamo noi alla docente il punto dove cadrà ogni inserto, così ogni silenzio è già previsto.
- Le voci delle «pillole di grammatica» (repaso) e del riepilogo non sono della docente: le produce la squadra con lo strumento vocale.

## 5. Da decidere con la direzione
- Formula fissa per annunciare un esercizio.
- Se la spiegazione resta bilingue o solo in spagnolo.
