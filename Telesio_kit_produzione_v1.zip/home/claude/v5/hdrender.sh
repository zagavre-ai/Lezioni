cd /home/claude/v5
python3 build_intro.py 1.0 intro_1080 > hd_intro.log 2>&1
python3 run_dark.py 1.0 dk_hd > hd_dark.log 2>&1
mkdir -p po9_hd; python3 run_po_hd.py > hd_po.log 2>&1
HD=1 python3 build_slides.py > hd_sv.log 2>&1
echo ALLDONE > hd_done.log
