import numpy as np,subprocess,sys
AUD='/mnt/user-data/attachments/6f0ad356-eb6e-5e82-bb5b-b32ac31c8256/0743a8c5-audio_per_Claude.m4a'
def segs(a,b,thr_db=-38,gap=0.12,minlen=0.10):
    x=np.frombuffer(subprocess.run(['ffmpeg','-v','error','-ss',str(a),'-t',str(b-a),'-i',AUD,'-ac','1','-ar','16000','-f','f32le','-'],capture_output=True).stdout,dtype=np.float32)
    h=160;n=len(x)//h;e=np.sqrt((x[:n*h].reshape(n,h)**2).mean(1)+1e-12);db=20*np.log10(e)
    pk=np.percentile(db,98);v=db>pk+thr_db+38-38 if False else db>(pk-26)
    out=[];s=None
    for i,f in enumerate(v):
        if f and s is None:s=i
        if not f and s is not None:out.append([s,i]);s=None
    if s is not None:out.append([s,n])
    m=[]
    for s,e_ in out:
        if m and (s-m[-1][1])*0.01<gap:m[-1][1]=e_
        else:m.append([s,e_])
    return [(round(a+s*0.01,2),round(a+e_*0.01,2)) for s,e_ in m if (e_-s)*0.01>=minlen]
if __name__=='__main__':
    a,b=float(sys.argv[1]),float(sys.argv[2])
    for s in segs(a,b):print(s)
