import re,subprocess,sys,os,math,shutil
FF='ffmpeg'
SRC='/mnt/user-data/uploads/anteprima_per_Claude.mp4'
AUD='/mnt/user-data/attachments/6f0ad356-eb6e-5e82-bb5b-b32ac31c8256/0743a8c5-audio_per_Claude.m4a'
RNN='/home/claude/out/Telesio_Nuove_Registrazioni/bin/sh.rnnn'
DUR=3631.6;INS=600.0
W='/home/claude/lez1/work';os.makedirs(W,exist_ok=True)
def sec(t):
    p=t.split(':');return float(p[0])*3600+float(p[1])*60+float(p[2])
rows=[]
for l in open('/home/claude/lez1/tempi.txt'):
    l=l.split('#')[0].strip()
    if not l or l.startswith('WEBCAM'):continue
    a=l.split();rows.append((sec(a[0]),a[1],a[2]))
def seg_list(a,b):
    out=[]
    for i,(t,k,img) in enumerate(rows):
        e=rows[i+1][0] if i+1<len(rows) else DUR
        s0,e0=max(t,a),min(e,b)
        if e0>s0:out.append((s0,e0,img))
    return out
PUL="highpass=f=80,arnndn=m=%s"%RNN
# misura volume una volta sola
if not os.path.exists(W+'/gain.txt'):
    r=subprocess.run([FF,'-nostdin','-hide_banner','-nostats','-i',AUD,'-vn','-af',PUL+',loudnorm=print_format=json','-f','null','-'],capture_output=True,text=True)
    m=re.search(r'"input_i"\s*:\s*"(-?[\d.]+)"',r.stderr);g=-16-float(m.group(1));g=max(-20,min(20,g))
    open(W+'/gain.txt','w').write('%.2f'%g)
GAIN=open(W+'/gain.txt').read().strip();print('gain',GAIN,flush=True)
X=['-threads','2','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r','30','-g','60','-c:a','aac','-b:a','192k','-ar','48000','-ac','2']
def lesson(name,a,b,cover):
    L=seg_list(a,b);parts=[]
    for i,(s0,e0,img) in enumerate(L):
        n=int(round((e0-a)*30))-int(round((s0-a)*30))
        if n<1:continue
        y=149
        cam="[1:v]fps=30,crop=514:386:253:97,scale=332:249:flags=lanczos,hqdn3d=1.5:1.5:3:3,eq=contrast=1.04:saturation=1.03,cas=0.35[c]"
        fc=f"[0:v]setsar=1[bg];{cam};[bg][c]overlay=1511:{y},format=yuv420p[v]"
        out=f'{W}/{name}_{i:02d}.mp4'
        subprocess.run([FF,'-y','-loglevel','error','-nostdin','-loop','1','-framerate','30','-i','/home/claude/lez1/slide/'+img,'-ss','%.3f'%s0,'-i',SRC,'-filter_complex',fc,'-map','[v]','-frames:v',str(n),'-an','-threads','2','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r','30','-g','60',out],check=True)
        parts.append(out)
    open(f'{W}/{name}_v.txt','w').write(''.join("file '%s'\n"%p for p in parts))
    subprocess.run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',f'{W}/{name}_v.txt','-c','copy',f'{W}/{name}_v.mp4'],check=True)
    af=f"{PUL},volume={GAIN}dB,alimiter=limit=0.89,aresample=48000,aformat=channel_layouts=stereo"
    subprocess.run([FF,'-y','-loglevel','error','-nostdin','-ss','%.3f'%a,'-t','%.3f'%(b-a),'-i',AUD,'-af',af,'-c:a','aac','-b:a','192k','-ar','48000',f'{W}/{name}_a.m4a'],check=True)
    subprocess.run([FF,'-y','-loglevel','error','-i',f'{W}/{name}_v.mp4','-i',f'{W}/{name}_a.m4a','-c','copy','-t','%.3f'%(b-a),f'{W}/{name}.mp4'],check=True);print(name,'ok',flush=True)
def reenc(src,dst):
    subprocess.run([FF,'-y','-loglevel','error','-nostdin','-i',src,'-vf','fps=30,scale=1920:1080,setsar=1,format=yuv420p','-af','aresample=48000,aformat=channel_layouts=stereo']+X+[dst],check=True)
mode=sys.argv[1]
if mode=='T':lesson('T',float(sys.argv[2]),float(sys.argv[3]),False)
if mode=='A':lesson('A',0,INS,True)
if mode=='B':lesson('B',INS,DUR,False)
if mode=='C':
    reenc('/home/claude/lez1/sigla_iniziale.mp4',W+'/S0.mp4');reenc('/home/claude/lez1/Animazione_Genere_e_Plurali.mp4',W+'/AN.mp4');reenc('/home/claude/lez1/sigla_finale.mp4',W+'/S9.mp4')
    open(W+'/all.txt','w').write(''.join("file '%s/%s.mp4'\n"%(W,n) for n in ('S0','A','AN','B','S9')))
    subprocess.run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',W+'/all.txt','-c','copy','-movflags','+faststart','/home/claude/lez1/Spagnolo_Lez1_PROVA_montaggio_540p.mp4'],check=True);print('final ok')

if mode=='P':
    lesson('P1',0,180,True);lesson('P2',288,300,False);lesson('P3',560,600,False);lesson('P4',600,660,False)
    reenc('/home/claude/lez1/sigla_iniziale.mp4',W+'/S0.mp4');reenc('/home/claude/lez1/sigla_finale.mp4',W+'/S9.mp4')
    subprocess.run([FF,'-y','-loglevel','error','-nostdin','-t','45','-i','/home/claude/lez1/Animazione_Genere_e_Plurali.mp4','-vf','fps=30,scale=1920:1080,setsar=1,format=yuv420p','-af','aresample=48000,aformat=channel_layouts=stereo,afade=t=out:st=43:d=2']+X+[W+'/ANX.mp4'],check=True)
    open(W+'/p.txt','w').write(''.join("file '%s/%s.mp4'\n"%(W,n) for n in ('S0','P1','P2','P3','ANX','P4','S9')))
    subprocess.run([FF,'-y','-loglevel','error','-f','concat','-safe','0','-i',W+'/p.txt','-c','copy','-movflags','+faststart','/home/claude/lez1/Spagnolo_Lez1_PROVA_estratti.mp4'],check=True);print('prova ok')
