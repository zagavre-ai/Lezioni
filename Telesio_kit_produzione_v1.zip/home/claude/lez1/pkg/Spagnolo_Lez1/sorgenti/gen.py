import sys,re,json,base64,html,os
sys.path.insert(0,'/home/claude/sp')
import build as B
FZ='/home/claude/l1/fz/33157a64-Bricolage_GrotesqueDM_MonoFigtree'
LOGO=base64.b64encode(open('/home/claude/l1/prev/s16.html').read() and b'' or b'').decode()
import json as _j
LG=_j.load(open('/home/claude/mm/logos.json'))['blue']
CSS_FONTS="""
@font-face{font-family:'BG';font-weight:800;src:url('file://%(z)s/Bricolage_Grotesque/static/BricolageGrotesque-ExtraBold.ttf')}
@font-face{font-family:'FG';font-weight:400;src:url('file://%(z)s/Figtree/static/Figtree-Regular.ttf')}
@font-face{font-family:'FG';font-weight:500;src:url('file://%(z)s/Figtree/static/Figtree-Medium.ttf')}
@font-face{font-family:'FG';font-weight:700;src:url('file://%(z)s/Figtree/static/Figtree-Bold.ttf')}
@font-face{font-family:'FG';font-weight:800;src:url('file://%(z)s/Figtree/static/Figtree-ExtraBold.ttf')}
@font-face{font-family:'DM';font-weight:400;src:url('file://%(z)s/DM_Mono/DMMono-Regular.ttf')}
@font-face{font-family:'DM';font-weight:500;src:url('file://%(z)s/DM_Mono/DMMono-Medium.ttf')}
"""%{'z':FZ}
CSS=CSS_FONTS+"""
:root{--ink:#0B1530;--blue:#2060AF;--hl:#FFE600;--soft:#EEF0F4;--rule:#C9D0DC;--k:1}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#fff}
.sheet{container-type:inline-size;position:relative;overflow:hidden;background:#fff;font-family:'FG';color:var(--ink);line-height:1.3;page-break-after:always}
.s16{width:1920px;height:1080px}.a4{width:297mm;height:210mm}
.hd{position:absolute;left:4.17cqw;right:4.17cqw;top:2.7cqw;height:3.8cqw;display:flex;justify-content:space-between;align-items:flex-start;border-bottom:.06cqw solid var(--rule)}
.hd img{height:2.7cqw;display:block}.hd span{font-size:1.15cqw;color:var(--blue);font-weight:700;margin-top:1.3cqw}
.ey{position:absolute;left:4.17cqw;top:7.6cqw;font-family:'DM';font-size:1.25cqw;letter-spacing:.12em;text-transform:uppercase;color:var(--blue);font-weight:500}
.tt{position:absolute;left:4.17cqw;top:9.6cqw;height:6.8cqw;display:flex;align-items:flex-end;font-family:'BG';font-weight:800;font-size:3.5cqw;line-height:1.02;letter-spacing:-.02em}
.s16 .tt{width:72.5cqw}.a4 .tt{width:91.6cqw}
.bar{position:absolute;left:4.17cqw;top:17.4cqw;width:5.6cqw;height:.26cqw;background:var(--ink)}
.bd{position:absolute;left:4.17cqw;top:19.2cqw;display:flex;flex-direction:column;gap:calc(1.1cqw*var(--k))}
.s16 .bd{width:72.5cqw}.a4 .bd{width:91.6cqw}
.fc{border:.2cqw solid var(--ink);box-shadow:.55cqw .55cqw 0 var(--ink);background:rgba(32,96,175,.07);padding:calc(.8cqw*var(--k)) 1.6cqw calc(.9cqw*var(--k));display:flex;flex-direction:column;gap:calc(.4cqw*var(--k));margin-right:.55cqw;margin-bottom:.55cqw}
.fc .lb{align-self:flex-start;font-family:'DM';font-size:1.05cqw;letter-spacing:.1em;background:var(--blue);color:#fff;padding:.25cqw .9cqw;font-weight:500}
.fc .t{font-weight:700;font-size:calc(1.5cqw*var(--k));line-height:1.3}
mark{background:var(--hl);color:var(--ink);padding:0 .25cqw}
.tx p{font-size:calc(1.62cqw*var(--k));font-weight:500;line-height:1.42;margin-bottom:calc(.7cqw*var(--k))}
.tx p b{font-weight:800}
.tx p.bu{padding-left:2.3cqw;position:relative}
.tx p.bu:before{content:'';position:absolute;left:.4cqw;top:.62em;width:.7cqw;height:.7cqw;background:var(--blue)}
.tx p.sub{font-family:'DM';font-size:calc(1.15cqw*var(--k));letter-spacing:.12em;color:var(--blue);font-weight:500;text-transform:uppercase;margin-top:calc(.5cqw*var(--k))}
.tbl{display:grid;border:.2cqw solid var(--ink);font-size:calc(1.45cqw*var(--k));font-weight:700}
.tbl div{padding:calc(.5cqw*var(--k)) 1.3cqw;border-bottom:.1cqw solid var(--ink);border-right:.1cqw solid var(--ink);line-height:1.2;overflow-wrap:anywhere}
.tbl div.h{background:var(--soft);font-weight:800;font-size:calc(1.15cqw*var(--k));letter-spacing:.1em;text-transform:uppercase}
.tbl div.k{color:var(--blue)}.tbl div.le{border-right:0}.tbl div.lr{border-bottom:0}
.ft{position:absolute;left:4.17cqw;right:4.17cqw;font-family:'DM';font-size:1.1cqw;color:var(--blue);display:flex;justify-content:space-between;border-top:.06cqw solid var(--rule);padding-top:.9cqw;font-weight:500}
.s16 .ft{top:51.1cqw}.a4 .ft{top:65.6cqw}
.doc{position:absolute;border:.1cqw solid var(--rule);background:var(--soft)}
.s16 .doc{left:78.65cqw;top:7.76cqw;width:17.29cqw;height:12.97cqw}
.cv{position:absolute;left:4.17cqw;top:9.2cqw}
.cv .k{font-family:'DM';font-size:1.4cqw;letter-spacing:.14em;color:var(--blue);font-weight:500;text-transform:uppercase}
.cv h1{font-family:'BG';font-weight:800;font-size:6.6cqw;line-height:1;letter-spacing:-.02em;margin:1.2cqw 0 1.4cqw;max-width:70cqw}
.two{columns:2;column-gap:2cqw}.two p{break-inside:avoid;margin-bottom:.4cqw}.cv .b{width:7cqw;height:.3cqw;background:var(--ink);margin-bottom:2cqw}
"""
def esc(s):return html.escape(s,quote=False)
def runs_html(runs,hl=False):
    o=''
    for t,b in runs:
        t=esc(t)
        o+=('<b>%s</b>'%t) if b else t
    return o
def hlarrow(txt):
    # evidenzia l'ultima parola della prima forma dopo la freccia
    m=re.search(r'(→\s*[^→.]*?\s)(\S+?)(\.|$)',txt)
    if not m:return txt
    return txt[:m.start(2)]+'<mark>'+m.group(2)+'</mark>'+txt[m.end(2):]
def blocks_html(blocks):
    o='<div class="tx">'
    for kind,runs in blocks:
        h=runs_html(runs)
        if kind=='bullet':o+='<p class="bu">%s</p>'%h
        elif kind=='sub':o+='<p class="sub">%s</p>'%h
        else:o+='<p>%s</p>'%h
    return o+'</div>'
def card_html(blocks,label='[FOCUS]',mark=True):
    t=''
    for kind,runs in blocks:
        h=runs_html(runs)
        if kind=='p' and ':' in plain1(runs)[:40]:
            lead,rest=h.split(':',1);h='<b>%s:</b>%s'%(lead,rest)
        t+=('<br>' if t else '')+(hlarrow(h) if mark and '→' in h else h)
    return '<div class="fc"><span class="lb">%s</span><span class="t">%s</span></div>'%(label,t)
def plain1(runs):return ''.join(t for t,b in runs)
def table_html(pg):
    rows=[pg['header']]+pg['rows'];nc=max(len(r) for r in rows)
    w=pg['widths'];tot=sum(w)
    cols=' '.join('%.3ffr'%(x/tot) for x in w)
    o='<div class="tbl" style="grid-template-columns:%s">'%cols
    for ri,r in enumerate(rows):
        for ci in range(nc):
            t=r[ci] if ci<len(r) else ''
            if B.only_underscores(t):t=''
            cls=[]
            if ri==0:cls.append('h')
            elif ci==0:cls.append('k')
            if ci==nc-1:cls.append('le')
            if ri==len(rows)-1:cls.append('lr')
            o+='<div class="%s">%s</div>'%(' '.join(cls),esc(t))
    return o+'</div>'
def strip_num(t):return re.sub(r'^\d+\.\s*','',t)
def slide_html(mode,eyebrow,title,body,num,k=1,doc=True,cover=None,foot='SPAGNOLO'):
    cls='s16' if mode=='v' else 'a4'
    o='<div class="sheet %s" style="--k:%.3f">'%(cls,k)
    o+='<div class="hd"><img src="data:image/png;base64,%s"><span>Spagnolo – Prof.ssa Romina Gisel Luna</span></div>'%LG
    if cover:
        o+=cover
    else:
        o+='<div class="ey">%s</div><div class="tt">%s</div><div class="bar"></div><div class="bd">%s</div>'%(esc(eyebrow),esc(title),body)
    if doc and mode=='v':o+='<div class="doc"%s></div>'%(' style="top:5.42cqw"' if cover else '')
    o+='<div class="ft"><span>%s</span><span>Pagina %d</span></div></div>'%(foot,num)
    return o
def cover_html(info):
    ag=''.join('<p class="bu">%s</p>'%esc(a) for a in info['argomenti'])
    return ('<div class="cv"><div class="k">Spagnolo · Lezione 1</div><h1>%s</h1><div class="b"></div></div>'
      '<div class="bd" style="top:25.5cqw"><div class="fc" style="width:46cqw"><span class="lb">[ARGOMENTI]</span><div class="tx two">%s</div></div></div>')%(esc(info['theme']),ag)
def page_body(pg):
    if pg['type']=='text':return blocks_html(pg['blocks'])
    o=''
    if pg.get('pre'):o+=blocks_html(pg['pre'])
    o+=table_html(pg)
    if pg.get('note'):
        t0=plain1(pg['note'][0][1]);lead=t0.split(':',1)[0] if ':' in t0[:30] else ''
        o+=card_html(pg['note'],'[%s]'%(lead.upper() if lead else 'NOTA'),mark=True)
    if pg.get('post'):o+=blocks_html(pg['post'])
    return o
