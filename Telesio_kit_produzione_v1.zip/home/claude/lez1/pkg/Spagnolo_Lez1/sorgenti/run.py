import sys,re,json,copy,os,shutil
sys.path.insert(0,'/home/claude/gen');sys.path.insert(0,'/home/claude/sp')
import gen,build as B
from playwright.sync_api import sync_playwright
items=B.applica_correzioni(B.parse_docx('/home/claude/sp/Spagnolo_Lez1.docx'))
info,secs=B.plan(items,'Spagnolo')
pages=B.build_pages(secs,avail=10**7)   # i testi li spezzo io dopo la misura; le tabelle restano intere
# unisco "testo breve + tabella" della stessa sezione/titolo
merged=[];i=0
while i<len(pages):
    p=pages[i]
    if p['type']=='text' and i+1<len(pages) and pages[i+1]['type']=='table' and pages[i+1]['title']==p['title'] and pages[i+1]['row']==p['row'] and len(p['blocks'])<=3 and not pages[i+1].get('pre'):
        q=copy.deepcopy(pages[i+1]);q['card']=p['blocks'];q['cand_split']=p['blocks'];merged.append(q);i+=2
    else:merged.append(p);i+=1
pages=merged
slides=[{'kind':'cover'}]
rows=info['intro']
slides.append({'kind':'page','pg':{'type':'text','row':info['theme'],'title':rows[0][0],'blocks':[('bullet',[(r[0],False)]) for r in rows[1:]]},'arg':0})
for p in pages:
    m=re.match(r'(\d+)',p['row']);slides.append({'kind':'page','pg':p,'arg':int(m.group(1))})
def body_of(pg):
    o=''
    if pg.get('card'):o+=gen.card_html(pg['card'],'[FOCUS]')
    return o+gen.page_body(pg)
def make(s,mode,k,num):
    if s['kind']=='cover':return gen.slide_html(mode,'','', '',num,1,True,cover=gen.cover_html(info))
    pg=s['pg'];return gen.slide_html(mode,pg['row'] if re.match(r'\d',pg['row']) else pg['row'],gen.strip_num(pg['title']),body_of(pg),num,k)
LIM=948.5
def doc(htmls,mode):
    pc='@page{size:1920px 1080px;margin:0}' if mode=='v' else '@page{size:297mm 210mm;margin:0}'
    return '<!doctype html><meta charset=utf-8><style>%s%s</style>%s'%(gen.CSS,pc,''.join(htmls))
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080})
    def bottom(s,k,num):
        open('t.html','w').write(doc([make(s,'v',k,num)],'v'));pg.goto('file:///home/claude/gen/t.html');pg.evaluate("document.fonts.ready")
        return pg.evaluate("(()=>{const e=document.querySelector('.bd');return e?e.getBoundingClientRect().bottom:0})()")
    out=[];log=[]
    idx=0
    queue=list(slides)
    while queue:
        s=queue.pop(0)
        if s['kind']=='cover':out.append((s,1));continue
        k=1.0
        while k>0.5 and bottom(s,k,3)>LIM:k=round(k-0.03,3)
        pgd=s['pg']
        if k<0.78 and pgd['type']=='text' and len(pgd['blocks'])>1:
            h=len(pgd['blocks'])//2
            a=copy.deepcopy(s);a['pg']['blocks']=pgd['blocks'][:h]
            c=copy.deepcopy(s);c['pg']['blocks']=pgd['blocks'][h:]
            queue=[a,c]+queue;continue
        if k<0.78 and pgd.get('card') and pgd['type']=='table':
            # la card separata dalla tabella
            a={'kind':'page','pg':{'type':'text','row':pgd['row'],'title':pgd['title'],'blocks':pgd['card']},'arg':s['arg']}
            c=copy.deepcopy(s);c['pg'].pop('card');queue=[a,c]+queue;continue
        if k<0.7:log.append('ATTENZIONE: %s | %s k=%.2f'%(pgd['row'],pgd['title'],k))
        out.append((s,k))
    b.close()
json.dump({'n':len(out),'log':log,'slides':[{'n':i+1,'kind':s['kind'],'arg':s.get('arg',0) if s['kind']!='cover' else -1,'row':(s['pg']['row'] if s['kind']!='cover' else ''),'title':(s['pg']['title'] if s['kind']!='cover' else info['theme']),'type':(s['pg']['type'] if s['kind']!='cover' else 'cover'),'card':bool(s['kind']!='cover' and s['pg'].get('card')),'k':k} for i,(s,k) in enumerate(out)],'info':{'theme':info['theme'],'argomenti':info['argomenti']}},open('manifest.json','w'),ensure_ascii=False,indent=1)
V=[make(s,'v',k,i+1) for i,(s,k) in enumerate(out)]
A=[make(s,'a',k,i+1) for i,(s,k) in enumerate(out)]
open('video.html','w').write(doc(V,'v'));open('a4.html','w').write(doc(A,'a'))
print(len(out),'slide');print('\n'.join(log))
