import subprocess
W='/home/claude/lez1/work';FF='ffmpeg'
def run(a):subprocess.run([FF,'-y','-loglevel','error','-nostdin']+a,check=True)
import shutil;shutil.copy(W+'/T.mp4',W+'/T_sp.mp4')
# 2) sigla + dissolvenza incrociata di 1,8 s (luminanza <20% in 330 ms) verso la lezione
D=1.8
run(['-i','/home/claude/lez1/sigla_iniziale.mp4','-i',W+'/T_sp.mp4','-filter_complex',
 f"[0:v]fps=30,scale=1920:1080,setsar=1,format=yuv420p,tpad=stop_mode=clone:stop_duration={D}[a];[1:v]fps=30,setsar=1,format=yuv420p[b];[a][b]xfade=transition=fade:duration={D}:offset=15.0[v];"
 f"[0:a]aresample=48000,aformat=channel_layouts=stereo,apad=pad_dur={D}[a0];[1:a]aresample=48000,aformat=channel_layouts=stereo[a1];[a0][a1]acrossfade=d={D}:c1=tri:c2=tri[aa]",
 '-map','[v]','-map','[aa]','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','/home/claude/lez1/Spagnolo_Lez1_PROVA_transizione_sottopancia.mp4'])
print('ok')
