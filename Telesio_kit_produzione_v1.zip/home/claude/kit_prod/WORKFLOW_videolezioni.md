# Workflow di produzione delle videolezioni — Centro Studi Telesio

Versione 1 · 2 novembre 2026 · Coordinatore del progetto: Prof.ssa Sara Zagarese
Lezione di riferimento: Spagnolo, Lezione 1 «¿De dónde eres?» (matrice grafica V4).

## 1. Come riprendere il lavoro in una nuova sessione

1. Scaricare il kit di produzione dalla release del repository delle lezioni
   (`Telesio_kit_produzione_v1.zip`, circa 22 MB: programmi, modelli, caratteri, logo, suoni) e scompattarlo nella radice: `unzip -o kit.zip -d /`.
   I percorsi interni (`/home/claude/...`) tornano come in origine.
2. Caratteri: copiare `home/claude/kit_prod/fonts/*.ttf` in `/root/.fonts/` e lanciare `fc-cache -f`.
3. Modello di trascrizione della voce (non incluso, circa 200 MB): scaricare
   `sherpa-onnx-whisper-base.tar.bz2` dalle release del progetto sherpa-onnx su GitHub
   (asr-models) e scompattarlo in `/tmp/asr/`.
4. Librerie Python richieste: playwright (già presente), numpy, scipy, Pillow, onnxruntime,
   python-docx, python-pptx, lxml, reportlab, pypdf. Programma video: ffmpeg.
5. Sigle: nel kit ci sono le sigle di apertura (`/home/claude/prev2/sigla_<materia>_premium_15s.mp4`)
   e la sigla finale di base (`/home/claude/lez1/sigla_finale.mp4`, senza avviso: l'avviso lo aggiunge il
   montaggio). Prima del montaggio copiare la sigla della materia in `/home/claude/lez1/sigla_iniziale.mp4`.
6. Leggere questo documento e le `Linee guida di produzione delle videolezioni`.

## 2. Cosa serve dalla coordinatrice per ogni lezione

| Materiale | Formato | Come si consegna |
|---|---|---|
| Testo della lezione del docente | Word (.docx): un titolo per argomento, Actividad in una parte a sé con le soluzioni | Allegato nella chat |
| Registrazione originale | Il file originale della registrazione (MP4 o MKV), **con l'audio dentro**, senza ricompressione | Release del repository delle lezioni, in pezzi da massimo 1,9 GB (`Materia_LezNN-1.mp4`, `-2`, …) |
| Segni F9 (se presenti) | File di testo esportato dalla registrazione | Allegato nella chat |
| Voci narranti | Un'unica registrazione per lezione, letta dal copione preparato in automatico | Allegato nella chat (MP3 o WAV) |
| Animazioni di approfondimento | MP4 1080p, una per argomento | Allegato nella chat o nella release |

Note:
- Non serve esportare l'audio a parte: l'audio si estrae dalla registrazione originale.
  Se la registrazione è in pezzi, i pezzi si tagliano in sequenza senza ricomprimerli.
- Le lezioni vecchie senza F9: i cambi di argomento e di slide si ricavano dalla trascrizione.
- Nomi dei file: `Materia_LezNN_tipo_descrizione` (es. `Spagnolo_Lez2_dispensa_A4.pdf`).

## 3. Le fasi, lezione per lezione

| # | Fase | Chi | Strumento nel kit | Uscita |
|---|---|---|---|---|
| 1 | Lettura del Word, correzione dei refusi evidenti (segnalati) | Automatico | `sp/build.py` | elenco contenuti |
| 2 | Slide 16:9 e dispensa A4 orizzontale dallo stesso file | Automatico | `gen/gen.py`, `gen/run.py` | `video.html`, `a4.html`, PDF |
| 3 | Scarico e unione della registrazione; audio pulito | Automatico | `orig/dl.sh` (modello), ffmpeg | `all.mkv`, `audio_clean.wav` |
| 4 | Trascrizione con i tempi; cambi di slide e di argomento (F9 o voce) | Automatico | `v5/asr.py`, `v5/asr_full.py`, `v5/seg.py`, `v5/segasr.py` | `srt.json`, tempi |
| 5 | Copione delle voci narranti (testo unico, ordine e pause) | Automatico, poi la coordinatrice genera la voce | modello: `Pacchetto_voci_Lez1.md` | copione |
| 6 | Taglio e composizione delle voci; **controllo per trascrizione** che ogni frase sia intera (nessun «Taglio», nessuna parola tronca) | Automatico | `v5/vo/compose9.py`, `v5/fixvoices.py` | `voci/*.wav` |
| 7 | Slide dinamiche con righe evidenziate a tempo di voce | Automatico | `v5/build_slides.py` | `sv_hd/` |
| 8 | Pillole e schemi guidati; schede titolo, quiz, riepilogo | Automatico | `v5/po9.py`, `v5/run_po_hd.py`, `v5/dark.py`, `v5/run_dark.py` | `po9_hd/`, `dk_hd/` |
| 9 | Montaggio 1080p con sigla, inserti e sigla finale con avviso dei diritti; volume −16 LUFS | Automatico | `v5/asm2.py` (`HD=1 python3 asm2.py go`) | video finale |
| 10 | Esercizi interattivi dalle Actividad; lettore che ferma il video | Automatico | `v5/es/build_es.py`, `player/build_player.py` | `index.html`, `esercizi.html` |
| 11 | Controlli (sezione 4) | Automatico + coordinatrice | — | lista di controllo |
| 12 | Revisione a video: la coordinatrice segnala i minuti da correggere | Coordinatrice | — | correzioni |

## 4. Controlli obbligatori prima della consegna

- **Voci narranti**: trascrivere ogni pillola e animazione nel video finale e confrontare con il copione
  (parole intere all'inizio e alla fine, nessuna parola «Taglio»).
- **Sincronia audio/video** dopo la sigla e lungo tutto il video (confronto con l'audio originale).
- **Arresti degli esercizi**: misurare l'inizio reale di ogni scheda quiz nel video finale
  (non i tempi calcolati) e impostare l'arresto 1,8 s dopo. Prova automatica di tutti gli esercizi.
- **Lettore**: parte sempre da zero; esercizi dentro il riquadro del video; barra spaziatrice e barra
  di avanzamento anche a schermo intero.
- **Slide dinamiche**: nessuna evidenziazione bloccata; la riga evidenziata segue la voce.
- **Dispensa**: testo identico alle slide del video (confronto pagina per pagina).
- **Audio**: −16 LUFS, picco reale entro −1,5 dBTP; lampeggi al massimo 3 al secondo.
- **PDF**: ogni HTML convertito in PDF deve dichiarare `<meta charset="utf-8">`
  (altrimenti accenti e simboli escono come «Â», «Ã»); controllare il testo estratto dal PDF.

## 5. Regole fisse

- Matrice V4: Blu notte #0B1530, Blu Telesio #2060AF, giallo #FFE600 solo per evidenziare,
  caratteri Bricolage Grotesque (titoli), Figtree (testo), DM Mono (etichette sigle).
- Il contenuto del docente non si cambia; si tolgono solo pause, ripetizioni, errori e parti non adatte.
- 60 minuti di video finito; sette argomenti indicativi; in ogni argomento: titolo, docente,
  animazione, pillola (13 s + schema 44 s), scheda quiz ed esercizio.
- Tabelle mai spezzate; piè di pagina solo materia e docente; mai il numero della lezione a video.
- Nei documenti per l'amministrazione: linguaggio impersonale, nessun nome di altre persone,
  nessun riferimento a costi o al numero di lezioni.

## 6. Lezioni già pronte da lavorare

Word disponibili: Spagnolo Lezioni 2, 4 e 5 (in `sp/`). Per ognuna serve la registrazione originale.
