for i in 1 2 3 4 5 6; do
  curl -sS -L -C - --retry 5 -o Spagnolo.-$i.mp4 https://github.com/zagavre-ai/Lezioni/releases/download/v1/Spagnolo.-$i.mp4 && echo done $i >> dl.log || echo fail $i >> dl.log
done
