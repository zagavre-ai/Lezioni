# Voce narrante con lo stesso motore di Vox Studio (Gemini TTS, voce Kore, stile «Docente E-Learning BES/DSA»).
# uso: python3 gemini_tts.py uscita.wav "testo"     · variabili: VOCE_G (Kore), MODELLO_G (gemini-3.8-flash-lite-tts)
# La chiave: variabile d'ambiente GEMINI_API_KEY (impostazioni dell'ambiente) o /root/.segreti/gemini_key. Mai nei kit né nei messaggi.
import sys,os,json,base64,time,urllib.request,urllib.error,wave
def _key():
    k=os.environ.get('GEMINI_API_KEY','')
    if not k and os.path.exists('/root/.segreti/gemini_key'):k=open('/root/.segreti/gemini_key').read()
    return k.strip()
KEY=_key()  # vuota = la aggiunge il «segreto di rete» dell'ambiente (intestazione x-goog-api-key)
MOD=os.environ.get('MODELLO_G','gemini-3.8-flash-lite-tts');VOX=os.environ.get('VOCE_G','Kore')  # 8/11: lite = il più economico (6 $ per 1M token audio)
# se la quota giornaliera di un modello è finita si passa al successivo (stessa voce Kore)
RISERVE=['gemini-3.8-flash-lite-tts','gemini-3.8-flash-tts']  # 8/11: MAI i modelli cari (3.1 preview 20 $, 2.5 pro)
ESAURITI=set()
STILE=os.environ.get("STILE_G","[docente di e-learning per studenti BES e DSA: dizione italiana cristallina, timbro luminoso e accogliente, brillante, chiara, coinvolgente e rassicurante, energia, calore, enfasi sulle parole chiave e scansione nitida delle parole]")  # tra parentesi quadre: è una regia, non viene letta
# Regie approvate da Sara (5/11/2026): tutte e tre vanno bene, si possono alternare.
STILI={
 'A':('gemini-3.8-flash-lite-tts','[entusiasta e coinvolgente, con enfasi sulle parole chiave, chiara e rassicurante]'),
 'B':('gemini-3.8-flash-lite-tts','[docente di e-learning per studenti BES e DSA: brillante, chiara, coinvolgente e rassicurante, con enfasi sulle parole chiave e ritmo scandito]'),
 'C':('gemini-3.8-flash-tts','[docente di e-learning per studenti BES e DSA: brillante, chiara, coinvolgente e rassicurante, con enfasi sulle parole chiave e ritmo scandito]'),
}
# Descrizione della voce Kore in Vox Studio: «Dizione italiana cristallina, timbro luminoso e accogliente. Ideale per videolezioni
# inclusive (BES/DSA) perché unisce energia, calore e scansione nitida delle parole.»
if os.environ.get('REGIA') in STILI: MOD,STILE=STILI[os.environ['REGIA']]
def tts(text,out,tries=4):
    global MOD
    body={"contents":[{"parts":[{"text":f"{STILE} {text}"}]}],
          "generationConfig":{"responseModalities":["AUDIO"],"speechConfig":{"voiceConfig":{"prebuiltVoiceConfig":{"voiceName":VOX}}}}}
    k=0
    while k<tries:
        url=f"https://generativelanguage.googleapis.com/v1beta/models/{MOD}:generateContent"+(f"?key={KEY}" if KEY else "")
        try:
            r=urllib.request.urlopen(urllib.request.Request(url,json.dumps(body).encode(),{'Content-Type':'application/json'}),timeout=300)
            d=json.load(r);p=d['candidates'][0]['content']['parts'][0]['inlineData']
            raw=base64.b64decode(p['data']);mt=p.get('mimeType','')
            if 'wav' in mt or raw[:4]==b'RIFF':open(out,'wb').write(raw)
            else:
                rate=int(mt.split('rate=')[1].split(';')[0]) if 'rate=' in mt else 24000
                with wave.open(out,'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(raw)
            with wave.open(out) as w:dd=w.getnframes()/w.getframerate()
            open('/home/claude/tts/uso.log','a').write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{MOD}\t{len(text)}\t{dd:.1f}\tOK\n");return dd
        except urllib.error.HTTPError as e:
            full=e.read().decode();msg=full[:400];open('/home/claude/tts/uso.log','a').write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{MOD}\t{len(text)}\t0\tERR{e.code}\n")
            if e.code==429 and ('per day' in full.lower() or 'PerDay' in full):
                ESAURITI.add(MOD);alt=[m for m in RISERVE if m not in ESAURITI]
                if not alt:raise RuntimeError('quota giornaliera finita su tutti i modelli')
                print('quota finita su',MOD,'→ passo a',alt[0],file=sys.stderr);MOD=alt[0];continue
            print('errore',e.code,msg[:200],file=sys.stderr);k+=1
            if e.code in (429,500,503):time.sleep(20*k);continue
            raise
        except Exception as e:
            print('errore',e,file=sys.stderr);k+=1;time.sleep(10)
    raise RuntimeError('generazione non riuscita')
if __name__=='__main__':
    print(round(tts(sys.argv[2],sys.argv[1]),2),'s')
