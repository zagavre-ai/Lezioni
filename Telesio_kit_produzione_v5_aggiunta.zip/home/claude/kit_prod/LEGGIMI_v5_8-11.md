# Kit v5 (8/11/2026, chat master) · VELOCITÀ e VOCI

Si scompatta DOPO i kit v1–v4: unzip -o /home/claude/lezioni/Telesio_kit_produzione_v5_aggiunta.zip -d /
Sigle pronte: unzip -o /home/claude/lezioni/Telesio_sigle_v1.zip -d /home/claude/  (leggi /home/claude/sigle/LEGGIMI.txt)

## Cosa c'è
- tts/gemini_tts.py: voce Kore, modello predefinito gemini-3.8-flash-lite-tts (il più economico), ripieghi SOLO lite e flash, ogni richiesta registrata in /home/claude/tts/uso.log (ora, modello, caratteri, secondi, esito). Costo misurato l'8/11: circa 1 centesimo per minuto di voce.
- tools/controllo_jingle.py: controllo dello scatto dei Quiz sul file finale (esce con errore se uno scarto supera 0,05 s).
- tools/scheda_da_timeline.py: scheda_pubblicazione.json dalla timeline (durata misurata sul file).

## Regole di velocità (obbligatorie)
1. UNA LEZIONE PER CHAT. Non si aspetta niente da nessuno: analisi → testi → voci → montaggio → codifica → controlli → consegna.
2. Sigla: già pronta (zip sigle). Mai rifarla. Se manca (Psicologia, Storia III), lascia 15 s e scrivi nel blocco.
3. Animazioni: solo quelle necessarie per arrivare a 50 minuti, massimo 2 per argomento, e con gli schemi già pronti del modello (R, S, TIT, GL, RF). Niente animazioni nuove «da zero» se la Parte è già sopra i 50 minuti.
4. Voci: TUTTI i testi prima, poi UNA sola tornata con voci_gruppi.py (export MODELLO_G=gemini-3.8-flash-lite-tts). Niente prove.
5. Quiz e testi: si mandano a Sara in un unico file e si va avanti senza aspettare.
6. Un lavoro pesante alla volta, ma la macchina non deve MAI stare ferma: mentre aspetti una risposta, lavora alla parte successiva (dispensa, quiz, test Excel).
7. Video grandi: in streaming dalla Release (ffmpeg -http_proxy "$HTTPS_PROXY" -i <url>), mai scaricati interi se oltre 1,5 GB.
8. Ogni lavoro lungo: «> log && touch .fatto», mai «| tail».
9. Controlli finali obbligatori (non si consegna senza): controllo_jingle.py senza errori, fotogrammi, peso < 400 MB, un fotogramma per pezzo guardato.
