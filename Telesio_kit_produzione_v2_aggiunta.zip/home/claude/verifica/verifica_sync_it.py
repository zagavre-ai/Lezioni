"""Verifica della sincronia tra voce del docente e righe evidenziate nelle slide.

Uso:  python3 verifica_sync.py VIDEO_FINALE.mp4 AUDIO_SORGENTE.wav SOTTOTITOLI.json RAPPORTO.html [da_s a_s]

1. Legge il video finale a 4 fotogrammi al secondo e trova, nelle slide con il docente
   (banda gialla del nome presente), quando si accende una riga evidenziata e dove sta.
2. Legge con l'OCR il testo della riga appena accesa.
3. Allinea l'audio del video finale con l'audio sorgente (correlazione) per ogni slide,
   così i tempi della trascrizione sorgente diventano tempi del video finale.
4. Cerca nella trascrizione il primo momento in cui il docente nomina la riga
   (parole della riga, con un indizio di passaggio «otra regla», «regola», ecc. subito prima).
5. Scrive un rapporto: scarto tra accensione della riga e voce; segnala ogni scarto > 1,5 s.
"""
import sys, os, re, json, subprocess, unicodedata, difflib, html
import numpy as np
from scipy.signal import fftconvolve

FPS = 4; W, H = 640, 360
VID, SRC, SUB, OUT = sys.argv[1:5]
T0 = float(sys.argv[5]) if len(sys.argv) > 5 else 0.0
T1 = float(sys.argv[6]) if len(sys.argv) > 6 else 1e9
TOL = 2.0

def norm(s):
    s = unicodedata.normalize('NFD', s.lower())
    s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-zñ0-9 ]+', ' ', s)

STOP = set(norm('el la los las un una unos unas de del al y e o a en con por para que se es son lo le les su sus mi tu yo il lo gli i di da per come più non ma ed una uno questo esta este eso esto muy también tambien ejemplo ejemplos esempio esempi regla regola cuando quando palabra parola').split())
MARK = [norm(x) for x in ['otra regla', 'la regla', 'regola', "l'altra", 'altra regola', 'otro caso', 'segunda', 'tercera', 'ahora vemos', 'vediamo', 'por ejemplo', 'per esempio', 'también', 'anche']]

# ---------- 1. eventi visivi ----------
def frames():
    dur = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', VID], capture_output=True, text=True).stdout)
    a, b = max(0, T0), min(dur, T1)
    p = subprocess.Popen(['ffmpeg', '-v', 'error', '-ss', str(a), '-i', VID, '-t', str(b - a), '-vf', f'fps={FPS},scale={W}:{H}', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
    n = 0; sz = W * H * 3
    while True:
        buf = p.stdout.read(sz)
        if len(buf) < sz: break
        yield a + n / FPS, np.frombuffer(buf, np.uint8).reshape(H, W, 3); n += 1

def analyse(fr):
    R, G, B = [fr[..., i].astype(np.int16) for i in range(3)]
    yel = (R > 230) & (G > 205) & (B < 185) & (R - B > 60)
    name = yel[140:200, 480:630].sum() > 2500           # banda gialla del nome: slide con docente
    white = fr[:, 2:12].mean() > 235
    if not (name and white): return None
    c = yel[:, 15:470].sum(1)
    rows = np.where(c > 250)[0]
    if len(rows) == 0: return ('none', None)
    # banda principale: gruppo contiguo più lungo
    groups = np.split(rows, np.where(np.diff(rows) > 7)[0] + 1)
    g = max(groups, key=len)
    if len(g) < 5: return ('none', None)
    return ('row', (int(g[0]), int(g[-1])))

events = []; prev = None; stable = 0; cand = None; slide_on = False; spans = []; prevg = None
for t, fr in frames():
    r = analyse(fr)
    if r is None:
        if slide_on: spans[-1][1] = t
        slide_on = False; prev = None; cand = None; prevg = None; continue
    g = fr[20:340:4, 15:470:4].mean(2)
    if slide_on and prevg is not None and np.abs(g - prevg).mean() > 14:   # cambio di slide: nuovo tratto
        spans.append([t, t]); prev = None; cand = None
    prevg = g
    if not slide_on: spans.append([t, t]); slide_on = True
    spans[-1][1] = t
    key = None if r[0] == 'none' else (r[1][0] // 4, r[1][1] // 4)
    if key == cand: stable += 1
    else: cand = key; stable = 1
    if stable == 2 and key != prev:
        if key is not None: events.append({'t': round(t - 1 / FPS, 2), 'y': r[1]})
        prev = key
print('slide con docente:', len(spans), ' righe accese:', len(events), flush=True)

# ---------- 2. OCR della riga ----------
def ocr(ev):
    t = ev['t'] + 1.5; yc = (ev['y'][0] + ev['y'][1]) / 2 * 3
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-ss', str(t), '-i', VID, '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], capture_output=True).stdout
    fr = np.frombuffer(raw, np.uint8).reshape(1080, 1920, 3)
    R, G, B = [fr[..., i].astype(np.int16) for i in range(3)]
    yel = (R > 230) & (G > 205) & (B < 185) & (R - B > 60)
    c = yel[:, 45:1455].sum(1); rows = np.where(c > 700)[0]
    if len(rows):
        groups = np.split(rows, np.where(np.diff(rows) > 20)[0] + 1)
        g = min(groups, key=lambda g: 0 if g[0] <= yc <= g[-1] else min(abs(g[0] - yc), abs(g[-1] - yc)))
        y0, y1 = int(g[0]), int(g[-1]); ev['y'] = [y0 // 3, y1 // 3]
    else:
        y0, y1 = int(ev['y'][0] * 3), int(ev['y'][1] * 3)
    from PIL import Image
    im = Image.fromarray(fr[max(0, y0 - 4):y1 + 5, 45:1455]).convert('L').point(lambda v: 0 if v < 160 else 255)
    im = im.resize((im.width * 2, im.height * 2)); png = '/tmp/_vs_row.png'; im.save(png)
    txt = subprocess.run(['tesseract', png, '-', '--psm', '6', '-l', 'eng'], capture_output=True, text=True).stdout
    return ' '.join(txt.split())
for ev in events: ev['txt'] = ocr(ev)

# ---------- 3. allineamento final -> sorgente ----------
def load(f, a, d, sr=2000):
    x = subprocess.run(['ffmpeg', '-v', 'error', '-ss', str(max(0, a)), '-t', str(d), '-i', f, '-ac', '1', '-ar', str(sr), '-f', 'f32le', '-'], capture_output=True).stdout
    return np.frombuffer(x, np.float32)
SRCALL = None
def offset_at(t):
    snip = load(VID, t - 6, 12); snip = snip - snip.mean()
    lo = max(0, t - 900); seg = SRCALL[int(lo * 2000):int((t + 300) * 2000)]
    if len(seg) < len(snip) or snip.std() < 1e-4: return None, 0
    c = fftconvolve(seg, snip[::-1], 'valid')
    e = fftconvolve(seg * seg, np.ones(len(snip)), 'valid'); e = np.maximum(e, 0.2 * np.median(np.abs(e)) + 1e-9)
    n = np.sqrt(e * (snip * snip).sum())
    r = c / n; i = int(r.argmax())
    return lo + i / 2000 - (t - 6), float(r[i])      # sorgente = finale + offset
for ev in events: ev['off'], ev['corr'] = 0.0, 1.0

# ---------- 4. voce: parole con tempi (trascrizione con tempi per parola, file SUB in formato jsonl) ----------
WORDS=[]
for l in open(SUB):
    d=json.loads(l); WORDS+= [(float(t),w) for t,w in d['w']]
WT=np.array([t for t,_ in WORDS]); WN=[norm(w) for _,w in WORDS]
def kws(txt):
    w = [x for x in norm(txt).split() if len(x) >= 5 and x not in STOP and not x.isdigit()]
    return list(dict.fromkeys(w))
def near(k,x): return x==k or (len(k)>=5 and len(x)>=5 and (x[:5]==k[:5])) or difflib.SequenceMatcher(None,k,x).ratio()>=.82
for ev in events: ev['kw']=kws(ev['txt']); ev['voce']=None; ev['match']=''; ev['delta']=None
from collections import Counter
DF=Counter(WN)
def rare(k): return len(k)>=7 and sum(v for x,v in DF.items() if x[:6]==k[:6])<=4
for sp in spans:
    E=[e for e in events if sp[0]-0.5<=e['t']<=sp[1]+0.5]
    prev=sp[0]-20
    for e in E:
        lo=max(prev,e['t']-25); hi=e['t']+15
        idx=np.where((WT>=lo)&(WT<=hi))[0]; ks=e['kw'][:10]
        f=None
        for j in idx:
            hk=[k for k in ks if near(k,WN[j])]
            if not hk: continue
            if any(rare(k) for k in hk): f=j; break
            win_=[WN[q] for q in idx if WT[j]<=WT[q]<=WT[j]+5]
            got=set(k for k in ks for x in win_ if near(k,x))
            if len(got)>=2: f=j; break
        if f is None: continue
        e['voce']=round(float(WT[f]),2); e['match']='«'+' '.join(w for _,w in WORDS[max(0,f-3):f+7])+'»'
        e['delta']=round(e['t']-e['voce'],1); prev=e['voce']
    print('  slide',round(sp[0],1),'righe',len(E),flush=True)

# ---------- 5. rapporto ----------
bad = [e for e in events if e.get('delta') is not None and (e['delta'] > 1.5 or e['delta'] < -15)]
unk = [e for e in events if e.get('delta') is None]
def mm(t): return '%d:%04.1f' % (t // 60, t % 60)
rows = ''.join(f"<tr class='{'ko' if e in bad else ('nd' if e in unk else 'ok')}'><td>{mm(e['t'])}</td><td>{html.escape(e['txt'][:90])}</td><td>{mm(e['voce']) if e['voce'] is not None else '—'}</td><td>{'' if e['delta'] is None else ('%+.1f s' % e['delta'])}</td><td>{html.escape(e['match'][:80])}</td></tr>" for e in events)
doc = f"""<!doctype html><meta charset="utf-8"><title>Verifica sincronia</title><style>body{{font:14px system-ui;margin:24px;color:#0B1530}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #DDE3EE;padding:4px 6px;text-align:left}}tr.ko{{background:#FFE3E3}}tr.nd{{background:#FFF6D6}}h1{{font-size:20px}}</style>
<h1>Verifica sincronia voce / righe evidenziate</h1><p>{html.escape(os.path.basename(VID))} · righe controllate: {len(events)} · <b>fuori tolleranza (in ritardo oltre 1,5 s o in anticipo oltre 15 s): {len(bad)}</b> · da controllare a mano (voce non trovata): {len(unk)}</p>
<p>Scarto = accensione della riga − prima parola chiave della riga detta dalla docente (trascrizione con tempi per parola, precisione circa ±0,2 s). Negativo: la riga si accende mentre la docente introduce la frase; positivo: la riga arriva tardi.</p>
<table><tr><th>Riga accesa</th><th>Testo della riga (OCR)</th><th>Voce</th><th>Scarto</th><th>Frase trovata</th></tr>{rows}</table>"""
open(OUT, 'w').write(doc)
json.dump(events, open(OUT + '.json', 'w'), ensure_ascii=False, indent=1)
print('fuori tolleranza:', len(bad), ' non trovate:', len(unk), ' rapporto:', OUT)
for e in bad: print('  KO', mm(e['t']), '%+.1f s' % e['delta'], e['txt'][:60])
