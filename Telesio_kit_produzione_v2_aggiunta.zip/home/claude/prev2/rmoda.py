import subprocess,os,shutil,sys,json
from playwright.sync_api import sync_playwright
cfg=json.loads(sys.argv[1]); out=sys.argv[2]; ID=sys.argv[3] if len(sys.argv)>3 else "mo"; AUD="a_"+ID+".wav"
with sync_playwright() as p:
    b=p.chromium.launch(args=["--allow-file-access-from-files"]);pg=b.new_page(viewport={"width":1920,"height":1080})
    pg.goto("file:///home/claude/prev2/page_moda.html")
    pg.evaluate("async()=>{await document.fonts.load('800 100px \"Bricolage Grotesque\"');await document.fonts.load('500 30px \"DM Mono\"');await document.fonts.load('700 44px \"Figtree\"');await new Promise(r=>{if(LG.complete)r();else LG.onload=r})}")
    pg.evaluate("c=>{window.MODA=c}",cfg)
    d="/tmp/fr_mo";shutil.rmtree(d,ignore_errors=True);os.makedirs(d)
    for i in range(450):
        pg.evaluate(f"draw('{ID}',{i/30})");pg.screenshot(path=f"{d}/{i:04d}.png")
    subprocess.run(["ffmpeg","-y","-loglevel","error","-framerate","30","-i",f"{d}/%04d.png","-i",AUD,"-c:v","libx264","-preset","medium","-crf","16","-pix_fmt","yuv420p","-c:a","aac","-b:a","192k","-shortest",out],check=True)
    shutil.rmtree(d);b.close()
