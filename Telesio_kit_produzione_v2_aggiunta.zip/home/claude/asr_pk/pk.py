# Trascrizione con parole e tempi (Parakeet TDT 0.6b v3, onnxruntime puro)
import numpy as np, onnxruntime as ort, wave, sys, json, os
D='/tmp/asr/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8/'
TOK=[l.rstrip('\n').rsplit(' ',1)[0] for l in open(D+'tokens.txt',encoding='utf-8')]
BLANK=len(TOK)-1; DUR=[0,1,2,3,4]
so=ort.SessionOptions(); so.intra_op_num_threads=2
ENC=ort.InferenceSession(D+'encoder.int8.onnx',so,providers=['CPUExecutionProvider'])
DEC=ort.InferenceSession(D+'decoder.int8.onnx',so,providers=['CPUExecutionProvider'])
JOI=ort.InferenceSession(D+'joiner.int8.onnx',so,providers=['CPUExecutionProvider'])

def hz2mel(f):
    f=np.asarray(f,float); m=f/(200/3); lin=1000/(200/3); ls=np.log(6.4)/27
    return np.where(f>=1000, lin+np.log(np.maximum(f,1e-9)/1000)/ls, m)
def mel2hz(m):
    m=np.asarray(m,float); lin=1000/(200/3); ls=np.log(6.4)/27
    return np.where(m>=lin, 1000*np.exp(ls*(m-lin)), m*(200/3))
def melfb(sr=16000,n_fft=512,n_mels=128):
    fft=np.linspace(0,sr/2,n_fft//2+1); mp=mel2hz(np.linspace(hz2mel(0),hz2mel(sr/2),n_mels+2))
    fd=np.diff(mp); r=mp[:,None]-fft[None,:]; W=np.zeros((n_mels,len(fft)))
    for i in range(n_mels):
        lo=-r[i]/fd[i]; hi=r[i+2]/fd[i+1]; W[i]=np.maximum(0,np.minimum(lo,hi))
    W*= (2.0/(mp[2:n_mels+2]-mp[:n_mels]))[:,None]
    return W.astype(np.float32)
FB=melfb(); WIN=np.hanning(401)[:-1].astype(np.float32)  # hann periodic 400
def feats(x):
    x=np.append(x[0],x[1:]-0.97*x[:-1]).astype(np.float32)
    x=np.pad(x,(256,256),mode='constant')
    n=1+(len(x)-512)//160
    idx=np.arange(512)[None,:]+160*np.arange(n)[:,None]
    fr=x[idx]; w=np.zeros(512,np.float32); w[56:456]=WIN
    sp=np.abs(np.fft.rfft(fr*w,axis=1))**2
    m=np.log(sp@FB.T+2**-24).T  # 128 x n
    mu=m.mean(1,keepdims=True); sd=m.std(1,ddof=1,keepdims=True)+1e-5
    return ((m-mu)/sd).astype(np.float32)

def dec_step(tok,st):
    o=DEC.run(None,{'targets':np.array([[tok]],np.int32),'target_length':np.array([1],np.int32),'states.1':st[0],'onnx::Slice_3':st[1]})
    return o[0],(o[2],o[3])
def transcribe(x,t0=0.0):
    f=feats(x)[None]
    enc,el=ENC.run(None,{'audio_signal':f,'length':np.array([f.shape[2]],np.int64)})
    T=int(el[0]); st=(np.zeros((2,1,640),np.float32),np.zeros((2,1,640),np.float32))
    d,st2=dec_step(BLANK,st); out=[]; t=0; emitted=0
    while t<T:
        lg=JOI.run(None,{'encoder_outputs':enc[:,:,t:t+1],'decoder_outputs':d})[0][0,0,0]
        k=int(np.argmax(lg[:BLANK+1])); du=DUR[int(np.argmax(lg[BLANK+1:]))]
        if k!=BLANK:
            out.append((t0+t*0.08,TOK[k])); d,st2n=dec_step(k,st2); st2=st2n; emitted+=1
            if du==0 and emitted>=5: du=1
        else:
            if du==0: du=1
        if du>0: emitted=0
        t+=du
    return out
def words(toks):
    W=[]
    for t,s in toks:
        if s.startswith('<|') : continue
        if s.startswith('▁') or not W: W.append([t,s.lstrip('▁')])
        else: W[-1][1]+=s
    return [(round(t,2),w) for t,w in W if w]
def load(p):
    w=wave.open(p); assert w.getframerate()==16000
    x=np.frombuffer(w.readframes(w.getnframes()),np.int16).astype(np.float32)/32768
    if w.getnchannels()==2: x=x.reshape(-1,2).mean(1)
    return x
if __name__=='__main__':
    x=load(sys.argv[1]); out=sys.argv[2]; lo=float(sys.argv[3]) if len(sys.argv)>3 else 0
    CH=24.0; sr=16000; e=np.convolve(x**2,np.ones(1600)/1600,'same')
    t=lo; T=len(x)/sr
    with open(out,'a') as o:
        while t<T-0.2:
            b=min(T,t+CH)
            if b<T:  # taglia nel punto più silenzioso tra b-4 e b
                a0=int((b-4)*sr); a1=int(b*sr); b=(a0+int(np.argmin(e[a0:a1:160]))*160)/sr
            seg=x[int(t*sr):int(b*sr)]
            ws=words(transcribe(seg,t)) if np.abs(seg).max()>0.01 else []
            o.write(json.dumps({'t':round(t,2),'e':round(b,2),'w':ws},ensure_ascii=False)+'\n'); o.flush(); t=b
