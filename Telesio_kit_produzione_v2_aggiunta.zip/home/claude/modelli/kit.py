import os,re,json,asyncio,html as H
from playwright.async_api import async_playwright
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color
from pypdf import PdfReader,PdfWriter
LOGO=open('/home/claude/logo/out/Telesio_logo_blu.svg').read()
LOGO=re.sub(r'<\?xml.*?\?>','',LOGO);LOGO=re.sub(r'<title>.*?</title>','',LOGO)
LOGO=re.sub(r'(<svg[^>]*?)\swidth="[^"]*"',r'\1',LOGO,1);LOGO=re.sub(r'(<svg[^>]*?)\sheight="[^"]*"',r'\1',LOGO,1)
LOGO=LOGO.replace('<svg','<svg class="lg"',1)
CSS='''
@page{size:%(W)smm %(H)smm;margin:0}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#fff}
body{font-family:'Figtree',Arial,sans-serif;color:#0B1530;font-size:9.5pt;line-height:1.35;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.pg{width:%(W)smm;height:%(H)smm;position:relative;padding:14mm 15mm 0 15mm;page-break-after:always;overflow:hidden}
.hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:.6pt solid #C9D0DC;padding-bottom:2.5mm;margin-bottom:7mm}
.lg{height:9mm;width:auto;display:block}
.hl{font:800 7pt 'Figtree';letter-spacing:.16em;text-transform:uppercase;color:#2060AF}
.ft{position:absolute;left:15mm;right:15mm;bottom:10mm;border-top:.6pt solid #C9D0DC;padding-top:2mm;display:flex;justify-content:space-between;font-size:6.6pt;color:#2060AF}
.ft b{color:#0B1530;font-weight:800}
h1{font:800 22pt/1.08 'Bricolage Grotesque';letter-spacing:-.02em;color:#0B1530}
h1+.bar,h2+.bar{width:20mm;height:1.3mm;background:#2060AF;border-radius:1mm;margin:3mm 0 6mm}
h2{font:800 14pt/1.15 'Bricolage Grotesque';letter-spacing:-.01em}
h2 small{font:800 8pt 'Figtree';color:#2060AF;letter-spacing:.08em;margin-left:2mm}
.sec{background:#0B1530;color:#fff;font:800 7.6pt 'Figtree';letter-spacing:.1em;text-transform:uppercase;padding:1.6mm 2.4mm;border-radius:1.2mm 1.2mm 0 0;margin-top:3.2mm}
.lab{font:800 7pt 'Figtree';letter-spacing:.14em;text-transform:uppercase;color:#2060AF;margin:4mm 0 1.6mm}
table{width:100%%;border-collapse:collapse;table-layout:fixed}
th{background:#E9EFF7;color:#0B1530;font:800 6.8pt 'Figtree';letter-spacing:.06em;text-transform:uppercase;text-align:left;padding:1.4mm 1.8mm;border:.5pt solid #DDE3EE}
table.dk th{background:#0B1530;color:#fff;border-color:#0B1530}
td{border:.5pt solid #DDE3EE;padding:1.2mm 1.8mm;vertical-align:middle;font-size:8.6pt}
td.k{background:#E9EFF7;color:#2060AF;font-weight:800;font-size:8pt}
td.n{text-align:center;font-weight:800;color:#2060AF;width:8mm}
.f{display:block;width:100%%;height:7mm}
.cb{display:inline-block;width:3.4mm;height:3.4mm;border:.8pt solid #2060AF;border-radius:.6mm;vertical-align:-0.6mm;margin-right:1.2mm;background:#fff}
.opt{display:inline-block;margin-right:3mm;white-space:nowrap;font-size:8pt}
.box{background:#EEF0F4;border-radius:2mm;padding:3mm 4mm;margin-top:4mm;font-size:8.4pt}
.box b.t{display:block;font:800 7pt 'Figtree';letter-spacing:.14em;text-transform:uppercase;color:#2060AF;margin-bottom:1.2mm}
.yl{display:inline-block;background:linear-gradient(transparent 62%%,#FFE600 62%%)}
'''
FOOT='<div class="ft"><span><b>Centro Studi Telesio</b> · Via Monte Napoleone, 8 – 20121 Milano (MI) · Tel. +39 0240130356 · Cell. +39 351 7945556 · info@centrostuditelesio.it</span><span><b>Pagina %d</b></span></div>'
def page(label,body,n):
    return f'<div class="pg"><div class="hd">{LOGO}<span class="hl">{H.escape(label)}</span></div>{body}{FOOT%n}</div>'
def doc(pages,W=210,Hh=297,title='Modello'):
    return f'<!doctype html><html lang="it"><head><meta charset="utf-8"><title>{H.escape(title)}</title><style>{CSS%dict(W=W,H=Hh)}</style></head><body>{"".join(pages)}</body></html>'
def F(name,cls='f',style='',c='',fs=''):return f'<span class="{cls}" data-f="{name}" data-t="text" style="{style}"'+(f' data-c="{c}"' if c else '')+(f' data-fs="{fs}"' if fs else '')+'></span>'
def C(name,label=''):return f'<span class="opt"><span class="cb" data-f="{name}" data-t="check"></span>{H.escape(label)}</span>' if label else f'<span class="cb" data-f="{name}" data-t="check"></span>'
async def _render(html_path,pdf_path,W,Hh):
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':900,'height':1200})
        await pg.goto('file://'+html_path);await pg.evaluate('document.fonts.ready');await pg.wait_for_timeout(500)
        boxes=await pg.evaluate('''()=>{const P=[...document.querySelectorAll('.pg')];const out=[];P.forEach((p,i)=>{const r0=p.getBoundingClientRect();p.querySelectorAll('[data-f]').forEach(e=>{const r=e.getBoundingClientRect();out.push({p:i,n:e.dataset.f,t:e.dataset.t,x:r.left-r0.left,y:r.top-r0.top,w:r.width,h:r.height,c:e.dataset.c||'#0B1530',fs:e.dataset.fs||''})})});return {n:P.length,pw:r0w(P[0]),boxes:out};function r0w(p){const r=p.getBoundingClientRect();return [r.width,r.height]}}''')
        await pg.pdf(path=pdf_path,width=f'{W}mm',height=f'{Hh}mm',print_background=True,margin=dict(top='0',bottom='0',left='0',right='0'))
        await b.close();return boxes
def build(name,pages,label_title,W=210,Hh=297,outdir='/home/claude/modelli/out'):
    os.makedirs(outdir,exist_ok=True)
    hp=f'/home/claude/modelli/{name}.html';open(hp,'w').write(doc(pages,W,Hh,label_title))
    base=f'/home/claude/modelli/{name}_base.pdf'
    info=asyncio.run(_render(hp,base,W,Hh))
    pw,ph=info['pw'];k=0.75
    Wpt,Hpt=W/25.4*72,Hh/25.4*72
    ov=f'/home/claude/modelli/{name}_ov.pdf';c=canvas.Canvas(ov,pagesize=(Wpt,Hpt))
    byp={}
    for bx in info['boxes']:byp.setdefault(bx['p'],[]).append(bx)
    seen=set()
    for i in range(info['n']):
        for bx in byp.get(i,[]):
            nm=bx['n'];assert nm not in seen,nm;seen.add(nm)
            x=bx['x']*k;w=bx['w']*k;h=bx['h']*k;y=Hpt-(bx['y']*k)-h
            if bx['t']=='check':
                c.acroForm.checkbox(name=nm,x=x,y=y,size=min(w,h),buttonStyle='check',borderWidth=0,borderColor=None,fillColor=None,textColor=HexColor('#0B1530'),forceBorder=False)
            else:
                # tutti i campi vanno a capo da soli (anche in Anteprima del Mac): multiline + carattere fisso
                fsz=float(bx['fs']) if bx['fs'] else (10 if h>24 else 7.5)
                c.acroForm.textfield(name=nm,x=x,y=y,width=w,height=h,borderWidth=0,borderColor=None,fillColor=None,textColor=HexColor(bx['c']),fontName='Helvetica',fontSize=fsz,fieldFlags='multiline',forceBorder=False)
        c.showPage()
    c.save()
    rb=PdfReader(base);w=PdfWriter(clone_from=ov)
    for i,pgo in enumerate(w.pages):pgo.merge_page(rb.pages[i],over=False)
    w.set_need_appearances_writer(True)
    from pypdf.generic import NameObject,DictionaryObject
    zd=w._add_object(DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/ZapfDingbats')}))
    w._root_object['/AcroForm']['/DR']['/Font'][NameObject('/ZaDb')]=zd
    out=f'{outdir}/{name}.pdf';w.write(out)
    return out,len(seen),info['n']
