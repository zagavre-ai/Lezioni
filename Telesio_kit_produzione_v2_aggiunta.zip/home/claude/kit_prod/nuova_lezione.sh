#!/bin/bash
# Crea la cartella di lavoro di una lezione nuova copiando il modello (Tecnologie Lez1) e scarica i file dalla Release.
# uso: ./nuova_lezione.sh <tag_release> "<video.mp4>" "<testo.pdf>" "<domande.xlsx>"
# es.: ./nuova_lezione.sh moda-tecnologie-III-lez02 "Lezione 2.mp4" "Lezione 2.pdf" "Lezione 2.xlsx"
set -e
TAG="$1"; V="$2"; P="$3"; X="$4"; M=/home/claude/moda_tec; D=/home/claude/lezioni/$TAG
[ -n "$TAG" ] || { echo "uso: $0 tag video pdf xlsx"; exit 1; }
mkdir -p "$D"/{orig,audio,voci/wav,an,es,po,dk,sv,w2,consegna,anteprima,fr}
cd $M
for f in align.py align_s.py coverage.py sync.py build_blocks.py struttura.py estrai_pdf.py estrai_quiz.py gen_moda.py render_slides.py \
         comp.sh full2.sh make_sting.py asm_moda2.py build_player_moda.py run_dark_moda.py run_dark2.py po_moda.py show_s.py show_b.py \
         check_align.py prepara_lezione.sh test_player.py redo7a.sh redo7.sh redo8.sh make_scorm.py; do
  sed "s#/home/claude/moda_tec#$D#g" "$f" > "$D/$f"; done
for f in an/anim.html an/render_an.py an/render_extra.py es/build_es_moda.py voci/cut_voci.py voci/estese_P1.py voci/importa_voce_esterna.py voci/prepara_testi_voce.py an/render_rip.py; do
  sed "s#/home/claude/moda_tec#$D#g" "$f" > "$D/$f"; done
chmod +x "$D"/*.sh
cp cam_mask.png cam_ring.png "$D/"; cp audio/bed.wav "$D/audio/bed_modello.wav"
echo '{}' > "$D/override_s.json"; echo '{}' > "$D/numeri_chiave.json"
U=https://github.com/zagavre-ai/Lezioni/releases/download/$TAG
enc(){ python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))" "$1"; }
[ -n "$V" ] && curl -sS -L --retry 5 -C - -o "$D/orig/lez1.mp4" "$U/$(enc "$V")"
[ -n "$P" ] && curl -sS -L --retry 5 -o "$D/lez1.pdf" "$U/$(enc "$P")"
[ -n "$X" ] && curl -sS -L --retry 5 -o "$D/lez1.xlsx" "$U/$(enc "$X")"
ls -la "$D/orig" "$D"/lez1.* 2>/dev/null || true
echo "CARTELLA PRONTA: $D"
