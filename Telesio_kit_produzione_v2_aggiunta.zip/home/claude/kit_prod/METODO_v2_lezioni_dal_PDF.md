# Metodo v2 — Lezioni registrate con il PDF della docente
Centro Studi Telesio · versione 2 · 4 novembre 2026 · Coordinatrice: Prof.ssa Sara Zagarese
Lezione modello approvata: **Tecnologie dei materiali (Prof.ssa Caputi), Lezione 1 «Preparazione · parte I», Parte 1**
(cartella `/home/claude/moda_tec`). Tutto ciò che segue è stato provato su quella lezione.

> Regola della coordinatrice (4/11/2026): «molto molto bene la sincronizzazione, **non cambiare mai più questa impostazione**
> e applicala a tutti i pacchetti». Il metodo di sincronia del §4 non si modifica.

---

## 0. Le regole che non si discutono

1. **Le parole della docente non si tagliano e non si cambiano.** Si tolgono solo pause, inizi e fini a vuoto. Nessun riassunto.
2. **Le slide mostrano solo ciò che la docente dice** (frasi del suo PDF che pronuncia). Le parti del PDF che non dice restano
   nella dispensa e, se utili, diventano **animazioni con voce narrante** (testo preso dal PDF, senza aggiunte).
3. **Sincronia al secondo** (§4): ogni frase si accende quando la docente comincia a introdurla; i tagli solo nelle pause.
4. **Niente spagnolo né altre lingue** nelle grafiche (es. «RIPASSO», mai «REPASO»). **Niente numero di lezione** nei materiali.
5. **BES/DSA**: caratteri grandi (Figtree/Bricolage), contrasto alto, una idea per card, evidenziazione gialla, niente muri di testo.
6. **Audio versione B** e **correzione colore della webcam** su tutte le lezioni (§3, §6).
7. Prima di consegnare: **controlla tu** (fotogrammi, trascrizione dei tagli, player). Di' sempre cosa hai verificato.

## 1. Avvio di una sessione nuova

```bash
GIT_LFS_SKIP_SMUDGE=1 git clone --depth 1 https://github.com/zagavre-ai/lezioni /tmp/lz
unzip -o /tmp/lz/Telesio_kit_produzione_v1.zip -d /
unzip -o /tmp/lz/Telesio_kit_produzione_v2_aggiunta.zip -d /     # questo metodo + lezione modello
mkdir -p /root/.fonts && cp /home/claude/kit_prod/fonts/*.ttf /root/.fonts/ && fc-cache -f
# trascrizione (Parakeet TDT 0.6b v3, circa 490 MB)
mkdir -p /tmp/asr && cd /tmp/asr && curl -sS -L -O https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8.tar.bz2 && tar xjf sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8.tar.bz2
pip install --break-system-packages onnxruntime pdfplumber openpyxl pypdf reportlab 2>/dev/null || true
```
Prova veloce della trascrizione: `cd /home/claude/asr_pk && python3 pk.py it.wav /tmp/t.jsonl 0`.

Cartella di una lezione nuova (copia gli script della lezione modello e scarica i file dalla Release):
```bash
/home/claude/kit_prod/nuova_lezione.sh <tag> "<video>" "<pdf>" "<excel>"
```
I nomi dei file sono quelli **mostrati nella Release** (GitHub cambia gli spazi in punti: «Lezione 2.mp4» → «Lezione.2.mp4»).
La lezione finisce in `/home/claude/lezioni/<tag>/` con `orig/lez1.mp4`, `lez1.pdf`, `lez1.xlsx` (i nomi interni restano «lez1»).

Spazio su disco: circa 13 GB liberi. Una lezione alla volta; a consegna fatta cancella `sv/`, `w2/`, `po/*/`, `dk/*/`.

## 2. Che cosa si produce (struttura del video)

Ogni file della docente = **una nostra lezione**. Se supera ~75 minuti → **Parte 1 / Parte 2** (circa 45–55 min l'una).

| Blocco | Contenuto |
|---|---|
| Sigla della materia (15 s) | `sigle/Sigla_<materia>_15s.mp4` (le 7 della Caputi sono pronte) |
| Saluto INTRO | se la docente non saluta, voce narrante sulla copertina |
| Per ogni argomento | titolo (T) → docente con slide (D) → [animazioni AN dove servono] → RIPASSO (R) → **schema di ripasso con voce** (S) → quiz (Q) |
| Fine parte | **glossario animato** delle parole chiave (GL) → **ripasso finale** animato (RF) → card FINE (FIN) → sigla finale |
| Parte 2 | si apre con lo **«spiegone»** (RIP): ripasso animato della Parte 1 |

Transizioni e jingle come Spagnolo (`asm_moda2.py`): `circleopen/circleclose` per i titoli, `wipeleft` verso il ripasso,
`fade` verso lo schema, `zoomin` verso il quiz. Ogni inserto è introdotto dal nostro jingle. Sotto gli schemi e le animazioni
lunghe c'è la musica leggera (`audio/bed.wav`, ricavata dal jingle della materia). Ai cambi di sottoargomento un jingle breve
sotto la voce della docente (`make_sting.py`).

## 3. Preparazione (automatica)

Dalla cartella della lezione: `./prepara_lezione.sh`. Fa:
1. **audio versione B**: `highpass=f=80, arnndn (sh.rnnn), loudnorm I=-16 TP=-1.5 LRA=11` → `audio/audio_B_full.wav`;
2. trascrizione con parole e tempi → `pk.jsonl`;
3. testo del PDF con grassetti → `pdf_lines.json` → `blocks.json` (`build_blocks.py`; salta la copertina e le righe con
   carattere < 14, cioè i testi dentro le tabelle-immagine: controlla che valga anche per il PDF nuovo).

## 4. Struttura e SINCRONIA (metodo approvato — non cambiare)

1. **`struttura.py`** (a mano, leggendo `blocks.txt` e il PDF): `ARG` = gli argomenti (primo blocco, titolo), `SUB` = i
   sottotitoli delle slide, eventuali tabelle-immagine trascritte (`INSERT_AFTER`). Poi `python3 struttura.py` → `units.json`.
2. `python3 estrai_quiz.py lez1.xlsx` → `quiz_raw.json` (ogni domanda assegnata al suo argomento: controlla).
3. Parlato: `python3 align.py` → `python3 coverage.py` → `python3 sync.py` → `sync.json` (frasi del PDF che la docente dice).
4. **Allineamento per frasi**: `python3 align_s.py` → `align_s.json` e `sync2.json`. Ogni frase della docente è assegnata, in
   ordine, alla frase del PDF che sta spiegando; la frase del PDF si accende **all'inizio della frase della docente che la
   introduce** (le frasi di passaggio vanno avanti, le chiusure brevi restano indietro).
5. **Revisione manuale obbligatoria** di tutti gli inizi di argomento e dei cambi di slide: `python3 align_s.py <da> <a>`
   e `show_s.py` stampano frase per frase testo del PDF e parole della docente con i tempi. Le correzioni vanno **solo** in
   `override_s.json` (`"indice": secondi` · `"prev"` · `"w:parola@secondi"`), poi si rilancia `align_s.py`.
6. Tagli: sempre 0,15 s prima dell'inizio della frase (`cut()` in `asm_moda2.py`), mai a metà frase.
7. Dopo il montaggio: trascrivi 6 s intorno a ogni taglio e guarda i fotogrammi dei cambi di argomento.

## 5. Slide (impaginazione v3 approvata: proposte A+B)

`gen_moda.py` (modello Telesio V4): **una card per frase, massimo 3 card per slide**, numerate; la frase in corso è in primo
piano (bordo blu e alone giallo), le altre restano visibili ma attenuate; le frasi introduttive («si dividono in:») sono
sottotitoli blu sottolineati in giallo; gli elenchi sono card con pallino. **Numeri chiave** a lato (proposta B): percentuali,
misure, intervalli, ognuno con la sua parola fondamentale; si illuminano quando la docente ne parla. I numeri vengono
estratti in automatico, ma **vanno ricontrollati** e corretti in `numeri_chiave.json` (`"indice":[["valore","unità","etichetta"]]`,
`[]` per toglierli). Riquadro «Parole chiave» sotto la webcam (grassetti della docente, max 5).
Da adattare per materia: `MAT`, `DOC` e la fascia gialla in `gen_moda.py`.

Comandi: fase A di `redo7a.sh` (costruisce le slide, `render_slides.py`, copertina, `comp.sh`).

## 6. Webcam

`comp.sh`: ritaglio del cerchio della webcam dal video originale (**misura la posizione su un fotogramma**: per la Caputi
`crop=62:62:779:406`), ingrandimento, **correzione colore automatica** (`normalize` + `eq` contrasto 1,05, saturazione 1,1,
gamma 1,04), riduzione del rumore e nitidezza; maschera tonda `cam_mask.png`, anello `cam_ring.png`.
Il limite resta la risoluzione di partenza: non usare sfocature dello sfondo (bocciate).

## 7. Voci narranti (decisione del 5/11/2026: voce Vox Studio / ElevenLabs, generata dalla coordinatrice)

- La voce approvata è quella di **ElevenLabs** (es. il benvenuto della Parte 2 di Tecnologie). Il nostro generatore
  (`voce/`) è stato **bocciato** come voce finale: usalo solo, se serve, per una prova dei tempi, mai nella consegna.
- Testi solo dal PDF della docente; numeri scritti in lettere. Tutti i testi delle voci in `voci/testi_voci.json`
  (`{"NOME":["frase 1","frase 2",…]}`: INTRO, R1…, S1…, AN1…, GL1, RF1, FIN1, IN2, RIP…).
- **Prepara presto il file dei testi** e mandalo alla coordinatrice:
  `python3 voci/prepara_testi_voce.py "Materia" INTRO1 R1 S1 … ` → `voci/Testi_voci_da_generare.txt`
  (un blocco = un file audio, con nome e caratteri). Lei li genera con **Vox Studio** (o ElevenLabs) e te li allega.
  Nel frattempo vai avanti con struttura, sincronia e slide.
- Quando arrivano: `python3 voci/importa_voce_esterna.py NOME file.mp3` per ognuno: trova l'inizio di ogni frase con la
  trascrizione (per le righe a tempo di voce), toglie i silenzi, normalizza, scrive `voci/wav/NOME.wav` e il meta.
  Stampa le parole diverse dal testo: controlla quelle vere (i nomi stranieri e tecnici di solito sono solo trascritti male).
- Se una voce è già stata fatta con ElevenLabs e il testo non è cambiato, **si riusa**.
- Modello dei testi: `voci/estese_P1.py` della lezione modello (schemi estesi S1–S6, glossario GL1, ripasso finale RF1, FIN1).

## 8. Grafiche

> Regola della coordinatrice (4/11/2026): **tutte le grafiche hanno l'aspetto delle animazioni dell'anteprima Parte 1 v2**
> (finezza, pecore/razze, categorie commerciali: `an/anim.html`). Dove il testo è lungo e pesante **bisogna inventarsi il movimento**:
> frasi che entrano una alla volta, numeri che crescono, oggetti disegnati che illustrano il concetto, evidenziazioni a tempo di voce.
> Mai una pagina ferma piena di testo («muro di testo»).
> **Copertina del saluto: mai la foto fissa della docente** (bocciata il 5/11: «sembra un santino»). Riquadro come nella lezione modello.

- Titoli/quiz (T, Q): `run_dark_moda.py` · RIPASSO e FINE: `run_dark2.py` (kicker = solo la materia, mai il numero di lezione).
- Schemi di ripasso con voce: `po_moda.py` (righe a tempo di voce, `[SCHEMA DI RIPASSO]`, piè di pagina materia·docente).
- Animazioni: `an/anim.html` (scene AN1–AN6, RIP, **GL1 glossario**, **RF1 ripasso finale**) · `an/render_an.py`, `an/render_extra.py`.

## 9. Montaggio, esercizi, player

- `asm_moda2.py <parte>`: sequenza dei blocchi (da adattare: argomenti di ogni parte, punti delle animazioni).
- Esercizi: `es/build_es_moda.py` (domande della docente, 1 giusta + 5 sbagliate) · player: `build_player_moda.py <parte>`
  (soglia 80 %, arresti = inizio della scheda quiz nel video finale + 1,8 s) · prova automatica: `test_player.py <parte>`.
- Pacchetto per la piattaforma (SCORM 1.2, SoluzioneFAD): `make_scorm.py <parte> hd|leggero` (adatta `NAME`); completamento =
  tutti gli esercizi superati + video finito; punteggio = primo tentativo; ripresa dal punto lasciato. Formato definitivo:
  in attesa delle risposte di SoluzioneFAD (peso massimo, versione).
- Anteprime per la coordinatrice: 3 pezzi 720p sotto i 25 MB (fine di `redo7.sh`).

## 10. Checklist prima di consegnare

- [ ] tagli: trascrizione intorno a ogni taglio, nessuna frase spezzata
- [ ] sincronia: inizio di ogni argomento e campioni a metà slide (tolleranza ±1,5 s)
- [ ] slide: nessuna «troppo piena» (il build lo stampa), numeri chiave giusti
- [ ] voci: complete, nessun «Taglio» udibile, schemi e ripassi non muti
- [ ] testi: niente spagnolo, niente numero di lezione, accenti giusti
- [ ] player: tutti i quiz, soglia 80 %, nessun errore in pagina
- [ ] audio: −16 LUFS, nessun salto di volume ai cambi
