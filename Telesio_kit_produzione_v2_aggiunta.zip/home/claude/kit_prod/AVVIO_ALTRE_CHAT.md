# Come avviare le altre chat (anche quella di tuo fratello)

## A. Una volta sola: carica il kit aggiornato su GitHub
1. Apri https://github.com/zagavre-ai/lezioni
2. **Add file → Upload files**, trascina `Telesio_kit_produzione_v2_aggiunta.zip` (quello che ti ho mandato), poi **Commit changes**.
   (Deve stare accanto a `Telesio_kit_produzione_v1.zip`.)

## B. Per ogni lezione nuova: crea una «Release» con i 3 file della docente
1. Apri https://github.com/zagavre-ai/lezioni/releases/new
2. **Tag**: scrivi un nome senza spazi, per esempio `alb-cucina-III-IV-lez01` (per Gastronomia) → «Create new tag».
3. Titolo: come nella regola qui sotto.
4. Trascina in basso i 3 file: **video .mp4, PDF, Excel delle domande**.
5. **Publish release**. Aspetta che il video sia caricato del tutto.
6. Guarda i nomi dei file come li mostra GitHub (cambia gli spazi in punti): ti servono nel messaggio.

### Come chiamare i tag (sempre minuscolo, senza spazi, numero a due cifre)
`<indirizzo>-<materia>-<anno>-lez<NN>` · titolo della Release: `<Materia> · <anno> anno · Lez. NN – <titolo della docente>`

Il III e il IV anno sono un unico percorso (due anni in uno): un solo tag con `III-IV`.

| Materia | Indirizzo | Tag | Dove si lavora |
|---|---|---|---|
| Tecnologie dei materiali e dei processi produttivi e organizzativi della moda | Tecnico Sistema Moda | `moda-tecnologie-III-lez01` (già caricate così: si lasciano) | chat principale |
| Laboratori tecnologici ed esercitazione | Tecnico Istituto Moda | `moda-laboratori-III-IV-lez01` | chat principale (cartamodelli rifatti in vettoriale) |
| Laboratori dei servizi enogastronomici – settore cucina | Alberghiero · Gastronomia | `alb-cucina-III-IV-lez01` | chat del fratello |
| Scienza e cultura dell'alimentazione | Alberghiero | `alb-alimentazione-III-IV-lez01` | terza chat |
| Ideazione, progettazione e industrializzazione dei prodotti di moda | Tecnico Sistema Moda | `moda-ideazione-III-IV-lez01` | quando si libera una chat |
| Economia e marketing delle aziende della moda | Tecnico Istituto Moda | `moda-economia-III-IV-lez01` | quando si libera una chat |
| Chimica applicata e nobilitazione dei materiali per i prodotti della moda | Tecnico Sistema Moda | `moda-chimica-III-IV-lez01` | quando si libera una chat |

Titolo della Release: `<Materia> · III-IV anno · Lez. 01 – <titolo della docente>`.

## C. Prima della chat di tuo fratello (se usa un suo account Claude)
Il repository è pubblico: per leggerlo non serve impostare niente. Serve solo che apra una sessione di Claude
nel cloud (la stessa schermata dove lavori tu) e incolli il messaggio qui sotto.

## D. Messaggio da incollare come primo messaggio della chat nuova

Riempi le parti tra parentesi quadre. Esempio per **Gastronomia**:

---
Ciao Claude, sono Sara Zagarese (Centro Studi Telesio). In questa conversazione lavoriamo **una sola lezione**.

1. Prepara l'ambiente: clona il repository `zagavre-ai/lezioni` (lettura) e scompatta, nell'ordine,
   `Telesio_kit_produzione_v1.zip` e `Telesio_kit_produzione_v2_aggiunta.zip` nella radice (`unzip -o … -d /`).
   Poi leggi `/home/claude/kit_prod/CLAUDE.md` e `/home/claude/kit_prod/METODO_v2_lezioni_dal_PDF.md` e segui il §1.
2. Lezione da lavorare:
   - Release (tag): `[cucina-lab-lez01]`
   - File nella Release: video `[nome.mp4]` · PDF `[nome.pdf]` · domande `[nome.xlsx]`
   - Materia: `Laboratori dei servizi enogastronomici – settore cucina` · indirizzo `Alberghiero · Gastronomia` · anno `III-IV`
   - Docente: `Prof.ssa Piera Caputi` · sigla: `sigle/Sigla_Laboratori_enogastronomici_cucina_15s.mp4`
   - Titolo della lezione (dal file della docente): `[titolo]`
   - È una materia nuova: adatta `MAT`, `DOC` e la fascia gialla in `gen_moda.py`, e il kicker in `run_dark2.py`.
3. Lavora con il metodo v2 in tutto: sincronia per frasi con revisione manuale, tagli solo nelle pause, slide a card con
   numeri chiave, audio B, colore della webcam, schemi di ripasso con voce, glossario e ripasso finale, quiz e player.
4. Le voci narranti le genero io con Vox Studio: appena hai i testi (schemi, glossario, ripasso finale, animazioni) preparami il
   file con `voci/prepara_testi_voce.py` (METODO §7) e mandamelo; intanto vai avanti. Quando te li allego, importali con `importa_voce_esterna.py`.
5. Alla fine mandami le anteprime (3 pezzi 720p) e un breve rapporto: durata, tagli, controlli fatti e cosa resta da decidere.

Rispondimi in italiano, in modo semplice; non sono una programmatrice.
---

Per le altre materie della Prof.ssa Caputi cambia solo materia, indirizzo e sigla:

| Materia | Indirizzo | Sigla |
|---|---|---|
| Laboratori tecnologici ed esercitazione | Tecnico Istituto Moda | `sigle/Sigla_Laboratori_tecnologici_moda_15s.mp4` |
| Ideazione, progettazione e industrializzazione dei prodotti di moda | Tecnico Sistema Moda | `sigle/Sigla_Ideazione_progettazione_moda_15s.mp4` |
| Economia e marketing delle aziende della moda | Tecnico Istituto Moda | `sigle/Sigla_Economia_marketing_moda_15s.mp4` |
| Chimica applicata e nobilitazione dei materiali per i prodotti della moda | Tecnico Sistema Moda | `sigle/Sigla_Chimica_nobilitazione_moda_15s.mp4` |
| Scienza e cultura dell'alimentazione | Alberghiero | `sigle/Sigla_Scienza_alimentazione_15s.mp4` |

## Da sapere
- Massimo 2–3 chat insieme (consumano i limiti dell'abbonamento).
- Le voci le generi tu con Vox Studio dal file di testi che ti manda la chat (un audio per blocco, con il nome indicato).
- La revisione finale la facciamo nella chat principale (questa delle Tecnologie): mi incolli il rapporto e le anteprime.
