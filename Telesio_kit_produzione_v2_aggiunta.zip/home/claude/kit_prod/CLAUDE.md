# Istruzioni per Claude — Videolezioni Centro Studi Telesio (kit v2)

Prima di qualsiasi lavoro leggi, in quest'ordine:
1. `/home/claude/kit_prod/METODO_v2_lezioni_dal_PDF.md` — **metodo attuale** per le lezioni registrate con il PDF della docente
   (lezione modello: `/home/claude/moda_tec`). È quello da usare per le lezioni della Prof.ssa Caputi e simili.
2. `/home/claude/kit_prod/GUIDA_MONTATORE.md` e `/home/claude/kit_prod/WORKFLOW_videolezioni.md` — regole generali e metodo v1 (Spagnolo).

Regole che valgono sempre:
- Non modificare il contenuto del docente; si tolgono solo pause, ripetizioni a vuoto ed errori evidenti.
- **Sincronia**: metodo per frasi del METODO v2 §4, con revisione manuale e correzioni in `override_s.json`. Non cambiarlo.
- Tagli solo nelle pause tra le frasi. Audio versione B. Correzione colore della webcam.
- Esercizi: soglia 80 %, arresti misurati sul video finale, prova automatica di tutti gli esercizi.
- Voci narranti: le genera la coordinatrice con Vox Studio / ElevenLabs dai testi che le prepari (METODO §7); il nostro generatore non va nella consegna.
- Copertine: mai la foto fissa della docente.
- Ogni HTML convertito in PDF deve avere `<meta charset="utf-8">`; i campi dei PDF compilabili vanno sempre a capo (multiline, carattere fisso).
- Grafiche: stile delle animazioni della lezione modello (finezza, pecore, categorie); dove il testo è pesante, movimento. Mai muri di testo.
- Niente numero di lezione nei materiali; niente nomi di strumenti o programmi nei documenti per la scuola.
- Scrivi in italiano semplice, dai del tu alla coordinatrice; di' sempre cosa hai verificato e cosa no.
- La revisione finale di ogni lezione la fa la sessione principale della coordinatrice: consegna anteprime e rapporto.
