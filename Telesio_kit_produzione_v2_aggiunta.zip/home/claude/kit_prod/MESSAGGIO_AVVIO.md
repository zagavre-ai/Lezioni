# Messaggio di avvio per una conversazione nuova (una lezione per conversazione)

Copia il testo tra le righe, sostituisci le parti tra parentesi quadre e incollalo come primo messaggio.

---
Ciao Claude, sono Sara Zagarese (Centro Studi Telesio). In questa conversazione lavoriamo **una sola lezione**.

1. Prepara l'ambiente: clona il repository `zagavre-ai/lezioni` (lettura) e scompatta, nell'ordine,
   `Telesio_kit_produzione_v1.zip` e `Telesio_kit_produzione_v2_aggiunta.zip` nella radice (`unzip -o … -d /`).
   Poi leggi `/home/claude/kit_prod/CLAUDE.md` e `/home/claude/kit_prod/METODO_v2_lezioni_dal_PDF.md` e segui il §1.
2. Lezione da lavorare:
   - Release (tag): `[moda-tecnologie-III-lez02]`
   - File nella Release: video `[Lezione.2.mp4]` · PDF `[Lezione.2.pdf]` · domande `[Lezione.2.xlsx]`
   - Materia: `[Tecnologie dei materiali e dei processi produttivi e organizzativi della moda]` · indirizzo `[TECNICO SISTEMA MODA]` · anno `[III]`
   - Docente: `[Prof.ssa Piera Caputi]` · sigla: `[sigle/Sigla_Tecnologie_materiali_moda_15s.mp4]`
   - Titolo della lezione (dal file della docente): `[Preparazione · parte II]`
3. Lavora con il metodo v2 in tutto: sincronia per frasi con revisione manuale, tagli solo nelle pause, slide a card con
   numeri chiave, audio B, colore della webcam, schemi di ripasso con voce, glossario e ripasso finale, quiz e player.
4. Le voci narranti le genero io con Vox Studio: appena hai i testi (schemi, glossario, ripasso finale, animazioni) preparami il
   file con `voci/prepara_testi_voce.py` (METODO §7) e mandamelo; intanto vai avanti. Quando te li allego, importali con `importa_voce_esterna.py`.
5. Alla fine mandami le anteprime (3 pezzi 720p) e un breve rapporto: durata, tagli, controlli fatti e cosa resta da decidere.

Rispondimi in italiano, in modo semplice; non sono una programmatrice.
---

Note:
- Due o tre conversazioni insieme al massimo (consumano più in fretta i limiti dell'abbonamento).
- Se la lezione supera ~75 minuti, la conversazione la divide in Parte 1 e Parte 2 e te lo dice.
- La revisione finale di ogni lezione la fa la conversazione principale.
