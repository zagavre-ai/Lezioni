# Voci narranti — il nostro generatore (dal 4/11/2026 sostituisce ElevenLabs)

- Installazione: `bash /home/claude/kit_prod/voce/installa_voce.sh` (servono i domini `huggingface.co` e `*.hf.co` consentiti).
  La trascrizione di controllo usa Parakeet (`/tmp/asr/...`, vedi METODO §1).
- Voce femminile approvata: `ref35.wav`, espressività **1.15** (variante più vivace: `ref35v.wav`, 1.0). Maschile: `ref36.wav`.
- Ogni frase viene **trascritta e confrontata col testo**: si accetta solo se tutte le parole tornano; altrimenti si rigenera
  (variabile `TENTATIVI`, predefinito 6) e si tiene la migliore. Il testo viene scritto in minuscolo e con gli accenti scomposti:
  così gli accenti vengono pronunciati.
- Velocità: circa 15–20 minuti di calcolo per un minuto di voce (2 processori). Genera le voci **per prime** e lascia girare.
- Uso nella lezione: copia `gen_voci.py` in `voci/`, adatta l'elenco dei file (stringhe con i marcatori «Taglio.» come nel
  METODO §7, oppure il dizionario `F` in `estese_P1.py`), poi
  `TENTATIVI=5 VOCE=/home/claude/tts/ref35.wav ESAG=1.15 python3 gen_voci.py S1 S2 GL1 ...`
  Scrive `wav/<NOME>.wav` e i tempi delle frasi nei `meta_*.json`; il rapporto è in `rapporto_voci.txt`
  (punteggio < 1.00 = qualche parola non riconosciuta: di solito nomi stranieri, ma ascolta quelle frasi).
- Le stringhe da 4.000 caratteri per ElevenLabs non servono più.
