# Genera le voci narranti con il nostro programma (Chatterbox) e controllo automatico, nel formato usato dal montaggio:
#   wav/<NOME>.wav  +  meta (dur, inizio di ogni frase) nei file meta_*.json che leggono grafiche e animazioni
# uso: python3 gen_voci.py NOME1 NOME2 ...   (variabili: VOCE=file di riferimento, ESAG=espressività)
import sys,os,re,json,shutil,numpy as np,soundfile as sf
sys.path.insert(0,'/home/claude/tts');sys.path.insert(0,'/home/claude/moda_tec/voci')
import voce,cb,estese_P1 as X
D='/home/claude/moda_tec/voci/';W=D+'wav/'
def split(s,n5=True):
    fs=[f.strip() for f in re.split(r'(?:Taglio\. ){4}Taglio\. ?',s)]
    return [[p.strip() for p in re.split(r'(?:Taglio\. ){2}Taglio\. ?',f) if p.strip()] for f in fs]
TX={}
for k,f in zip(['R1','R2','R3','R4','R5','FIN1','IN2','R6','R7','R8','R9','FIN2','AN1','AN2','AN3','AN4','AN5','AN6'],split(open(D+'Stringa_voci_Tecnologie_Lez1.txt').read())):TX[k]=f
for k,f in zip(['INTRO1','RIP'],split(open(D+'Stringa_voci_Tecnologie_Lez1_aggiunta.txt').read())):TX[k]=f
for k in X.F:TX[k]=X.F[k]
META={'INTRO1':'meta_INTRO1','RIP':'meta_INTRO1','GL1':'meta_GL1','RF1':'meta_GL1'}
for k in TX:
    if k not in META:META[k]='meta_S1' if re.match(r'S\d$',k) else 'meta_R1'
VOICE=os.environ.get('VOCE','/home/claude/tts/ref35.wav');EX=float(os.environ.get('ESAG','1.15'));GAP=0.6
os.makedirs(D+'wav_eleven',exist_ok=True)
rep=open(D+'rapporto_voci.txt','a')
for name in sys.argv[1:]:
    if os.path.exists(W+name+'.wav') and not os.path.exists(D+'wav_eleven/'+name+'.wav'):shutil.copy(W+name+'.wav',D+'wav_eleven/'+name+'.wav')
    parts=[];starts=[];pos=0.0;texts=TX[name]
    for t in texts:
        import hashlib;cf=D+'cache/'+name+'_'+hashlib.md5((t+VOICE+str(EX)).encode()).hexdigest()[:10]+'.wav'
        if os.path.exists(cf):w,_=sf.read(cf,dtype='float32');s=float(open(cf+'.s').read())
        else:
            s,w,sd=voce.frase(t,VOICE,EX,tag='g');os.makedirs(D+'cache',exist_ok=True);sf.write(cf,w,cb.SR);open(cf+'.s','w').write(str(s))
        rep.write('%s\t%.2f\t%s\n'%(name,s,t));rep.flush()
        starts.append(round(pos,2));parts.append(w);pos+=len(w)/cb.SR
        parts.append(np.zeros(int(GAP*cb.SR),np.float32));pos+=GAP
    y=np.concatenate(parts[:-1]);y=y/max(1e-6,np.abs(y).max())*0.9
    sf.write(W+name+'.wav',y,cb.SR)
    mf=W+META[name]+'.json';M=json.load(open(mf)) if os.path.exists(mf) else {}
    M[name]={'dur':round(len(y)/cb.SR,2),'phrases':starts,'text':texts};json.dump(M,open(mf,'w'),ensure_ascii=False,indent=1)
    print(name,M[name]['dur'],'s',len(texts),'frasi',flush=True)
