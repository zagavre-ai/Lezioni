# Generatore di voce narrante con controllo automatico: ogni frase viene trascritta e confrontata col testo; se non torna, si rigenera.
import cb,numpy as np,soundfile as sf,subprocess,json,os,re,unicodedata,difflib,sys
NUMW=set('zero uno una due tre quattro cinque sei sette otto nove dieci undici dodici tredici quattordici quindici sedici diciassette diciotto diciannove venti trenta quaranta cinquanta sessanta settanta ottanta novanta cento mille virgola per cento percento'.split())
def norm(s):
    s=unicodedata.normalize('NFD',s.lower());s=''.join(c for c in s if unicodedata.category(c)!='Mn')
    w=re.findall(r"[a-z]+",s);return [x for x in w if x not in NUMW and not any(x.startswith(n) and len(n)>3 for n in ('ventu','trent','quarant','cinquant','sessant','settant','ottant','novant','cent','mill','milleno'))]
_PK=None
def asr(wav,tag='q'):
    # trascrizione nello stesso processo (il modello si carica una volta sola)
    global _PK
    if _PK is None:
        sys.path.insert(0,'/home/claude/asr_pk');import pk as _p;_PK=_p
    x=subprocess.run(['ffmpeg','-v','error','-i',wav,'-ac','1','-ar','16000','-f','f32le','-'],capture_output=True).stdout
    x=np.frombuffer(x,np.float32).copy();W=[];t=0.0;sr=16000;T=len(x)/sr
    while t<T-0.2:
        b=min(T,t+20.0);seg=x[int(t*sr):int(b*sr)]
        if np.abs(seg).max()>0.01:W+=_PK.words(_PK.transcribe(seg,t))
        t=b
    return W
def score(text,W):
    a,b=norm(text),norm(' '.join(w for _,w in W))
    sm=difflib.SequenceMatcher(None,a,b);r=sm.ratio()
    bad=sum(max(i2-i1,j2-j1) for op,i1,i2,j1,j2 in sm.get_opcodes() if op!='equal')
    r=1.0 if bad==0 else min(r,0.92)
    extra_start= bool(b and a and b[0]!=a[0] and (len(b)<2 or b[1]!=a[0]))
    return r-(0.2 if extra_start else 0)
def trim(w,sr=cb.SR,th=0.012):
    e=np.convolve(np.abs(w),np.ones(480)/480,'same');idx=np.where(e>th)[0]
    if not len(idx):return w
    a=max(0,idx[0]-int(.06*sr));b=min(len(w),idx[-1]+int(.12*sr));return w[a:b]
def frase(text,voice,exag=0.8,tries=int(os.environ.get('TENTATIVI','6')),tag='q'):
    best=None
    for sd in range(tries):
        w=trim(cb.tts(text,voice,exag=exag,seed=sd));f=f'/home/claude/tts/{tag}.wav';sf.write(f,w,cb.SR)
        s=score(text,asr(f,tag))
        if best is None or s>best[0]:best=(s,w,sd)
        if s>=0.99:break
    return best
if __name__=='__main__':
    T=[x for x in sys.argv[2].split('|')];out=sys.argv[1];v=sys.argv[3] if len(sys.argv)>3 else '/home/claude/tts/ref35.wav';ex=float(sys.argv[4]) if len(sys.argv)>4 else 0.8
    parts=[]
    for t in T:
        s,w,sd=frase(t,v,ex);print('%.2f seme %d | %s'%(s,sd,t[:70]),flush=True);parts+=[w,np.zeros(int(.55*cb.SR),np.float32)]
    sf.write(out,np.concatenate(parts[:-1]),cb.SR)
