# Voce narrante Telesio: Chatterbox multilingue (ONNX, licenza MIT) · uso: python3 cb.py "testo" out.wav [voce_rif.wav] [esagerazione]
import onnxruntime as ort, numpy as np, subprocess, sys, soundfile as sf, time, os
from tokenizers import Tokenizer
M='/tmp/cbx/';SR=24000;START,STOP=6561,6562
so=ort.SessionOptions();so.intra_op_num_threads=os.cpu_count() or 2
def S(n):return ort.InferenceSession(M+'onnx/'+n,so,providers=['CPUExecutionProvider'])
ENC,EMB,LM,DEC=S('speech_encoder.onnx'),S('embed_tokens.onnx'),S('language_model_q4.onnx'),S('conditional_decoder.onnx')
TOK=Tokenizer.from_file(M+'tokenizer.json')
LMI=[i.name for i in LM.get_inputs()]
def load(p):
    x=subprocess.run(['ffmpeg','-v','error','-i',p,'-ac','1','-ar',str(SR),'-f','f32le','-'],capture_output=True).stdout
    return np.frombuffer(x,np.float32)[None,:].copy()
_cache={}
def ref(p):
    if p not in _cache:_cache[p]=ENC.run(None,{'audio_values':load(p)})
    return _cache[p]
def tts(text,voice=M+'default_voice.wav',exag=0.5,lang='it',max_new=None,rp=1.2,temp=0.8,min_p=0.05,seed=0):
    rng=np.random.default_rng(seed)
    max_new=max_new or int(len(text)*2.4)+60
    cond_emb,prompt_tok,xvec,pfeat=ref(voice)
    import unicodedata
    text=unicodedata.normalize('NFKD',text.lower())  # come il tokenizer originale (minuscole + accenti scomposti)
    ids=np.array([TOK.encode(f'[{lang}]'+text).ids],np.int64)
    pos=np.where(ids>=START,0,np.arange(ids.shape[1])[None,:]-1).astype(np.int64)
    inp={'input_ids':ids,'position_ids':pos,'exaggeration':np.array([exag],np.float32)}
    gen=np.array([[START]],np.int64);past=None
    for i in range(max_new):
        e=EMB.run(None,inp)[0]
        if i==0:
            e=np.concatenate((cond_emb,e),axis=1);B,L,_=e.shape
            past={n:np.zeros([B,16,0,64],np.float32) for n in LMI if n.startswith('past_key_values')}
            mask=np.ones((B,L),np.int64)
        out=LM.run(None,dict(inputs_embeds=e,attention_mask=mask,**past))
        lg=out[0][:,-1,:].copy()
        sc=np.take_along_axis(lg,gen,axis=1);sc=np.where(sc<0,sc*rp,sc/rp);np.put_along_axis(lg,gen,sc,axis=1)
        if temp>0:
            z=lg[0]/temp;z=z-z.max();p=np.exp(z);p/=p.sum();p[p<min_p*p.max()]=0;p/=p.sum()
            nt=np.array([[rng.choice(len(p),p=p)]],np.int64)
        else: nt=np.argmax(lg,axis=-1,keepdims=True).astype(np.int64)
        gen=np.concatenate((gen,nt),axis=-1)
        if nt[0,0]==STOP:break
        inp['input_ids']=nt;inp['position_ids']=np.full((1,1),i+1,np.int64)
        mask=np.concatenate([mask,np.ones((1,1),np.int64)],axis=1)
        for k,n in enumerate(past):past[n]=out[1+k]
    sp=np.concatenate([prompt_tok,gen[:,1:-1] if gen[0,-1]==STOP else gen[:,1:]],axis=1)
    w=DEC.run(None,{'speech_tokens':sp,'speaker_embeddings':xvec,'speaker_features':pfeat})[0]
    return np.squeeze(w,0)
if __name__=='__main__':
    t0=time.time();w=tts(sys.argv[1],*( [sys.argv[3]] if len(sys.argv)>3 else []),**({'exag':float(sys.argv[4])} if len(sys.argv)>4 else {}))
    sf.write(sys.argv[2],w,SR);print('durata %.1f s, tempo %.1f s'%(len(w)/SR,time.time()-t0))
