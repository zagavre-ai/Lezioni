#!/bin/bash
# Installa il nostro generatore di voce (Chatterbox multilingue ONNX, licenza MIT) · circa 1,5 GB
# Serve che nelle impostazioni di rete siano consentiti: huggingface.co  e  *.hf.co
set -e
NO_PROXY=localhost no_proxy=localhost pip install --break-system-packages onnxruntime tokenizers soundfile numpy 2>/dev/null || true
mkdir -p /tmp/cbx/onnx && cd /tmp/cbx
B=https://huggingface.co/onnx-community/chatterbox-multilingual-ONNX/resolve/main
for f in tokenizer.json tokenizer_config.json generation_config.json default_voice.wav; do curl -sSL -o $f $B/$f; done
cd onnx
for f in conditional_decoder.onnx conditional_decoder.onnx_data embed_tokens.onnx embed_tokens.onnx_data language_model_q4.onnx language_model_q4.onnx_data speech_encoder.onnx speech_encoder.onnx_data; do
  [ -s $f ] || curl -sSL -o $f $B/onnx/$f; done
mkdir -p /home/claude/tts && cp /home/claude/kit_prod/voce/{cb.py,voce.py,ref35.wav,ref35v.wav,ref36.wav} /home/claude/tts/
ls -la /tmp/cbx/onnx && echo "Prova: cd /home/claude/tts && python3 voce.py /tmp/prova.wav 'Buongiorno a tutti, oggi parliamo di fibre tessili.' ref35.wav 1.15"
