set -e
cd /home/claude/moda_tec
rm -rf sv && python3 render_slides.py > render_sv.log 2>&1
python3 - <<'P'
from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1920,'height':1080})
    pg.goto('file:///home/claude/moda_tec/slides_spoken.html');pg.wait_for_timeout(800)
    pg.evaluate("""()=>{const s=document.querySelectorAll('.sheet')[0];document.querySelectorAll('.sheet').forEach((x,i)=>x.style.display=i?'none':'');
    s.querySelector('.ey').textContent='Tecnologie dei materiali · Tecnico Sistema Moda';
    s.querySelector('.tt').textContent='Preparazione · parte I';
    s.querySelector('.bd').innerHTML='<p style="font-size:2cqw;line-height:1.45">Parleremo di classificazione generale delle fibre tessili e approfondiremo le caratteristiche, l\\'origine e i processi di lavorazione delle fibre naturali di origine animale: <b>lana</b> e <b>seta</b>.</p>';
    s.querySelector('.kw').style.display='none';s.querySelector('.ft span:last-child').textContent='';}""")
    pg.query_selector_all('.sheet')[0].screenshot(path='/home/claude/moda_tec/sv/s000_cover.png')
P=json.load(open('/home/claude/moda_tec/sv_plan.json'))
L=["file '/home/claude/moda_tec/sv/s000_cover.png'","duration %.3f"%P['starts'][0]]
for f,d in P['plan']: L+=["file '%s'"%f,"duration %.3f"%d]
L.append("file '%s'"%P['plan'][-1][0])
open('/home/claude/moda_tec/sv_concat.txt','w').write('\n'.join(L)+'\n')
P
./comp.sh 0 2110 docente_slide_1080.mp4
echo COMP_OK
python3 make_sting.py
rm -rf w2 Tecnologie_Lez1_Parte1_VIDEO.mp4
python3 asm_moda2.py 1
echo MONT1_OK
rm -rf consegna/Tecnologie_Lez1_Parte1
python3 build_player_moda.py 1
python3 /tmp/claude-0/-home-claude/6f0ad356-eb6e-5e82-bb5b-b32ac31c8256/scratchpad/pt/test_moda.py 1
echo PLAYER1_OK
F=Tecnologie_Lez1_Parte1_VIDEO.mp4; Dd=$(ffprobe -v error -show_entries format=duration -of csv=p=0 $F); L=$(python3 -c "print($Dd/3)")
rm -f anteprima/*.mp4
for i in 0 1 2; do S=$(python3 -c "print($L*$i)"); ffmpeg -v error -ss $S -t $L -i $F -vf scale=1280:720 -c:v libx264 -preset veryfast -crf 31 -c:a aac -b:a 64k -ac 1 -movflags +faststart -y anteprima/Tecnologie_Lez1_Parte1_v2_$((i+1))di3.mp4; done
ls -la anteprima
echo PREV1_OK
