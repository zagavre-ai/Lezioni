# Struttura della lezione: argomenti, sottotitoli, unità (frasi) e tabelle aggiunte
import json,re
B=json.load(open('/home/claude/moda_tec/blocks.json'))
ARG=[ # (primo blocco, titolo argomento)
 (0,'Le fibre tessili: definizione e classificazione'),
 (10,'Le proprietà delle fibre'),
 (19,'Il mercato delle fibre e la manutenzione'),
 (26,'Le fibre animali e la lana'),
 (42,'La fibra di lana: composizione e classificazione'),
 (85,'Trattamenti, proprietà e cura della lana'),
 (105,'Le lane speciali'),
 (130,'La seta: origine e produzione'),
 (155,'La seta: trattamenti, proprietà e cura'),
]
SUB=[ # (primo blocco, sottotitolo della slide)
 (0,"Che cos'è la fibra tessile"),(1,'Fibre naturali e fibre chimiche'),(9,'Le fibre in mischia'),
 (10,'I quattro gruppi di proprietà'),(15,'Le proprietà morfologiche'),(16,'Le proprietà chimiche'),(17,'Le proprietà fisico-meccaniche'),(18,'Le proprietà fisiologiche'),
 (19,'La domanda di fibre tessili'),(21,"Sporco e indice di sporcabilità"),(25,'La pulibilità'),
 (26,"Le fibre di origine animale"),(31,'La lana di pecora'),(32,'Le razze degli ovini'),(36,'La tosatura'),(37,'Selezione del vello e cernita'),(41,'Lavaggio e asciugatura'),
 (42,'Composizione della lana'),(44,'Le categorie commerciali'),(49,'La finezza'),(55,'Bradford System e IWTO'),(74,'Morbidezza, ondulazione e lunghezza'),(79,'Colore e provenienza'),(84,'La lana al microscopio'),
 (85,'I trattamenti della lana'),(91,'I finissaggi meccanici'),(93,'Le proprietà della lana'),(104,'Lavorazione e manutenzione'),
 (105,'Le lane speciali'),(117,'Rese e metodi di raccolta'),
 (130,'La seta e le sue origini'),(133,'La bachicoltura'),(137,'Cernita, trattura e sgommatura'),(146,'Caratteristiche e valore della seta'),
 (155,'I trattamenti della seta'),(165,'Le proprietà della seta'),(171,'Lavorazione e manutenzione della seta'),(180,'Sete selvatiche e fibre del futuro'),
]
# tabelle che nel PDF sono immagini: testo trascritto (senza i rimandi numerici)
TAB_LANA_SETA={'t':'tab','cols':['Fibra','Lavaggio','Asciugatura','Stiratura'],'rows':[
 ['Lana',"Richiede acqua a temperatura **tiepida e costante** con detergenti neutri. Si può lavare a mano o in lavatrice con programmi specifici, controllando la velocità di centrifuga per evitare la **compenetrazione delle squame**. Il **lavaggio a secco** è consigliato per prevenire il restringimento.",
  "Deve avvenire **all'ombra** e **in piano**, dopo aver rimosso l'acqua in eccesso con un panno per evitare deformazioni. L'asciugatura domestica con aria calda in tamburo è sconsigliata per non compromettere l'elasticità.",
  "Deve essere eseguita con **calore moderato**. Una piega fissata ad alte temperature non si può più eliminare a causa della **termoplasticità** della fibra."],
 ['Seta',"Si effettua a mano o in lavatrice con molte precauzioni, a temperatura **tiepida e costante** con detergenti neutri. È da evitare la **centrifuga** perché la fibra bagnata si indebolisce. Il **lavaggio a secco** è raccomandato per capi colorati o macchiati.",
  "Deve essere eseguita **lontano da fonti di calore** e dalla **luce solare** diretta. Si sconsiglia l'uso dell'asciugatrice in tamburo.",
  "Si esegue posizionando il tessuto tra **2** panni umidi per inumidire indirettamente la fibra. Stirare **a rovescio** con **ferro tiepido** evitando l'uso diretto del vapore."]]}
TAB_PROT={'t':'tab','cols':['Proteina','Percentuale','Descrizione'],'rows':[
 ['Fibroina','75-77%','proteina fibrosa che rappresenta la parte indispensabile per ottenere un filato'],
 ['Sericina','22-23%','proteina gommosa che funziona da collante per tenere unite le **2** bavelle']]}
TAB_L={'t':'tab','cols':TAB_LANA_SETA['cols'],'rows':[TAB_LANA_SETA['rows'][0]]}
TAB_S={'t':'tab','cols':TAB_LANA_SETA['cols'],'rows':[TAB_LANA_SETA['rows'][1]]}
INSERT_AFTER={104:[TAB_L,TAB_S],147:[TAB_PROT]}
SUPER=range(56,74)

def txt(runs): return ''.join(t for _,t in runs)
def split_runs(runs,maxlen=330):
    """divide un paragrafo in frasi mantenendo i grassetti"""
    s=txt(runs); cut=[0]
    for m in re.finditer(r'(?<! n)(?<=[a-zàèéìòù0-9\)%”»"])\. (?=[A-ZÈÉ0-9L])',s): cut.append(m.end())
    cut.append(len(s))
    # unisci frasi troppo corte alla successiva
    segs=[(cut[i],cut[i+1]) for i in range(len(cut)-1)]
    out=[]
    for a,b in segs:
        if out and (b-a<60 or out[-1][1]-out[-1][0]<60) and (b-out[-1][0])<maxlen: out[-1]=(out[-1][0],b)
        else: out.append((a,b))
    res=[]
    for a,b in out:
        rr=[];pos=0
        for bo,t in runs:
            s0,s1=pos,pos+len(t);pos=s1
            x0,x1=max(a,s0),min(b,s1)
            if x1>x0: rr.append([bo,t[x0-s0:x1-s0]])
        rr[0][1]=rr[0][1].lstrip(); rr[-1][1]=rr[-1][1].rstrip()
        res.append(rr)
    return res
def units():
    U=[]
    ai=-1; si=-1
    for i,b in enumerate(B):
        na=[k for k,(s,_) in enumerate(ARG) if s<=i][-1]
        ns=[k for k,(s,_) in enumerate(SUB) if s<=i][-1]
        if i in SUPER:
            m=re.match(r"super (\d+)'s, con un diametro massimo delle fibre di ([\d,]+) micron",txt(b['runs']))
            if U and U[-1]['t']=='super': U[-1]['rows'].append([f"super {m.group(1)}'s",m.group(2)+' micron'])
            else: U.append({'t':'super','rows':[[f"super {m.group(1)}'s",m.group(2)+' micron']],'a':na,'s':ns,'b':i,'pg':b['pg'],
                            'txt':'super 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 diametro massimo micron'})
            continue
        parts=split_runs(b['runs']) if b['t']=='p' or len(txt(b['runs']))>330 else [b['runs']]
        for k,r in enumerate(parts):
            U.append({'t':b['t'] if k==0 else ('cont' if b['t']=='li' else 'p'),'runs':r,'a':na,'s':ns,'b':i,'pg':b['pg'],'txt':txt(r),'par0':k==0})
        for T in INSERT_AFTER.get(i,[]):
            d=dict(T); d.update({'a':na,'s':ns,'b':i,'pg':b['pg'],'txt':' '.join(' '.join(r) for r in T['rows'])}); U.append(d)
    return U
if __name__=='__main__':
    U=units(); print(len(U)); import collections
    print(collections.Counter(u['t'] for u in U))
    print(max(len(u['txt']) for u in U if u['t'] in('p','li','cont')))
    json.dump(U,open('/home/claude/moda_tec/units.json','w'),ensure_ascii=False)
