# Rifà una o più frasi di un file voce già generato, lasciando le altre come sono.
# uso: TENTATIVI=8 python3 rifai_frase.py S4 2 4     (indici delle frasi, da 0)
import sys,os,json,numpy as np,soundfile as sf
sys.path.insert(0,'/home/claude/tts');sys.path.insert(0,'/home/claude/moda_tec/voci')
import voce,cb
D='/home/claude/moda_tec/voci/';W=D+'wav/';GAP=0.6
name=sys.argv[1];idx=[int(i) for i in sys.argv[2:]]
mf=[W+f for f in os.listdir(W) if f.startswith('meta_') and name in json.load(open(W+f))][0]
M=json.load(open(mf));m=M[name];y,sr=sf.read(W+name+'.wav',dtype='float32')
ph=m['phrases']+[m['dur']+GAP]
segs=[y[int(ph[i]*sr):int((ph[i+1]-GAP)*sr)] for i in range(len(m['text']))]
pk=np.abs(y).max()
VOICE=os.environ.get('VOCE','/home/claude/tts/ref35.wav');EX=float(os.environ.get('ESAG','1.15'))
rep=open(D+'rapporto_voci.txt','a')
for i in idx:
    s,w,sd=voce.frase(m['text'][i],VOICE,EX,tag='r')
    w=w/max(1e-6,np.abs(w).max())*pk*0.97;segs[i]=w
    rep.write('%s#%d rifatta\t%.2f\t%s\n'%(name,i,s,m['text'][i]));rep.flush();print(name,i,'%.2f'%s,flush=True)
parts=[];starts=[];pos=0.0
for w in segs:
    starts.append(round(pos,2));parts+=[w,np.zeros(int(GAP*sr),np.float32)];pos+=len(w)/sr+GAP
y=np.concatenate(parts[:-1]);y=y/max(1e-6,np.abs(y).max())*0.9;sf.write(W+name+'.wav',y,sr)
M[name].update(dur=round(len(y)/sr,2),phrases=starts);json.dump(M,open(mf,'w'),ensure_ascii=False,indent=1)
print(name,'ok',M[name]['dur'])
