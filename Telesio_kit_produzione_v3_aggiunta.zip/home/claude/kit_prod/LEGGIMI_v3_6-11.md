# Kit v3 · aggiunta del 6/11/2026 (si scompatta DOPO v1 e v2: unzip -o … -d /)

- /home/claude/lezioni/tools/taglio.py — taglio.snap(t, wav): sposta ogni taglio nel punto più silenzioso tra t−2 s e t+0,1 s (finestra 120 ms). Usarlo per OGNI taglio (inizi argomento, tappa 3, montaggio).
- /home/claude/lezioni/tools/tappa3.py — pacchetto di tappa 3 (miniature, ascolto dei tagli, sincronia) da mandare a Sara.
- /home/claude/lezioni/tools/voci_gruppi.py, voci_auto.py, voci_tutte.sh, testi_txt.py — voci narranti a gruppi (una richiesta ogni ~3.500 caratteri), con controllo di ogni blocco.
- /home/claude/tts/gemini_tts.py — motore delle voci (Kore). La chiave NON è qui: va in /root/.segreti/gemini_key (o variabile GEMINI_API_KEY). Mai nei documenti, nei kit o nei messaggi.
- /home/claude/kit_prod/modello_lezione_6-11/ — gli script della lezione «Tessitura parte II» (Tecnologie, montata il 6/11, 60 min, 7 argomenti, 7 quiz): fase_a.sh, fase_b.sh/fase_b2.sh, gen_moda.py, run_dark2.py (schede scure: titolo, ripasso, Quiz «5 domande»), po_moda.py (schemi), asm_moda2.py (montaggio finale 2560×1440 con taglio.snap). Sono il MODELLO da adattare alla materia (MAT, DOC, kicker, fascia gialla), non da usare così.
- Niente SCORM, niente lettore interattivo: la pagina quiz la prepara la chat master dalla scheda_pubblicazione.json.
