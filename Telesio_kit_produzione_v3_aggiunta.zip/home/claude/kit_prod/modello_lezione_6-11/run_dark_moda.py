import sys,json,os
sys.path.insert(0,'/home/claude/v5')
import dark
OUT='/home/claude/lezioni/moda-tecnologie-III-lez05/dk'
TT=[(['Tessuti a treccia','e a rete'],'treccia · bobinet · malines · tulle'),
(['I non tessuti'],'feltri · TNT · agocuciti'),
(['I tessuti','accoppiati'],'doubleface · imbottiti · laminati'),
(['Il controllo','qualità'],'specula · riduzione · difetti'),
(['Peso, stabilità','e pilling'],'g/m² · tolleranze · grado 1-5'),
(['La sicurezza','nei reparti'],'microclima · luce · rumore'),
(['Navetta, maglia','e laboratorio'],'confronto · maglieria · analisi')]
import collections
NQd=collections.Counter(q['quiz'] for q in json.load(open('/home/claude/lezioni/moda-tecnologie-III-lez05/quiz_raw.json')))
NQ=[5]*len(TT)  # quiz di fine argomento scritti da noi: 5 domande ciascuno
SP={}
for i,(l,e) in enumerate(TT):
    SP['T%d'%(i+1)]={'type':'title','num':str(i+1).zfill(2),'total':len(TT),'lines':l,'ex':e,'fs':128 if max(len(x) for x in l)<17 else 108,'dur':3.6,'lineY':720 if len(l)==2 else 600}
    if NQ[i]:SP['Q%d'%(i+1)]={'type':'quiz','topic':' '.join(l).replace(': ',' · ').replace(':',''),'act':'Quiz %d'%(sum(1 for x in NQ[:i+1] if x)),'pts':'%d domand%s · per continuare almeno l’80%%'%(NQ[i],'a' if NQ[i]==1 else 'e'),'dur':4.0}
json.dump(SP,open('/home/claude/lezioni/moda-tecnologie-III-lez05/scripts_dark.json','w'),ensure_ascii=False,indent=1)
for k in (sys.argv[1:] or SP):
    if os.path.exists(f'{OUT}/{k}.mp4'):continue
    dark.render(SP[k],f'{OUT}/{k}',1.0);print(k,flush=True)
