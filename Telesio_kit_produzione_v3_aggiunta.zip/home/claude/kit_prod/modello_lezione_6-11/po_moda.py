import sys,json
sys.path.insert(0,'/home/claude/v5')
import po9
nt=po9.nt
EY='[SCHEMA DI RIPASSO]'
S={}
S['S1']=dict(title='Tessuti a treccia e a rete',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Tessuti a treccia',"soli fili d'ordito in diagonale · elevata elasticità trasversale"],
 ['Come si forma','almeno 3 fili a zig-zag · resistenza superiore alla somma dei singoli fili'],
 ['Tipi di treccia','piatti → nastri e cappelli · tubolari → cordoncini, stoppini, lacci'],
 ['Tessuti a rete',"fili d'ordito legati in obliquo · spazi a losanga, esagono, ottagono · telai Raschel"],
 ['Le reti','bobinet → bomboniere · malines → base per pizzi · tulle → abiti da sposa e tutù']],
 note=nt('ATTENZIONE','I tessuti a rete sono delicati al lavaggio e difficili da rammendare.'),notep=6)
S['S2']=dict(title='I non tessuti',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Feltri','umidità + calore + pressione → infeltrimento delle fibre di lana'],
 ['Uso dei feltri',"cappelli, pantofole, isolanti per l'edilizia · pannolenci"],
 ['TNT','veli di fibre parallele · incrociate · non orientate'],
 ['Coesione dei veli','incollaggio · saldatura termica · agugliatura · spunlacing (getti d\'acqua)'],
 ['Impieghi del TNT','rinforzi termoadesivi · filtri e mascherine · pannolini e salviette'],
 ['Agocuciti','cucitura a catenella · basso impatto ambientale']],note=None)
S['S3']=dict(title='I tessuti accoppiati',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Doubleface','due tessuti usabili su entrambi i lati · filato di collegamento nascosto'],
 ['Imbottiti','strati di tessuto con un velo di fibre interno'],
 ['Laminati','tessuto + pellicola sottile, senza aumentare lo spessore'],
 ['Scoppiati','adesivo solubile in acqua: al lavaggio resta un effetto foderato']],rowp=[2,3,4,5],
 note=nt('ATTENZIONE AL LAVAGGIO',"Spesso non sopportano né il lavaggio a secco né quello in acqua."),notep=1)
S['S4']=dict(title='Il controllo qualità',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Chi controlla','il tessitore a fine produzione · il confezionista prima di lavorare'],
 ['Specula o tribunale','tavolo luminoso inclinabile · contrassegni colorati sulla cimosa'],
 ['Riduzione','fili di ordito e trama in 1 cm² · lentino contafili · equilibrata o quadrata'],
 ['Scarto angolare di trama','tolleranza 2% (trama visibile) · 3% (trama invisibile)'],
 ['Sinuosità degli orditi','tolleranza 1% (intreccio visibile e stampati) · 2% (non visibile)'],
 ['Difetti','chiarella: manca un filo di trama · barrature: strisce di colore o spessore diverso']],rowp=[0,1,2,3,4,5],note=None)
S['S5']=dict(title='Peso, stabilità dimensionale e pilling',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Peso','g/m² o g/m lineare · once per gli Stati Uniti · sempre sul tessuto finito'],
 ['Come si pesa','dischetto di 1 dm² (diametro 11,3 cm) × 100 · once × 33,9 = g/m²'],
 ['Stabilità dimensionale','lunghezza e larghezza dopo lavaggio, asciugatura e stiro'],
 ['Il test','provetta 50 × 50 cm · tolleranza da −4% a +6%'],
 ['Pilling','scala fotografica: grado 1 eccessivo → grado 5 assente'],
 ['Lo riducono','filati molto ritorti · fibre lunghe · alta riduzione · gasatura, resinatura, termofissaggio']],note=None)
S['S6']=dict(title='La sicurezza nei reparti tessili',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Norma','D. Lgs. 81/2008'],
 ['Microclima in tessitura','umidità oltre il 65% · temperatura oltre i 20 °C'],
 ["Senza ricambio d'aria","sindrome dell'edificio malato"],
 ['Illuminazione','prima la luce naturale · da 100 lux (depositi) a 4.000 lux (lavorazioni finissime)'],
 ['Rumore','80 dB(A) attenzione · 85 dB(A) azione · 87 dB(A) valore limite'],
 ['In tessitura','oltre 90 dB: tappi auricolari o cuffie obbligatori']],rowp=[0,1,2,3,4,5],note=None)
S['S7']=dict(title='Navetta, maglia e analisi di laboratorio',cols='30% 70%',fs=30,header=['Voce','In sintesi'],rows=[
 ['Tessuti a navetta','poco deformabili · facili da tagliare e curare · resistono alla centrifuga · si stropicciano'],
 ['Tessuti a maglia','elastici e comodi · poco stiro · si smagliano e si deformano'],
 ['Armature derivate','irregolari (panama) · dalle derivate (diamantine)'],
 ['Maglieria','in trama: si smaglia · in catena: indemagliabile (telai in catena, Raschel, crochet)'],
 ['Analisi di laboratorio','ritiro, allungamento e peso fuori tolleranza (−4% / +6%) → scarti nel taglio']],note=None)
DUR=44.0
for k,v in S.items():
    v['eyebrow']=EY; v.setdefault('tweak','')
    po9.SPEC[k]=v
def times(n,has_note):
    T=[];span=38.0/(n+(1 if has_note else 0));a=1.0
    for i in range(n):
        T.append((round(a,2),round(a+0.3,2),round(a+span,2)));a+=span
    return {'rows':T,'note':(round(a,2),round(a+.3,2),DUR-1) if has_note else None}
# piè di pagina: materia e docente
orig=po9.build_html
def bh(name,sp,tms,cards=False):
    return orig(name,sp,tms,cards).replace('<span>SPAGNOLO</span>','<span>TECNOLOGIE DEI MATERIALI E DEI PROCESSI PRODUTTIVI E ORGANIZZATIVI DELLA MODA · Prof.ssa Piera Caputi</span>')
po9.build_html=bh
if __name__=='__main__':
    ks=sys.argv[1:] or list(S)
    import glob;M={}
    [M.update(json.load(open(f))) for f in glob.glob('/home/claude/lezioni/moda-tecnologie-III-lez05/voci/wav/meta_*.json')]
    for k in ks:
        v=S[k];m=M[k];DL=1.0
        P=[p+DL for p in m['phrases']];n=len(v['rows']);hn=bool(v.get('note'))
        dur=round(m['dur']+DL+2.5,2)
        rp=v.get('rowp',[i+1 for i in range(n)]);nq=v.get('notep',n+1)
        rows=[(round(P[rp[i]],2),round(P[rp[i]]+0.3,2),round(P[rp[i]+1] if rp[i]+1<len(P) else dur-1,2)) for i in range(n)]
        tm={'rows':rows,'note':(round(P[nq],2),round(P[nq]+.3,2),dur-1) if hn else None}
        po9.render_po(k,k,tm,dur,'/home/claude/lezioni/moda-tecnologie-III-lez05/po',scale=float(__import__('os').environ.get('SC','1')))
        __import__('shutil').rmtree('/home/claude/lezioni/moda-tecnologie-III-lez05/po/'+k,ignore_errors=True)
