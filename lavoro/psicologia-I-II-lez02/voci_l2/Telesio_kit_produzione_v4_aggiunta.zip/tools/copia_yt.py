# Copia per YouTube alla massima qualità che sta sotto il limite di invio, a pezzi da 10 minuti (riprende da dove si è fermata).
# uso: python3 copia_yt.py master.mp4 uscita.mp4 CRF [maxrate_M]
# - video: pezzi di 18000 fotogrammi codificati a parte (x264 medium, stesso CRF), poi uniti senza ricomprimere
# - audio: tutto in una volta (AAC 192k), poi unito al video
# - controllo finale: numero di fotogrammi e durata uguali al master
import sys,os,subprocess,json
M,OUT,CRF=os.path.abspath(sys.argv[1]),os.path.abspath(sys.argv[2]),sys.argv[3];MR=int(sys.argv[4]) if len(sys.argv)>4 else 16
W=OUT+'.pezzi/';os.makedirs(W,exist_ok=True)
pr=lambda *a:subprocess.run(['ffprobe','-v','error']+list(a)+[M],capture_output=True,text=True).stdout.strip()
NF=int(pr('-select_streams','v:0','-count_packets','-show_entries','stream=nb_read_packets','-of','csv=p=0'))
FPS=30;SEG=18000;n=(NF+SEG-1)//SEG
for k in range(n):
    f=W+'v%03d.mp4'%k
    if os.path.exists(f) and os.path.exists(f+'.ok'):continue
    a=k*SEG;nf=min(SEG,NF-a)
    subprocess.run(['nice','-n','5','ffmpeg','-v','error','-y','-ss','%.6f'%(a/FPS),'-i',M,'-map','0:v:0','-frames:v',str(nf),
        '-c:v','libx264','-preset','medium','-crf',CRF,'-pix_fmt','yuv420p','-maxrate','%dM'%MR,'-bufsize','%dM'%(2*MR),'-r','30','-an',f],check=True)
    open(f+'.ok','w').write(str(nf));print('pezzo',k+1,'di',n,flush=True)
open(W+'list.txt','w').write(''.join("file '%sv%03d.mp4'\n"%(W,k) for k in range(n)))
if not os.path.exists(W+'a.m4a.ok'):
    subprocess.run(['ffmpeg','-v','error','-y','-i',M,'-map','0:a:0','-c:a','aac','-b:a','192k','-ar','48000',W+'a.m4a'],check=True);open(W+'a.m4a.ok','w').write('1')
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',W+'list.txt','-i',W+'a.m4a','-map','0:v','-map','1:a','-c','copy','-movflags','+faststart',OUT],check=True)
q=lambda f,s,e:subprocess.run(['ffprobe','-v','error','-select_streams',s,'-count_packets','-show_entries','stream='+e,'-of','csv=p=0',f],capture_output=True,text=True).stdout.strip()
nf2=int(q(OUT,'v:0','nb_read_packets'))
print('fotogrammi master',NF,'copia',nf2,'| durata audio',q(M,'a:0','duration'),q(OUT,'a:0','duration'),'| MB',round(os.path.getsize(OUT)/2**20,1))
assert nf2==NF,'fotogrammi diversi'
