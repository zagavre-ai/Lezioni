#!/usr/bin/env python3
# Voce narrante Telesio - tutte le voci di una lezione.
# uso: python3 voci_locali.py cartella_lezione [NOME1 NOME2 ...]   (senza nomi: tutte)
# Legge  cartella_lezione/voci/testi_voci.json
# Scrive cartella_lezione/voci/wav/NOME.wav  e  cartella_lezione/voci/wav/meta_NOME.json
# Il modello si carica una volta sola; le frasi già fatte e non cambiate si riusano (cartella .cache_telesio).
import sys, os, json, time, argparse
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'motore'))
ap = argparse.ArgumentParser()
ap.add_argument('lezione'); ap.add_argument('nomi', nargs='*')
ap.add_argument('--campione'); ap.add_argument('--esagerazione', type=float)
a = ap.parse_args()

def leggi_testi(p):
    """Accetta {"NOME": "testo"}, {"NOME": {"testo": ...}} oppure [{"nome": ..., "testo": ...}]."""
    j = json.load(open(p, encoding='utf-8'))
    if isinstance(j, list):
        return {x.get('nome') or x.get('codice') or x.get('id'): x.get('testo') or x.get('text') for x in j}
    out = {}
    for k, v in j.items():
        if k.startswith('_'): continue
        out[k] = v if isinstance(v, str) else (v.get('testo') or v.get('text'))
    return out

base = os.path.join(a.lezione, 'voci')
testi = leggi_testi(os.path.join(base, 'testi_voci.json'))
nomi = a.nomi or list(testi)
manca = [n for n in nomi if n not in testi]
if manca: sys.exit('Non trovo in testi_voci.json: ' + ', '.join(manca))
out = os.path.join(base, 'wav'); os.makedirs(out, exist_ok=True)
import telesio, cb2
t0 = time.time(); cb2.carica_tutto(); print('modello caricato in %.0f s' % (time.time() - t0), flush=True)
tot_voce = 0; riepilogo = []
for n in nomi:
    m = telesio.genera_voce(testi[n], os.path.join(out, n + '.wav'), campione=a.campione, esag=a.esagerazione,
                            cache=os.path.join(base, '.cache_telesio'), meta=os.path.join(out, 'meta_%s.json' % n))
    tot_voce += m['durata']
    riepilogo.append((n, m['durata'], m['tempo_di_calcolo_s'], m['avvisi']))
    print('%-10s %6.1f s di voce  %5.0f s di calcolo  %s' % (n, m['durata'], m['tempo_di_calcolo_s'],
          'OK' if not m['avvisi'] else 'DA ASCOLTARE: ' + ' | '.join(m['avvisi'])), flush=True)
tt = time.time() - t0
print('TOTALE: %d voci, %.1f min di voce in %.1f min (caricamento compreso)' % (len(nomi), tot_voce / 60, tt / 60))
json.dump({'voci': [{'nome': n, 'durata': d, 'calcolo_s': c, 'avvisi': av} for n, d, c, av in riepilogo],
           'minuti_voce': round(tot_voce / 60, 2), 'minuti_calcolo': round(tt / 60, 2)},
          open(os.path.join(out, 'riepilogo_generazione.json'), 'w'), ensure_ascii=False, indent=1)
