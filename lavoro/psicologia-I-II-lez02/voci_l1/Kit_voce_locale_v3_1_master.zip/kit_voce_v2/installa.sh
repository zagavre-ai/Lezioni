#!/bin/bash
# Installa il generatore di voce Telesio (una volta per ambiente). Circa 2-5 minuti.
set -e
cd "$(dirname "$0")"
NO_PROXY=localhost,127.0.0.1 no_proxy=localhost,127.0.0.1 pip install --break-system-packages -q onnxruntime tokenizers soundfile huggingface_hub onnx pyloudnorm numpy scipy pyworld 2>&1 | grep -v -i warn || true
which ffmpeg >/dev/null || { echo "Serve ffmpeg"; exit 1; }
NO_PROXY=localhost,127.0.0.1 no_proxy=localhost,127.0.0.1 python3 motore/prepara_modelli.py
echo "Pronto. Prova: python3 voce_locale.py prova.wav \"Ripassiamo insieme la filatura.\""
