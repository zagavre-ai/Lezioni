# Porta le voci del generatore locale nel formato usato dal montaggio (come le voci di prima).
# uso: python3 voci_locale_a_meta.py cartella_lezione
# legge  cartella/voci/testi_voci.json (NOME -> lista di frasi) e cartella/voci_gen/voci/wav/{NOME.wav, meta_NOME.json}
# scrive cartella/voci/wav/NOME.wav (copia) e cartella/voci/wav/meta_locale.json:
#        {NOME: {"dur": s, "phrases": [inizio di ogni frase della lista], "text": [...], "avvisi": [...]}}
# Il generatore può unire frasi brevi in un solo pezzo («Il lino. Il lino è…»): in quel caso l'inizio della frase
# si stima in proporzione ai caratteri e si aggancia all'attacco della parola trascritta più vicina.
import sys, os, json, re, shutil, unicodedata
B = os.path.abspath(sys.argv[1]); G = B + '/voci_gen/voci/wav/'; O = B + '/voci/wav/'; os.makedirs(O, exist_ok=True)
T = json.load(open(B + '/voci/testi_voci.json'))
norm = lambda s: re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD', s.lower()).encode('ascii', 'ignore').decode())
M = {}; manca = []; agganci = []
for n, frasi in T.items():
    if not os.path.exists(G + n + '.wav'): manca.append(n); continue
    m = json.load(open(G + 'meta_%s.json' % n)); gen = m['frasi']
    # posizione (in caratteri normalizzati) di inizio di ogni pezzo generato e di ogni frase della lista
    gl = [len(norm(g['testo'])) for g in gen]; gs = [sum(gl[:i]) for i in range(len(gen))]
    fl = [len(norm(f)) for f in frasi]; fs = [sum(fl[:i]) for i in range(len(frasi))]
    assert sum(gl) == sum(fl), (n, sum(gl), sum(fl))
    starts = []
    for c in fs:
        i = max(k for k in range(len(gen)) if gs[k] <= c); g = gen[i]
        if gs[i] == c: starts.append(round(g['inizio'], 3)); continue
        te = g['inizio'] + (g['fine'] - g['inizio']) * (c - gs[i]) / gl[i]
        P = g.get('parole', [])
        # di preferenza la parola che segue un punto (la frase della lista finisce sempre con . ! ?)
        w = [P[k][0] for k in range(1, len(P)) if str(P[k - 1][1]).rstrip()[-1:] in '.!?' and g['inizio'] < P[k][0] < g['fine']]
        w = w or [t for t, _ in P if g['inizio'] < t < g['fine']]
        t = min(w, key=lambda x: abs(x - te)) if w else te
        starts.append(round(t, 3)); agganci.append('%s %.2f' % (n, t))
    assert starts == sorted(starts), (n, starts)
    shutil.copy(G + n + '.wav', O + n + '.wav')
    M[n] = {'dur': round(m['durata'], 3), 'phrases': starts, 'text': frasi, 'avvisi': m.get('avvisi', [])}
json.dump(M, open(O + 'meta_locale.json', 'w'), ensure_ascii=False, indent=1)
print('voci', len(M), '| mancano', manca, '| frasi agganciate dentro un pezzo:', len(agganci), agganci[:10])
