#!/usr/bin/env python3
# Voce narrante Telesio - una voce.
# uso: python3 voce_locale.py uscita.wav "testo"  [--campione file.wav] [--esagerazione 0.5]
# Scrive uscita.wav (24 kHz mono, -16 LUFS) e accanto meta_<nome>.json (durata, inizio di ogni frase, testo).
import sys, os, argparse
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'motore'))
ap = argparse.ArgumentParser()
ap.add_argument('uscita'); ap.add_argument('testo')
ap.add_argument('--campione'); ap.add_argument('--esagerazione', type=float)
a = ap.parse_args()
import telesio
u = os.path.abspath(a.uscita); d, n = os.path.split(u)
m = telesio.genera_voce(a.testo, u, campione=a.campione, esag=a.esagerazione,
                        cache=os.path.join(d, '.cache_telesio'), meta=os.path.join(d, 'meta_' + os.path.splitext(n)[0] + '.json'))
print('%s  durata %.1f s  calcolo %.0f s  avvisi %d' % (u, m['durata'], m['tempo_di_calcolo_s'], len(m['avvisi'])))
for x in m['avvisi']: print('  AVVISO', x)
