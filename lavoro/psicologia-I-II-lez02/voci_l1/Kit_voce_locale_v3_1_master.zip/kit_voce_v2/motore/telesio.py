# Generatore di voce narrante "Telesio" (uso interno).
# Catena: testo -> pezzi (frasi) -> generazione -> trascrizione e confronto (rigenera se non torna)
#         -> pulizia dei bordi -> ritmo e pause come Kore -> stesso volume -> unione -> WAV 24 kHz mono + meta.
import os, sys, re, json, time, hashlib, difflib, unicodedata, subprocess, tempfile
import numpy as np, soundfile as sf
QUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, QUI)
import cb2, numeri

KIT = os.path.dirname(QUI)
VERSIONE = 'telesio-5'
# ---- impostazioni (si possono cambiare con variabili d'ambiente) ----
CAMPIONE = os.environ.get('TELESIO_CAMPIONE', os.path.join(KIT, 'campioni', 'kore_S4_10s.wav'))
STILE = os.environ.get('TELESIO_STILE', os.path.join(KIT, 'campioni', 'kore_stile_caloroso.wav'))  # campione per lo stile/emozione (vuoto = come CAMPIONE)
ESAGERAZIONE = float(os.environ.get('TELESIO_ESAGERAZIONE', '1.0'))
MELODIA = float(os.environ.get('TELESIO_MELODIA', '1.5'))  # allargamento della melodia (1.0 = nessuno)
ACCENTI = float(os.environ.get('TELESIO_ACCENTI', '1.6'))  # contrasto tra sillabe forti e deboli (Kore misurata: 6-7 dB)
BRILLANTEZZA = float(os.environ.get('TELESIO_BRILLANTEZZA', '6.5'))  # dB in più sopra 2,5 kHz (lo "squillo")
TEMPO = float(os.environ.get('TELESIO_TEMPO', '1.0'))  # >1 = più svelta (a 1.08 le parole brevi perdono nitidezza: misurato)
CONSONANTI = float(os.environ.get('TELESIO_CONSONANTI', '3'))  # dB in più sulle consonanti sorde (dizione)
ALTEZZA = float(os.environ.get('TELESIO_ALTEZZA', '1.5'))  # semitoni in più (allegria, scelta di Sara: versioni 16-17)
TENTATIVI = int(os.environ.get('TELESIO_TENTATIVI', '5'))
RITMO = float(os.environ.get('TELESIO_RITMO', '6.0'))          # oltre questo ritmo la voce viene rallentata (con RALL_MAX=1.0 mai)
RALL_MAX = float(os.environ.get('TELESIO_RALL_MAX', '1.0'))    # rallentamento massimo (0.85 = 15%)
PROMPT_SEC = float(os.environ.get('TELESIO_PROMPT_SEC', '6'))   # secondi di campione dati al decoder
LUFS = float(os.environ.get('TELESIO_LUFS', '-16'))
os.environ.setdefault('TELESIO_DECODER', 'cd_singolo_int8.onnx')  # decoder a passaggio singolo, 8 bit
# pause (secondi) dopo la punteggiatura: obiettivo, minimo, massimo (misurate sulla Kore vera)
PAUSE = {',': (0.17, 0.10, 0.30), '.': (0.40, 0.30, 0.60), '!': (0.42, 0.30, 0.65), '?': (0.45, 0.30, 0.70),
         ':': (0.35, 0.25, 0.55), ';': (0.32, 0.22, 0.50)}
LETTERE = dict(zip('abcdefghijklmnopqrstuvwxyz', 'a bi ci di e effe gi acca i ilunga cappa elle emme enne o pi cu erre esse ti u vu doppiavu ics ipsilon zeta'.split()))

def log(*a):
    print(*a, file=sys.stderr, flush=True)

# ------------------------------------------------------------------ testo
def pronunce():
    p = os.path.join(KIT, 'pronunce.json')
    return json.load(open(p, encoding='utf-8')) if os.path.exists(p) else {}

def da_leggere(t):
    """Testo che riceve il modello: sigle e nomi stranieri sostituiti con la pronuncia (pronunce.json)."""
    for k, v in pronunce().items():
        if k.startswith('_'): continue
        fl = 0 if k.isupper() else re.I  # le sigle (tutte maiuscole) solo come scritte; le parole anche con la maiuscola
        t = re.sub(r'(?<!\w)' + re.escape(k) + r'(?!\w)', v, t, flags=fl)
    # lettera maiuscola isolata (non A E I O U, che sono parole): "a S" -> "a esse"
    t = re.sub(r'(?<![\w\'’])([B-DF-HJ-NP-TV-Z])(?![\w\'’])', lambda m: LETTERE[m.group(1).lower()], t)
    # sigla tutta maiuscola senza vocali (es. "DPCM"): lettera per lettera
    t = re.sub(r'(?<!\w)([B-DF-HJ-NP-TV-Z]{2,6})(?!\w)', lambda m: ' '.join(LETTERE[c.lower()] for c in m.group(1)), t)
    t = t.replace('«', '').replace('»', '').replace('"', '').replace('¿', '').replace('¡', '')
    return re.sub(r'\s+', ' ', t).strip()

def dividi(testo):
    """Divide in pezzi da generare. Restituisce [(testo_pezzo, pausa_dopo_in_secondi)]."""
    out = []
    parti = re.split(r'(\[pausa\s*[\d.,]+\])', testo)
    for p in parti:
        m = re.match(r'\[pausa\s*([\d.,]+)\]', p)
        if m:
            if out: out[-1][1] = max(out[-1][1], float(m.group(1).replace(',', '.')))
            continue
        p = p.strip()
        if not p: continue
        frasi = [f.strip() for f in re.split(r'(?<=[.!?])\s+', p) if f.strip()]
        # unisce i pezzi troppo corti (meno di 4 parole) a quello dopo
        pezzi = []; acc = ''
        for f in frasi:
            acc = (acc + ' ' + f).strip()
            if len(acc.split()) >= 4: pezzi.append(acc); acc = ''
        if acc:
            if pezzi and len(acc.split()) < 3: pezzi[-1] += ' ' + acc
            else: pezzi.append(acc)
        # spezza i pezzi troppo lunghi alla virgola più vicina al centro
        fin = []
        for z in pezzi:
            coda = [z]
            while coda:
                x = coda.pop(0)
                if len(x) <= 230: fin.append(x); continue
                virg = [m.end() for m in re.finditer(r'[;:]\s', x) if 60 < m.end() < len(x) - 40] or [m.end() for m in re.finditer(r',\s', x)]
                if not virg: fin.append(x); continue
                k = min(virg, key=lambda i: abs(i - len(x) / 2))
                coda[:0] = [x[:k].strip(), x[k:].strip()]
        for z in fin:
            out.append([z, PAUSE.get(z[-1], PAUSE['.'])[0] if z[-1] in PAUSE else 0.35])
    return out

def parole(t):
    """Parole normalizzate per il confronto: minuscole, senza accenti, numeri in lettere, lettere singole col loro nome."""
    t = unicodedata.normalize('NFD', t.lower()); t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    t = re.sub(r'(\d)[.,](\d{3})', r'\1\2', t)
    out = []
    for w in re.findall(r'[a-z]+|\d+', t):
        if w.isdigit(): w = numeri.in_lettere(w)
        elif len(w) == 1 and w not in 'aeioulcdn': w = LETTERE[w]  # lettera detta da sola: "S" = "esse"
        out.append(w)
    return out

def confronta(testo, trascr):
    """Restituisce (errori, simili, dettagli). Parola quasi uguale (>=70% di lettere) = simile, non errore."""
    a, b = parole(testo), parole(trascr)
    err = 0; sim = 0; det = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == 'equal': continue
        A, B = a[i1:i2], b[j1:j2]
        if op == 'replace' and ''.join(A) == ''.join(B): continue  # "centottanta" vs "cento ottanta"
        if op == 'replace' and len(A) == len(B) and all(difflib.SequenceMatcher(None, x, y).ratio() >= 0.7 for x, y in zip(A, B)):
            sim += len(A); det.append('simile: %s ~ %s' % (' '.join(A), ' '.join(B))); continue
        if op == 'replace' and difflib.SequenceMatcher(None, ''.join(A), ''.join(B)).ratio() >= 0.8 and abs(len(A) - len(B)) <= 1:
            sim += max(len(A), len(B)); det.append('simile: %s ~ %s' % (' '.join(A), ' '.join(B))); continue
        if op in ('delete', 'insert') and all(x in ('e', 'a', 'o', 'i', 'ed', 'ad') for x in A + B):
            sim += 1; det.append('lieve: %s %s' % ({'delete': 'manca', 'insert': 'in più'}[op], ' '.join(A + B))); continue
        err += max(i2 - i1, j2 - j1)
        det.append({'replace': 'diversa', 'delete': 'manca', 'insert': 'in più'}[op] + ': %s | %s' % (' '.join(A), ' '.join(B)))
    return err, sim, det

def sillabe(t):
    t = unicodedata.normalize('NFD', ' '.join(parole(t)))
    return len(re.findall(r'[aeiouy]+', t))

# ------------------------------------------------------------------ audio
_ASR = None
def trascrivi(w, sr=24000):
    """[(inizio_s, parola)] con la trascrizione automatica."""
    global _ASR
    if _ASR is None:
        import pk as _p; _ASR = _p
    x = np.interp(np.arange(0, len(w), sr / 16000), np.arange(len(w)), w).astype(np.float32) if sr != 16000 else w
    W = []; t = 0.0; T = len(x) / 16000
    while t < T - 0.2:
        b = min(T, t + 20.0); seg = x[int(t * 16000):int(b * 16000)]
        if np.abs(seg).max() > 0.01: W += _ASR.words(_ASR.transcribe(seg, t))
        t = b
    return W

def energia(w, sr=24000):
    """dB a passi di 10 ms."""
    h = sr // 100; n = len(w) // h
    e = np.sqrt(np.mean(w[:n * h].reshape(n, h) ** 2, axis=1) + 1e-12)
    return 20 * np.log10(e)

def voce_si(w):
    db = energia(w); return db > (np.percentile(db, 98) - 38)

def pulisci_bordi(w, W):
    """Toglie silenzi e rumori prima della prima parola e dopo l'ultima."""
    v = voce_si(w)
    if not v.any() or not W: return w, 0.0
    # segmenti di voce separati da almeno 0,25 s di silenzio
    seg = []; i = 0; n = len(v)
    while i < n:
        if v[i]:
            j = i
            while j < n and v[j]: j += 1
            seg.append([i, j]); i = j
        else: i += 1
    unito = []
    for s in seg:
        if unito and s[0] - unito[-1][1] < 25: unito[-1][1] = s[1]
        else: unito.append(s)
    t0 = int(W[0][0] * 100); tl = int(W[-1][0] * 100)
    keep = [s for s in unito if s[1] > t0 - 5 and s[0] <= tl + 15]
    if not keep: keep = unito
    a = max(0, keep[0][0] - 4); b = min(n, keep[-1][1] + 8)
    z = w[a * 240:b * 240].copy()
    f = 240; z[:f] *= np.linspace(0, 1, f); z[-f * 2:] *= np.linspace(1, 0, f * 2)
    return z, a / 100

def rallenta(w, f):
    if f >= 0.995: return w
    with tempfile.TemporaryDirectory() as d:
        sf.write(d + '/a.wav', w, 24000, subtype='FLOAT')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', d + '/a.wav', '-af', 'atempo=%.4f' % f, '-c:a', 'pcm_f32le', d + '/b.wav'], check=True)
        z, _ = sf.read(d + '/b.wav', dtype='float32')
    return z

def velocizza(w, f):
    if f <= 1.005: return w
    with tempfile.TemporaryDirectory() as d:
        sf.write(d + '/a.wav', w, 24000, subtype='FLOAT')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', d + '/a.wav', '-af', 'atempo=%.4f' % f, '-c:a', 'pcm_f32le', d + '/b.wav'], check=True)
        z, _ = sf.read(d + '/b.wav', dtype='float32')
    return z

def tempo_parlato(w):
    """Secondi di voce senza le pause oltre 0,15 s."""
    v = voce_si(w); idx = np.where(v)[0]
    if not len(idx): return len(w) / 24000
    v = v[idx[0]:idx[-1] + 1]; p = 0; r = 0
    for x in v:
        if not x: r += 1
        else:
            if r >= 15: p += r
            r = 0
    return (len(v) - p) / 100

def sistema_pause(w, testo, W):
    """Porta le pause dopo la punteggiatura ai valori di Kore. Allinea il testo alle parole trascritte."""
    tw = [(m.group(0), m.end()) for m in re.finditer(r"\S+", testo)]
    # per ogni parola del testo: la sua forma normalizzata (può essere più parole) e la punteggiatura finale
    tn = []
    for tok, _ in tw:
        p = parole(tok); pun = tok.rstrip('»"\')')[-1:] if tok.rstrip('»"\')') else ''
        for k, x in enumerate(p): tn.append((x, pun if k == len(p) - 1 else ''))
    an = []
    for k, (t, ww) in enumerate(W):
        for x in parole(ww): an.append((x, k))
    sm = difflib.SequenceMatcher(None, [x for x, _ in tn], [x for x, _ in an], autojunk=False)
    mappa = {}
    for blk in sm.get_matching_blocks():
        for d in range(blk.size): mappa[blk.a + d] = an[blk.b + d][1]
    db = energia(w); soglia = np.percentile(db, 98) - 38
    modifiche = []  # (posizione_campione, nuova_durata_silenzio, vecchia_durata)
    for i, (x, pun) in enumerate(tn[:-1]):
        if pun not in PAUSE or i not in mappa or i + 1 not in mappa: continue
        k1, k2 = mappa[i], mappa[i + 1]
        if k2 != k1 + 1: continue
        a = int(W[k1][0] * 100) + 10; b = int(W[k2][0] * 100)
        if b - a < 3: continue
        reg = db[a:b] < soglia
        # silenzio più lungo nella regione
        best = (0, a); r = 0
        for j, s in enumerate(reg):
            r = r + 1 if s else 0
            if r > best[0]: best = (r, a + j - r + 1)
        obi, lo, hi = PAUSE[pun]
        L = best[0] / 100
        if lo <= L <= hi: continue
        if L >= 0.03:
            centro = best[1] + best[0] // 2; modifiche.append((centro * 240, obi, L))
        else:
            j = a + int(np.argmin(db[a:b]))
            if db[j] < soglia + 8: modifiche.append((j * 240 + 120, obi, 0.0))
    if not modifiche: return w, [], []
    pezzi = []; prec = 0; info = []; spost = []
    for pos, obi, L in sorted(modifiche):
        delta = obi - L
        if delta > 0:
            pezzi += [w[prec:pos], np.zeros(int(delta * 24000), np.float32)]; prec = pos
        else:
            togli = int(-delta * 24000) // 2
            pezzi.append(w[prec:pos - togli]); prec = pos + togli
        info.append('%.2f->%.2f' % (L, obi)); spost.append((pos / 24000, delta))
    pezzi.append(w[prec:])
    # piccole dissolvenze sui punti di taglio per evitare click
    z = np.concatenate(pezzi).astype(np.float32)
    return z, info, spost

_FIR = None
def colore_kore(w):
    """Correzione del colore (equalizzazione) misurata: spettro medio Kore vera / spettro medio generato (max +-6 dB)."""
    global _FIR
    p = os.path.join(KIT, 'campioni', 'kore_eq.npy')
    if os.environ.get('TELESIO_EQ', '1') != '1' or not os.path.exists(p): return w
    if _FIR is None:
        import scipy.signal as ss
        f, g = np.load(p); _FIR = ss.firwin2(1025, f / 12000, 10 ** (g / 20))
    import scipy.signal as ss
    return ss.fftconvolve(w, _FIR, 'same').astype(np.float32)

def brillante(w, db):
    """Mensola sugli acuti: +db sopra circa 2,5 kHz (presenza, squillo)."""
    import scipy.signal as ss
    f = np.array([0, 1500, 2500, 6000, 9000, 12000]); g = np.array([0, 0, db * 0.7, db, db * 0.8, db * 0.5])
    fir = ss.firwin2(513, f / 12000, 10 ** (g / 20))
    return ss.fftconvolve(w, fir, 'same').astype(np.float32)

def accentua(w, k):
    """Aumenta il contrasto tra sillabe forti e deboli: guadagno = (k-1) * (energia - mediana), solo dove c'è voce."""
    import scipy.signal as ss
    h = 240; n = len(w) // h
    e = np.sqrt(np.convolve(w[:n * h] ** 2, np.ones(960) / 960, 'same')[::h] + 1e-10)
    db = 20 * np.log10(e); v = db > db.max() - 35
    if v.sum() < 10: return w
    med = np.median(db[v])
    g = np.clip((k - 1) * (db - med), -6, 6); g[~v] = 0
    g = np.convolve(g, np.ones(5) / 5, 'same')  # 50 ms di smussatura
    gs = np.interp(np.arange(len(w)), np.arange(n) * h + h / 2, g)
    return (w * 10 ** (gs / 20)).astype(np.float32)

def lufs(w):
    import pyloudnorm as pyln
    try: return pyln.Meter(24000).integrated_loudness(w.astype(np.float64))
    except Exception: return -30.0

# ------------------------------------------------------------------ un pezzo
def _chiave(testo, campione, esag):
    h = hashlib.md5(open(campione, 'rb').read()).hexdigest()[:8]
    hs = hashlib.md5(open(STILE, 'rb').read()).hexdigest()[:8] if STILE else ''
    return hashlib.md5(('%s|%s|%s|%s|%s|%s|%s' % (VERSIONE, testo + '|' + da_leggere(testo), h, esag, PROMPT_SEC, TENTATIVI, hs)).encode()).hexdigest()[:16]

def genera_pezzo(testo, campione=None, esag=None, cache=None, seme0=0):
    """Genera un pezzo controllato. Restituisce (audio, rapporto)."""
    campione = campione or CAMPIONE; esag = ESAGERAZIONE if esag is None else esag
    detto = da_leggere(testo)
    grezzo = None
    if cache:
        os.makedirs(cache, exist_ok=True); ch = os.path.join(cache, _chiave(testo, campione, esag))
        if os.path.exists(ch + '.wav') and os.path.exists(ch + '.json'):
            z, _ = sf.read(ch + '.wav', dtype='float32'); j = json.load(open(ch + '.json'))
            grezzo = (z, [tuple(x) for x in j['W']], j['rit'], j['scelta'], j['prove'])
    if grezzo is None:
        grezzo = _genera_grezzo(testo, detto, campione, esag, seme0)
        if cache:
            sf.write(ch + '.wav', grezzo[0], 24000, subtype='FLOAT')
            json.dump({'W': grezzo[1], 'rit': grezzo[2], 'scelta': grezzo[3], 'prove': grezzo[4]}, open(ch + '.json', 'w'), ensure_ascii=False)
    w, W, rit, scelta, prove = grezzo
    return lavora(w, W, rit, testo, detto, scelta, prove)

def _genera_grezzo(testo, detto, campione, esag, seme0):
    migliore = None; prove = []
    toks = {}; salto = 0
    for k in range(TENTATIVI):
        # tentativi pari: frase nuova; dispari: stessa frase, solo decoder rifatto (costa circa la metà)
        seme = seme0 + (k + salto) // 2
        t0 = time.time()
        if seme not in toks: toks[seme] = cb2.genera_token(detto, campione, exag=esag, seed=seme, stile=STILE or None)
        tok, finito = toks[seme]
        w = cb2.decodifica(tok, campione, PROMPT_SEC)
        tg = time.time() - t0
        W = trascrivi(w)
        w, off = pulisci_bordi(w, W)
        W = [(max(0.0, t - off), x) for t, x in W if -0.4 <= t - off < len(w) / 24000]
        trascr = ' '.join(x for _, x in W)
        e1, s1, d1 = confronta(testo, trascr)
        if detto != testo:
            e2, s2, d2 = confronta(detto, trascr)
            if e2 < e1: e1, s1, d1 = e2, s2, d2
        parl = tempo_parlato(w); rit = sillabe(testo) / max(parl, 0.3)
        problemi = list(d1)
        if not finito: problemi.append('non chiuso'); e1 += 3; salto += 1 if (k + salto) % 2 == 0 else 0
        if not (3.5 <= rit <= 8.0): problemi.append('ritmo strano %.1f' % rit); e1 += 2
        punti = e1 * 10 + s1
        prove.append({'seme': seme, 'errori': e1, 'simili': s1, 'secondi': round(tg, 1), 'trascrizione': trascr, 'note': problemi})
        log('   tentativo %d: errori %d simili %d (%.0f s) %s' % (k + 1, e1, s1, tg, '; '.join(problemi)[:120]))
        if migliore is None or punti < migliore[0]: migliore = (punti, w, W, rit, prove[-1])
        if e1 == 0 and s1 == 0: break
        # nessun errore vero: si accetta, tranne quando la prima parola è solo "simile" (difetto tipico d'attacco)
        primo = (parole(testo) or [''])[0]
        if e1 == 0 and not any(x.startswith('simile: ' + primo + ' ') for x in problemi): break
        # differenze minori già viste in un tentativo precedente senza errori: è la trascrizione, non la voce
        minori = sorted(x for x in problemi if x.startswith(('simile', 'lieve')))
        if e1 == 0 and any(p['errori'] == 0 and sorted(x for x in p['note'] if x.startswith(('simile', 'lieve'))) == minori for p in prove[:-1]): break
        if e1 == 0 and k >= 1 and all(x.startswith('lieve') for x in minori): break
    _, w, W, rit, scelta = migliore
    return w, W, rit, scelta, prove

def lavora(w, W, rit, testo, detto, scelta, prove):
    """Ritmo e pause come Kore, volume uniforme (rapido: si rifà ogni volta)."""
    # ritmo come Kore
    f = min(1.0, max(RALL_MAX, RITMO / rit)) * TEMPO
    w = rallenta(w, f) if f < 0.995 else velocizza(w, f)
    W = [(t / f, x) for t, x in W]
    w, pause_info, spost = sistema_pause(w, testo, W)
    W = [(t + sum(d for p, d in spost if p < t), x) for t, x in W]
    if MELODIA != 1.0 or CONSONANTI or ALTEZZA:
        import melodia; w = melodia.allarga(w, fattore=MELODIA, consonanti_db=CONSONANTI, semitoni=ALTEZZA)
    w = colore_kore(w)
    if BRILLANTEZZA: w = brillante(w, BRILLANTEZZA)
    if ACCENTI != 1.0: w = accentua(w, ACCENTI)
    # volume uguale per tutti i pezzi
    g = LUFS - lufs(w); w = (w * 10 ** (g / 20)).astype(np.float32)
    rapporto = {'testo': testo, 'detto': detto, 'tentativi': len(prove), 'scelto': scelta, 'ritmo_prima': round(rit, 2),
                'rallentamento': round(f, 3), 'pause_sistemate': pause_info, 'parole': [[round(t, 2), x] for t, x in W]}
    return w, rapporto

# ------------------------------------------------------------------ voce intera
def limita(w, picco_db=-1.0):
    lim = 10 ** (picco_db / 20)
    if np.abs(w).max() <= lim: return w
    with tempfile.TemporaryDirectory() as d:
        sf.write(d + '/a.wav', w, 24000, subtype='FLOAT')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', d + '/a.wav', '-af', 'alimiter=limit=%.4f:level=false:attack=2:release=40' % (lim * 0.97), '-c:a', 'pcm_f32le', d + '/b.wav'], check=True)
        z, _ = sf.read(d + '/b.wav', dtype='float32')
    return z[:len(w)]

def genera_voce(testo, uscita, campione=None, esag=None, cache=None, meta=None):
    t0 = time.time()
    pezzi = dividi(testo)
    log('%d pezzi' % len(pezzi))
    audio = []; frasi = []; tpos = 0.0; rapp = []
    for i, (p, pausa) in enumerate(pezzi):
        log(' [%d/%d] %s' % (i + 1, len(pezzi), p[:80]))
        w, r = genera_pezzo(p, campione, esag, cache, seme0=0)
        if os.environ.get('TELESIO_CONTROLLO_FINALE') == '1':  # seconda trascrizione sul pezzo finito (più lento)
            Wf = [tuple(x) for x in trascrivi(w)]
        else:
            Wf = [tuple(x) for x in r['parole']]
        frasi.append({'inizio': round(tpos, 2), 'fine': round(tpos + len(w) / 24000, 2), 'testo': p,
                      'parole': [[round(tpos + t, 2), x] for t, x in Wf]})
        audio.append(w); tpos += len(w) / 24000
        if i < len(pezzi) - 1:
            audio.append(np.zeros(int(pausa * 24000), np.float32)); tpos += pausa
        rapp.append(r)
    z = np.concatenate(audio)
    g = LUFS - lufs(z); z = limita((z * 10 ** (g / 20)).astype(np.float32))
    os.makedirs(os.path.dirname(os.path.abspath(uscita)), exist_ok=True)
    sf.write(uscita, z, 24000, subtype='PCM_16')
    dur = len(z) / 24000; tempo = time.time() - t0
    avvisi = ['pezzo %d: %s' % (i + 1, '; '.join(x for x in r['scelto']['note'] if not x.startswith('lieve'))) for i, r in enumerate(rapp)
              if r['scelto']['errori'] or any(x.startswith('simile') for x in r['scelto']['note'])]
    m = {'durata': round(dur, 2), 'testo': testo, 'frasi': frasi, 'volume_lufs': round(lufs(z), 1),
         'tempo_di_calcolo_s': round(tempo, 1), 'avvisi': avvisi, 'versione': VERSIONE,
         'impostazioni': {'campione': os.path.basename(campione or CAMPIONE), 'esagerazione': ESAGERAZIONE if esag is None else esag,
                          'ritmo': RITMO, 'prompt_sec': PROMPT_SEC, 'melodia': MELODIA, 'accenti': ACCENTI, 'brillantezza': BRILLANTEZZA, 'tempo': TEMPO, 'consonanti': CONSONANTI, 'altezza': ALTEZZA},
         'dettagli': rapp}
    if meta: json.dump(m, open(meta, 'w'), ensure_ascii=False, indent=1)
    log('fatto: %.1f s di voce in %.0f s; avvisi: %d' % (dur, tempo, len(avvisi)))
    return m
