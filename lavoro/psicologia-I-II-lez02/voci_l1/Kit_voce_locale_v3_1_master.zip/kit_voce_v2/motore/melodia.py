# Allarga la melodia (escursione dell'intonazione) lasciando nitide le consonanti.
# Metodo: analisi e risintesi WORLD (pyworld, licenza MIT/BSD) SOLO sui tratti con voce (vocali, consonanti sonore);
# le consonanti sorde (s, t, f, c, p...) restano quelle originali, più nitide, e si possono rinforzare (consonanti_db).
#   f0_nuova = centro * (f0 / centro) ** fattore
import numpy as np, pyworld as pw, scipy.signal as ss, os
TREMOLIO = float(os.environ.get('TELESIO_TREMOLIO', '0.5'))  # quota del tremolio rapido mantenuta (Kore: 4-5 centesimi)

def allarga(w, sr=24000, fattore=1.2, centro_hz=None, consonanti_db=0.0, semitoni=0.0):
    x = w.astype(np.float64)
    f0, t = pw.harvest(x, sr, f0_floor=100, f0_ceil=500, frame_period=5.0)
    f0 = pw.stonemask(x, f0, t, sr)
    v = f0 > 0
    if v.sum() < 10: return w
    if fattore != 1.0 or centro_hz or semitoni:
        sp = pw.cheaptrick(x, f0, t, sr); ap = pw.d4c(x, f0, t, sr)
        c = np.exp(np.median(np.log(f0[v]))); f1 = f0.copy()
        # si allarga solo l'andamento ampio (media mobile 60 ms); il tremolio rapido si riduce (voce più giovane e ferma)
        lf = np.zeros_like(f0); lf[v] = np.log(f0[v] / c)
        k = 12; peso = np.convolve(v.astype(float), np.ones(k), 'same'); liscio = np.convolve(lf, np.ones(k), 'same') / np.maximum(peso, 1)
        rapido = lf - liscio
        f1[v] = (centro_hz or c) * 2 ** (semitoni / 12) * np.exp(fattore * liscio[v] + TREMOLIO * rapido[v])
        y = pw.synthesize(f1, sp, ap, sr, frame_period=5.0)[:len(w)]
        if len(y) < len(w): y = np.pad(y, (0, len(w) - len(y)))
    else:
        y = x.copy()
    # maschera "voce" (1) / "consonante sorda o silenzio" (0), smussata 15 ms
    m = np.interp(np.arange(len(w)), t * sr, v.astype(float))
    k = int(0.015 * sr); m = np.convolve(m, np.ones(k) / k, 'same')
    out = m * y + (1 - m) * x
    if consonanti_db:
        b, a = ss.butter(4, 2500 / (sr / 2), 'high'); hp = ss.filtfilt(b, a, x)
        out = out + (10 ** (consonanti_db / 20) - 1) * (1 - m) * hp
    return out.astype(np.float32)
