# Crea il decoder "singolo": fa solo la versione guidata (la versione di confronto della guida CFG viene tolta).
# Misurato: timbro uguale all'originale, calcolo del decoder circa dimezzato. Poi quantizzazione a 8 bit.
# uso: python3 decoder_singolo.py uscita.onnx      (parte da cd_fix.onnx, creato da prepara_modelli.py)
import sys, os, onnx, numpy as np
from onnx import helper, numpy_helper
M = os.environ.get('TELESIO_MODELLI', '/tmp/cbx/') + 'onnx/'
uscita = sys.argv[1]
m = onnx.load(M + 'cd_fix.onnx', load_external_data=False); g = m.graph
prod = {o: n for n in g.node for o in n.output}
def rinomina(gr, vecchio, nuovo):
    for c in gr.node:
        for i, x in enumerate(c.input):
            if x == vecchio: c.input[i] = nuovo
        for a in c.attribute:
            if a.type == onnx.AttributeProto.GRAPH: rinomina(a.g, vecchio, nuovo)
# 1) i buffer a 2 caselle (Concat con zeri sull'asse 0) diventano a 1 casella
n_buf = 0
for n in list(g.node):
    if n.op_type == 'Concat' and [a.i for a in n.attribute if a.name == 'axis'][0] == 0 and len(n.input) == 2 \
       and n.input[1] in prod and prod[n.input[1]].op_type == 'ConstantOfShape' and not n.name.startswith('/m_source'):
        rinomina(g, n.output[0], n.input[0]); g.node.remove(n); n_buf += 1
# 2) scritture di 2 caselle insieme (indici [0,1]): si tiene solo la prima metà dell'aggiornamento
uno = 'singolo_uno'; zero = 'singolo_zero'
g.initializer.extend([numpy_helper.from_array(np.array([0], np.int64), zero), numpy_helper.from_array(np.array([1], np.int64), uno)])
n_sc = 0
for n in list(g.node):
    if n.op_type == 'ScatterND' and not n.name.startswith('/m_source') and n.input[1] in prod:
        p = prod[n.input[1]]
        if p.op_type in ('Unsqueeze', 'Concat', 'Reshape') and n.name not in ('/ScatterND', '/ScatterND_56', '/ScatterND_57'):
            # ScatterND con indici calcolati: in questo modello sono quelli [0,1] (verificato facendolo girare)
            s = n.output[0] + '_singolo'
            g.node.append(helper.make_node('Slice', [n.input[2], zero, uno, zero], [s], name=n.name + '_singolo'))
            rinomina(g, n.output[0], s); g.node.remove(n); n_sc += 1
# 3) alla fine di ogni passo la "seconda metà" (confronto) diventa uguale alla prima: (1+w)*c - w*c = c
n_sl = 0
for n in g.node:
    if n.op_type == 'Sub':
        a, b = [prod.get(x) for x in n.input]
        if a is None or b is None or a.op_type != 'Mul' or b.op_type != 'Mul': continue
        sa = [prod[x] for x in a.input if x in prod and prod[x].op_type == 'Slice']
        sb = [prod[x] for x in b.input if x in prod and prod[x].op_type == 'Slice']
        if sa and sb and sa[0].input[0] == sb[0].input[0]:
            sb[0].input[1] = sa[0].input[1]; sb[0].input[2] = sa[0].input[2]; n_sl += 1
# 4) il "2" scritto fisso nelle forme dei blocchi di attenzione della rete principale diventa 1
INIT = {i.name: i for i in g.initializer}
due_uno = 'singolo_forma_uno'; g.initializer.append(numpy_helper.from_array(np.array([1], np.int64), due_uno))
n_fx = 0
def fissa(gr):
    global n_fx
    for nd in gr.node:
        if nd.name.startswith(('/down_blocks', '/mid_blocks', '/up_blocks')) and nd.op_type in ('Concat', 'Reshape', 'Expand', 'Tile'):
            for i, x in enumerate(nd.input):
                if x in INIT and INIT[x].data_location != onnx.TensorProto.EXTERNAL:
                    v = numpy_helper.to_array(INIT[x])
                    if v.dtype == np.int64 and v.shape == (1,) and v[0] == 2 and nd.op_type == 'Concat' and i == 0:
                        nd.input[i] = due_uno; n_fx += 1
                    elif v.dtype == np.int64 and v.ndim == 1 and v.size > 1 and v[0] == 2 and nd.op_type == 'Reshape' and i == 1:
                        nome = x + '_singolo'
                        if nome not in INIT:
                            w = v.copy(); w[0] = 1; t = numpy_helper.from_array(w, nome); g.initializer.append(t); INIT[nome] = t
                        nd.input[i] = nome; n_fx += 1
fissa(g)
print('forme con 2 fisso corrette', n_fx)
print('buffer resi singoli', n_buf, '| scritture doppie tolte', n_sc, '| passi con guida semplificata', n_sl)
# ordina i nodi (i nuovi Slice sono in fondo)
nodes = list(g.node); out_of = {o: nd for nd in nodes for o in nd.output}
fatti = set(i.name for i in g.input) | set(i.name for i in g.initializer) | {''}
ordinati = []; visti = set()
def sub_in(gr):
    s = set()
    for nd in gr.node:
        s.update(nd.input)
        for a in nd.attribute:
            if a.type == onnx.AttributeProto.GRAPH: s |= sub_in(a.g)
    return s
import sys as _s; _s.setrecursionlimit(100000)
def visita(nd):
    if nd.name in visti: return
    visti.add(nd.name)
    dip = set(nd.input)
    for a in nd.attribute:
        if a.type == onnx.AttributeProto.GRAPH: dip |= sub_in(a.g)
    for x in dip:
        if x in out_of: visita(out_of[x])
    ordinati.append(nd)
for nd in nodes: visita(nd)
del g.node[:]; g.node.extend(ordinati)
onnx.load_external_data_for_model(m, M)
# 5) costanti già calcolate in doppia copia (tempo di ogni passo): si tiene la prima copia
n_c = 0
for ini in list(g.initializer):
    if ini.name.endswith('_output_0') and len(ini.dims) >= 2 and ini.dims[0] == 2:
        v = numpy_helper.to_array(ini)
        if np.allclose(v[0], v[1]):
            nuovo = numpy_helper.from_array(v[:1].copy(), ini.name); g.initializer.remove(ini); g.initializer.append(nuovo); n_c += 1
print('costanti doppie ridotte', n_c)
tmp = uscita + '.fp32.onnx'
for f in (tmp, tmp + '_data'):
    if os.path.exists(f): os.remove(f)
onnx.save(m, tmp, save_as_external_data=True, location=os.path.basename(tmp) + '_data')
from onnxruntime.quantization import quantize_dynamic, QuantType
quantize_dynamic(tmp, uscita, weight_type=QuantType.QInt8, op_types_to_quantize=['MatMul'], use_external_data_format=True, extra_options={'MatMulConstBOnly': True})
for f in (tmp, tmp + '_data'): os.remove(f)
print('scritto', uscita)
