# Scarica i modelli (una volta sola) e crea il decoder alleggerito a 8 bit.
# Voce: onnx-community/chatterbox-multilingual-ONNX (MIT). Trascrizione: Parakeet TDT 0.6b v3 (CC-BY-4.0) da sherpa-onnx.
import os, sys, subprocess, time
M = os.environ.get('TELESIO_MODELLI', '/tmp/cbx/')
A = os.environ.get('TELESIO_ASR', '/tmp/asr/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8/')
def passo(s): print('==', s, flush=True)

if not os.path.exists(M + 'onnx/language_model_q4.onnx_data'):
    passo('scarico il modello della voce (circa 1,9 GB)')
    from huggingface_hub import hf_hub_download
    R = 'onnx-community/chatterbox-multilingual-ONNX'
    for f in ['tokenizer.json'] + ['onnx/%s.onnx%s' % (n, e) for n in ('speech_encoder', 'embed_tokens', 'language_model_q4', 'conditional_decoder') for e in ('', '_data')]:
        hf_hub_download(R, f, local_dir=M)

if not os.path.exists(A + 'encoder.int8.onnx'):
    passo('scarico il modello della trascrizione (circa 0,7 GB)')
    base = os.path.dirname(A.rstrip('/'))
    os.makedirs(base, exist_ok=True)
    u = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8.tar.bz2'
    subprocess.run('cd "%s" && curl -sSL -o p.tar.bz2 %s && tar xjf p.tar.bz2 && rm p.tar.bz2' % (base, u), shell=True, check=True)

if not os.path.exists(M + 'onnx/cd_singolo_int8.onnx'):
    passo('creo il decoder veloce: passaggio singolo, 8 bit (circa 3 minuti)')
    import onnx
    from onnxruntime.quantization import quantize_dynamic, QuantType
    m = onnx.load(M + 'onnx/conditional_decoder.onnx')
    g = m.graph; main = {i.name for i in g.initializer}; cnt = [0]
    def fix(gr):  # il file originale ha 20 nomi doppi nei sottografi: li rinomino
        for nd in gr.node:
            for a in nd.attribute:
                if a.type == onnx.AttributeProto.GRAPH:
                    sub = a.g
                    for ini in sub.initializer:
                        if ini.name in main:
                            old = ini.name; new = old + '_sub%d' % cnt[0]; cnt[0] += 1; ini.name = new
                            for n2 in sub.node:
                                for k, x in enumerate(n2.input):
                                    if x == old: n2.input[k] = new
                    fix(sub)
    fix(g)
    onnx.save(m, M + 'onnx/cd_fix.onnx', save_as_external_data=True, location='cd_fix.onnx_data')
    del m
    subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'decoder_singolo.py'), M + 'onnx/cd_singolo_int8.onnx'], check=True)
    for f in ('cd_fix.onnx', 'cd_fix.onnx_data'): os.remove(M + 'onnx/' + f)
passo('modelli pronti')
