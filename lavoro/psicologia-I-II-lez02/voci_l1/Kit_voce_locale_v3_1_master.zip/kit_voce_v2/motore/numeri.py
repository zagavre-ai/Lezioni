# Numeri in lettere (italiano), per confrontare la trascrizione (che scrive "21") con il testo ("ventuno").
U = 'zero uno due tre quattro cinque sei sette otto nove dieci undici dodici tredici quattordici quindici sedici diciassette diciotto diciannove'.split()
D = ['', '', 'venti', 'trenta', 'quaranta', 'cinquanta', 'sessanta', 'settanta', 'ottanta', 'novanta']

def _sotto100(n):
    if n < 20: return U[n]
    d, u = divmod(n, 10); s = D[d]
    if u in (1, 8): s = s[:-1]
    return s + (U[u] if u else '')

def _sotto1000(n):
    c, r = divmod(n, 100)
    s = '' if c == 0 else ('cento' if c == 1 else U[c] + 'cento')
    if r:
        t = _sotto100(r)
        if c and t.startswith('o'): s = s[:-1]  # centottanta, centotto
        s += t
    return s

def in_lettere(n):
    n = int(n)
    if n < 1000: return _sotto1000(n) if n else 'zero'
    if n < 1000000:
        m, r = divmod(n, 1000)
        s = 'mille' if m == 1 else _sotto1000(m) + 'mila'
        return s + (_sotto1000(r) if r else '')
    mi, r = divmod(n, 1000000)
    s = 'unmilione' if mi == 1 else in_lettere(mi) + 'milioni'
    return s + (in_lettere(r) if r else '')
