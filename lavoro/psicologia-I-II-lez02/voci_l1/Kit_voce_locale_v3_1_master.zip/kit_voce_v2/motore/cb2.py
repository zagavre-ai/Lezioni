# Motore voce narrante "Telesio" (Chatterbox multilingue ONNX, licenza MIT).
# Differenze dal vecchio cb.py: modelli caricati una volta sola, campione elaborato salvato su disco (.npz),
# numero di thread regolabile (variabile TELESIO_THREAD), avvisi di onnxruntime silenziati.
import onnxruntime as ort, numpy as np, subprocess, os, unicodedata, hashlib
from tokenizers import Tokenizer
M = os.environ.get('TELESIO_MODELLI', '/tmp/cbx/')
SR = 24000; START, STOP = 6561, 6562
ort.set_default_logger_severity(3)
_S = {}
def _sess(n):
    if n not in _S:
        so = ort.SessionOptions()
        so.intra_op_num_threads = int(os.environ.get('TELESIO_THREAD', os.cpu_count() or 2))
        so.inter_op_num_threads = 1
        _S[n] = ort.InferenceSession(M + 'onnx/' + n, so, providers=['CPUExecutionProvider'])
    return _S[n]
_TOK = None
def _tok():
    global _TOK
    if _TOK is None: _TOK = Tokenizer.from_file(M + 'tokenizer.json')
    return _TOK
def carica_tutto():
    for n in ('embed_tokens.onnx', 'language_model_q4.onnx', os.environ.get('TELESIO_DECODER', 'cd_singolo_int8.onnx')): _sess(n)

def _load(p):
    x = subprocess.run(['ffmpeg', '-v', 'error', '-i', p, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True).stdout
    return np.frombuffer(x, np.float32)[None, :].copy()
_cache = {}
def campione(p):
    """Elabora il campione una volta sola e lo salva accanto (campione.wav.npz)."""
    if p in _cache: return _cache[p]
    h = hashlib.md5(open(p, 'rb').read()).hexdigest()[:10]
    npz = p + '.npz'
    if os.path.exists(npz):
        z = np.load(npz)
        if str(z['h']) == h:
            _cache[p] = [z['a'], z['b'], z['c'], z['d']]; return _cache[p]
    a, b, c, d = _sess('speech_encoder.onnx').run(None, {'audio_values': _load(p)})
    np.savez(npz, a=a, b=b, c=c, d=d, h=h)
    _cache[p] = [a, b, c, d]; return _cache[p]

def genera_token(text, voice, exag=0.5, lang='it', max_new=None, rp=1.2, temp=0.8, min_p=0.05, seed=0, stile=None):
    EMB, LM = _sess('embed_tokens.onnx'), _sess('language_model_q4.onnx')
    LMI = [i.name for i in LM.get_inputs()]
    rng = np.random.default_rng(seed)
    max_new = max_new or int(len(text) * 2.4) + 60
    cond_emb = campione(stile or voice)[0]  # stile (espressività) può venire da un campione diverso dal timbro
    t = unicodedata.normalize('NFKD', text.lower())  # come il tokenizer originale
    ids = np.array([_tok().encode(f'[{lang}]' + t).ids], np.int64)
    pos = np.where(ids >= START, 0, np.arange(ids.shape[1])[None, :] - 1).astype(np.int64)
    inp = {'input_ids': ids, 'position_ids': pos, 'exaggeration': np.array([exag], np.float32)}
    gen = np.array([[START]], np.int64); past = None
    for i in range(max_new):
        e = EMB.run(None, inp)[0]
        if i == 0:
            e = np.concatenate((cond_emb, e), axis=1); B, L, _ = e.shape
            past = {n: np.zeros([B, 16, 0, 64], np.float32) for n in LMI if n.startswith('past_key_values')}
            mask = np.ones((B, L), np.int64)
        out = LM.run(None, dict(inputs_embeds=e, attention_mask=mask, **past))
        lg = out[0][:, -1, :].copy()
        sc = np.take_along_axis(lg, gen, axis=1); sc = np.where(sc < 0, sc * rp, sc / rp); np.put_along_axis(lg, gen, sc, axis=1)
        if temp > 0:
            z = lg[0] / temp; z = z - z.max(); p = np.exp(z); p /= p.sum(); p[p < min_p * p.max()] = 0; p /= p.sum()
            nt = np.array([[rng.choice(len(p), p=p)]], np.int64)
        else:
            nt = np.argmax(lg, axis=-1, keepdims=True).astype(np.int64)
        gen = np.concatenate((gen, nt), axis=-1)
        if nt[0, 0] == STOP: break
        inp['input_ids'] = nt; inp['position_ids'] = np.full((1, 1), i + 1, np.int64)
        mask = np.concatenate([mask, np.ones((1, 1), np.int64)], axis=1)
        for k, n in enumerate(past): past[n] = out[1 + k]
    finito = bool(gen[0, -1] == STOP)
    return (gen[:, 1:-1] if finito else gen[:, 1:]), finito

def decodifica(tok, voice, prompt_sec=None, dec=None):
    """Trasforma i token in suono. prompt_sec: quanti secondi del campione passare al decoder (None = tutti, max 10)."""
    DEC = dec or _sess(os.environ.get('TELESIO_DECODER', 'cd_singolo_int8.onnx'))
    cond_emb, prompt_tok, xvec, pfeat = campione(voice)
    imp = os.environ.get('TELESIO_IMPRONTA', os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'campioni', 'kore_impronta_media.npy'))
    if imp and os.path.exists(imp):  # impronta della voce media su tutti i campioni Kore (timbro più fedele, misurato)
        m = np.load(imp).astype(np.float32); xvec = (m / np.linalg.norm(m) * np.linalg.norm(xvec)).astype(np.float32)
    if prompt_sec:
        n = int(prompt_sec * 25); prompt_tok = prompt_tok[:, -n:]; pfeat = pfeat[:, -2 * n:, :]
    sp = np.concatenate([prompt_tok, tok], axis=1)
    w = DEC.run(None, {'speech_tokens': sp, 'speaker_embeddings': xvec, 'speaker_features': pfeat})[0]
    return np.squeeze(w, 0)

def tts(text, voice, exag=0.5, seed=0, prompt_sec=None, **k):
    tok, fin = genera_token(text, voice, exag=exag, seed=seed, **k)
    return decodifica(tok, voice, prompt_sec), fin

def genera_token_lotto(testi, voice, exag=0.5, semi=None, lang='it', rp=1.2, temp=0.8, min_p=0.05):
    """Come genera_token, ma più frasi insieme (stesso campione): costa poco più di una sola."""
    EMB, LM = _sess('embed_tokens.onnx'), _sess('language_model_q4.onnx')
    LMI = [i.name for i in LM.get_inputs()]
    B = len(testi); semi = semi or list(range(B))
    rng = [np.random.default_rng(s) for s in semi]
    cond_emb = campione(voice)[0]
    embs = []
    for t in testi:
        t = unicodedata.normalize('NFKD', t.lower())
        ids = np.array([_tok().encode(f'[{lang}]' + t).ids], np.int64)
        pos = np.where(ids >= START, 0, np.arange(ids.shape[1])[None, :] - 1).astype(np.int64)
        e = EMB.run(None, {'input_ids': ids, 'position_ids': pos, 'exaggeration': np.array([exag], np.float32)})[0]
        embs.append(np.concatenate((cond_emb, e), axis=1))
    L = max(e.shape[1] for e in embs)
    x = np.zeros((B, L, embs[0].shape[2]), np.float32); mask = np.zeros((B, L), np.int64)
    for b, e in enumerate(embs):  # riempimento a sinistra
        x[b, L - e.shape[1]:] = e[0]; mask[b, L - e.shape[1]:] = 1
    past = {n: np.zeros([B, 16, 0, 64], np.float32) for n in LMI if n.startswith('past_key_values')}
    max_new = [int(len(t) * 2.4) + 60 for t in testi]
    gen = [[START] for _ in range(B)]; fatto = [False] * B
    e = x
    for i in range(max(max_new)):
        out = LM.run(None, dict(inputs_embeds=e, attention_mask=mask, **past))
        lg = out[0][:, -1, :]
        nts = []
        for b in range(B):
            if fatto[b]: nts.append(STOP); continue
            l = lg[b].copy(); g = np.array(gen[b])
            sc = l[g]; l[g] = np.where(sc < 0, sc * rp, sc / rp)
            z = l / temp; z = z - z.max(); p = np.exp(z); p /= p.sum(); p[p < min_p * p.max()] = 0; p /= p.sum()
            nt = int(rng[b].choice(len(p), p=p)) if temp > 0 else int(np.argmax(l))
            gen[b].append(nt)
            if nt == STOP or len(gen[b]) > max_new[b]: fatto[b] = True
            nts.append(nt)
        if all(fatto): break
        e = EMB.run(None, {'input_ids': np.array(nts, np.int64)[:, None], 'position_ids': np.full((B, 1), i + 1, np.int64),
                           'exaggeration': np.full((B,), exag, np.float32)})[0]
        mask = np.concatenate([mask, np.ones((B, 1), np.int64)], axis=1)
        for k, n in enumerate(past): past[n] = out[1 + k]
    res = []
    for b in range(B):
        g = gen[b][1:]; fin = bool(g and g[-1] == STOP)
        res.append((np.array([g[:-1] if fin else g], np.int64), fin))
    return res
