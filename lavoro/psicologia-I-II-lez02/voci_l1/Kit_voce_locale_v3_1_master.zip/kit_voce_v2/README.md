# Kit voce locale v2 · voce narrante «Telesio» (uso interno)

Genera le voci narranti con il timbro Kore, gratis e senza servizi online. Ogni frase viene trascritta e confrontata con il testo: se non torna, si rigenera da sola. Regolazioni predefinite = «versione 17» approvata da Sara il 7/11/2026 (allegra, calorosa, senza tremolio).

## Installazione (5 righe)
```
unzip Kit_voce_locale_v2.zip -d /home/claude/
cd /home/claude/kit_voce_v2
bash installa.sh          # una volta sola: scarica i modelli (circa 2,6 GB) e prepara il decoder veloce (circa 2-5 minuti)
python3 voce_locale.py prova.wav "Ripassiamo insieme la filatura."
```

## Uso
- Una voce: `python3 voce_locale.py uscita.wav "testo"`
- Tutta la lezione: `python3 voci_locali.py cartella_lezione NOME1 NOME2 …` (senza nomi = tutte)
  - legge `cartella_lezione/voci/testi_voci.json` (`{"NOME": "testo", …}`)
  - scrive `voci/wav/NOME.wav` e `voci/wav/meta_NOME.json`
  - alla fine stampa i tempi e scrive `voci/wav/riepilogo_generazione.json`
- Per più voci usa sempre `voci_locali.py`: il modello si carica una volta sola (circa 30-70 secondi).
- Le frasi già generate e non cambiate si riusano (cartella `voci/.cache_telesio`): se cambi una parola, si rifà solo quella frase.

## Cosa esce
- WAV 24 kHz mono, 16 bit, −16 LUFS, picco ≤ −1 dB, nessun silenzio all'inizio né alla fine.
- `meta_NOME.json`: `durata`, `frasi` (`inizio`, `fine`, `testo`, `parole` con i tempi), `avvisi`, `tempo_di_calcolo_s`, `impostazioni`.
- `avvisi` = frasi da ascoltare: parola trascritta «simile» ma non identica (spesso è la trascrizione che non conosce la parola tecnica).

## Testi
- Numeri in lettere (come già fate).
- `[pausa 0.6]` nel testo = pausa di 0,6 secondi in quel punto.
- Lettere isolate («a S», «a Z») lette col loro nome; sigle senza vocali lettera per lettera.
- Parole o sigle che escono male: aggiungile in `pronunce.json` (scritto → detto). Esempi: `"HACCP": "acca a ci ci pi"`, `"morbida": "mòrbida"` (gli accenti guidano la pronuncia).

## Campioni (cartella campioni/)
- `kore_S4_10s.wav`: timbro (10 s dal campione S4 di Kore).
- `kore_stile_caloroso.wav`: stile/emozione («Grazie per l'attenzione e buono studio!» + «Ascolta ogni parola… prova a ripeterla»).
- `kore_impronta_media.npy`: impronta della voce media su 32 tratti di Kore (timbro più fedele).
- `kore_eq.npy`: correzione del colore misurata sulla Kore vera.

## Regolazioni (variabili d'ambiente; i valori predefiniti sono quelli della versione 17)
`TELESIO_ESAGERAZIONE` 1.0 · `TELESIO_MELODIA` 1.5 (allargamento melodia) · `TELESIO_ALTEZZA` 1.5 (semitoni, allegria) ·
`TELESIO_BRILLANTEZZA` 6.5 (dB di squillo) · `TELESIO_ACCENTI` 1.6 (contrasto sillabe) · `TELESIO_CONSONANTI` 3 (dB, dizione) · `TELESIO_TREMOLIO` 0.5 (quota di tremolio mantenuta: voce giovane e ferma) ·
`TELESIO_TEMPO` 1.0 · `TELESIO_TENTATIVI` 5 · `TELESIO_PROMPT_SEC` 6 · `TELESIO_CAMPIONE`, `TELESIO_STILE` ·
`TELESIO_MODELLI` (/tmp/cbx/), `TELESIO_ASR` (/tmp/asr/…), `TELESIO_THREAD` (processori usati).

## Licenze
Voce: Chatterbox multilingue (Resemble AI, MIT), versione ONNX di onnx-community. Trascrizione: Parakeet TDT 0.6b v3 (NVIDIA, CC-BY-4.0) via sherpa-onnx (Apache 2.0). onnxruntime (MIT), WORLD/pyworld (BSD/MIT), ffmpeg (LGPL).
Il kit è interno: nei materiali per la scuola non vanno nomi di programmi.

## Aggiunte della chat master (7/11 sera)
- `installa.sh` passa da sé dal proxy della macchina: senza questo `pip` può non trovare pypi («Name or service not known»).
- Spazio: servono circa 3 GB liberi (modelli in /tmp/cbx e /tmp/asr). Se manca spazio, cancella solo file intermedi di video già finiti e controllati.
- Se il tuo `voci/testi_voci.json` ha una LISTA di frasi per voce (come negli schemi S con 6 frasi): crea `cartella/voci_gen/voci/testi_voci.json` con le frasi unite da uno spazio, genera con `python3 voci_locali.py cartella/voci_gen`, poi `python3 voci_locale_a_meta.py cartella`. Scrive `voci/wav/NOME.wav` e `voci/wav/meta_locale.json` nel formato del montaggio (dur, phrases = inizio di ogni frase, text, avvisi).
- Lavoro lungo: lancialo in background. Se viene fermato (limite di 2 ore), rilancia lo stesso comando: le frasi già fatte si riusano.
- Misurato sulla Lezione 2 di Tecnologie (34 voci, 13.350 caratteri): vedi il messaggio della master.
